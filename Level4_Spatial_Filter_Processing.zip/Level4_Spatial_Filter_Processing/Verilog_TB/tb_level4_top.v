/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_level4_top (Golden-compare testbench, 8 modes x 2 banks)
 * Goal         : Reconstruct each displayed frame from the SPI stream and
 *                compare it, pixel-exact, against a Python-generated golden.
 *
 * Golden path  : golden_m*_b*.mem live in  Golden_Data/  (see `GDIR below).
 *                >>> Use forward slashes '/', NOT backslashes '\' <
 *                (color.mem is read by oled_combined_rom, not here.)
 *
 * sw mapping: sw[0]=bank, sw[3:1]=mode  ->  sw = (mode<<1)|bank
 * ====================================================================== */
`timescale 1ns / 1ps

// Edit ONLY this line if the golden folder moves (keep the trailing slash):
`define GDIR "D:/SEMICONDUCTOR_LABS/Level4_Lab/Level4_Spatial_Filter_Processing/Golden_Data/"

module tb_level4_top;
    localparam H = 96, V = 64, TOTAL = H*V;   // 6144

    reg CLK100MHZ = 1'b0;
    reg btn0 = 1'b1, btn1 = 1'b0;
    reg [3:0] sw = 4'b0000;

    wire oled_mosi, oled_sck, oled_cs_n, oled_dc, oled_res, oled_vccen, oled_pmoden;

    top_arty_s7_oled #(.POWER_WAIT(24'd50), .RESET_WAIT(24'd20)) dut (
        .CLK100MHZ(CLK100MHZ), .btn0(btn0), .btn1(btn1), .sw(sw),
        .oled_mosi(oled_mosi), .oled_sck(oled_sck), .oled_cs_n(oled_cs_n),
        .oled_dc(oled_dc), .oled_res(oled_res),
        .oled_vccen(oled_vccen), .oled_pmoden(oled_pmoden)
    );

    always #5 CLK100MHZ = ~CLK100MHZ;   // 100 MHz

    // ---- golden storage : 16 frames (mode*2+bank) ----
    reg [15:0] golden [0:16*TOTAL-1];
    initial begin
        $readmemh({`GDIR,"golden_m0_b0.mem"}, golden, 0*TOTAL, 1*TOTAL-1);
        $readmemh({`GDIR,"golden_m0_b1.mem"}, golden, 1*TOTAL, 2*TOTAL-1);
        $readmemh({`GDIR,"golden_m1_b0.mem"}, golden, 2*TOTAL, 3*TOTAL-1);
        $readmemh({`GDIR,"golden_m1_b1.mem"}, golden, 3*TOTAL, 4*TOTAL-1);
        $readmemh({`GDIR,"golden_m2_b0.mem"}, golden, 4*TOTAL, 5*TOTAL-1);
        $readmemh({`GDIR,"golden_m2_b1.mem"}, golden, 5*TOTAL, 6*TOTAL-1);
        $readmemh({`GDIR,"golden_m3_b0.mem"}, golden, 6*TOTAL, 7*TOTAL-1);
        $readmemh({`GDIR,"golden_m3_b1.mem"}, golden, 7*TOTAL, 8*TOTAL-1);
        $readmemh({`GDIR,"golden_m4_b0.mem"}, golden, 8*TOTAL, 9*TOTAL-1);
        $readmemh({`GDIR,"golden_m4_b1.mem"}, golden, 9*TOTAL, 10*TOTAL-1);
        $readmemh({`GDIR,"golden_m5_b0.mem"}, golden,10*TOTAL,11*TOTAL-1);
        $readmemh({`GDIR,"golden_m5_b1.mem"}, golden,11*TOTAL,12*TOTAL-1);
        $readmemh({`GDIR,"golden_m6_b0.mem"}, golden,12*TOTAL,13*TOTAL-1);
        $readmemh({`GDIR,"golden_m6_b1.mem"}, golden,13*TOTAL,14*TOTAL-1);
        $readmemh({`GDIR,"golden_m7_b0.mem"}, golden,14*TOTAL,15*TOTAL-1);
        $readmemh({`GDIR,"golden_m7_b1.mem"}, golden,15*TOTAL,16*TOTAL-1);
    end

    // ---- SPI monitor : reconstruct frames from MOSI (Mode 3, MSB first) ----
    integer bitc = 0;
    reg [7:0] sh = 8'd0;
    integer fpix = 0;                 // data-pixel index within current frame
    integer half = 0;                 // 0=HI byte, 1=LO byte
    reg [15:0] cur_pixel = 16'd0;
    reg [15:0] frame_buf [0:TOTAL-1];
    integer frame_num = 0;
    reg      frame_done = 1'b0;

    always @(posedge oled_sck) begin
        frame_done <= 1'b0;
        if (!oled_cs_n) begin
            sh = {sh[6:0], oled_mosi};
            bitc = bitc + 1;
            if (bitc == 8) begin
                bitc = 0;
                if (oled_dc == 1'b1) begin           // pixel data byte
                    if (half == 0) begin
                        cur_pixel[15:8] = sh; half = 1;
                    end else begin
                        cur_pixel[7:0] = sh; half = 0;
                        frame_buf[fpix] = cur_pixel;
                        if (fpix == TOTAL-1) begin
                            fpix = 0; frame_num = frame_num + 1; frame_done <= 1'b1;
                        end else begin
                            fpix = fpix + 1;
                        end
                    end
                end
            end
        end
    end

    // ---- sweep + compare ----
    integer mode, bank, gi, i, snap, mism, firsti;
    integer total_fail = 0;
    initial begin
        btn0 = 1'b1; sw = 4'b0000; repeat (10) @(posedge CLK100MHZ);
        btn0 = 1'b0;

        for (mode = 0; mode < 8; mode = mode + 1) begin
            for (bank = 0; bank < 2; bank = bank + 1) begin
                sw   = (mode << 1) | bank;      // sw[3:1]=mode, sw[0]=bank
                snap = frame_num;
                // discard one (possibly mixed) frame, capture the next clean one
                wait (frame_num == snap + 2);
                #1;
                gi   = (mode*2 + bank) * TOTAL;
                mism = 0; firsti = -1;
                for (i = 0; i < TOTAL; i = i + 1) begin
                    if (frame_buf[i] !== golden[gi + i]) begin
                        mism = mism + 1;
                        if (firsti < 0) firsti = i;
                    end
                end
                if (mism == 0)
                    $display("[TB] PASS  mode=%0d bank=%0d  (all %0d px match)", mode, bank, TOTAL);
                else begin
                    total_fail = total_fail + 1;
                    $display("[TB] FAIL  mode=%0d bank=%0d  mismatches=%0d  first@(x=%0d,y=%0d) got=%04h exp=%04h",
                             mode, bank, mism, firsti % H, firsti / H,
                             frame_buf[firsti], golden[gi + firsti]);
                end
            end
        end

        $display("[TB] ================= SUMMARY =================");
        if (total_fail == 0) $display("[TB] ALL 16 CASES PASS (8 modes x 2 banks)");
        else                 $display("[TB] %0d / 16 CASES FAILED", total_fail);
        $finish;
    end

    initial begin
        #4000000000;
        $display("[TB] TIMEOUT");
        $finish;
    end
endmodule