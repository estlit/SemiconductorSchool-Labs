# Level 4 — Real-Time Spatial Image Filtering on FPGA

**Semiconductor School · EdgeChipLab**
Streaming 3×3 spatial-filter pipeline on the **Digilent Arty S7-25** driving a **Pmod OLEDrgb (SSD1331, 96×64 RGB565)** — no frame buffer, fully streaming, with a line-buffer-based convolution core.

This is Level 4 of the FPGA course, extending Level 3's per-pixel (point) operations to **3×3 neighborhood (windowed) operations**, building the groundwork up to Sobel edge detection.

\---

## What it does

An image stored in on-chip ROM is streamed pixel-by-pixel through a spatial-filter pipeline and displayed on the OLED in real time. A slide switch selects one of **8 filter modes**; another switch selects one of **2 source images**.

**Pipeline**

```
ROM (2-bank, RGB565) -> rgb565\_to\_gray (Y8) -> line\_buffer (3x3 window)
   -> conv\_proc\_core (8 modes) -> saturate -> border(valid-only=0) -> gray\_to\_rgb565
   -> spi\_master -> SSD1331
```

* 100 MHz system clock ÷16 → 6.25 MHz SPI (Mode 3)
* No frame buffer; the ROM read pointer **leads** the OLED write pointer by `LEAD = H\_RES + 1 = 97` (line-buffer center latency), primed before display.
* `valid-only` border handling: the outer 1-pixel edge is output as black (0x0000).

\---

## Controls

|Input|Function|
|-|-|
|`SW0`|Source image select (Image 1 / Image 2)|
|`SW\[3:1]`|Filter mode (see table below)|
|`BTN0`|Reset (active-high)|
|`BTN1`|Reserved (unused in Level 4)|

### Filter modes (`SW\[3:1]`)

|SW\[3:1]|Mode|Operation|
|-|-|-|
|000|Grayscale|center passthrough (Y8)|
|001|Box Blur|(Σ9 × 29) >> 8 (≈ /9)|
|010|Gaussian|(1 2 1 / 2 4 2 / 1 2 1) >> 4 (/16)|
|011|Sharpen|9·center − Σ(8 neighbors), clamped|
|100|Sobel X|\|Gx\|, clamp 255|
|101|Sobel Y|\|Gy\|, clamp 255|
|110|Magnitude|\|Gx\| + \|Gy\|, clamp 255|
|111|Threshold Edge|(\|Gx\|+\|Gy\| sat8) > 64 ? 255 : 0|

> \*\*Note on grayscale:\*\* all filters operate on 8-bit luma (Y). Edge operators (Sobel) are inherently luma-based, and a single channel keeps the line buffer and datapath small on the Arty S7-25. \*\*Color (3-channel) filtering is planned as a future extension\*\* — it reuses the same structure with 3× the line-buffer/MAC resources.

\---

## Repository structure

```
Level4\_Spatial\_Filter\_Processing/
├── Verilog\_RTL/
│   ├── top\_arty\_s7\_oled.v      # top level
│   ├── oled\_test.v             # SSD1331 FSM + fetch/prime/latch + pipeline
│   ├── rgb565\_to\_gray.v        # RGB565 -> Y8
│   ├── line\_buffer\_module.v    # 2-line shift register, 3x3 window
│   ├── conv\_proc\_core.v        # 8-mode 3x3 kernels + saturation
│   ├── spi\_master.v            # SPI Mode 3
│   └── oled\_combined\_rom.v     # 2-bank image ROM (reads color.mem)
├── Verilog\_TB/
│   └── tb\_level4\_top.v         # golden-compare testbench (8 modes × 2 banks)
├── Vivado\_xdc/
│   └── arty\_s7\_25\_pmod\_oled.xdc
├── Golden\_Data/
│   ├── color.mem               # ROM image data (2 images, RGB565)
│   ├── golden\_m{0..7}\_b{0,1}.mem  # 16 golden frames for the testbench
│   └── color{1,2}\_\*.jpg        # textbook reference renders
├── Python\_Source/
│   ├── gen\_golden.py           # color.mem -> 16 golden .mem (bit-exact vs RTL)
│   └── verify\_hw\_spatial\_filter.py  # color.mem -> textbook mode images
└── Level4\_ImageProc\_RTL\_Spec\_v0.3.md   # design specification
```

\---

## Build (Vivado)

1. Create a project targeting **xc7s25csga324-1** (Arty S7-25).
2. Add all files in `Verilog\_RTL/` as design sources (top = `top\_arty\_s7\_oled`).
3. Add `Vivado\_xdc/arty\_s7\_25\_pmod\_oled.xdc` as the constraints file.
4. **Place `Golden\_Data/color.mem` where synthesis can find it.** `oled\_combined\_rom.v` loads it with a relative `$readmemh("color.mem", ...)`, so either copy `color.mem` next to the project run directory or add it to the project sources. (Using an absolute path in `oled\_combined\_rom.v` is the most reliable option in Vivado.)
5. Generate bitstream and program the board.

\---

## Simulation (golden-compare testbench)

`tb\_level4\_top.v` reconstructs each displayed frame from the SPI stream and compares it **pixel-exact** against the Python-generated golden files. It sweeps all 8 modes × 2 banks and prints `PASS/FAIL` per case, ending with `ALL 16 CASES PASS`.

### ⚠️ Before you simulate — set the golden path

`tb\_level4\_top.v` locates the golden files through a path macro near the top of the file:

```verilog
`define GDIR "D:/SEMICONDUCTOR\_LABS/Level4\_Lab/Level4\_Spatial\_Filter\_Processing/Golden\_Data/"
```

**This is a machine-specific absolute path.** Edit this **one line** to match where `Golden\_Data/` lives on your system, keeping the trailing slash and using forward slashes `/` (not `\\`):

```verilog
`define GDIR "<your-path>/Level4\_Spatial\_Filter\_Processing/Golden\_Data/"
```

Alternatively, make it portable: remove `GDIR`, change each `$readmemh` to a bare filename (e.g. `$readmemh("golden\_m0\_b0.mem", ...)`), and add the 16 `golden\_\*.mem` files to your simulation fileset (the same way `color.mem` is handled).

Also ensure `Golden\_Data/color.mem` is on the simulation search path — it is read by `oled\_combined\_rom` via a relative `$readmemh("color.mem", ...)`.

### Run

Vivado xsim: add the RTL + `tb\_level4\_top.v`, set `tb\_level4\_top` as the simulation top, and launch. (The testbench shrinks the power-on/reset waits via top parameters for fast start; a full 16-case sweep takes \~1–2 s of simulated time.)

Icarus Verilog:

```bash
cd Verilog\_TB
iverilog -g2012 -o sim ../Verilog\_RTL/\*.v tb\_level4\_top.v \&\& vvp sim
```

\---

## Regenerating data

* **Golden files** — `python Python\_Source/gen\_golden.py` (run from a directory containing `color.mem`). Produces the 16 `golden\_m\*\_b\*.mem` using the exact integer math of the RTL.
* **Textbook images** — `python Python\_Source/verify\_hw\_spatial\_filter.py` (reads `color.mem`). Produces `color{1,2}\_mode0..7.jpg`, a 2×4 grid, and a Box-vs-Gaussian difference panel. Output is bit-true to the OLED (96×64 processing, integer-upscaled for visibility).

The golden generator and the RTL use identical integer arithmetic; correctness has been checked bit-exact (e.g., `golden\_m1\_b0` center pixel = `0x6B4D`, matching the on-board result), and all 16 testbench cases pass.

\---

## Credits

**Roger Kim** · EdgeChipLab / Semiconductor School

* Book: *AI NPU System Design with Python and Verilog* — https://www.amazon.com/dp/B0GMPSND15
* YouTube: **@EdgeChipLab**

© 2026 Roger Kim \& EdgeChipLab. All rights reserved.

