/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_arty_s7_oled (Level 4 - windowed image processing)
 * Architecture : ROM(raw RGB565) -> [inside oled_test: gray -> line buffer
 *                -> conv 3x3 -> border -> rgb565] -> SPI -> SSD1331
 * Change vs L3 : pixel_proc_core (point op) REMOVED. Processing now lives
 *                inside oled_test (windowed). sw[3:1] routed as 'mode'.
 *   sw[0]   : ROM Bank Select (Image 1 / 2)
 *   sw[3:1] : Filter Mode (skeleton: 000 gray / 001 box blur / 100 sobelX)
 *   btn0    : Reset       btn1 : reserved (unused in Level 4)
 * ====================================================================== */
`timescale 1ns / 1ps

module top_arty_s7_oled #(
    parameter POWER_WAIT = 24'd2000000,  // shrink in simulation via TB
    parameter RESET_WAIT = 24'd500000
)(
    input  wire       CLK100MHZ,
    input  wire       btn0,        // Active-high Reset
    input  wire       btn1,        // reserved (unused)
    input  wire [3:0] sw,          // sw[0]=image, sw[3:1]=mode

    output wire       oled_mosi,
    output wire       oled_sck,
    output wire       oled_cs_n,
    output wire       oled_dc,
    output wire       oled_res,
    output wire       oled_vccen,
    output wire       oled_pmoden
);
    wire reset = btn0;

    // 100 MHz -> 6.25 MHz
    reg [3:0] div_cnt = 4'd0;
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    wire spi_clk = div_cnt[3];

    wire        spi_start, spi_busy;
    wire [7:0]  spi_data;
    wire [12:0] oled_pix_addr;
    wire [15:0] rom_data_raw;   // RAW RGB565 (no more point-op filtering here)

    spi_master u_spi (
        .clk(spi_clk), .reset(reset), .start(spi_start), .data_in(spi_data),
        .busy(spi_busy), .sclk(oled_sck), .mosi(oled_mosi), .cs_n(oled_cs_n)
    );

    oled_combined_rom u_rom (
        .clk(spi_clk), .addr({sw[0], oled_pix_addr}), .data(rom_data_raw)
    );

    // Windowed OLED controller (owns the whole processing pipeline)
    oled_test #(.H_RES(96), .V_RES(64),
                .POWER_WAIT(POWER_WAIT), .RESET_WAIT(RESET_WAIT)) u_oled (
        .clk(spi_clk), .reset(reset),
        .spi_start(spi_start), .spi_data(spi_data), .spi_busy(spi_busy),
        .oled_dc(oled_dc), .oled_res(oled_res),
        .oled_vccen(oled_vccen), .oled_pmoden(oled_pmoden),
        .rom_addr(oled_pix_addr), .rom_data(rom_data_raw),
        .mode(sw[3:1])
    );
    // btn1 reserved for Level 4
    wire _unused = btn1;
endmodule
