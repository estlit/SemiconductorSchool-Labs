"""
======================================================================
 Level 4  교재 출력용 시각 자료 생성기 (Spatial Filtering, 8 modes)
----------------------------------------------------------------------
 - 입력 : color.mem  (Level 3 ROM, 16384 x RGB565)  ← OLED가 실제로 읽는 그 데이터
          bank0 -> 'color1',  bank1 -> 'color2'  로 매핑
 - 처리 : conv_proc_core.v / gen_golden.py 와 100% 동일한 정수식
          (RGB565->Y8 그레이,  3x3 커널,  valid-only 테두리=0,  Y8->RGB565)
 - 출력 : {base}_mode{i}.jpg (8개) + {base}_grid_composite.jpg   (Level 3 과 동일 파일명 규칙)
 - 특징 : 96x64 로 처리(=OLED 픽셀과 비트 일치) 후 교재 가시성을 위해
          정수배(UPSCALE) 최근접(NEAREST) 확대. 확대는 픽셀을 바꾸지 않음.

 * jpg 에서 다시 만들지 않고 color.mem 을 읽는 이유: Pillow/OpenCV 리사이즈
   차이로 인한 1~2 LSB 오차를 없애 OLED 화면과 완전히 동일하게 하기 위함.
======================================================================
"""
import cv2
import numpy as np
import os

# ============================================================================
# 파라미터
# ============================================================================
MEM_FILE = "color.mem"      # Level 3 ROM (같은 폴더 또는 경로 지정)
W, H     = 96, 64
BANKS    = {0: "color1", 1: "color2"}   # bank -> 출력 base name
UPSCALE  = 6                # 96x64 -> 576x384 (교재 가시성, 픽셀 불변)
THRESH   = 64               # mode 7 임계에지 (conv_proc_core.THRESH 와 동일)
GEN_DIFF_PANEL = True       # 박스 vs 가우시안 차이 비교 이미지 추가 출력(교재용)
DIFF_GAIN      = 8          # 차이 증폭 배율 (필터/골든/OLED 는 불변, 시각화만)

mode_names = [
    "0. Grayscale", "1. Box Blur", "2. Gaussian", "3. Sharpen",
    "4. Sobel X",   "5. Sobel Y",  "6. Magnitude", "7. Threshold Edge"
]

# ============================================================================
# 유틸
# ============================================================================
def add_label(img, text):
    """이미지 하단에 교재용 흰색 레이블 배너를 추가합니다."""
    h, w = img.shape[:2]
    banner = np.ones((40, w, 3), dtype=np.uint8) * 255
    text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
    text_x = (w - text_size[0]) // 2
    cv2.putText(banner, text, (text_x, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
    return cv2.vconcat([img, banner])

def to_bgr8(r5, g6, b5):
    """5-6-5 -> 8-8-8 BGR (하위 비트 0채움, Level 3 to_bgr8 과 동일 표시 규약)."""
    r8 = (r5.astype(np.uint16) << 3).astype(np.uint8)
    g8 = (g6.astype(np.uint16) << 2).astype(np.uint8)
    b8 = (b5.astype(np.uint16) << 3).astype(np.uint8)
    return cv2.merge([b8, g8, r8])

def load_mem(path):
    vals = []
    with open(path) as f:
        for ln in f:
            ln = ln.strip()
            if ln:
                vals.append(int(ln, 16))
    vals += [0] * (16384 - len(vals))
    return np.array(vals[:16384], dtype=np.int32)

# ============================================================================
# 하드웨어와 동일한 정수 연산
# ============================================================================
def bank_gray(mem, bank):
    """color.mem 한 뱅크 -> 96x64 Y8 (RTL rgb565_to_gray 와 동일)."""
    idx = bank * 8192 + np.arange(H * W)
    px  = mem[idx].reshape(H, W)
    r5 = (px >> 11) & 0x1F
    g6 = (px >> 5)  & 0x3F
    b5 =  px        & 0x1F
    r8 = (r5 << 3) | (r5 >> 2)
    g8 = (g6 << 2) | (g6 >> 4)
    b8 = (b5 << 3) | (b5 >> 2)
    return ((r8 + (g8 << 1) + b8) >> 2).astype(np.int32)   # Y=(R+2G+B)>>2

def process_all_modes(gray):
    """gray(HxW,int) -> {mode: out8(HxW,int)}  valid-only 테두리=0."""
    g = gray
    sh = lambda dy, dx: np.roll(np.roll(g, dy, 0), dx, 1)   # roll 경계는 이후 0으로 마스킹
    s9    = sum(sh(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
    gx    = (sh(-1, 1) + 2*sh(0, 1) + sh(1, 1)) - (sh(-1, -1) + 2*sh(0, -1) + sh(1, -1))
    gy    = (sh(1, -1) + 2*sh(1, 0) + sh(1, 1)) - (sh(-1, -1) + 2*sh(-1, 0) + sh(-1, 1))
    gauss = (sh(-1,-1) + 2*sh(-1,0) + sh(-1,1)
             + 2*sh(0,-1) + 4*g + 2*sh(0,1)
             + sh(1,-1) + 2*sh(1,0) + sh(1,1))
    ax, ay = np.abs(gx), np.abs(gy)
    c = lambda a: np.clip(a, 0, 255)

    outs = {
        0: g.copy(),
        1: c((s9 * 29) >> 8),
        2: c(gauss >> 4),
        3: c(9*g - (s9 - g)),
        4: c(ax),
        5: c(ay),
        6: c(ax + ay),
        7: np.where(c(ax + ay) > THRESH, 255, 0),
    }
    for m in outs:                       # valid-only : 1px 테두리 = 0
        o = outs[m].astype(np.int32)
        o[0, :] = 0; o[-1, :] = 0; o[:, 0] = 0; o[:, -1] = 0
        outs[m] = o
    return outs

def out8_to_img(out8):
    """out8(Y8) -> RGB565 재양자화 -> BGR8 (OLED가 보여주는 그대로) -> 정수배 확대."""
    y  = out8.astype(np.int32)
    r5 = (y >> 3).astype(np.uint8)       # {Y[7:3], Y[7:2], Y[7:3]}
    g6 = (y >> 2).astype(np.uint8)
    b5 = (y >> 3).astype(np.uint8)
    bgr = to_bgr8(r5, g6, b5)
    return cv2.resize(bgr, (W*UPSCALE, H*UPSCALE), interpolation=cv2.INTER_NEAREST)

def diff_panel(outs, gain):
    """[교재용] 박스 | 가우시안 | 차이x{gain} 3분할 비교. 필터 자체는 불변, 차이만 증폭 시각화."""
    box = out8_to_img(outs[1])
    gau = out8_to_img(outs[2])
    d   = np.clip(np.abs(outs[2].astype(np.int32) - outs[1].astype(np.int32)) * gain, 0, 255).astype(np.uint8)
    d[0, :] = 0; d[-1, :] = 0; d[:, 0] = 0; d[:, -1] = 0     # 테두리(무효영역) 제외
    dimg = cv2.resize(cv2.merge([d, d, d]), (W*UPSCALE, H*UPSCALE), interpolation=cv2.INTER_NEAREST)
    return cv2.hconcat([add_label(box, "Box Blur"),
                        add_label(gau, "Gaussian"),
                        add_label(dimg, f"Diff x{gain} (edges)")])

# ============================================================================
# 실행
# ============================================================================
def main():
    if not os.path.exists(MEM_FILE):
        print(f"[Error] '{MEM_FILE}' 를 찾을 수 없습니다. Level 3 ROM(color.mem)을 같은 폴더에 두세요.")
        return
    mem = load_mem(MEM_FILE)

    for bank, base in BANKS.items():
        print(f"[bank {bank} -> {base}] 8모드 이미지 생성...")
        gray = bank_gray(mem, bank)
        outs = process_all_modes(gray)

        labeled = []
        for i in range(8):
            img = out8_to_img(outs[i])
            cv2.imwrite(f"{base}_mode{i}.jpg", img)          # 개별 파일 (교재 단독 삽입용)
            labeled.append(add_label(img, mode_names[i]))    # 그리드용 레이블

        row1 = cv2.hconcat(labeled[:4])
        row2 = cv2.hconcat(labeled[4:])
        grid = cv2.vconcat([row1, row2])
        cv2.imwrite(f"{base}_grid_composite.jpg", grid)
        print(f" -> '{base}_grid_composite.jpg' 생성 완료 (개별 8개 포함)")

        if GEN_DIFF_PANEL:
            cv2.imwrite(f"{base}_diff_box_gauss.jpg", diff_panel(outs, DIFF_GAIN))
            print(f" -> '{base}_diff_box_gauss.jpg' (박스 vs 가우시안 차이 x{DIFF_GAIN})")
        print()

    print("Level 4 교재용 시각 자료 추출 완료!")

if __name__ == "__main__":
    main()