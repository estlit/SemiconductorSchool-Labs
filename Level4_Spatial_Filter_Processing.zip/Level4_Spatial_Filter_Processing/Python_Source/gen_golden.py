# ======================================================================
#  gen_golden.py  -  Level 4 golden generator (bit-exact with RTL)
#  Reads  ./color.mem  (Level 3 ROM, 16384 x RGB565)
#  Writes ./golden_m{0..7}_b{0,1}.mem  (16 files, 6144 x RGB565)
#  Integer math is IDENTICAL to conv_proc_core.v / oled_test.v.
#  Run from the Verilog_TB directory (where color.mem lives).
# ======================================================================
W,H = 96,64; TOTAL=W*H; THRESH=64
def clamp(v): return 0 if v<0 else (255 if v>255 else int(v))

mem=[]
for ln in open("color.mem"):
    ln=ln.strip()
    if ln: mem.append(int(ln,16))
mem += [0]*(16384-len(mem))

def gray_of(px):
    r5=(px>>11)&0x1F; g6=(px>>5)&0x3F; b5=px&0x1F
    r8=(r5<<3)|(r5>>2); g8=(g6<<2)|(g6>>4); b8=(b5<<3)|(b5>>2)
    return (r8+2*g8+b8)>>2          # Y=(R+2G+B)>>2

def to565(y): return ((y>>3)<<11)|((y>>2)<<5)|(y>>3)

def kernel(mode,win):               # win = 3x3, win[1][1]=center
    (w00,w01,w02),(w10,w11,w12),(w20,w21,w22)=win
    s9=w00+w01+w02+w10+w11+w12+w20+w21+w22
    gx=(w02+2*w12+w22)-(w00+2*w10+w20)
    gy=(w20+2*w21+w22)-(w00+2*w01+w02)
    ax,ay=abs(gx),abs(gy)
    if   mode==0: return w11
    elif mode==1: return clamp((s9*29)>>8)
    elif mode==2: return clamp((w00+2*w01+w02+2*w10+4*w11+2*w12+w20+2*w21+w22)>>4)
    elif mode==3: return clamp(9*w11-(s9-w11))
    elif mode==4: return clamp(ax)
    elif mode==5: return clamp(ay)
    elif mode==6: return clamp(ax+ay)
    else:         return 255 if clamp(ax+ay)>THRESH else 0

for bank in (0,1):
    g=[[gray_of(mem[bank*8192 + y*W + x]) for x in range(W)] for y in range(H)]
    for mode in range(8):
        with open(f"golden_m{mode}_b{bank}.mem","w") as f:
            for y in range(H):
                for x in range(W):
                    if 1<=x<=W-2 and 1<=y<=H-2:
                        win=((g[y-1][x-1],g[y-1][x],g[y-1][x+1]),
                             (g[y  ][x-1],g[y  ][x],g[y  ][x+1]),
                             (g[y+1][x-1],g[y+1][x],g[y+1][x+1]))
                        f.write(f"{to565(kernel(mode,win)):04X}\n")
                    else:
                        f.write("0000\n")   # valid-only border = black
print("generated 16 golden_m*_b*.mem")
