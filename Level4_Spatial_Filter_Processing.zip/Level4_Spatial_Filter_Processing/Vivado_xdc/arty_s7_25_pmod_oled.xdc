## Arty S7-25 + Pmod OLEDrgb (J1 on JA) constraints

## 100 MHz clock input (R2)
set_property PACKAGE_PIN R2 [get_ports { CLK100MHZ }]
set_property IOSTANDARD LVCMOS33 [get_ports { CLK100MHZ }]
create_clock -add -name sys_clk_pin -period 10.000 -waveform {0 5} [get_ports { CLK100MHZ }]

## BTN0 -> btn0 (active-high)
set_property PACKAGE_PIN G15 [get_ports { btn0 }]
set_property IOSTANDARD LVCMOS33 [get_ports { btn0 }]
## BTN1 -> btn1 (active-high)
set_property PACKAGE_PIN K16 [get_ports { btn1 }]
set_property IOSTANDARD LVCMOS33 [get_ports { btn1 }]

## Switches
# SW0 -> sw[0] (H14) : Image Select
set_property PACKAGE_PIN H14 [get_ports { sw[0] }]
set_property IOSTANDARD LVCMOS33 [get_ports { sw[0] }]

# SW1 -> sw[1] (H18) : Filter Mode Bit 0
set_property PACKAGE_PIN H18 [get_ports { sw[1] }]
set_property IOSTANDARD LVCMOS33 [get_ports { sw[1] }]

# SW2 -> sw[2] (G18) : Filter Mode Bit 1
set_property PACKAGE_PIN G18 [get_ports { sw[2] }]
set_property IOSTANDARD LVCMOS33 [get_ports { sw[2] }]

# SW3 -> sw[3] (M5)  : Filter Mode Bit 2
set_property PACKAGE_PIN M5 [get_ports { sw[3] }]
set_property IOSTANDARD LVCMOS33 [get_ports { sw[3] }]

## Pmod JA connections for Pmod OLEDrgb J1

# JA1 -> L17 : CS
set_property PACKAGE_PIN L17 [get_ports { oled_cs_n }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_cs_n }]

# JA2 -> L18 : MOSI
set_property PACKAGE_PIN L18 [get_ports { oled_mosi }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_mosi }]

# JA4 -> N14 : SCK
set_property PACKAGE_PIN N14 [get_ports { oled_sck }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_sck }]

# JA7 -> M16 : D/C
set_property PACKAGE_PIN M16 [get_ports { oled_dc }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_dc }]

# JA8 -> M17 : RES
set_property PACKAGE_PIN M17 [get_ports { oled_res }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_res }]

# JA9 -> M18 : VCCEN
set_property PACKAGE_PIN M18 [get_ports { oled_vccen }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_vccen }]

# JA10 -> N18 : PMODEN
set_property PACKAGE_PIN N18 [get_ports { oled_pmoden }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_pmoden }]
