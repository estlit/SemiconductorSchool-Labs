// =========================================================================
// Module Name:    frame_buffer_dpram
// Description:    True Dual-Port Block RAM (BRAM) synchronous frame buffer.
//                 Acts as a clean structural bridge across disjoint hardware 
//                 clock domains to prevent metastability issues.
// =========================================================================

module frame_buffer_dpram (
    // Write Interface Configuration (Camera Pipeline Clock Space)
    input  wire        wr_clk,   // Fast capture strobe (connected directly to cam_pclk)
    input  wire        wr_en,    // Synchronous memory write enable gating pulse
    input  wire [12:0] wr_addr,  // 13-bit linear destination address (0 to 6143)
    input  wire [15:0] wr_data,  // 16-bit active camera input pixel byte payload

    // Read Interface Configuration (Display Pipeline Clock Space)
    input  wire        rd_clk,   // System display engine clock (connected directly to spi_clk)
    input  wire [12:0] rd_addr,  // 13-bit sequential reading memory array address
    output reg  [15:0] rd_data   // Registered 16-bit output data (Enforces 1-cycle latency)
);

    // Allocate physical core memory space: 96 x 64 = 6144 blocks of 16-bit width word structures
    reg [15:0] ram_block [0:6143];

    // Synchronous Memory Write Routing Logic Block
    always @(posedge wr_clk) begin
        if (wr_en) begin
            ram_block[wr_addr] <= wr_data;
        end
    end

    // Synchronous Memory Read Routing Logic Block
    // Introduces a rigid 1-clock cycle execution latency optimized for BRAM hardware routing 
    always @(posedge rd_clk) begin
        rd_data <= ram_block[rd_addr];
    end

endmodule