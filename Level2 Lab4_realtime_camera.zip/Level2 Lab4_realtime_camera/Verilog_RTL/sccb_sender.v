`timescale 1ns / 1ps

module sccb_sender (
    input  wire       clk,       // 25MHz clock
    input  wire       rst,       // active-high reset
    inout  wire       sio_d,
    output reg        sio_c,
    input  wire       reg_ok,    // register data is valid
    output reg        sccb_ok = 1'b0,
    input  wire [7:0] slave_id,
    input  wire [7:0] reg_addr,
    input  wire [7:0] value
);

    reg [20:0] count = 21'd0;

    always @(posedge clk) begin
        if (rst) begin
            count <= 21'd0;
        end else begin
            if (count == 21'd0)
                count <= reg_ok;        // wait until reg_ok is active
            else if (count[20:11] == 10'd31)
                count <= 21'd0;         // one SCCB write transaction done
            else
                count <= count + 1'b1;
        end
    end

    always @(posedge clk) begin
        if (rst)
            sccb_ok <= 1'b0;
        else
            sccb_ok <= (count == 21'd0) && (reg_ok == 1'b1);
    end

    // SIO_C generation, reference-style timing
    always @(posedge clk) begin
        if (rst) begin
            sio_c <= 1'b1;
        end else begin
            if (count[20:11] == 10'd0) begin
                sio_c <= 1'b1;
            end
            else if (count[20:11] == 10'd1) begin
                if (count[10:9] == 2'b11)
                    sio_c <= 1'b0;
                else
                    sio_c <= 1'b1;
            end
            else if (count[20:11] == 10'd29) begin
                if (count[10:9] == 2'b00)
                    sio_c <= 1'b0;
                else
                    sio_c <= 1'b1;
            end
            else if ((count[20:11] == 10'd30) || (count[20:11] == 10'd31)) begin
                sio_c <= 1'b1;
            end
            else begin
                case (count[10:9])
                    2'b00: sio_c <= 1'b0;
                    2'b01: sio_c <= 1'b1;
                    2'b10: sio_c <= 1'b1;
                    2'b11: sio_c <= 1'b0;
                    default: sio_c <= 1'b1;
                endcase
            end
        end
    end

    reg sio_d_send = 1'b1;

    always @(posedge clk) begin
        if (rst) begin
            sio_d_send <= 1'b1;
        end else begin
            if ((count[20:11] == 10'd10) ||
                (count[20:11] == 10'd19) ||
                (count[20:11] == 10'd28))
                sio_d_send <= 1'b0;     // ACK time: release SDA
            else
                sio_d_send <= 1'b1;     // drive data_temp[31]
        end
    end

    reg [31:0] data_temp = 32'hFFFF_FFFF;

    always @(posedge clk) begin
        if (rst) begin
            data_temp <= 32'hFFFF_FFFF;
        end else begin
            if ((count == 21'd0) && (reg_ok == 1'b1)) begin
                // START + slave_id + ACK slot + reg_addr + ACK slot + value + ACK slot + STOP
                data_temp <= {2'b10, slave_id, 1'b1, reg_addr, 1'b1, value, 1'b1, 3'b011};
            end
            else if (count[10:0] == 11'd0) begin
                data_temp <= {data_temp[30:0], 1'b1};
            end
        end
    end

    // Open-drain style SDA:
    // - During ACK time, release SDA.
    // - During data time, drive 0 for bit=0, release for bit=1.
    assign sio_d = (sio_d_send == 1'b0) ? 1'bz :
                   (data_temp[31] == 1'b0) ? 1'b0 : 1'bz;

endmodule
