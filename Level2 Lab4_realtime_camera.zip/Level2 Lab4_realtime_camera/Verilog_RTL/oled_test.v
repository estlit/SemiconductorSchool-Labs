/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_test (OLED Display Controller FSM)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : SSD1331 SPI Display Driver Controller
 * Description  : Controls the Pmod OLEDrgb (SSD1331, 96x64) display.
 * Includes a fixed hardware orientation to match the physical label.
 * Upgraded with a 'Continuous Frame Refresh' feature to continuously 
 * stream real-time updates from the frame buffer (BRAM).
 * ====================================================================== */

`timescale 1ns / 1ps

module oled_test #(
    parameter H_RES = 96,
    parameter V_RES = 64
)(
    input  wire        clk,         // Operating clock (e.g., 6.25 MHz SPI Clock)
    input  wire        reset,       // Active-high synchronous reset

    // SPI Master Control Interface
    output reg         spi_start,   // Pulse to trigger SPI transmission
    output reg  [7:0]  spi_data,    // 8-bit data to send via SPI
    input  wire        spi_busy,    // High when SPI is transmitting

    // OLED Hardware Control Pins
    output reg         oled_dc,     // Data/Command control (0: Command, 1: Data)
    output reg         oled_res,    // OLED Reset (Active Low)
    output reg         oled_vccen,  // VCC Enable
    output reg         oled_pmoden, // PMOD Enable
    
    // Frame Buffer (BRAM) Interface
    output wire [12:0] rom_addr,    // Address request to the frame buffer
    input  wire [15:0] rom_data     // 16-bit RGB565 pixel data from the buffer
);

    // ==================================================================
    // 1. FSM State Definitions
    // ==================================================================
    localparam ST_POWER_ON      = 4'd0;
    localparam ST_RESET_RELEASE = 4'd2;
    localparam ST_INIT_SEND     = 4'd3;
    localparam ST_SET_WINDOW    = 4'd4;
    localparam ST_SEND_PIX_HI   = 4'd5;
    localparam ST_SEND_PIX_LO   = 4'd6;
    localparam ST_WAIT_SPI      = 4'd7;
    localparam ST_DONE          = 4'd8;

    reg [3:0]  state;
    reg [23:0] wait_cnt;
    reg [3:0]  prev_state; 
    
    localparam integer LONG_WAIT_CNT = 24'd2000000;
    localparam integer INIT_LEN      = 45;
    localparam integer WIN_LEN       = 7;

    reg [5:0]  init_index;
    reg [2:0]  win_index;
    
    localparam integer TOTAL_PIX = H_RES * V_RES; 
    reg [15:0] pix_index; 
    
    // Map the internal pixel index to the BRAM read address
    assign rom_addr = pix_index[12:0];

    // ==================================================================
    // 2. SSD1331 Initialization Sequence (ROM)
    // ==================================================================
    function [7:0] init_byte (input [5:0] idx);
        begin
            case (idx)
                6'd0:  init_byte = 8'hFD;
                6'd1:  init_byte = 8'h12; 
                6'd2:  init_byte = 8'hAE; // Display Off
                6'd3:  init_byte = 8'h75; // Set Row Address
                6'd4:  init_byte = 8'h00;
                6'd5:  init_byte = 8'h3F;
                6'd6:  init_byte = 8'h15; // Set Column Address
                6'd7:  init_byte = 8'h00;
                6'd8:  init_byte = 8'h5F;
                6'd9:  init_byte = 8'hA0; // Set Remap
                6'd10: init_byte = 8'h72; // Hardware Orientation Fix
                6'd11: init_byte = 8'hA1; // Set Start Line
                6'd12: init_byte = 8'h00;
                6'd13: init_byte = 8'hA2; // Set Display Offset
                6'd14: init_byte = 8'h00;
                6'd15: init_byte = 8'hA4; // Normal Display
                6'd16: init_byte = 8'hA8; // Set Multiplex Ratio
                6'd17: init_byte = 8'h3F;
                6'd18: init_byte = 8'hAD; // Set Master Configuration
                6'd19: init_byte = 8'h8F;
                6'd20: init_byte = 8'hB0; // Power Save Mode
                6'd21: init_byte = 8'h1A;
                6'd22: init_byte = 8'hB1; // Phase 1 and 2 Period
                6'd23: init_byte = 8'h74;
                6'd24: init_byte = 8'hB3; // Display Clock Divide
                6'd25: init_byte = 8'hD0;
                6'd26: init_byte = 8'h8A; // Second Pre-charge Speed
                6'd27: init_byte = 8'h81; // Set Contrast for Color A
                6'd28: init_byte = 8'h8B;
                6'd29: init_byte = 8'h82; // Set Contrast for Color B
                6'd30: init_byte = 8'h8C;
                6'd31: init_byte = 8'h83; // Set Contrast for Color C
                6'd32: init_byte = 8'hBB; // Set Pre-charge Voltage
                6'd33: init_byte = 8'h3E;
                6'd34: init_byte = 8'hBE; // Set VCOMH Voltage
                6'd35: init_byte = 8'h3E;
                6'd36: init_byte = 8'h87; // Master Current Control
                6'd37: init_byte = 8'h0F;
                6'd38: init_byte = 8'h81;
                6'd39: init_byte = 8'h80;
                6'd40: init_byte = 8'h82;
                6'd41: init_byte = 8'h80;
                6'd42: init_byte = 8'h83;
                6'd43: init_byte = 8'h80;
                6'd44: init_byte = 8'hAF; // Display On
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    // ==================================================================
    // 3. SSD1331 Drawing Window Setup
    // ==================================================================
    // Set Writing Window (0,0 to 95,63)
    function [7:0] win_byte (input [2:0] idx);
        begin
            case (idx)
                3'd0: win_byte = 8'h15; // Set Column Address Command
                3'd1: win_byte = 8'h00; // Start Column (0)
                3'd2: win_byte = 8'h5F; // End Column (95)
                3'd3: win_byte = 8'h75; // Set Row Address Command
                3'd4: win_byte = 8'h00; // Start Row (0)
                3'd5: win_byte = 8'h3F; // End Row (63)
                3'd6: win_byte = 8'h5C; // Write RAM Command
                default: win_byte = 8'h00;
            endcase
        end
    endfunction

    // ==================================================================
    // 4. Main FSM Logic
    // ==================================================================
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state       <= ST_POWER_ON;
            wait_cnt    <= 24'd0;
            init_index  <= 6'd0;
            win_index   <= 3'd0;
            spi_start   <= 1'b0;
            spi_data    <= 8'd0;
            pix_index   <= 16'd0;
            oled_dc     <= 1'b0;
            oled_res    <= 1'b0;
            oled_vccen  <= 1'b0;
            oled_pmoden <= 1'b0;
            prev_state  <= ST_POWER_ON;
        end else begin
            spi_start <= 1'b0; // Default to 0, pulse when needed
            
            case (state)
                ST_POWER_ON: begin
                    oled_vccen  <= 1'b1;
                    oled_pmoden <= 1'b1;
                    oled_res    <= 1'b0; // Hold reset low initially
                    wait_cnt    <= wait_cnt + 1'b1;
                    
                    if (wait_cnt == LONG_WAIT_CNT) begin
                        wait_cnt <= 24'd0;
                        state    <= ST_RESET_RELEASE;
                    end
                end

                ST_RESET_RELEASE: begin
                    oled_res <= 1'b1; // Release reset
                    wait_cnt <= wait_cnt + 1'b1;
                    
                    // Wait for OLED controller to stabilize
                    if (wait_cnt == 24'd500000) begin
                        wait_cnt   <= 24'd0;
                        init_index <= 6'd0;
                        state      <= ST_INIT_SEND;
                    end
                end

                ST_INIT_SEND: begin
                    if (!spi_busy) begin
                        oled_dc    <= 1'b0; // Command Mode
                        spi_data   <= init_byte(init_index);
                        spi_start  <= 1'b1;
                        prev_state <= ST_INIT_SEND;
                        state      <= ST_WAIT_SPI;
                    end
                end

                ST_SET_WINDOW: begin
                    if (!spi_busy) begin
                        oled_dc    <= 1'b0; // Command Mode
                        spi_data   <= win_byte(win_index);
                        spi_start  <= 1'b1;
                        prev_state <= ST_SET_WINDOW;
                        state      <= ST_WAIT_SPI;
                    end
                end

                ST_SEND_PIX_HI: begin
                    if (!spi_busy) begin
                        oled_dc    <= 1'b1; // Data Mode
                        spi_data   <= rom_data[15:8]; // Send MSB of RGB565
                        spi_start  <= 1'b1;
                        prev_state <= ST_SEND_PIX_HI;
                        state      <= ST_WAIT_SPI;
                    end
                end

                ST_SEND_PIX_LO: begin
                    if (!spi_busy) begin
                        oled_dc    <= 1'b1; // Data Mode
                        spi_data   <= rom_data[7:0];  // Send LSB of RGB565
                        spi_start  <= 1'b1;
                        prev_state <= ST_SEND_PIX_LO;
                        state      <= ST_WAIT_SPI;
                    end
                end
                
                ST_WAIT_SPI: begin
                    // Wait for the SPI transmission to complete, then determine the next step
                    case (prev_state)
                        ST_INIT_SEND: begin
                            if (init_index < INIT_LEN - 1) begin
                                init_index <= init_index + 1'b1;
                                state      <= ST_INIT_SEND;
                            end else begin
                                state      <= ST_SET_WINDOW;
                            end
                        end
                        
                        ST_SET_WINDOW: begin
                            if (win_index < WIN_LEN - 1) begin
                                win_index <= win_index + 1'b1;
                                state     <= ST_SET_WINDOW;
                            end else begin
                                pix_index <= 16'd0;
                                state     <= ST_SEND_PIX_HI;
                            end
                        end
                        
                        ST_SEND_PIX_HI: begin
                            state <= ST_SEND_PIX_LO;
                        end
                        
                        ST_SEND_PIX_LO: begin
                            if (pix_index == (TOTAL_PIX - 1)) begin
                                state <= ST_DONE; // Finished drawing one entire frame
                            end else begin
                                pix_index <= pix_index + 1'b1;
                                state     <= ST_SEND_PIX_HI;
                            end
                        end
                        
                        default: state <= ST_POWER_ON;
                    endcase
                end

                ST_DONE: begin
                    // *** Core Update: Continuous Frame Refresh ***
                    // Instead of halting after drawing one frame, reset the indices 
                    // and return to the ST_SET_WINDOW state.
                    // This creates an infinite loop that constantly fetches new data 
                    // from the frame buffer (BRAM), enabling real-time video streaming 
                    // and dynamic updates (e.g., toggling grayscale via SW0).
                    pix_index <= 16'd0;
                    win_index <= 3'd0;
                    state     <= ST_SET_WINDOW;
                end

                default: state <= ST_POWER_ON;
            endcase
        end
    end
endmodule