/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_camera_oled (Top-level Integration)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : DVP Camera to OLED Pipeline Top
 * Description  : Integrates the camera initialization, image sampler, 
 * frame buffer (BRAM), and OLED display controller to form a complete 
 * hardware pipeline from video capture to real-time display.
 * ====================================================================== */ 

`timescale 1ns / 1ps

module top_camera_oled (
    input  wire CLK100MHZ,
    input  wire btn0,
    input  wire sw0,          // 0: Color, 1: Grayscale

    output wire       cam_mclk,
    output wire       cam_scl,
    inout  wire       cam_sda,
    input  wire       cam_pclk,
    input  wire       cam_vsync,
    input  wire       cam_href,
    input  wire [7:0] cam_data,

    output wire oled_mosi,
    output wire oled_sck,
    output wire oled_cs_n,
    output wire oled_dc,
    output wire oled_res,
    output wire oled_vccen,
    output wire oled_pmoden,

    output wire led2,
    output wire led3,
    output wire led4,
    output wire led5
);

    wire reset = btn0;

    wire clk25;

    clk25_divider u_clk25 (
        .clk100 (CLK100MHZ),
        .rst    (reset),
        .clk25  (clk25)
    );

    wire init_done;
    wire scl_seen;
    wire sda_idle_high;

    camera_init u_camera_init (
        .clk25         (clk25),
        .rst           (reset),
        .sio_c         (cam_scl),
        .sio_d         (cam_sda),
        .xclk          (cam_mclk),
        .init_done     (init_done),
        .scl_seen      (scl_seen),
        .sda_idle_high (sda_idle_high)
    );

    reg [3:0] div_cnt = 4'd0;

    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset)
            div_cnt <= 4'd0;
        else
            div_cnt <= div_cnt + 1'b1;
    end

    wire spi_clk = div_cnt[3];

    wire        spi_start;
    wire        spi_busy;
    wire [7:0]  spi_data;
    wire [12:0] oled_pix_addr;
    wire [15:0] oled_pixel_data;

    wire sample_valid;

    camera_vga_to_oled_sampler u_cam_sampler (
        .rst          (reset),
        .pclk         (cam_pclk),
        .vsync        (cam_vsync),
        .href         (cam_href),
        .data_in      (cam_data),

        .grayscale_en (sw0),

        .oled_clk     (spi_clk),
        .oled_addr    (oled_pix_addr),
        .oled_pixel   (oled_pixel_data),

        .sample_valid (sample_valid)
    );

    spi_master u_spi (
        .clk     (spi_clk),
        .reset   (reset),
        .start   (spi_start),
        .data_in (spi_data),
        .busy    (spi_busy),
        .sclk    (oled_sck),
        .mosi    (oled_mosi),
        .cs_n    (oled_cs_n)
    );

    oled_test #(
        .H_RES(96),
        .V_RES(64)
    ) u_oled (
        .clk         (spi_clk),
        .reset       (reset),
        .spi_start   (spi_start),
        .spi_data    (spi_data),
        .spi_busy    (spi_busy),
        .oled_dc     (oled_dc),
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen),
        .oled_pmoden (oled_pmoden),
        .rom_addr    (oled_pix_addr),
        .rom_data    (oled_pixel_data)
    );

    reg [25:0] alive_cnt = 26'd0;

    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset)
            alive_cnt <= 26'd0;
        else
            alive_cnt <= alive_cnt + 1'b1;
    end

    assign led2 = alive_cnt[25];
    assign led3 = cam_href;
    assign led4 = sample_valid;
    assign led5 = init_done;

endmodule