/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : camera_vga_to_oled_sampler (VGA to OLED Down-sampler)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : DVP Image Capture & Hardware Image Processing Pipeline
 * Description  : Core processing module that captures the raw VGA (640x480)
 * stream from the camera via DVP (PCLK, VSYNC, HREF, DATA), down-samples
 * it to fit an 80x60 window on the OLED, and applies a hardware-level
 * grayscale filter (based on Luma estimation) controlled by 'grayscale_en'.
 * Captured data is safely passed to the OLED clock domain via Dual-Port RAM.
 * ====================================================================== */

`timescale 1ns / 1ps

module camera_vga_to_oled_sampler (
    // Camera Interface (Write Domain)
    input  wire        rst,
    input  wire        pclk,          // Camera Pixel Clock
    input  wire        vsync,         // Camera Vertical Sync (Frame Start)
    input  wire        href,          // Camera Horizontal Ref (Line Valid)
    input  wire [7:0]  data_in,       // 8-bit DVP Data Bus

    // Filter Control
    input  wire        grayscale_en,  // SW0: 1 enables Luma(Grayscale) filter

    // OLED Interface (Read Domain)
    input  wire        oled_clk,      // SPI Clock for OLED Display
    input  wire [12:0] oled_addr,     // Pixel index requested by OLED FSM
    output wire [15:0] oled_pixel,    // 16-bit RGB565 data sent to OLED

    // Debug/Status
    output reg         sample_valid = 1'b0  // Pulses when a pixel is successfully saved
);

    // ==================================================================
    // 1. Resolution & Offset Parameters
    // ==================================================================
    localparam IMG_W = 80;            // Down-sampled Image Width
    localparam IMG_H = 60;            // Down-sampled Image Height

    localparam OLED_W = 96;           // Actual OLED Physical Width
    localparam X_OFFSET = 8;          // Center the 80x60 image on the 96x64 OLED
    localparam Y_OFFSET = 2;          // Center the 80x60 image on the 96x64 OLED


    // ==================================================================
    // 2. Camera Frame & Line Counters
    // ==================================================================
    reg [10:0] cam_x_byte = 11'd0;    // Counts incoming bytes per line (0 to 1279 for VGA RGB565)
    reg [9:0]  cam_y      = 10'd0;    // Counts incoming lines per frame (0 to 479 for VGA)

    reg href_d  = 1'b0;               // Delayed href to detect falling edge (end of line)
    reg vsync_d = 1'b0;               // Delayed vsync to detect frame changes


    // ==================================================================
    // 3. 16-bit Pixel Assembly (RGB565)
    // ==================================================================
    // The camera sends 16-bit RGB565 pixels in two 8-bit chunks (High byte, Low byte).
    reg        byte_phase = 1'b0;     // 0: Waiting for High Byte, 1: Waiting for Low Byte
    reg [7:0]  byte_high  = 8'h00;    // Latches the High Byte

    // cam_x_pixel represents the actual pixel column (0 to 639)
    wire [9:0] cam_x_pixel = cam_x_byte[10:1];


    // ==================================================================
    // 4. Down-Sampling Logic (1/8 Scale)
    // ==================================================================
    // To scale 640x480 to 80x60, we only sample 1 out of every 8 pixels (both X and Y).
    // This is a naive nearest-neighbor approach.
    wire sample_x_en = (cam_x_pixel[2:0] == 3'b000); // True every 8th pixel horizontally
    wire sample_y_en = (cam_y[2:0]       == 3'b000); // True every 8th line vertically

    wire [6:0] sample_x = cam_x_pixel[9:3];          // Scaled X coordinate (0 to 79)
    wire [5:0] sample_y = cam_y[8:3];                // Scaled Y coordinate (0 to 59)

    // Ensure we do not write outside the bounded BRAM area
    wire in_sample_area = (sample_x < IMG_W) && (sample_y < IMG_H);
    
    // Calculate 1D memory address: (Y * Width) + X
    wire [12:0] wr_addr = sample_y * IMG_W + sample_x;

    reg        wr_en       = 1'b0;
    reg [12:0] wr_addr_reg = 13'd0;
    reg [15:0] wr_data_reg = 16'h0000;


    // ==================================================================
    // 5. Hardware Image Filter (RGB to Grayscale / Luma)
    // ==================================================================
    // Reconstruct the 16-bit RGB565 pixel from the two 8-bit bytes.
    wire [15:0] rgb565_raw = {byte_high, data_in};

    // Extract individual color channels
    wire [4:0] r5 = rgb565_raw[15:11];
    wire [5:0] g6 = rgb565_raw[10:5];
    wire [4:0] b5 = rgb565_raw[4:0];

    // Simple Luma (Grayscale) estimation: (R + G + B) / 3
    // Zero-padding is used to match bit widths before addition.
    wire [5:0] gray6 = ({1'b0, r5} + g6 + {1'b0, b5}) / 3;

    // Pack the 6-bit grayscale value back into an RGB565 format (R=G=B)
    wire [15:0] gray_rgb565 = {
        gray6[5:1], // R (5 bits)
        gray6,      // G (6 bits)
        gray6[5:1]  // B (5 bits)
    };

    // Mux selects between raw color and grayscale based on SW0
    wire [15:0] selected_pixel = grayscale_en ? gray_rgb565 : rgb565_raw;


    // ==================================================================
    // 6. Camera DVP State Machine (Write Domain)
    // ==================================================================
    always @(posedge pclk or posedge rst) begin
        if (rst) begin
            cam_x_byte   <= 11'd0;
            cam_y        <= 10'd0;
            href_d       <= 1'b0;
            vsync_d      <= 1'b0;
            byte_phase   <= 1'b0;
            byte_high    <= 8'h00;
            wr_en        <= 1'b0;
            wr_addr_reg  <= 13'd0;
            wr_data_reg  <= 16'h0000;
            sample_valid <= 1'b0;
        end else begin
            href_d  <= href;
            vsync_d <= vsync;
            wr_en   <= 1'b0; // Default state

            // Check for Frame Start (VSYNC change)
            if (vsync != vsync_d) begin
                cam_x_byte <= 11'd0;
                cam_y      <= 10'd0;
                byte_phase <= 1'b0;
            end
            // Active Line Data
            else if (href) begin
                cam_x_byte <= cam_x_byte + 1'b1;

                if (!byte_phase) begin
                    // First byte of the pixel (High Byte)
                    byte_high  <= data_in;
                    byte_phase <= 1'b1;
                end else begin
                    // Second byte of the pixel (Low Byte)
                    // If this pixel falls on our 1/8 down-sample grid, save it to BRAM.
                    if (sample_x_en && sample_y_en && in_sample_area) begin
                        wr_addr_reg  <= wr_addr;
                        wr_data_reg  <= selected_pixel;
                        wr_en        <= 1'b1;
                        sample_valid <= 1'b1;
                    end
                    byte_phase <= 1'b0; // Reset for the next pixel
                end
            end
            // Horizontal Blanking (End of Line)
            else begin
                cam_x_byte <= 11'd0;
                byte_phase <= 1'b0;

                // Increment Y counter exactly once when href drops
                if (href_d)
                    cam_y <= cam_y + 1'b1;
            end
        end
    end


    // ==================================================================
    // 7. OLED Display Address Mapping (Read Domain)
    // ==================================================================
    // Convert 1D OLED address request into 2D (X, Y) coordinates
    wire [6:0] oled_x = oled_addr % OLED_W;
    wire [5:0] oled_y = oled_addr / OLED_W;

    // Check if the current OLED coordinate is within our 80x60 centered image bounding box
    wire oled_in_img =
        (oled_x >= X_OFFSET) &&
        (oled_x <  X_OFFSET + IMG_W) &&
        (oled_y >= Y_OFFSET) &&
        (oled_y <  Y_OFFSET + IMG_H);

    // Calculate local image coordinates (0 to 79, 0 to 59)
    wire [6:0] img_x = oled_x - X_OFFSET;
    wire [5:0] img_y = oled_y - Y_OFFSET;

    // Calculate BRAM read address for the requesting OLED pixel
    wire [12:0] rd_addr = img_y * IMG_W + img_x;
    wire [15:0] fb_pixel;


    // ==================================================================
    // 8. Dual-Port Frame Buffer (BRAM)
    // ==================================================================
    // Asynchronous Clock BRAM: Safely crosses data from PCLK to SPI Clock.
    frame_buffer_dpram u_frame_buffer (
        // Write Port (Camera Domain)
        .wr_clk  (pclk),
        .wr_en   (wr_en),
        .wr_addr (wr_addr_reg),
        .wr_data (wr_data_reg),

        // Read Port (OLED SPI Domain)
        .rd_clk  (oled_clk),
        .rd_addr (rd_addr),
        .rd_data (fb_pixel)
    );

    // If the OLED is drawing outside the 80x60 box, output black (16'h0000).
    assign oled_pixel = oled_in_img ? fb_pixel : 16'h0000;

endmodule