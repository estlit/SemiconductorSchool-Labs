/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : spi_master (8-bit SPI Master)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Serial Peripheral Interface (SPI) Protocol Controller
 * Description  : Hardware SPI Master configured for Mode 3 (CPOL=1, CPHA=1).
 * It transmits 8-bit data MSB first. At CPOL=1, the idle clock is HIGH.
 * At CPHA=1, data is shifted out on the falling edge and sampled by the 
 * slave (OLED) on the rising edge.
 * ====================================================================== */

`timescale 1ns / 1ps

module spi_master (
    input  wire       clk,      // SPI operating clock domain
    input  wire       reset,    // Active-high synchronous reset
    input  wire       start,    // 1-cycle pulse to trigger transmission
    input  wire [7:0] data_in,  // 8-bit data to transmit
    
    output reg        busy,     // High while transmission is in progress
    output reg        sclk,     // SPI Clock output
    output reg        mosi,     // SPI Master Out Slave In (Data output)
    output reg        cs_n      // SPI Chip Select (Active Low)
);

    // Internal registers
    reg [3:0] bit_cnt;          // Counter for the 8 bits (7 down to 0)
    reg [7:0] shreg;            // Shift register holding the data

    // FSM State Definitions
    localparam IDLE = 2'd0,
               LOAD = 2'd1,
               SEND = 2'd2,
               DONE = 2'd3;

    reg [1:0] state;
    
    // Sub-state for clock generation within a bit period
    // 0: Prepare for falling edge (Shift data)
    // 1: Prepare for rising edge  (Slave samples data)
    reg       phase;    

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state   <= IDLE;
            bit_cnt <= 4'd0;
            shreg   <= 8'd0;
            busy    <= 1'b0;
            sclk    <= 1'b1;   // SPI Mode 3: Clock is HIGH when idle
            mosi    <= 1'b0;
            cs_n    <= 1'b1;   // Chip Select is inactive (HIGH)
            phase   <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    // Wait for the start trigger
                    if (start) begin
                        busy  <= 1'b1;
                        state <= LOAD;
                    end
                end

                LOAD: begin
                    // Latch the input data and reset bit counter for 8 bits
                    shreg   <= data_in;
                    bit_cnt <= 4'd7;
                    cs_n    <= 1'b0;   // Assert Chip Select (Active Low) to select OLED
                    sclk    <= 1'b1;   // Ensure SCLK starts HIGH (Mode 3)
                    phase   <= 1'b0;   // Next action will be the falling edge
                    state   <= SEND;
                end

                SEND: begin
                    if (phase == 1'b0) begin
                        // Phase 0: Falling Edge
                        // SCLK goes 1 -> 0. Shift out the MSB to MOSI immediately.
                        sclk  <= 1'b0;
                        mosi  <= shreg[7];
                        phase <= 1'b1; // Move to rising edge phase
                    end else begin
                        // Phase 1: Rising Edge
                        // SCLK goes 0 -> 1. The slave (SSD1331) samples the MOSI data here.
                        sclk <= 1'b1;
                        
                        // Check if all 8 bits have been transmitted
                        if (bit_cnt == 0) begin
                            state <= DONE; // All bits sent, finish transmission
                        end else begin
                            // Decrement bit counter and shift data left by 1 bit
                            bit_cnt <= bit_cnt - 1'b1;
                            shreg   <= {shreg[6:0], 1'b0};
                            phase   <= 1'b0; // Reset phase for the next bit's falling edge
                        end
                    end
                end

                DONE: begin
                    // Transmission complete, return to idle state securely
                    sclk  <= 1'b1;     // Ensure clock returns to idle HIGH
                    cs_n  <= 1'b1;     // De-assert Chip Select
                    busy  <= 1'b0;     // Clear busy flag
                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule