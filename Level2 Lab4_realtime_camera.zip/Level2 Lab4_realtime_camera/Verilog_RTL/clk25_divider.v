`timescale 1ns / 1ps

module clk25_divider (
    input  wire clk100,
    input  wire rst,
    output wire clk25
);

    reg [1:0] div = 2'd0;

    always @(posedge clk100 or posedge rst) begin
        if (rst)
            div <= 2'd0;
        else
            div <= div + 1'b1;
    end

    assign clk25 = div[1];   // 100MHz / 4 = 25MHz

endmodule
