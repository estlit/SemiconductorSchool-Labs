/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : camera_init (Camera Initialization Wrapper)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : SCCB (I2C-compatible) Master Controller
 * Description  : Wrapper module for camera sensor initialization.
 * It drives the camera's master clock (XCLK) and manages the SCCB 
 * transmission by coordinating the register lookup table (reg_init) 
 * and the serial sender (sccb_sender).
 * ====================================================================== */

`timescale 1ns / 1ps

module camera_init (
    // System Clock and Reset
    input  wire clk25,          // 25MHz input clock
    input  wire rst,            // Active-high asynchronous reset

    // SCCB (Serial Camera Control Bus) Interface
    output wire sio_c,          // SCCB Serial Clock (SCL)
    inout  wire sio_d,          // SCCB Serial Data (SDA)
    output wire xclk,           // Camera Master Clock (MCLK)

    // Status and Debug Flags
    output wire init_done,      // High when all registers are successfully configured
    output reg  scl_seen,       // Debug: High if successful SCCB transmission occurred
    output reg  sda_idle_high   // Debug: High if SDA line was observed in idle state (High)
);

    // ==================================================================
    // 1. Clock and Bus Configuration
    // ==================================================================
    // Reference-style camera clock:
    // The camera requires a master clock to operate its internal PLL and SCCB.
    // We drive xclk directly with the 25MHz system clock.
    assign xclk = clk25;

    // Explicit pull-up on SCCB data line.
    // In I2C/SCCB protocols, the data line must be pulled high when idle.
    pullup up_sio_d (sio_d);


    // ==================================================================
    // 2. Internal Wires for Module Interconnection
    // ==================================================================
    wire [15:0] data_send;      // 16-bit data (8-bit address + 8-bit value) to send
    wire reg_ok;                // High when the reg_init module is still fetching data
    wire sccb_ok;               // High when sccb_sender completes one transaction


    // ==================================================================
    // 3. Register Lookup Table (ROM)
    // ==================================================================
    // Sequentially provides the camera register addresses and configuration values.
    reg_init u_reg_init (
        .clk      (clk25),
        .rst      (rst),
        .data_out (data_send),
        .reg_ok   (reg_ok),
        .sccb_ok  (sccb_ok)
    );


    // ==================================================================
    // 4. SCCB Serial Transmitter
    // ==================================================================
    // Converts the parallel address/value data into serial I2C/SCCB format.
    sccb_sender u_sccb_sender (
        .clk       (clk25),
        .rst       (rst),
        .sio_d     (sio_d),
        .sio_c     (sio_c),
        .reg_ok    (reg_ok),
        .sccb_ok   (sccb_ok),
        .slave_id  (8'h60),            // Camera sensor I2C Write Address (e.g., OV2640/OV7670)
        .reg_addr  (data_send[15:8]),  // Upper 8 bits: Register Address
        .value     (data_send[7:0])    // Lower 8 bits: Register Value
    );


    // ==================================================================
    // 5. Status and Debug Logic
    // ==================================================================
    // init_done is active high when reg_ok drops to 0 (meaning no more registers to send)
    assign init_done = ~reg_ok;

    // Latch debug signals to monitor SCCB bus activity
    always @(posedge clk25 or posedge rst) begin
        if (rst) begin
            scl_seen      <= 1'b0;
            sda_idle_high <= 1'b0;
        end else begin
            // Latch high if at least one SCCB transaction is completed
            if (sccb_ok)
                scl_seen <= 1'b1;

            // Latch high if the SDA line is ever observed at logic HIGH (idle/pull-up state)
            if (sio_d == 1'b1)
                sda_idle_high <= 1'b1;
        end
    end

endmodule