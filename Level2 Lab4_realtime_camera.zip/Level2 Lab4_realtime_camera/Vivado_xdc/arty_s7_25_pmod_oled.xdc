## =========================================================================
## Arty S7-25 XDC: OV2640 Camera + Pmod OLEDrgb
## SW0 = 0 : Color
## SW0 = 1 : Grayscale
## =========================================================================

## System Clock
set_property PACKAGE_PIN R2 [get_ports { CLK100MHZ }]
set_property IOSTANDARD LVCMOS33 [get_ports { CLK100MHZ }]
create_clock -add -name sys_clk_pin -period 10.000 -waveform {0 5} [get_ports { CLK100MHZ }]

## BTN0 Reset
set_property PACKAGE_PIN G15 [get_ports { btn0 }]
set_property IOSTANDARD LVCMOS33 [get_ports { btn0 }]

## SW0: Color / Grayscale select
set_property PACKAGE_PIN H14 [get_ports { sw0 }]
set_property IOSTANDARD LVCMOS33 [get_ports { sw0 }]

## LEDs
set_property PACKAGE_PIN E18 [get_ports { led2 }]
set_property IOSTANDARD LVCMOS33 [get_ports { led2 }]

set_property PACKAGE_PIN F13 [get_ports { led3 }]
set_property IOSTANDARD LVCMOS33 [get_ports { led3 }]

set_property PACKAGE_PIN E13 [get_ports { led4 }]
set_property IOSTANDARD LVCMOS33 [get_ports { led4 }]

set_property PACKAGE_PIN H15 [get_ports { led5 }]
set_property IOSTANDARD LVCMOS33 [get_ports { led5 }]


## -------------------------------------------------------------------------
## PMOD JA: Pmod OLEDrgb
## -------------------------------------------------------------------------
set_property PACKAGE_PIN L17 [get_ports { oled_cs_n }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_cs_n }]

set_property PACKAGE_PIN L18 [get_ports { oled_mosi }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_mosi }]

set_property PACKAGE_PIN N14 [get_ports { oled_sck }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_sck }]

set_property PACKAGE_PIN M16 [get_ports { oled_dc }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_dc }]

set_property PACKAGE_PIN M17 [get_ports { oled_res }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_res }]

set_property PACKAGE_PIN M18 [get_ports { oled_vccen }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_vccen }]

set_property PACKAGE_PIN N18 [get_ports { oled_pmoden }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_pmoden }]


## -------------------------------------------------------------------------
## PMOD JC: PMOD-CAMERA Control Connector
## -------------------------------------------------------------------------
## PK / PCLK  -> JC2  -> V16
## HR / HREF  -> JC3  -> U17
## SCL        -> JC4  -> U18
## XK / MCLK  -> JC8  -> P13
## VS / VSYNC -> JC9  -> R13
## SDA        -> JC10 -> V14

set_property PACKAGE_PIN P13 [get_ports { cam_mclk }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_mclk }]

set_property PACKAGE_PIN V16 [get_ports { cam_pclk }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_pclk }]
create_clock -add -name cam_pclk_pin -period 83.333 [get_ports { cam_pclk }]

set_property PACKAGE_PIN U17 [get_ports { cam_href }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_href }]

set_property PACKAGE_PIN R13 [get_ports { cam_vsync }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_vsync }]

set_property PACKAGE_PIN U18 [get_ports { cam_scl }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_scl }]

set_property PACKAGE_PIN V14 [get_ports { cam_sda }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_sda }]
set_property PULLUP true [get_ports { cam_sda }]


## -------------------------------------------------------------------------
## PMOD JD: PMOD-CAMERA Data Connector
## -------------------------------------------------------------------------
set_property PACKAGE_PIN V15 [get_ports { cam_data[7] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[7] }]

set_property PACKAGE_PIN T13 [get_ports { cam_data[6] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[6] }]

set_property PACKAGE_PIN U12 [get_ports { cam_data[5] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[5] }]

set_property PACKAGE_PIN R11 [get_ports { cam_data[4] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[4] }]

set_property PACKAGE_PIN V13 [get_ports { cam_data[3] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[3] }]

set_property PACKAGE_PIN T11 [get_ports { cam_data[2] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[2] }]

set_property PACKAGE_PIN T12 [get_ports { cam_data[1] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[1] }]

set_property PACKAGE_PIN U11 [get_ports { cam_data[0] }]
set_property IOSTANDARD LVCMOS33 [get_ports { cam_data[0] }]


## -------------------------------------------------------------------------
## Timing
## -------------------------------------------------------------------------
set_false_path -from [get_clocks sys_clk_pin] -to [get_clocks cam_pclk_pin]
set_false_path -from [get_clocks cam_pclk_pin] -to [get_clocks sys_clk_pin]

set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets -of_objects [get_ports { cam_pclk }]]