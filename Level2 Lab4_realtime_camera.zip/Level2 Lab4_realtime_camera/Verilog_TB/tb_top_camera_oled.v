/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_camera_oled (Top-level Testbench)
 * Target Board : Simulation Only
 * Architecture : Testbench for DVP Camera to OLED Pipeline
 * Description  : Verifies the full hardware pipeline from camera image
 * capture (simulated DVP signals) to the OLED display buffer. Tests 
 * both Color and Grayscale modes using simulated frame generation.
 * [UPDATED] Full SCCB/I2C initialization simulation with Dummy ACK.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top_camera_oled;

    // ==================================================================
    // 1. Signals & DUT Instantiation
    // ==================================================================
    reg  CLK100MHZ = 1'b0;
    reg  btn0      = 1'b1;      // Active-high reset
    reg  sw0       = 1'b0;      // Filter control: 0 for Color, 1 for Grayscale

    // Camera interface signals
    wire cam_mclk;
    wire cam_scl;
    tri1 cam_sda;               // Pull-up wire for I2C/SCCB

    // Simulated camera DVP outputs
    reg        cam_pclk  = 1'b0;
    reg        cam_vsync = 1'b0;
    reg        cam_href  = 1'b0;
    reg  [7:0] cam_data  = 8'h00;

    // OLED interface signals
    wire oled_mosi;
    wire oled_sck;
    wire oled_cs_n;
    wire oled_dc;
    wire oled_res;
    wire oled_vccen;
    wire oled_pmoden;

    // Debug LEDs
    wire led2;
    wire led3;
    wire led4;
    wire led5;

    // Device Under Test (DUT)
    top_camera_oled dut (
        .CLK100MHZ   (CLK100MHZ),
        .btn0        (btn0),
        .sw0         (sw0),

        .cam_mclk    (cam_mclk),
        .cam_scl     (cam_scl),
        .cam_sda     (cam_sda),
        .cam_pclk    (cam_pclk),
        .cam_vsync   (cam_vsync),
        .cam_href    (cam_href),
        .cam_data    (cam_data),

        .oled_mosi   (oled_mosi),
        .oled_sck    (oled_sck),
        .oled_cs_n   (oled_cs_n),
        .oled_dc     (oled_dc),
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen),
        .oled_pmoden (oled_pmoden),

        .led2        (led2),
        .led3        (led3),
        .led4        (led4),
        .led5        (led5)
    );

    // ==================================================================
    // 2. Clock Generation
    // ==================================================================
    // System Clock: 100MHz (Period = 10ns)
    always #5 CLK100MHZ = ~CLK100MHZ;

    // Camera PCLK: 25MHz equivalent (Period = 40ns)
    always #20 cam_pclk = ~cam_pclk;

    // ==================================================================
    // 3. Dummy I2C/SCCB Slave for ACK Generation
    // ==================================================================
    // Send a dummy ACK on the 9th clock to prevent the I2C Master from halting during communication.
    reg sda_out = 1'b1;
    assign cam_sda = (sda_out == 1'b0) ? 1'b0 : 1'bz;
    
    reg [3:0] bit_cnt = 0;
    reg i2c_started = 0;

    // START Condition Detection
    always @(negedge cam_sda) begin
        if (cam_scl === 1'b1) begin
            i2c_started <= 1'b1;
            bit_cnt <= 0;
        end
    end

    // STOP Condition Detection
    always @(posedge cam_sda) begin
        if (cam_scl === 1'b1) begin
            i2c_started <= 1'b0;
        end
    end

    // Bit counting and ACK driving
    always @(negedge cam_scl) begin
        if (i2c_started) begin
            if (bit_cnt == 8) begin
                bit_cnt <= 0;
                sda_out <= 1'b1; // Release SDA after ACK
            end else if (bit_cnt == 7) begin
                bit_cnt <= bit_cnt + 1;
                sda_out <= 1'b0; // Pull SDA low on the 9th clock for ACK response
            end else begin
                bit_cnt <= bit_cnt + 1;
                sda_out <= 1'b1;
            end
        end else begin
            sda_out <= 1'b1;
        end
    end

    // ==================================================================
    // 4. Simulated Camera Frame Generator Task
    // ==================================================================
    integer frame;
    integer line;
    integer byte_idx;

    task send_camera_frames;
        input integer num_frames;
        begin
            for (frame = 0; frame < num_frames; frame = frame + 1) begin
                // Frame Start (VSYNC pulse)
                cam_vsync = 1'b1;
                repeat (20) @(posedge cam_pclk);
                cam_vsync = 1'b0;
                repeat (20) @(posedge cam_pclk);

                // Send lines for the down-scaled target (60 lines)
                for (line = 0; line < 60; line = line + 1) begin
                    cam_href = 1'b1; // Line valid start

                    // Send pixels for the line (160 bytes = 80 pixels * 2 bytes/pixel)
                    for (byte_idx = 0; byte_idx < 160; byte_idx = byte_idx + 1) begin
                        @(posedge cam_pclk);
                        // Generate dummy image data based on byte and line index
                        cam_data <= byte_idx[7:0] + line[7:0];
                    end

                    @(posedge cam_pclk);
                    cam_href = 1'b0; // Line valid end
                    
                    // Horizontal blanking interval
                    repeat (20) @(posedge cam_pclk);
                end
            end
        end
    endtask

    // ==================================================================
    // 5. Main Simulation Sequence
    // ==================================================================
    initial begin
        $display("========================================");
        $display("TOP BLOCK TEST START");
        $display("========================================");

        // Initialize signals
        btn0      = 1'b1; // Assert reset
        sw0       = 1'b0; // Color mode
        cam_vsync = 1'b0;
        cam_href  = 1'b0;
        cam_data  = 8'h00;

        #1000;
        btn0 = 1'b0; // Release reset
        $display("[%0t] System Reset Released. Waiting for full SCCB Initialization...", $time);

        // ------------------------------------------------------------
        // Wait for actual SCCB/I2C initialization completion
        // Increased timeout to 1 second (1000ms) considering simulation delay, and print waiting status.
        // ------------------------------------------------------------
        begin : TIMEOUT_BLOCK
            fork
                begin
                    wait(dut.init_done == 1'b1);
                    $display("[%0t] SUCCESS: SCCB Initialization Complete! (init_done = 1)", $time);
                    disable TIMEOUT_BLOCK; // Force exit the entire block upon completion
                end
                begin
                    // Print progress messages 10 times at 100ms intervals to monitor simulation status
                    repeat(10) begin
                        #100_000_000; // 100ms
                        $display("[%0t] Waiting... SCCB Initialization is still in progress.", $time);
                    end
                    $display("[%0t] ERROR: SCCB Initialization Timeout (1 sec)!", $time);
                    $finish; // Terminate simulation upon error
                end
            join
        end

        // ------------------------------------------------------------
        // Test Case 1: Color Mode
        // ------------------------------------------------------------
        sw0 = 1'b0;
        $display("[%0t] COLOR MODE TEST START", $time);
        send_camera_frames(2); // Simulate sending 2 camera frames

        // Wait for pipeline processing
        repeat (20000) @(posedge CLK100MHZ);

        // Assertions
        if (led5 !== 1'b1) begin
            $display("ERROR: led5(init_done) is not ON.");
            $stop;
        end

        if (led4 !== 1'b1) begin
            $display("ERROR: led4(sample_valid) is not ON in color mode.");
            $stop;
        end

        if (dut.u_cam_sampler.sample_valid !== 1'b1) begin
            $display("ERROR: Sampler did not write sampled image data in color mode.");
            $stop;
        end

        // The OLED display needs time to initialize and read from BRAM.
        // Checking for unknown (X) data immediately will fail in simulation, so it is commented out.
        // if (dut.oled_pixel_data === 16'hxxxx) begin
        //     $display("ERROR: OLED pixel data is unknown (X) in color mode.");
        //     $stop;
        // end

        $display("COLOR MODE PASS");
        $display("oled_pixel_data(color) = %h", dut.oled_pixel_data);

        // ------------------------------------------------------------
        // Test Case 2: Grayscale Mode
        // ------------------------------------------------------------
        sw0 = 1'b1;
        $display("[%0t] GRAYSCALE MODE TEST START", $time);
        send_camera_frames(2); // Simulate sending 2 more frames

        // Wait for pipeline processing
        repeat (20000) @(posedge CLK100MHZ);

        // Assertions
        if (dut.u_cam_sampler.sample_valid !== 1'b1) begin
            $display("ERROR: Sampler did not write sampled image data in grayscale mode.");
            $stop;
        end

        // Commented out for the same reason as in Color Mode
        // if (dut.oled_pixel_data === 16'hxxxx) begin
        //     $display("ERROR: OLED pixel data is unknown (X) in grayscale mode.");
        //     $stop;
        // end

        $display("GRAYSCALE MODE PASS");
        $display("oled_pixel_data(gray) = %h", dut.oled_pixel_data);

        // ------------------------------------------------------------
        // Test Complete
        // ------------------------------------------------------------
        $display("========================================");
        $display("TOP BLOCK TEST PASSED");
        $display("sample_valid = %b", dut.u_cam_sampler.sample_valid);
        $display("final oled_pixel_data = %h", dut.oled_pixel_data);
        $display("========================================");

        $finish;
    end

endmodule