=========================================================================
Semiconductor School
Author: Roger Kim
Copyright (c) 2026 Roger Kim & EdgeChipLab

Program image
=========================================================================

IF_Stage.v reads its instruction memory with

    $readmemh("program_calc_full.mem", rom);

so the file the CPU runs is always named program_calc_full.mem.

Add it to the Vivado project as a Memory File. Do not rename it, and do
not give the path in the source; Vivado resolves the name against the
project, and an absolute path will not survive being moved to another
machine.

Each line is one 32-bit instruction word in hexadecimal, low address
first. The first line is the @00000000 address marker.

The image holds ten instructions. Program_Source/calc_demo_full.s is the
assembly it was built from, and the two correspond line for line.
