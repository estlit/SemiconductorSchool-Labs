# =========================================================================
# Semiconductor School
# Author: Roger Kim
# Copyright (c) 2026 Roger Kim & EdgeChipLab
#
# TinyRV32I.xdc
#   Pin assignments for the Arty S7-25.
#
#   Every port named here must match a port on FPGA_Arty_S7_Top.v. The pin
#   numbers come from the board schematic, not from the design.
# =========================================================================

## ===================================================================
## Arty S7-25 FPGA Board Constraints File (Modified for BTN2 Reset)
## ===================================================================

## 1. System Clock
set_property -dict { PACKAGE_PIN F14 IOSTANDARD LVCMOS33 } [get_ports { clk }];

## 2. Input A: 4-Bit Slide Switches [SW3 ~ SW0]
set_property -dict { PACKAGE_PIN M5  IOSTANDARD LVCMOS33 } [get_ports { i_sw[3] }];
set_property -dict { PACKAGE_PIN G18 IOSTANDARD LVCMOS33 } [get_ports { i_sw[2] }];
set_property -dict { PACKAGE_PIN H18 IOSTANDARD LVCMOS33 } [get_ports { i_sw[1] }];
set_property -dict { PACKAGE_PIN H14 IOSTANDARD LVCMOS33 } [get_ports { i_sw[0] }];

## 3. Input B: 2-Bit Push Buttons [BTN1 ~ BTN0]
set_property -dict { PACKAGE_PIN K16 IOSTANDARD LVCMOS33 } [get_ports { i_btn_b[1] }]; # BTN1
set_property -dict { PACKAGE_PIN G15 IOSTANDARD LVCMOS33 } [get_ports { i_btn_b[0] }]; # BTN0

## 4. System Reset (Moved to BTN2)
set_property -dict { PACKAGE_PIN J16 IOSTANDARD LVCMOS33 } [get_ports { i_rst_btn }]; # BTN2

## 5. Mode Select Button [BTN3]
set_property -dict { PACKAGE_PIN H13 IOSTANDARD LVCMOS33 } [get_ports { i_btn_mode }]; # BTN3

## 6. Result Output: 6-Bit LEDs [5:0]
# Upper four bits [5:2] drive the green LEDs LD5 to LD2.
set_property -dict { PACKAGE_PIN H15 IOSTANDARD LVCMOS33 } [get_ports { o_led[5] }]; # LD5
set_property -dict { PACKAGE_PIN E13 IOSTANDARD LVCMOS33 } [get_ports { o_led[4] }]; # LD4
set_property -dict { PACKAGE_PIN F13 IOSTANDARD LVCMOS33 } [get_ports { o_led[3] }]; # LD3
set_property -dict { PACKAGE_PIN E18 IOSTANDARD LVCMOS33 } [get_ports { o_led[2] }]; # LD2

# Lower two bits [1:0] drive the green pins of the RGB LEDs. 
set_property -dict { PACKAGE_PIN F18 IOSTANDARD LVCMOS33 } [get_ports { o_led[1] }]; # LD1_Green
set_property -dict { PACKAGE_PIN G17 IOSTANDARD LVCMOS33 } [get_ports { o_led[0] }]; # LD0_Green