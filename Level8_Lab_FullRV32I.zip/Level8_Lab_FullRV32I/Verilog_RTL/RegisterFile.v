// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// RegisterFile.v
//   Thirty-two registers, with write-through on read.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: RegisterFile
// Description: 32x32-bit General Purpose Register File for RV32I.
//              * [CRITICAL FIX] Implements Write-Through (Internal Forwarding)
//                to resolve Same-Cycle Read-After-Write (RAW) hazards.
// =========================================================================
module RegisterFile (
    input  wire        clk,
    input  wire        rst,
    input  wire [4:0]  rs1_addr,
    input  wire [4:0]  rs2_addr,
    input  wire [4:0]  rd_addr,
    input  wire [31:0] wb_data,
    input  wire        reg_write,
    output wire [31:0] rs1_data,
    output wire [31:0] rs2_data
);
    reg [31:0] regs [0:31];
    integer i;

    // Synchronous Write
    always @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'd0;
        end else if (reg_write && rd_addr != 5'd0) begin
            regs[rd_addr] <= wb_data;
        end
    end

    // =========================================================================
    // [FIX] Asynchronous Read with Write-Through (Internal Forwarding)
    // If a register is read and written in the exact same cycle, 
    // forward the incoming write data directly to the read port.
    // =========================================================================
    assign rs1_data = (rs1_addr == 5'd0) ? 32'd0 :
                      ((rs1_addr == rd_addr) && reg_write) ? wb_data : 
                      regs[rs1_addr];

    assign rs2_data = (rs2_addr == 5'd0) ? 32'd0 :
                      ((rs2_addr == rd_addr) && reg_write) ? wb_data : 
                      regs[rs2_addr];

endmodule
