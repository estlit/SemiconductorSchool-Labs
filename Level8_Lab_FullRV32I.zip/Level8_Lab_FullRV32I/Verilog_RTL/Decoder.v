// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Decoder.v
//   Turns one instruction word into the control signals.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: Decoder (v2.1 - Backward Compatible + Privileged Extension)
// Description: Fixed JAL alu_src signal to match standard datapath MUX.
// =========================================================================
module Decoder (
    input  wire [31:0] instr,
    
    // Original RV32I Control Signals
    output reg  [4:0]  alu_ctrl,
    output reg         alu_src,
    output reg         mem_read,
    output reg         mem_write,
    output reg         reg_write,
    output reg         branch,
    output reg         jump,
    output reg         jalr,
    output reg  [1:0]  wb_sel,
    output reg         alu_src_pc,
    output reg         is_system,

    // NEW Privileged & CSR Control Signals
    output reg         is_csr_instr,
    output reg         ecall_instr,
    output reg         ebreak_instr,
    output reg         mret_instr,
    output reg         illegal_instr
);

    wire [6:0]  opcode = instr[6:0];
    wire [2:0]  funct3 = instr[14:12];
    wire [6:0]  funct7 = instr[31:25];
    wire [11:0] funct12 = instr[31:20];

    always @(*) begin
        // Default to 0
        alu_ctrl = 5'b00000; alu_src = 0; mem_read = 0; mem_write = 0; reg_write = 0;
        branch = 0; jump = 0; jalr = 0; wb_sel = 2'b00; alu_src_pc = 0; is_system = 0;
        is_csr_instr = 0; ecall_instr = 0; ebreak_instr = 0; mret_instr = 0; illegal_instr = 0;

        case (opcode)
            7'b0110011: begin // R-Type
                reg_write = 1; alu_src = 0; wb_sel = 2'b00; alu_src_pc = 0;
                if (funct3 == 3'b000 && funct7 == 7'b0000000) alu_ctrl = 5'b00000; // ADD
                else if (funct3 == 3'b000 && funct7 == 7'b0100000) alu_ctrl = 5'b00001; // SUB
                else if (funct3 == 3'b001) alu_ctrl = 5'b00101; // SLL
                else if (funct3 == 3'b010) alu_ctrl = 5'b01000; // SLT
                else if (funct3 == 3'b011) alu_ctrl = 5'b01001; // SLTU
                else if (funct3 == 3'b100) alu_ctrl = 5'b00100; // XOR
                else if (funct3 == 3'b101 && funct7 == 7'b0000000) alu_ctrl = 5'b00110; // SRL
                else if (funct3 == 3'b101 && funct7 == 7'b0100000) alu_ctrl = 5'b00111; // SRA
                else if (funct3 == 3'b110) alu_ctrl = 5'b00011; // OR
                else if (funct3 == 3'b111) alu_ctrl = 5'b00010; // AND
                else illegal_instr = 1;
            end
            7'b0010011: begin // I-Type
                reg_write = 1; alu_src = 1; wb_sel = 2'b00; alu_src_pc = 0;
                if (funct3 == 3'b000) alu_ctrl = 5'b00000; // ADDI
                else if (funct3 == 3'b001) alu_ctrl = 5'b00101; // SLLI
                else if (funct3 == 3'b010) alu_ctrl = 5'b01000; // SLTI
                else if (funct3 == 3'b011) alu_ctrl = 5'b01001; // SLTIU
                else if (funct3 == 3'b100) alu_ctrl = 5'b00100; // XORI
                else if (funct3 == 3'b101 && funct7 == 7'b0000000) alu_ctrl = 5'b00110; // SRLI
                else if (funct3 == 3'b101 && funct7 == 7'b0100000) alu_ctrl = 5'b00111; // SRAI
                else if (funct3 == 3'b110) alu_ctrl = 5'b00011; // ORI
                else if (funct3 == 3'b111) alu_ctrl = 5'b00010; // ANDI
                else illegal_instr = 1;
            end
            7'b0000011: begin // LOAD
                reg_write = 1; alu_src = 1; mem_read = 1; wb_sel = 2'b01; alu_ctrl = 5'b00000;
            end
            7'b0100011: begin // STORE
                alu_src = 1; mem_write = 1; alu_ctrl = 5'b00000;
            end
            7'b1100011: begin // BRANCH
                branch = 1; alu_src = 0; 
                if (funct3 == 3'b000) alu_ctrl = 5'b01011; // BEQ
                else if (funct3 == 3'b001) alu_ctrl = 5'b01100; // BNE
                else if (funct3 == 3'b100) alu_ctrl = 5'b01101; // BLT
                else if (funct3 == 3'b101) alu_ctrl = 5'b01110; // BGE
                else if (funct3 == 3'b110) alu_ctrl = 5'b01111; // BLTU
                else if (funct3 == 3'b111) alu_ctrl = 5'b10000; // BGEU
                else illegal_instr = 1;
            end
            7'b0110111: begin // LUI
                reg_write = 1; alu_src = 1; wb_sel = 2'b00; alu_ctrl = 5'b01010; 
            end
            7'b0010111: begin // AUIPC
                reg_write = 1; alu_src = 1; wb_sel = 2'b00; alu_ctrl = 5'b00000; alu_src_pc = 1;
            end
            7'b1101111: begin // JAL
                // [FIXED] alu_src changed to 1 to allow Immediate through ALU MUX
                reg_write = 1; jump = 1; wb_sel = 2'b10; alu_ctrl = 5'b00000; alu_src_pc = 1; alu_src = 1;
            end
            7'b1100111: begin // JALR
                reg_write = 1; jump = 1; jalr = 1; alu_src = 1; wb_sel = 2'b10; alu_ctrl = 5'b00000;
            end
            7'b1110011: begin // SYSTEM
                is_system = 1;
                if (funct3 == 3'b000) begin
                    if (funct12 == 12'h000)      ecall_instr  = 1;
                    else if (funct12 == 12'h001) ebreak_instr = 1;
                    else if (funct12 == 12'h302) mret_instr   = 1;
                    else illegal_instr = 1;
                end else begin
                    case (funct3)
                        3'b001, 3'b010, 3'b011, 3'b101, 3'b110, 3'b111: begin
                            is_csr_instr = 1; reg_write = 1; wb_sel = 2'b11; alu_ctrl = 5'b00000;
                        end
                        default: illegal_instr = 1;
                    endcase
                end
            end
            default: illegal_instr = 1; // Catch-all
        endcase
    end
endmodule
