`timescale 1ns / 1ps

// =========================================================================
// Module: Decoder (v2.2 - Backward Compatible + Privileged + FENCE)
// Description:
//   - Fixed JAL alu_src signal to match standard datapath MUX.
//   - Added minimal RV32I FENCE support.
//   - FENCE is decoded as a legal instruction with no additional
//     architectural state update in this in-order core.
// =========================================================================
module Decoder (
    input  wire [31:0] instr,
    
    // Original RV32I Control Signals
    output reg  [4:0]  alu_ctrl,
    output reg         alu_src,
    output reg         mem_read,
    output reg         mem_write,
    output reg         reg_write,
    output reg         branch,
    output reg         jump,
    output reg         jalr,
    output reg  [1:0]  wb_sel,
    output reg         alu_src_pc,
    output reg         is_system,

    // Privileged & CSR Control Signals
    output reg         is_csr_instr,
    output reg         ecall_instr,
    output reg         ebreak_instr,
    output reg         mret_instr,
    output reg         illegal_instr
);

    wire [6:0]  opcode  = instr[6:0];
    wire [2:0]  funct3  = instr[14:12];
    wire [6:0]  funct7  = instr[31:25];
    wire [11:0] funct12 = instr[31:20];

    always @(*) begin
        // -----------------------------------------------------------------
        // Default Control Values
        // -----------------------------------------------------------------
        alu_ctrl    = 5'b00000;
        alu_src     = 1'b0;
        mem_read    = 1'b0;
        mem_write   = 1'b0;
        reg_write   = 1'b0;
        branch      = 1'b0;
        jump        = 1'b0;
        jalr        = 1'b0;
        wb_sel      = 2'b00;
        alu_src_pc  = 1'b0;
        is_system   = 1'b0;

        is_csr_instr = 1'b0;
        ecall_instr  = 1'b0;
        ebreak_instr = 1'b0;
        mret_instr   = 1'b0;
        illegal_instr = 1'b0;

        case (opcode)

            // =============================================================
            // R-Type
            // =============================================================
            7'b0110011: begin
                reg_write  = 1'b1;
                alu_src    = 1'b0;
                wb_sel     = 2'b00;
                alu_src_pc = 1'b0;

                if (funct3 == 3'b000 && funct7 == 7'b0000000)
                    alu_ctrl = 5'b00000; // ADD
                else if (funct3 == 3'b000 && funct7 == 7'b0100000)
                    alu_ctrl = 5'b00001; // SUB
                else if (funct3 == 3'b001)
                    alu_ctrl = 5'b00101; // SLL
                else if (funct3 == 3'b010)
                    alu_ctrl = 5'b01000; // SLT
                else if (funct3 == 3'b011)
                    alu_ctrl = 5'b01001; // SLTU
                else if (funct3 == 3'b100)
                    alu_ctrl = 5'b00100; // XOR
                else if (funct3 == 3'b101 && funct7 == 7'b0000000)
                    alu_ctrl = 5'b00110; // SRL
                else if (funct3 == 3'b101 && funct7 == 7'b0100000)
                    alu_ctrl = 5'b00111; // SRA
                else if (funct3 == 3'b110)
                    alu_ctrl = 5'b00011; // OR
                else if (funct3 == 3'b111)
                    alu_ctrl = 5'b00010; // AND
                else
                    illegal_instr = 1'b1;
            end

            // =============================================================
            // I-Type ALU
            // =============================================================
            7'b0010011: begin
                reg_write  = 1'b1;
                alu_src    = 1'b1;
                wb_sel     = 2'b00;
                alu_src_pc = 1'b0;

                if (funct3 == 3'b000)
                    alu_ctrl = 5'b00000; // ADDI
                else if (funct3 == 3'b001)
                    alu_ctrl = 5'b00101; // SLLI
                else if (funct3 == 3'b010)
                    alu_ctrl = 5'b01000; // SLTI
                else if (funct3 == 3'b011)
                    alu_ctrl = 5'b01001; // SLTIU
                else if (funct3 == 3'b100)
                    alu_ctrl = 5'b00100; // XORI
                else if (funct3 == 3'b101 && funct7 == 7'b0000000)
                    alu_ctrl = 5'b00110; // SRLI
                else if (funct3 == 3'b101 && funct7 == 7'b0100000)
                    alu_ctrl = 5'b00111; // SRAI
                else if (funct3 == 3'b110)
                    alu_ctrl = 5'b00011; // ORI
                else if (funct3 == 3'b111)
                    alu_ctrl = 5'b00010; // ANDI
                else
                    illegal_instr = 1'b1;
            end

            // =============================================================
            // LOAD
            // =============================================================
            7'b0000011: begin
                reg_write = 1'b1;
                alu_src   = 1'b1;
                mem_read  = 1'b1;
                wb_sel    = 2'b01;
                alu_ctrl  = 5'b00000;
            end

            // =============================================================
            // STORE
            // =============================================================
            7'b0100011: begin
                alu_src   = 1'b1;
                mem_write = 1'b1;
                alu_ctrl  = 5'b00000;
            end

            // =============================================================
            // BRANCH
            // =============================================================
            7'b1100011: begin
                branch  = 1'b1;
                alu_src = 1'b0;

                if (funct3 == 3'b000)
                    alu_ctrl = 5'b01011; // BEQ
                else if (funct3 == 3'b001)
                    alu_ctrl = 5'b01100; // BNE
                else if (funct3 == 3'b100)
                    alu_ctrl = 5'b01101; // BLT
                else if (funct3 == 3'b101)
                    alu_ctrl = 5'b01110; // BGE
                else if (funct3 == 3'b110)
                    alu_ctrl = 5'b01111; // BLTU
                else if (funct3 == 3'b111)
                    alu_ctrl = 5'b10000; // BGEU
                else
                    illegal_instr = 1'b1;
            end

            // =============================================================
            // LUI
            // =============================================================
            7'b0110111: begin
                reg_write = 1'b1;
                alu_src   = 1'b1;
                wb_sel    = 2'b00;
                alu_ctrl  = 5'b01010;
            end

            // =============================================================
            // AUIPC
            // =============================================================
            7'b0010111: begin
                reg_write  = 1'b1;
                alu_src    = 1'b1;
                wb_sel     = 2'b00;
                alu_ctrl   = 5'b00000;
                alu_src_pc = 1'b1;
            end

            // =============================================================
            // JAL
            // =============================================================
            7'b1101111: begin
                reg_write  = 1'b1;
                jump       = 1'b1;
                wb_sel     = 2'b10;
                alu_ctrl   = 5'b00000;
                alu_src_pc = 1'b1;
                alu_src    = 1'b1;
            end

            // =============================================================
            // JALR
            // =============================================================
            7'b1100111: begin
                reg_write = 1'b1;
                jump      = 1'b1;
                jalr      = 1'b1;
                alu_src   = 1'b1;
                wb_sel    = 2'b10;
                alu_ctrl  = 5'b00000;
            end

            // =============================================================
            // FENCE
            // =============================================================
            7'b0001111: begin
                if (funct3 == 3'b000) begin
                    // -----------------------------------------------------
                    // RV32I FENCE
                    //
                    // This core uses an in-order pipeline and does not
                    // contain cache, store buffer, memory reordering, or
                    // speculative memory execution.
                    //
                    // Therefore, FENCE is decoded as a legal instruction,
                    // while all architectural control outputs remain at
                    // their default inactive values.
                    //
                    // No register write
                    // No memory read/write
                    // No branch/jump
                    // No CSR update
                    // No trap
                    // -----------------------------------------------------
                end
                else begin
                    // FENCE.I and other funct3 encodings are not implemented.
                    illegal_instr = 1'b1;
                end
            end

            // =============================================================
            // SYSTEM / CSR
            // =============================================================
            7'b1110011: begin
                is_system = 1'b1;

                if (funct3 == 3'b000) begin
                    if (funct12 == 12'h000)
                        ecall_instr = 1'b1;
                    else if (funct12 == 12'h001)
                        ebreak_instr = 1'b1;
                    else if (funct12 == 12'h302)
                        mret_instr = 1'b1;
                    else
                        illegal_instr = 1'b1;
                end
                else begin
                    case (funct3)
                        3'b001,
                        3'b010,
                        3'b011,
                        3'b101,
                        3'b110,
                        3'b111: begin
                            is_csr_instr = 1'b1;
                            reg_write    = 1'b1;
                            wb_sel       = 2'b11;
                            alu_ctrl     = 5'b00000;
                        end

                        default: begin
                            illegal_instr = 1'b1;
                        end
                    endcase
                end
            end

            // =============================================================
            // Unsupported Opcode
            // =============================================================
            default: begin
                illegal_instr = 1'b1;
            end

        endcase
    end

endmodule