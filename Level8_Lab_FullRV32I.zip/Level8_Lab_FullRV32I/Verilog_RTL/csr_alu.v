// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// csr_alu.v
//   Computes the value a CSR instruction writes.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: csr_alu
// Description: Execution unit for RISC-V CSR instructions (Zicsr extension).
//              Calculates the next value to be written into a CSR based on
//              the operation type (RW, RS, RC) and the operand (rs1 or zimm).
// =========================================================================
module csr_alu (
    // Inputs from Pipeline (EX Stage) and csr_file
    input  wire [31:0] csr_rdata,  // Current value read from CSR
    input  wire [31:0] rs1_data,   // Value from GPR rs1
    input  wire [4:0]  zimm,       // 5-bit Zero-extended immediate (rs1 field)
    input  wire [2:0]  csr_op,     // CSR Operation type (funct3)
    
    // Outputs to csr_file and Pipeline (WB Stage)
    output reg  [31:0] csr_wdata,  // Next value to write to CSR
    output wire [31:0] rd_data     // Value to write back to GPR rd
);

    // ---------------------------------------------------------------------
    // RISC-V Zicsr funct3 definitions
    // ---------------------------------------------------------------------
    localparam CSRRW  = 3'b001;
    localparam CSRRS  = 3'b010;
    localparam CSRRC  = 3'b011;
    localparam CSRRWI = 3'b101;
    localparam CSRRSI = 3'b110;
    localparam CSRRCI = 3'b111;

    // ---------------------------------------------------------------------
    // 1. Determine Operand (GPR rs1 or Zero-Extended Immediate)
    // ---------------------------------------------------------------------
    wire [31:0] operand;
    // If bit 2 of funct3 is 1, use immediate. Otherwise, use rs1.
    assign operand = (csr_op[2]) ? {27'd0, zimm} : rs1_data;

    // ---------------------------------------------------------------------
    // 2. Compute Write Data for CSR
    // ---------------------------------------------------------------------
    always @(*) begin
        case (csr_op)
            CSRRW, CSRRWI: csr_wdata = operand;                         // Write exactly operand
            CSRRS, CSRRSI: csr_wdata = csr_rdata | operand;             // Set bits
            CSRRC, CSRRCI: csr_wdata = csr_rdata & (~operand);          // Clear bits
            default:       csr_wdata = csr_rdata;                       // Default: Do not modify
        endcase
    end

    // ---------------------------------------------------------------------
    // 3. Output to Destination Register (rd)
    // ---------------------------------------------------------------------
    // For all standard CSR instructions, the old CSR value is written to rd.
    assign rd_data = csr_rdata;

endmodule
