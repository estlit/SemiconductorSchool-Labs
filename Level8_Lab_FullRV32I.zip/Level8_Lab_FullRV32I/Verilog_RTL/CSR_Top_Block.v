// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// CSR_Top_Block.v
//   Instantiates the four CSR modules.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module CSR_Top_Block (
    input  wire        clk,
    input  wire        rst,

    input  wire [31:0] instr,
    input  wire        is_csr_instr,  
    input  wire [2:0]  csr_op,          
    input  wire [31:0] rs1_data,        
    input  wire        csr_write_en,    

    input  wire        ext_irq,         
    input  wire        illegal_instr_in,
    input  wire        ecall_instr,     
    input  wire        ebreak_instr,    
    input  wire        mret_instr,      
    input  wire [31:0] current_pc,      
    input  wire [31:0] instr_val,       
    
    // [NEW] Misaligned Exception Inputs
    input  wire        misaligned_load,
    input  wire        misaligned_store,
    input  wire        misaligned_jump,
    input  wire [31:0] mem_addr,
    input  wire [31:0] jump_addr,

    output wire [31:0] csr_read_data,   
    output wire        trap_req_out,    
    output wire        do_mret_out,     
    output wire        pc_override,     
    output wire [31:0] next_pc          
);

    wire [11:0] csr_addr = instr[31:20];
    wire [4:0]  rs1_zimm = instr[19:15]; 
    
    wire [31:0] current_csr_val;
    wire [31:0] next_csr_val;
    wire        illegal_csr_access;
    
    wire [31:0] mstatus_val, mie_val, mip_val, mtvec_val, mepc_val;
    wire        trap_req_internal;
    wire [31:0] trap_cause;
    wire [31:0] trap_pc_save;
    wire [31:0] trap_val_out;
    wire        mret_internal;
    
    assign trap_req_out = trap_req_internal;
    assign do_mret_out  = mret_internal;

    wire final_illegal_instr = illegal_instr_in | illegal_csr_access;

    csr_alu u_csr_alu (
        .csr_rdata (current_csr_val),
        .rs1_data  (rs1_data),
        .zimm      (rs1_zimm),
        .csr_op    (csr_op),
        .csr_wdata (next_csr_val),
        .rd_data   (csr_read_data)
    );

    csr_decode u_csr_decode (
        .csr_addr           (csr_addr),
        .is_csr_instr       (is_csr_instr),
        .csr_op             (csr_op),
        .rs1_zimm           (rs1_zimm),
        .illegal_csr_access (illegal_csr_access)
    );

    trap_ctrl u_trap_ctrl (
        .ext_irq       (ext_irq),
        .mstatus_mie   (mstatus_val[3]), 
        .mie           (mie_val),
        .mip           (mip_val),
        .mtvec         (mtvec_val),
        .mepc          (mepc_val),
        
        .illegal_instr (final_illegal_instr),
        .ecall_instr   (ecall_instr),
        .ebreak_instr  (ebreak_instr),
        .mret_instr    (mret_instr),
        .current_pc    (current_pc),
        .instr_val     (instr_val),
        
        .misaligned_load (misaligned_load),
        .misaligned_store(misaligned_store),
        .misaligned_jump (misaligned_jump),
        .mem_addr        (mem_addr),
        .jump_addr       (jump_addr),
        
        .trap_req      (trap_req_internal),
        .trap_cause    (trap_cause),
        .trap_pc_save  (trap_pc_save),
        .trap_val      (trap_val_out),
        .do_mret       (mret_internal),
        .pc_override   (pc_override),
        .next_pc       (next_pc)
    );

    wire actual_csr_write = csr_write_en & is_csr_instr & ~illegal_csr_access;

    csr_file u_csr_file (
        .clk          (clk),
        .rst          (rst),
        .csr_addr     (csr_addr),
        .csr_wdata    (next_csr_val),
        .csr_write_en (actual_csr_write),
        .csr_rdata    (current_csr_val),
        
        .trap_req     (trap_req_internal),
        .trap_cause   (trap_cause),
        .faulting_pc  (trap_pc_save),
        .trap_val     (trap_val_out),
        .mret_exec    (mret_internal),
        .ext_irq      (ext_irq),
        
        .mstatus_out  (mstatus_val),
        .mie_out      (mie_val),
        .mip_out      (mip_val),
        .mtvec_out    (mtvec_val),
        .mepc_out     (mepc_val)
    );
endmodule
