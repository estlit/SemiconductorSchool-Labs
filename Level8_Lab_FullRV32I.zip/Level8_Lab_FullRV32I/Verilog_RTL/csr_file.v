// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// csr_file.v
//   The eight control and status registers.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: csr_file (v2.0)
// Description: Upgraded M-Mode Control & Status Register Storage.
//              Provides dedicated parallel output ports for real-time 
//              trap prioritization and interrupt masking in trap_ctrl.v.
// =========================================================================
module csr_file (
    input  wire        clk,
    input  wire        rst,

    // Software CSR Instruction Interface (Muxed)
    input  wire [11:0] csr_addr,
    input  wire [31:0] csr_wdata,
    input  wire        csr_write_en,
    output reg  [31:0] csr_rdata,

    // Hardware Trap/Interrupt Interface (From trap_ctrl)
    input  wire        trap_req,
    input  wire [31:0] trap_cause,
    input  wire [31:0] faulting_pc,
    input  wire [31:0] trap_val,
    input  wire        mret_exec,
    
    // External Signals
    input  wire        ext_irq,

    // [NEW v2.0] Dedicated Parallel Monitoring Ports for trap_ctrl.v
    output wire [31:0] mstatus_out,
    output wire [31:0] mie_out,
    output wire [31:0] mip_out,
    output wire [31:0] mtvec_out,
    output wire [31:0] mepc_out
);

    // RISC-V Standard M-Mode CSR Addresses
    localparam ADDR_MSTATUS  = 12'h300;
    localparam ADDR_MIE      = 12'h304;
    localparam ADDR_MTVEC    = 12'h305;
    localparam ADDR_MSCRATCH = 12'h340;
    localparam ADDR_MEPC     = 12'h341;
    localparam ADDR_MCAUSE   = 12'h342;
    localparam ADDR_MTVAL    = 12'h343;
    localparam ADDR_MIP      = 12'h344;

    // Architectural Registers
    reg [31:0] mstatus;
    reg [31:0] mie;
    reg [31:0] mtvec;
    reg [31:0] mscratch;
    reg [31:0] mepc;
    reg [31:0] mcause;
    reg [31:0] mtval;
    reg [31:0] mip;

    // =====================================================================
    // [NEW v2.0] Continuous Parallel Assignments
    // =====================================================================
    assign mstatus_out = mstatus;
    assign mie_out     = mie;
    assign mip_out     = mip;
    assign mtvec_out   = mtvec;
    assign mepc_out    = mepc;

    // =====================================================================
    // 1. Asynchronous Read Logic (Muxed Read Data)
    // =====================================================================
    always @(*) begin
        case (csr_addr)
            ADDR_MSTATUS:  csr_rdata = mstatus;
            ADDR_MIE:      csr_rdata = mie;
            ADDR_MTVEC:    csr_rdata = mtvec;
            ADDR_MSCRATCH: csr_rdata = mscratch;
            ADDR_MEPC:     csr_rdata = mepc;
            ADDR_MCAUSE:   csr_rdata = mcause;
            ADDR_MTVAL:    csr_rdata = mtval;
            ADDR_MIP:      csr_rdata = mip;
            default:       csr_rdata = 32'd0;
        endcase
    end

    // =====================================================================
    // 2. Synchronous Write & Hardware Update Logic
    // =====================================================================
    always @(posedge clk) begin
        if (rst) begin
            mstatus  <= 32'h00001800; // MPP = 2'b11 (Machine Mode) initially
            mie      <= 32'd0;
            mtvec    <= 32'd0;
            mscratch <= 32'd0;
            mepc     <= 32'd0;
            mcause   <= 32'd0;
            mtval    <= 32'd0;
            mip      <= 32'd0;
        end else begin
            // Mirror external interrupt line asynchronously into MIP
            mip[11] <= ext_irq; 

            // Priority 1: Hardware Trap Entry
            if (trap_req) begin
                mepc           <= faulting_pc;
                mcause         <= trap_cause;
                mtval          <= trap_val;
                mstatus[7]     <= mstatus[3]; // MPIE <- MIE
                mstatus[3]     <= 1'b0;       // Disable MIE
                mstatus[12:11] <= 2'b11;     // MPP <- M-Mode
            end
            // Priority 2: Trap Return (MRET)
            else if (mret_exec) begin
                mstatus[3]     <= mstatus[7]; // MIE <- MPIE
                mstatus[7]     <= 1'b1;       // MPIE <- 1
                mstatus[12:11] <= 2'b11;     // Maintain M-Mode
            end
            // Priority 3: Software CSR Write Instruction
            else if (csr_write_en) begin
                case (csr_addr)
                    ADDR_MSTATUS: begin
                        mstatus[3]     <= csr_wdata[3];    // MIE
                        mstatus[7]     <= csr_wdata[7];    // MPIE
                        mstatus[12:11] <= csr_wdata[12:11]; // MPP
                    end
                    ADDR_MIE:      mie      <= csr_wdata;
                    ADDR_MTVEC:    mtvec    <= csr_wdata;
                    ADDR_MSCRATCH: mscratch <= csr_wdata;
                    ADDR_MEPC:     mepc     <= {csr_wdata[31:2], 2'b00}; // Enforce alignment
                    ADDR_MCAUSE:   mcause   <= csr_wdata;
                    ADDR_MTVAL:    mtval    <= csr_wdata;
                endcase
            end
        end
    end

endmodule
