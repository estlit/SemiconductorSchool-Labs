// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Forwarding_Unit.v
//   Chooses which stage supplies each operand.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
// ============================================================================
// Module      : Forwarding_Unit
// Description : Bypass logic to resolve Data Dependency (RAW Hazard).
//               Controls ALU input MUXes to forward data from MEM or WB stages.
// ============================================================================
module Forwarding_Unit (
    input  wire [4:0] ex_rs1,       // Source register 1 required in EX stage
    input  wire [4:0] ex_rs2,       // Source register 2 required in EX stage
    
    input  wire [4:0] mem_rd,       // Destination register in MEM stage
    input  wire       mem_regwrite, // Register write enable in MEM stage
    
    input  wire [4:0] wb_rd,        // Destination register in WB stage
    input  wire       wb_regwrite,  // Register write enable in WB stage

    output reg  [1:0] forward_a,    // MUX control for ALU input A
    output reg  [1:0] forward_b     // MUX control for ALU input B
);

    always @(*) begin
        // Default: No forwarding (Use original register value)
        forward_a = 2'b00;
        forward_b = 2'b00;

        // -------------------------------------------------------------
        // Forwarding logic for ALU input A (rs1)
        // -------------------------------------------------------------
        // Priority 1: EX Hazard (Data from MEM stage is the most recent)
        if (mem_regwrite && (mem_rd != 5'b00000) && (mem_rd == ex_rs1)) begin
            forward_a = 2'b10;
        end
        // Priority 2: MEM Hazard (Data from WB stage)
        else if (wb_regwrite && (wb_rd != 5'b00000) && (wb_rd == ex_rs1)) begin
            forward_a = 2'b01;
        end

        // -------------------------------------------------------------
        // Forwarding logic for ALU input B (rs2)
        // -------------------------------------------------------------
        if (mem_regwrite && (mem_rd != 5'b00000) && (mem_rd == ex_rs2)) begin
            forward_b = 2'b10;
        end
        else if (wb_regwrite && (wb_rd != 5'b00000) && (wb_rd == ex_rs2)) begin
            forward_b = 2'b01;
        end
    end
endmodule
