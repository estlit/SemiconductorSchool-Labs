// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// ALU.v
//   Seventeen operations, selected by a five-bit control field.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module ALU (
    input  wire [31:0] alu_in_a,    // Operand A from Register File (rs1) or Forwarding Unit
    input  wire [31:0] alu_in_b,    // Operand B from Register File (rs2), Forwarding, or ImmGen
    input  wire [4:0]  alu_ctrl,    // 5-bit ALU control signal (Expanded for RV32I Full ISA)
    output reg  [31:0] alu_result,  // 32-bit computation result
    output wire        zero         // Zero flag for Branch condition resolution
);

    // ALU Operation Codes (Expanded to 5 bits to support up to 32 operations)
    localparam ALU_ADD     = 5'b00000;
    localparam ALU_SUB     = 5'b00001;
    localparam ALU_AND     = 5'b00010;
    localparam ALU_OR      = 5'b00011;
    localparam ALU_XOR     = 5'b00100;
    
    // Shift Operations (Barrel Shifter mapped by Synthesizer)
    localparam ALU_SLL     = 5'b00101; // Shift Left Logical
    localparam ALU_SRL     = 5'b00110; // Shift Right Logical
    localparam ALU_SRA     = 5'b00111; // Shift Right Arithmetic
    
    // Set Less Than Operations (Comparators)
    localparam ALU_SLT     = 5'b01000; // Set Less Than (Signed)
    localparam ALU_SLTU    = 5'b01001; // Set Less Than (Unsigned)
    
    // Data Routing
    localparam ALU_PASS_B  = 5'b01010; // Pass Operand B directly (For LUI)

    // Full Branch Condition Evaluations 
    // (Outputs 0 to assert the 'zero' flag based on the existing architectural convention)
    localparam ALU_CMP_EQ  = 5'b01011; // BEQ
    localparam ALU_CMP_NE  = 5'b01100; // BNE
    localparam ALU_CMP_LT  = 5'b01101; // BLT  (Signed Less Than)
    localparam ALU_CMP_GE  = 5'b01110; // BGE  (Signed Greater or Equal)
    localparam ALU_CMP_LTU = 5'b01111; // BLTU (Unsigned Less Than)
    localparam ALU_CMP_GEU = 5'b10000; // BGEU (Unsigned Greater or Equal)

    // Combinational logic for ALU arithmetic, logical, shift, and comparison operations
    always @(*) begin
        case (alu_ctrl)
            // Basic Arithmetic & Logical
            ALU_ADD:     alu_result = alu_in_a + alu_in_b;
            ALU_SUB:     alu_result = alu_in_a - alu_in_b;
            ALU_AND:     alu_result = alu_in_a & alu_in_b;
            ALU_OR:      alu_result = alu_in_a | alu_in_b;
            ALU_XOR:     alu_result = alu_in_a ^ alu_in_b;
            
            // Shift Operations 
            // Note: Only the lower 5 bits of operand B [4:0] are used for shift amount in RV32I
            ALU_SLL:     alu_result = alu_in_a << alu_in_b[4:0];
            ALU_SRL:     alu_result = alu_in_a >> alu_in_b[4:0];
            // SRA requires arithmetic shift operator (>>>) and signed casting
            ALU_SRA:     alu_result = $signed(alu_in_a) >>> alu_in_b[4:0];
            
            // Set Less Than Operations
            // 1 if true, 0 if false (Writes to rd)
            ALU_SLT:     alu_result = ($signed(alu_in_a) < $signed(alu_in_b)) ? 32'd1 : 32'd0;
            ALU_SLTU:    alu_result = (alu_in_a < alu_in_b) ? 32'd1 : 32'd0;
            
            // Pass Through Operand B
            ALU_PASS_B:  alu_result = alu_in_b; 

            // Full Branch Condition Evaluations 
            // Outputs 0 if condition is met, so the 'assign zero' below works properly
            ALU_CMP_EQ:  alu_result = (alu_in_a == alu_in_b) ? 32'd0 : 32'd1;
            ALU_CMP_NE:  alu_result = (alu_in_a != alu_in_b) ? 32'd0 : 32'd1;
            ALU_CMP_LT:  alu_result = ($signed(alu_in_a) < $signed(alu_in_b)) ? 32'd0 : 32'd1;
            ALU_CMP_GE:  alu_result = ($signed(alu_in_a) >= $signed(alu_in_b)) ? 32'd0 : 32'd1;
            ALU_CMP_LTU: alu_result = (alu_in_a < alu_in_b) ? 32'd0 : 32'd1;
            ALU_CMP_GEU: alu_result = (alu_in_a >= alu_in_b) ? 32'd0 : 32'd1;

            default:     alu_result = 32'd0; // Default to 0 to prevent inferred latches
        endcase
    end

    // The zero flag is asserted strictly when the ALU result is exactly 0.
    // This flag is routed to the Hazard & Branch Unit to determine if a branch is taken.
    assign zero = (alu_result == 32'd0) ? 1'b1 : 1'b0;

endmodule
