// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// MEM_MMIO_Decoder.v
//   Splits memory accesses from device accesses.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: MEM_MMIO_Decoder (v2.2 - Sub-word Store Alignment)
// Description: Generates 4-bit write enable and aligned write data for SB/SH/SW
// =========================================================================
module MEM_MMIO_Decoder (
    input  wire [31:0] mem_instr,  // [NEW] To extract funct3 for Store size
    input  wire [31:0] alu_result, // Treated as Address
    input  wire [31:0] rs2_data,   // Data to write
    input  wire        mem_read,
    input  wire        mem_write,
    
    // Inputs from All Peripherals (Ready/Valid Handshake)
    input  wire        peri_board_ready,
    input  wire        peri_sonar_ready,
    input  wire        peri_camera_ready,
    input  wire        peri_npu_ready,
    input  wire        peri_oled_ready,
    input  wire        peri_motor_ready,
    
    // Outputs to Data RAM
    output wire        ram_en,
    output reg  [3:0]  ram_we,     // [FIX] Changed to 4-bit Byte Enable
    output wire [31:0] ram_addr,
    output reg  [31:0] ram_wdata,  // [FIX] Aligned Data
    
    // Outputs to MMIO Peripherals
    output wire        mmio_valid,
    output wire        mmio_write,
    output wire [31:0] mmio_addr,
    output wire [31:0] mmio_wdata,
    
    // Specific Peripheral Select Signals
    output reg         cs_board_io,
    output reg         cs_sonar,
    output reg         cs_camera,
    output reg         cs_npu,
    output reg         cs_oled,
    output reg         cs_motor,
    
    // Output to Pipeline Control
    output wire        system_stall
);

    wire is_mmio = (alu_result[31:30] == 2'b01);
    
    assign ram_en    = !is_mmio & (mem_read | mem_write);
    assign ram_addr  = alu_result;
    
    assign mmio_valid = is_mmio & (mem_read | mem_write);
    assign mmio_write = mem_write;
    assign mmio_addr  = alu_result;
    assign mmio_wdata = rs2_data;

    // =========================================================
    // [CRITICAL FIX] Sub-word Store Alignment (SB, SH, SW)
    // =========================================================
    wire [2:0] funct3      = mem_instr[14:12];
    wire [1:0] byte_offset = alu_result[1:0];

    always @(*) begin
        ram_we    = 4'b0000;
        ram_wdata = rs2_data; 
        
        if (!is_mmio && mem_write) begin
            case (funct3)
                3'b000: begin // SB (Store Byte)
                    ram_wdata = {4{rs2_data[7:0]}}; // Replicate byte to all lanes
                    case (byte_offset)
                        2'b00: ram_we = 4'b0001;
                        2'b01: ram_we = 4'b0010;
                        2'b10: ram_we = 4'b0100;
                        2'b11: ram_we = 4'b1000;
                    endcase
                end
                3'b001: begin // SH (Store Halfword)
                    ram_wdata = {2{rs2_data[15:0]}}; // Replicate halfword
                    case (byte_offset[1])
                        1'b0: ram_we = 4'b0011;
                        1'b1: ram_we = 4'b1100;
                    endcase
                end
                3'b010: begin // SW (Store Word)
                    ram_wdata = rs2_data;
                    ram_we    = 4'b1111;
                end
                default: ram_we = 4'b0000;
            endcase
        end
    end

    // MMIO Peripheral Decoding 
    always @(*) begin
        cs_board_io = 1'b0; cs_sonar = 1'b0; cs_camera = 1'b0;
        cs_npu      = 1'b0; cs_oled  = 1'b0; cs_motor  = 1'b0;

        if (is_mmio && (mem_read || mem_write)) begin
            case (alu_result[15:8])
                8'h00: cs_board_io = 1'b1; 
                8'h01: cs_sonar    = 1'b1; 
                8'h10: cs_camera   = 1'b1; 
                8'h20: cs_npu      = 1'b1; 
                8'h30: cs_oled     = 1'b1; 
                8'h40: cs_motor    = 1'b1; 
                default: ; 
            endcase
        end
    end

    assign system_stall = 
        (cs_board_io & ~peri_board_ready) |
        (cs_sonar    & ~peri_sonar_ready) |
        (cs_camera   & ~peri_camera_ready)|
        (cs_npu      & ~peri_npu_ready)   |
        (cs_oled     & ~peri_oled_ready)  |
        (cs_motor    & ~peri_motor_ready);

endmodule
