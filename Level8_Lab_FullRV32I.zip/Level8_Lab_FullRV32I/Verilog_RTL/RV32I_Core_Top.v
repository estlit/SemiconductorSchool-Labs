// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// RV32I_Core_Top.v
//   The five-stage core.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: RV32I_Core_Top (v3.2 - Absolute 100% Perfect Edition)
// Description: Fully Integrated Top-level RV32I Processor Core.
//              * [TRUE FINAL FIX] Corrected JAL vs JALR target address routing
//                to ensure proper mtval exception reporting.
// =========================================================================
module RV32I_Core_Top (
    input  wire        clk,
    input  wire        rst,               
    input  wire        ext_irq,           
    
    input  wire        peri_board_ready,
    input  wire        peri_sonar_ready,
    input  wire        peri_camera_ready,
    input  wire        peri_npu_ready,
    input  wire        peri_oled_ready,
    input  wire        peri_motor_ready,
    
    output wire        cs_board_io,
    output wire        cs_sonar,
    output wire        cs_camera,
    output wire        cs_npu,
    output wire        cs_oled,
    output wire        cs_motor,
    
    output wire        mmio_valid,
    output wire        mmio_write,
    output wire [31:0] mmio_addr,
    output wire [31:0] mmio_wdata,
    input  wire [31:0] mmio_rdata         
);

    wire        system_stall;
    wire [31:0] if_instr, id_instr, ex_instr, mem_instr, wb_instr;
    wire [31:0] if_pc, id_pc, ex_pc, mem_pc, wb_pc;
    
    wire [31:0] id_rs1_data, id_rs2_data, ex_rs1_data, ex_rs2_data, mem_rs2_data, wb_data;
    wire [31:0] id_imm, ex_imm;
    wire [31:0] ex_alu_result, mem_alu_result, wb_alu_result;
    
    wire [31:0] ex_csr_read_data, mem_csr_read_data, wb_csr_read_data;

    wire [4:0]  id_alu_ctrl, ex_alu_ctrl;
    wire        id_alu_src, ex_alu_src;
    wire        id_mem_read, ex_mem_read, mem_mem_read;
    wire        id_mem_write, ex_mem_write, mem_mem_write;
    wire        id_reg_write, ex_reg_write, mem_reg_write, wb_reg_write;
    wire        id_branch, ex_branch;
    
    wire        id_jump, ex_jump;
    wire        id_jalr, ex_jalr;
    wire [1:0]  id_wb_sel, ex_wb_sel, mem_wb_sel, wb_wb_sel;
    wire        id_alu_src_pc, ex_alu_src_pc;
    wire        id_is_system, ex_is_system, mem_is_system, wb_is_system;

    wire        id_is_csr_instr, ex_is_csr_instr;
    wire        id_ecall_instr, ex_ecall_instr;
    wire        id_ebreak_instr, ex_ebreak_instr;
    wire        id_mret_instr, ex_mret_instr;
    wire        id_illegal_instr, ex_illegal_instr;

    wire        ex_zero_flag;
    wire        ram_en;
    wire [3:0]  ram_we; 
    wire [31:0] ram_addr, ram_wdata, mem_read_data, wb_read_data;

    wire [4:0] id_rs1_addr = id_instr[19:15];
    wire [4:0] id_rs2_addr = id_instr[24:20];
    wire [4:0] ex_rs1_addr = ex_instr[19:15];
    wire [4:0] ex_rs2_addr = ex_instr[24:20];
    wire [4:0] ex_rd_addr  = ex_instr[11:7];
    wire [4:0] mem_rd_addr = mem_instr[11:7];
    wire [4:0] wb_rd_addr  = wb_instr[11:7];

    wire pc_write, if_id_write, ctrl_mux;

    Hazard_Detection_Unit HDU (
        .id_rs1      (id_rs1_addr),
        .id_rs2      (id_rs2_addr),
        .ex_rd       (ex_rd_addr),
        .ex_memread  (ex_mem_read),
        .ext_stall   (system_stall),
        .pc_write    (pc_write),
        .if_id_write (if_id_write),
        .ctrl_mux    (ctrl_mux)
    );

    wire [1:0] forward_a, forward_b;
    
    Forwarding_Unit FWU (
        .ex_rs1      (ex_rs1_addr),
        .ex_rs2      (ex_rs2_addr),
        .mem_rd      (mem_rd_addr),
        .mem_regwrite(mem_reg_write),
        .wb_rd       (wb_rd_addr),
        .wb_regwrite (wb_reg_write),
        .forward_a   (forward_a),
        .forward_b   (forward_b)
    );

    wire        hbu_branch_taken;
    wire [31:0] hbu_branch_target;
    wire        hbu_pipe_flush;
    wire        hbu_pipe_stall;

    Hazard_Branch_Unit u_Hazard_Branch (
        .ex_pc        (ex_pc),
        .ex_imm       (ex_imm),
        .ex_branch    (ex_branch),
        .ex_zero_flag (ex_zero_flag),
        .system_stall (system_stall),
        .branch_target(hbu_branch_target),
        .branch_taken (hbu_branch_taken),
        .pipe_stall   (hbu_pipe_stall),
        .pipe_flush   (hbu_pipe_flush)
    );

    // =========================================================
    // [TRUE FINAL FIX] Trap Control & Branch Routing Masking
    // =========================================================
    wire        trap_req_out, do_mret_out, csr_pc_override;
    wire [31:0] csr_next_pc;

    wire        raw_branch_taken  = hbu_branch_taken | ex_jump;
    
    // Only JALR takes its target from the ALU; JAL and branches take theirs
    // from the Hazard_Branch_Unit.
    wire [31:0] raw_branch_target = (ex_jalr) ? {ex_alu_result[31:1], 1'b0} : hbu_branch_target;
    
    wire        ex_misaligned_jump = raw_branch_taken & (raw_branch_target[1:0] != 2'b00);

    wire        final_branch_taken  = raw_branch_taken & ~ex_misaligned_jump;
    wire [31:0] final_branch_target = raw_branch_target;
    
    wire        final_trap_override = trap_req_out | do_mret_out | csr_pc_override;
    wire        trap_flush = trap_req_out | do_mret_out;
    wire        final_pipe_flush    = hbu_pipe_flush | ex_jump | trap_flush;

    IF_Stage u_IF_Stage (
        .clk          (clk),
        .rst          (rst),
        .stall        (~pc_write),
        .branch_taken (final_branch_taken),
        .branch_target(final_branch_target),
        .trap_override(final_trap_override),  
        .trap_pc      (csr_next_pc),
        .pc           (if_pc),
        .instr        (if_instr)
    );

    IF_ID_Reg u_IF_ID (
        .clk     (clk),
        .rst     (rst),
        .stall   (~if_id_write),
        .flush   (final_pipe_flush),
        .if_pc   (if_pc),
        .if_instr(if_instr),
        .id_pc   (id_pc),
        .id_instr(id_instr)
    );

    RegisterFile u_RegFile (
        .clk      (clk),
        .rst      (rst),
        .rs1_addr (id_rs1_addr),
        .rs2_addr (id_rs2_addr),
        .rd_addr  (wb_rd_addr),
        .wb_data  (wb_data),  
        .reg_write(wb_reg_write),
        .rs1_data (id_rs1_data),
        .rs2_data (id_rs2_data)
    );

    ImmGen u_ImmGen (
        .instr(id_instr),
        .imm  (id_imm)
    );

    Decoder u_Decoder (
        .instr        (id_instr),
        .alu_ctrl     (id_alu_ctrl),
        .alu_src      (id_alu_src),
        .mem_read     (id_mem_read),
        .mem_write    (id_mem_write),
        .reg_write    (id_reg_write),
        .branch       (id_branch),
        .jump         (id_jump),        
        .jalr         (id_jalr),        
        .wb_sel       (id_wb_sel),      
        .alu_src_pc   (id_alu_src_pc),  
        .is_system    (id_is_system),
        .is_csr_instr (id_is_csr_instr),
        .ecall_instr  (id_ecall_instr),
        .ebreak_instr (id_ebreak_instr),
        .mret_instr   (id_mret_instr),
        .illegal_instr(id_illegal_instr)
    );

    wire id_ex_flush = final_pipe_flush | ~ctrl_mux;

    ID_EX_Reg u_ID_EX (
        .clk          (clk),
        .rst          (rst),
        .stall        (system_stall),
        .flush        (id_ex_flush),
        .id_pc        (id_pc),
        .id_instr     (id_instr),
        .id_rs1_data  (id_rs1_data),
        .id_rs2_data  (id_rs2_data),
        .id_imm       (id_imm),
        
        .id_alu_ctrl  (id_alu_ctrl),
        .id_alu_src   (id_alu_src),
        .id_alu_src_pc(id_alu_src_pc),
        .id_branch    (id_branch),
        .id_jump      (id_jump),
        .id_jalr      (id_jalr),
        .id_mem_read  (id_mem_read),
        .id_mem_write (id_mem_write),
        .id_reg_write (id_reg_write),
        .id_wb_sel    (id_wb_sel),
        .id_is_system (id_is_system),
        
        .id_is_csr_instr (id_is_csr_instr),
        .id_csr_op       (id_instr[14:12]),
        .id_ecall_instr  (id_ecall_instr),
        .id_ebreak_instr (id_ebreak_instr),
        .id_mret_instr   (id_mret_instr),
        .id_illegal_instr(id_illegal_instr),
        .id_raw_instr    (id_instr),
        
        .ex_pc        (ex_pc),
        .ex_instr     (ex_instr),
        .ex_rs1_data  (ex_rs1_data),
        .ex_rs2_data  (ex_rs2_data),
        .ex_imm       (ex_imm),
        
        .ex_alu_ctrl  (ex_alu_ctrl),
        .ex_alu_src   (ex_alu_src),
        .ex_alu_src_pc(ex_alu_src_pc),
        .ex_branch    (ex_branch),
        .ex_jump      (ex_jump),
        .ex_jalr      (ex_jalr),
        .ex_mem_read  (ex_mem_read),
        .ex_mem_write (ex_mem_write),
        .ex_reg_write (ex_reg_write),
        .ex_wb_sel    (ex_wb_sel),
        .ex_is_system (ex_is_system),
        
        .ex_is_csr_instr (ex_is_csr_instr),
        .ex_csr_op       (), 
        .ex_ecall_instr  (ex_ecall_instr),
        .ex_ebreak_instr (ex_ebreak_instr),
        .ex_mret_instr   (ex_mret_instr),
        .ex_illegal_instr(ex_illegal_instr),
        .ex_raw_instr    () 
    );

    wire [31:0] mem_forward_data = (mem_wb_sel == 2'b11) ? mem_csr_read_data :  
                                   (mem_wb_sel == 2'b10) ? (mem_pc + 32'd4) :   
                                   (mem_wb_sel == 2'b01) ? mem_read_data :      
                                                           mem_alu_result;

    wire [31:0] wb_forward_data  = (wb_wb_sel == 2'b11) ? wb_csr_read_data :    
                                   (wb_wb_sel == 2'b10) ? (wb_pc + 32'd4) :     
                                   (wb_wb_sel == 2'b01) ? wb_read_data :  
                                                          wb_alu_result;

    reg [31:0] fwd_alu_in_a;
    always @(*) begin
        if      (forward_a == 2'b10) fwd_alu_in_a = mem_forward_data;
        else if (forward_a == 2'b01) fwd_alu_in_a = wb_forward_data;  
        else                         fwd_alu_in_a = ex_rs1_data;
    end

    wire [31:0] ex_alu_in_a = (ex_alu_src_pc) ? ex_pc : fwd_alu_in_a;

    reg [31:0] ex_rs2_data_fwd;
    always @(*) begin
        if      (forward_b == 2'b10) ex_rs2_data_fwd = mem_forward_data;
        else if (forward_b == 2'b01) ex_rs2_data_fwd = wb_forward_data;
        else                         ex_rs2_data_fwd = ex_rs2_data;
    end

    wire [31:0] ex_alu_in_b = (ex_alu_src) ? ex_imm : ex_rs2_data_fwd;

    ALU u_ALU (
        .alu_in_a  (ex_alu_in_a),
        .alu_in_b  (ex_alu_in_b),
        .alu_ctrl  (ex_alu_ctrl),
        .alu_result(ex_alu_result),
        .zero      (ex_zero_flag)
    );

    wire [2:0] ex_funct3 = ex_instr[14:12];
    wire ex_is_half = (ex_funct3 == 3'b001) || (ex_funct3 == 3'b101);
    wire ex_is_word = (ex_funct3 == 3'b010);
    
    wire ex_misaligned = (ex_is_word & (ex_alu_result[1:0] != 2'b00)) |
                         (ex_is_half & (ex_alu_result[0]   != 1'b0));

    wire ex_misaligned_load  = ex_mem_read  & ex_misaligned;
    wire ex_misaligned_store = ex_mem_write & ex_misaligned;

    CSR_Top_Block u_CSR (
        .clk              (clk),
        .rst              (rst),
        .instr            (ex_instr),
        .is_csr_instr     (ex_is_csr_instr),
        .csr_op           (ex_instr[14:12]),
        .rs1_data         (fwd_alu_in_a),
        .csr_write_en     (ex_reg_write & ex_is_csr_instr),
        .ext_irq          (ext_irq),
        
        .illegal_instr_in (ex_illegal_instr),
        .ecall_instr      (ex_ecall_instr),
        .ebreak_instr     (ex_ebreak_instr),
        .mret_instr       (ex_mret_instr),
        .current_pc       (ex_pc),
        .instr_val        (ex_instr),
        
        .misaligned_load  (ex_misaligned_load),
        .misaligned_store (ex_misaligned_store),
        .misaligned_jump  (ex_misaligned_jump), 
        .mem_addr         (ex_alu_result),
        .jump_addr        (final_branch_target), 
        
        .csr_read_data    (ex_csr_read_data),
        .trap_req_out     (trap_req_out),
        .do_mret_out      (do_mret_out),
        .pc_override      (csr_pc_override),
        .next_pc          (csr_next_pc)
    );

    wire safe_mem_read  = ex_mem_read  & ~trap_req_out;
    wire safe_mem_write = ex_mem_write & ~trap_req_out;
    wire safe_reg_write = ex_reg_write & ~trap_req_out;

    EX_MEM_Reg u_EX_MEM (
        .clk          (clk),
        .rst          (rst),
        .stall        (system_stall),
        
        .ex_pc        (ex_pc),       
        .ex_instr     (ex_instr),
        .ex_alu_result(ex_alu_result),
        .ex_rs2_data  (ex_rs2_data_fwd),
        
        .ex_mem_read  (safe_mem_read),
        .ex_mem_write (safe_mem_write),
        .ex_reg_write (safe_reg_write),
        
        .ex_wb_sel    (ex_wb_sel),
        .ex_is_system (ex_is_system),
        .ex_csr_rdata (ex_csr_read_data),
        
        .mem_pc        (mem_pc),
        .mem_instr     (mem_instr),
        .mem_alu_result(mem_alu_result),
        .mem_rs2_data  (mem_rs2_data),
        .mem_mem_read  (mem_mem_read),
        .mem_mem_write (mem_mem_write),
        .mem_reg_write (mem_reg_write),
        .mem_wb_sel    (mem_wb_sel),
        .mem_is_system (mem_is_system),
        .mem_csr_rdata (mem_csr_read_data)
    );

    MEM_MMIO_Decoder u_MEM_MMIO_Decoder (
        .mem_instr        (mem_instr),     
        .alu_result       (mem_alu_result),
        .rs2_data         (mem_rs2_data),
        .mem_read         (mem_mem_read),
        .mem_write        (mem_mem_write),
        
        .peri_board_ready (peri_board_ready),
        .peri_sonar_ready (peri_sonar_ready),
        .peri_camera_ready(peri_camera_ready),
        .peri_npu_ready   (peri_npu_ready),
        .peri_oled_ready  (peri_oled_ready),
        .peri_motor_ready (peri_motor_ready),
        
        .ram_en           (ram_en),
        .ram_we           (ram_we),        
        .ram_addr         (ram_addr),
        .ram_wdata        (ram_wdata),
        .mmio_valid       (mmio_valid),
        .mmio_write       (mmio_write),
        .mmio_addr        (mmio_addr),
        .mmio_wdata       (mmio_wdata),
        
        .cs_board_io      (cs_board_io),
        .cs_sonar         (cs_sonar),
        .cs_camera        (cs_camera),
        .cs_npu           (cs_npu),
        .cs_oled          (cs_oled),
        .cs_motor         (cs_motor),
        .system_stall     (system_stall)
    );

    wire [11:0] ram_idx = { ~ram_addr[13], ram_addr[12:2] };
    reg [31:0] data_ram [0:4095];

    always @(posedge clk) begin
        if (ram_en) begin
            if (ram_we[0]) data_ram[ram_idx][7:0]   <= ram_wdata[7:0];
            if (ram_we[1]) data_ram[ram_idx][15:8]  <= ram_wdata[15:8];
            if (ram_we[2]) data_ram[ram_idx][23:16] <= ram_wdata[23:16];
            if (ram_we[3]) data_ram[ram_idx][31:24] <= ram_wdata[31:24];
        end
    end
    
    wire [31:0] async_ram_data = data_ram[ram_idx];
    wire is_mem_mmio = (mem_alu_result[31:30] == 2'b01);
    wire [31:0] raw_mem_read_data = is_mem_mmio ? mmio_rdata : async_ram_data;

    wire [2:0] mem_load_funct3 = mem_instr[14:12];
    wire [1:0] mem_load_offset = mem_alu_result[1:0];
    reg  [31:0] aligned_mem_read_data;

    always @(*) begin
        if (mem_mem_read) begin
            case (mem_load_funct3)
                3'b000: begin 
                    case (mem_load_offset)
                        2'b00: aligned_mem_read_data = {{24{raw_mem_read_data[7]}},  raw_mem_read_data[7:0]};
                        2'b01: aligned_mem_read_data = {{24{raw_mem_read_data[15]}}, raw_mem_read_data[15:8]};
                        2'b10: aligned_mem_read_data = {{24{raw_mem_read_data[23]}}, raw_mem_read_data[23:16]};
                        2'b11: aligned_mem_read_data = {{24{raw_mem_read_data[31]}}, raw_mem_read_data[31:24]};
                    endcase
                end
                3'b100: begin 
                    case (mem_load_offset)
                        2'b00: aligned_mem_read_data = {24'd0, raw_mem_read_data[7:0]};
                        2'b01: aligned_mem_read_data = {24'd0, raw_mem_read_data[15:8]};
                        2'b10: aligned_mem_read_data = {24'd0, raw_mem_read_data[23:16]};
                        2'b11: aligned_mem_read_data = {24'd0, raw_mem_read_data[31:24]};
                    endcase
                end
                3'b001: begin 
                    case (mem_load_offset[1])
                        1'b0: aligned_mem_read_data = {{16{raw_mem_read_data[15]}}, raw_mem_read_data[15:0]};
                        1'b1: aligned_mem_read_data = {{16{raw_mem_read_data[31]}}, raw_mem_read_data[31:16]};
                    endcase
                end
                3'b101: begin 
                    case (mem_load_offset[1])
                        1'b0: aligned_mem_read_data = {16'd0, raw_mem_read_data[15:0]};
                        1'b1: aligned_mem_read_data = {16'd0, raw_mem_read_data[31:16]};
                    endcase
                end
                3'b010: begin 
                    aligned_mem_read_data = raw_mem_read_data;
                end
                default: aligned_mem_read_data = raw_mem_read_data;
            endcase
        end else begin
            aligned_mem_read_data = raw_mem_read_data;
        end
    end

    assign mem_read_data = aligned_mem_read_data;

    MEM_WB_Reg u_MEM_WB (
        .clk          (clk), 
        .rst          (rst), 
        .stall        (system_stall),
        
        .mem_pc        (mem_pc),     
        .mem_instr     (mem_instr),   
        .mem_alu_result(mem_alu_result), 
        .mem_read_data (mem_read_data), 
        .mem_reg_write (mem_reg_write), 
        .mem_wb_sel    (mem_wb_sel),
        .mem_is_system (mem_is_system),
        .mem_csr_rdata (mem_csr_read_data),
        
        .wb_pc        (wb_pc),       
        .wb_instr     (wb_instr), 
        .wb_alu_result(wb_alu_result), 
        .wb_read_data (wb_read_data),
        .wb_reg_write (wb_reg_write), 
        .wb_wb_sel    (wb_wb_sel),
        .wb_is_system (wb_is_system),
        .wb_csr_rdata (wb_csr_read_data)
    );

    reg [31:0] final_wb_data;
    always @(*) begin
        case (wb_wb_sel)
            2'b00: final_wb_data = wb_alu_result;
            2'b01: final_wb_data = wb_read_data; 
            2'b10: final_wb_data = wb_pc + 32'd4;
            2'b11: final_wb_data = wb_csr_read_data;
            default: final_wb_data = wb_alu_result;
        endcase
    end

    assign wb_data = final_wb_data;
endmodule
