// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// trap_ctrl.v
//   Selects which trap request is taken.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: trap_ctrl (v2.5 - MRET Misalignment Trap Added)
// Description: The absolute final fix for the I-MISALIGN_JMP infinite loop.
// =========================================================================
module trap_ctrl (
    input  wire        ext_irq,         
    input  wire        mstatus_mie,     
    input  wire [31:0] mie,             
    input  wire [31:0] mip,             
    input  wire [31:0] mtvec,           
    input  wire [31:0] mepc,            
    
    input  wire        illegal_instr,   
    input  wire        ecall_instr,     
    input  wire        ebreak_instr,    
    input  wire        mret_instr,      
    input  wire [31:0] current_pc,      
    input  wire [31:0] instr_val,       
    
    input  wire        misaligned_load,
    input  wire        misaligned_store,
    input  wire        misaligned_jump,
    input  wire [31:0] mem_addr,
    input  wire [31:0] jump_addr,

    output reg         trap_req,        
    output reg  [31:0] trap_cause,      
    output reg  [31:0] trap_pc_save,    
    output reg  [31:0] trap_val,        
    output reg         do_mret,         
    output reg         pc_override,     
    output reg  [31:0] next_pc          
);

    wire m_ext_irq_pending = mip[11] & mie[11];
    wire take_interrupt = mstatus_mie & m_ext_irq_pending;

    always @(*) begin
        trap_req     = 1'b0;
        trap_cause   = 32'd0;
        trap_pc_save = 32'd0;
        trap_val     = 32'd0;
        do_mret      = 1'b0;
        pc_override  = 1'b0;
        next_pc      = 32'd0;

        // 1. MRET Instruction (Check for Misaligned Return Address!)
        if (mret_instr) begin
            if (mepc[1:0] != 2'b00) begin
                // [FINAL BUG FIX] mret targets a misaligned address
                trap_req     = 1'b1;
                pc_override  = 1'b1;
                trap_pc_save = current_pc; // Save the PC of the mret instruction itself
                trap_cause   = 32'd0;      // Cause 0: Instruction Address Misaligned
                trap_val     = mepc;       // The faulting return address
                next_pc      = {mtvec[31:2], 2'b00};
            end else begin
                // Normal safe return
                do_mret     = 1'b1;
                pc_override = 1'b1;
                next_pc     = mepc;
            end
        end
        // 2. Asynchronous Interrupt
        else if (take_interrupt) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'h8000_000B; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        // 3. Synchronous Exceptions
        else if (illegal_instr) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd2; 
            trap_val     = instr_val; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        else if (misaligned_jump) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd0; 
            trap_val     = jump_addr; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        else if (ebreak_instr) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd3; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        else if (ecall_instr) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd11; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        else if (misaligned_load) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd4; 
            trap_val     = mem_addr; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
        else if (misaligned_store) begin
            trap_req     = 1'b1;
            pc_override  = 1'b1;
            trap_pc_save = current_pc;
            trap_cause   = 32'd6; 
            trap_val     = mem_addr; 
            next_pc      = {mtvec[31:2], 2'b00};
        end
    end
endmodule
