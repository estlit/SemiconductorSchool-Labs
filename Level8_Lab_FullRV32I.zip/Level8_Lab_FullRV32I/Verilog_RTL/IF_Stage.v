// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// IF_Stage.v
//   Instruction fetch and PC selection.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: IF_Stage (Instruction Fetch)
// Description: Fetches instructions from ROM and handles PC updates.
//              * Added trap_override & trap_pc for CSR/Exception jumps.
//              * Explicitly loads 'program_por.mem' and logs it.
//              * [UPDATED] Expanded ROM size to 16KB to prevent PC wrap-around.
// =========================================================================
module IF_Stage(
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    
    // Branch / Jump
    input  wire        branch_taken,
    input  wire [31:0] branch_target,
    
    // CSR Trap / MRET PC Override
    input  wire        trap_override,
    input  wire [31:0] trap_pc,
    
    output wire [31:0] pc,
    output wire [31:0] instr
);

    reg [31:0] pc_reg;
    
    // Expanded to 16KB Instruction Memory (4096 words) to handle large compliance tests
    reg [31:0] rom [0:4095]; 

    // Load instructions and output verification message
    initial begin
        $display("===============================================================");
        $display("[HARDWARE INIT] IF_Stage: Loading Instruction Memory...");
        $display("                -> Target File: 'program_calc_full.mem'");
        $display("===============================================================");
        
        $readmemh("program_calc_full.mem", rom);
    end

    assign pc = pc_reg;
    
    // Extracted 12 bits [13:2] to correctly map the 4096-word memory address space
    assign instr = rom[pc_reg[13:2]];

    always @(posedge clk) begin
        if (rst) begin
            pc_reg <= 32'd0;
        end else if (!stall || trap_override) begin 
            // Trap override should bypass normal stalls if necessary
            if (trap_override) begin
                pc_reg <= trap_pc;         // 1st Priority: Traps & MRET
            end else if (branch_taken) begin
                pc_reg <= branch_target;   // 2nd Priority: Branch / Jumps
            end else begin
                pc_reg <= pc_reg + 32'd4;  // Default: Next PC
            end
        end
    end

endmodule
