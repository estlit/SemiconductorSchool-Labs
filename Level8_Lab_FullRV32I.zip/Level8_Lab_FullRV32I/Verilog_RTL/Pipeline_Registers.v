// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Pipeline_Registers.v
//   The four stage boundaries.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// 1. IF/ID Pipeline Register
// =========================================================================
module IF_ID_Reg(
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    input  wire        flush,
    input  wire [31:0] if_pc,
    input  wire [31:0] if_instr,
    output reg  [31:0] id_pc,
    output reg  [31:0] id_instr
);
    always @(posedge clk) begin
        if (rst || flush) begin
            id_pc    <= 32'd0;
            id_instr <= 32'h00000013; // NOP (addi x0, x0, 0)
        end else if (!stall) begin
            id_pc    <= if_pc;
            id_instr <= if_instr;
        end
    end
endmodule

// =========================================================================
// 2. ID/EX Pipeline Register
// =========================================================================
module ID_EX_Reg(
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    input  wire        flush,
    
    // Data Paths
    input  wire [31:0] id_pc,
    input  wire [31:0] id_instr,
    input  wire [31:0] id_rs1_data,
    input  wire [31:0] id_rs2_data,
    input  wire [31:0] id_imm,
    
    // Base Control Signals
    input  wire [4:0]  id_alu_ctrl,
    input  wire        id_alu_src,
    input  wire        id_alu_src_pc,
    input  wire        id_branch,
    input  wire        id_jump,
    input  wire        id_jalr,
    input  wire        id_mem_read,
    input  wire        id_mem_write,
    input  wire        id_reg_write,
    input  wire [1:0]  id_wb_sel,
    input  wire        id_is_system,
    
    // [NEW] CSR & Trap Control Signals
    input  wire        id_is_csr_instr,
    input  wire [2:0]  id_csr_op,
    input  wire        id_ecall_instr,
    input  wire        id_ebreak_instr,
    input  wire        id_mret_instr,
    input  wire        id_illegal_instr,
    input  wire [31:0] id_raw_instr,

    // Outputs
    output reg  [31:0] ex_pc,
    output reg  [31:0] ex_instr,
    output reg  [31:0] ex_rs1_data,
    output reg  [31:0] ex_rs2_data,
    output reg  [31:0] ex_imm,
    
    output reg  [4:0]  ex_alu_ctrl,
    output reg         ex_alu_src,
    output reg         ex_alu_src_pc,
    output reg         ex_branch,
    output reg         ex_jump,
    output reg         ex_jalr,
    output reg         ex_mem_read,
    output reg         ex_mem_write,
    output reg         ex_reg_write,
    output reg  [1:0]  ex_wb_sel,
    output reg         ex_is_system,
    
    // [NEW] CSR & Trap Outputs
    output reg         ex_is_csr_instr,
    output reg  [2:0]  ex_csr_op,
    output reg         ex_ecall_instr,
    output reg         ex_ebreak_instr,
    output reg         ex_mret_instr,
    output reg         ex_illegal_instr,
    output reg  [31:0] ex_raw_instr
);
    always @(posedge clk) begin
        if (rst || flush) begin
            ex_pc <= 0; ex_instr <= 0; ex_rs1_data <= 0; ex_rs2_data <= 0; ex_imm <= 0;
            ex_alu_ctrl <= 0; ex_alu_src <= 0; ex_alu_src_pc <= 0; ex_branch <= 0; 
            ex_jump <= 0; ex_jalr <= 0; ex_mem_read <= 0; ex_mem_write <= 0; 
            ex_reg_write <= 0; ex_wb_sel <= 0; ex_is_system <= 0;
            
            ex_is_csr_instr <= 0; ex_csr_op <= 0; ex_ecall_instr <= 0; 
            ex_ebreak_instr <= 0; ex_mret_instr <= 0; ex_illegal_instr <= 0; ex_raw_instr <= 0;
        end else if (!stall) begin
            ex_pc <= id_pc; ex_instr <= id_instr; ex_rs1_data <= id_rs1_data; 
            ex_rs2_data <= id_rs2_data; ex_imm <= id_imm;
            
            ex_alu_ctrl <= id_alu_ctrl; ex_alu_src <= id_alu_src; ex_alu_src_pc <= id_alu_src_pc;
            ex_branch <= id_branch; ex_jump <= id_jump; ex_jalr <= id_jalr; 
            ex_mem_read <= id_mem_read; ex_mem_write <= id_mem_write; 
            ex_reg_write <= id_reg_write; ex_wb_sel <= id_wb_sel; ex_is_system <= id_is_system;
            
            ex_is_csr_instr <= id_is_csr_instr; ex_csr_op <= id_csr_op; 
            ex_ecall_instr <= id_ecall_instr; ex_ebreak_instr <= id_ebreak_instr; 
            ex_mret_instr <= id_mret_instr; ex_illegal_instr <= id_illegal_instr; 
            ex_raw_instr <= id_raw_instr;
        end
    end
endmodule

// =========================================================================
// 3. EX/MEM Pipeline Register
// =========================================================================
module EX_MEM_Reg(
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    
    input  wire [31:0] ex_pc,
    input  wire [31:0] ex_instr,
    input  wire [31:0] ex_alu_result,
    input  wire [31:0] ex_rs2_data,
    input  wire        ex_mem_read,
    input  wire        ex_mem_write,
    input  wire        ex_reg_write,
    input  wire [1:0]  ex_wb_sel,
    input  wire        ex_is_system,
    input  wire [31:0] ex_csr_rdata, // [NEW]

    output reg  [31:0] mem_pc,
    output reg  [31:0] mem_instr,
    output reg  [31:0] mem_alu_result,
    output reg  [31:0] mem_rs2_data,
    output reg         mem_mem_read,
    output reg         mem_mem_write,
    output reg         mem_reg_write,
    output reg  [1:0]  mem_wb_sel,
    output reg         mem_is_system,
    output reg  [31:0] mem_csr_rdata // [NEW]
);
    always @(posedge clk) begin
        if (rst) begin
            mem_pc <= 0; mem_instr <= 0; mem_alu_result <= 0; mem_rs2_data <= 0;
            mem_mem_read <= 0; mem_mem_write <= 0; mem_reg_write <= 0;
            mem_wb_sel <= 0; mem_is_system <= 0; mem_csr_rdata <= 0;
        end else if (!stall) begin
            mem_pc <= ex_pc; mem_instr <= ex_instr; mem_alu_result <= ex_alu_result; 
            mem_rs2_data <= ex_rs2_data; mem_mem_read <= ex_mem_read; 
            mem_mem_write <= ex_mem_write; mem_reg_write <= ex_reg_write;
            mem_wb_sel <= ex_wb_sel; mem_is_system <= ex_is_system;
            mem_csr_rdata <= ex_csr_rdata;
        end
    end
endmodule

// =========================================================================
// 4. MEM/WB Pipeline Register
// =========================================================================
module MEM_WB_Reg(
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    
    input  wire [31:0] mem_pc,
    input  wire [31:0] mem_instr,
    input  wire [31:0] mem_alu_result,
    input  wire [31:0] mem_read_data,
    input  wire        mem_reg_write,
    input  wire [1:0]  mem_wb_sel,
    input  wire        mem_is_system,
    input  wire [31:0] mem_csr_rdata, // [NEW]

    output reg  [31:0] wb_pc,
    output reg  [31:0] wb_instr,
    output reg  [31:0] wb_alu_result,
    output reg  [31:0] wb_read_data,
    output reg         wb_reg_write,
    output reg  [1:0]  wb_wb_sel,
    output reg         wb_is_system,
    output reg  [31:0] wb_csr_rdata   // [NEW]
);
    always @(posedge clk) begin
        if (rst) begin
            wb_pc <= 0; wb_instr <= 0; wb_alu_result <= 0; wb_read_data <= 0;
            wb_reg_write <= 0; wb_wb_sel <= 0; wb_is_system <= 0; wb_csr_rdata <= 0;
        end else if (!stall) begin
            wb_pc <= mem_pc; wb_instr <= mem_instr; wb_alu_result <= mem_alu_result; 
            wb_read_data <= mem_read_data; wb_reg_write <= mem_reg_write; 
            wb_wb_sel <= mem_wb_sel; wb_is_system <= mem_is_system;
            wb_csr_rdata <= mem_csr_rdata;
        end
    end
endmodule
