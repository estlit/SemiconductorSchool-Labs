// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Hazard_Detection_Unit.v
//   Detects load-use and drives the stall.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
// ============================================================================
// Module      : Hazard_Detection_Unit
// Description : Detects Load-Use hazards and handles external stall requests 
//               for SMP-Ready architecture. Inserts bubbles and freezes pipeline.
// ============================================================================
module Hazard_Detection_Unit (
    // Inputs from Pipeline (ID and EX stages)
    input  wire [4:0] id_rs1,       // Source register 1 in current ID stage
    input  wire [4:0] id_rs2,       // Source register 2 in current ID stage
    input  wire [4:0] ex_rd,        // Destination register in current EX stage
    input  wire       ex_memread,   // Indicates if EX stage instruction is Load
    
    // SMP-Ready Hook
    input  wire       ext_stall,    // External stall request (Bus contention/Debug)

    // Control Outputs to Pipeline Registers
    output wire       pc_write,     // Enable PC register update (0 = freeze)
    output wire       if_id_write,  // Enable IF/ID pipeline register update (0 = freeze)
    output wire       ctrl_mux      // Force control signals to ID/EX to 0 (Bubble)
);

    wire load_use_hazard;
    
    // -------------------------------------------------------------
    // Load-Use Hazard Condition
    // True if EX stage is a Load instruction AND its destination 
    // register matches either of the ID stage source registers.
    // -------------------------------------------------------------
    assign load_use_hazard = ex_memread && 
                             (ex_rd != 5'b00000) && // Register x0 is hardwired to 0
                             ((ex_rd == id_rs1) || (ex_rd == id_rs2));

    // -------------------------------------------------------------
    // Global Pipeline Freeze
    // Stop PC and IF/ID registers from updating to keep current instructions.
    // -------------------------------------------------------------
    assign pc_write    = ~(load_use_hazard | ext_stall);
    assign if_id_write = ~(load_use_hazard | ext_stall);
    
    // -------------------------------------------------------------
    // Control Signal Bubble Insertion
    // Insert a bubble (NOP) into EX stage ONLY for internal Load-Use hazards.
    // External stalls freeze the whole pipeline, so no bubble is injected.
    // -------------------------------------------------------------
    assign ctrl_mux    = ~load_use_hazard; 

endmodule
