// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// csr_decode.v
//   Checks that a CSR address and access are allowed.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: csr_decode
// Description: Access control and illegal instruction detector for CSRs.
//              Checks valid addresses and read-only violations.
// =========================================================================
module csr_decode (
    input  wire [11:0] csr_addr,
    input  wire        is_csr_instr, // Valid CSR instruction detected by main decoder
    input  wire [2:0]  csr_op,       // funct3 from instruction
    input  wire [4:0]  rs1_zimm,     // rs1 field (used to detect pure read)

    output wire        illegal_csr_access
);

    // ---------------------------------------------------------------------
    // 1. Implemented CSR Address Registry (Whitelist)
    // ---------------------------------------------------------------------
    wire valid_address;
    assign valid_address = (
        csr_addr == 12'h300 || // mstatus
        csr_addr == 12'h304 || // mie
        csr_addr == 12'h305 || // mtvec
        csr_addr == 12'h340 || // mscratch
        csr_addr == 12'h341 || // mepc
        csr_addr == 12'h342 || // mcause
        csr_addr == 12'h343 || // mtval
        csr_addr == 12'h344    // mip
    );

    // ---------------------------------------------------------------------
    // 2. Read-Only Violation Check
    // ---------------------------------------------------------------------
    // CSR Address [11:10] == 2'b11 means Read-Only.
    wire is_read_only = (csr_addr[11:10] == 2'b11);
    
    // RISC-V Zicsr Note: If rs1=0 (for RS/RC) or zimm=0 (for RSI/RCI), 
    // it's considered a pure read, NOT a write. 
    // CSRRW/CSRRWI ALWAYS attempt to write, even if rs1/zimm is 0.
    wire write_attempt;
    assign write_attempt = (csr_op == 3'b001 || csr_op == 3'b101) || // RW, RWI
                           ((csr_op == 3'b010 || csr_op == 3'b011 || 
                             csr_op == 3'b110 || csr_op == 3'b111) && (rs1_zimm != 5'd0));

    wire read_only_violation = is_read_only && write_attempt;

    // ---------------------------------------------------------------------
    // 3. Final Illegal Access Decision
    // ---------------------------------------------------------------------
    assign illegal_csr_access = is_csr_instr && (!valid_address || read_only_violation);

endmodule
