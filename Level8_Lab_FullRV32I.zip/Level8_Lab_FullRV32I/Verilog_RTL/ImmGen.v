// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// ImmGen.v
//   Assembles the immediate for each instruction format.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module ImmGen (
    input  wire [31:0] instr,
    output reg  [31:0] imm
);

    // Extract opcode (lower 7 bits of the instruction)
    wire [6:0] opcode = instr[6:0];

    // RISC-V Standard Opcode Macros (Expanded for 40 Instructions)
    localparam OP_LOAD   = 7'b0000011; // I-type (LW, LH, LB, LHU, LBU)
    localparam OP_IMM    = 7'b0010011; // I-type (ADDI, ANDI, ORI, XORI, SLLI, SRLI, SRAI, SLTI, SLTIU)
    localparam OP_JALR   = 7'b1100111; // I-type (JALR - NEW)
    localparam OP_STORE  = 7'b0100011; // S-type (SW, SH, SB)
    localparam OP_BRANCH = 7'b1100011; // B-type (BEQ, BNE, BLT, BGE, BLTU, BGEU)
    localparam OP_LUI    = 7'b0110111; // U-type (LUI)
    localparam OP_AUIPC  = 7'b0010111; // U-type (AUIPC - NEW)
    localparam OP_JAL    = 7'b1101111; // J-type (JAL - NEW)
    localparam OP_SYSTEM = 7'b1110011; // Z-type (CSRRWI, CSRRSI, CSRRCI - NEW)

    // Combinational logic for immediate extraction and sign-extension
    always @(*) begin
        case (opcode)
            // ---------------------------------------------------------
            // I-Type: Sign-extend instr[31:20]
            // Used by: Arithmetic Immediates, Loads, and JALR
            // ---------------------------------------------------------
            OP_LOAD, OP_IMM, OP_JALR: 
                imm = {{20{instr[31]}}, instr[31:20]};
                
            // ---------------------------------------------------------
            // S-Type: Combine instr[31:25] and instr[11:7], then sign-extend
            // Used by: Stores
            // ---------------------------------------------------------
            OP_STORE: 
                imm = {{20{instr[31]}}, instr[31:25], instr[11:7]};
                
            // ---------------------------------------------------------
            // B-Type: Combine shuffled bits and append 1'b0 (even address)
            // Used by: Branches
            // ---------------------------------------------------------
            OP_BRANCH: 
                imm = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0};
                
            // ---------------------------------------------------------
            // U-Type: Shift instr[31:12] to the upper 20 bits, fill lower 12 with 0
            // Used by: LUI, AUIPC
            // ---------------------------------------------------------
            OP_LUI, OP_AUIPC: 
                imm = {instr[31:12], 12'd0};

            // ---------------------------------------------------------
            // J-Type: Combine shuffled bits and append 1'b0 (even address)
            // Used by: JAL (Jump and Link)
            // ---------------------------------------------------------
            OP_JAL:
                imm = {{12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0};

            // ---------------------------------------------------------
            // Z-Type (CSR Immediate): Zero-extend 5-bit instr[19:15]
            // Used by: System CSR Instructions (zimm)
            // ---------------------------------------------------------
            OP_SYSTEM:
                imm = {27'd0, instr[19:15]};

            // Default case to prevent latches
            default: 
                imm = 32'd0; 
        endcase
    end

endmodule
