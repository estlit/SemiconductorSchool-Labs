// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_PipelineRegs.v
//   Testbench for PipelineRegs.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_PipelineRegs
// Description: Exhaustive Wire-Toggle & Stress Testbench for Pipeline Regs.
//              * [UPDATED] Integrated all Zicsr & Privileged Architecture 
//                control signals and data paths for full structural coverage.
// =========================================================================
module tb_PipelineRegs;

    reg         clk, rst, stall, flush;
    integer     err_cnt = 0;

    // ------------------------------------------------------------------------
    // Pipeline Interfaces (Original + New CSR Signals)
    // ------------------------------------------------------------------------
    reg  [31:0] if_pc, if_instr;
    wire [31:0] id_pc, id_instr;

    reg  [31:0] id_rs1_data, id_rs2_data, id_imm;
    reg  [4:0]  id_alu_ctrl; 
    reg         id_alu_src, id_alu_src_pc, id_branch, id_jump, id_jalr;
    reg         id_mem_read, id_mem_write, id_reg_write, id_is_system;
    reg  [1:0]  id_wb_sel;   
    
    // [NEW] ID Stage CSR/Trap Inputs
    reg         id_is_csr_instr, id_ecall_instr, id_ebreak_instr;
    reg         id_mret_instr, id_illegal_instr;
    reg  [2:0]  id_csr_op;
    reg  [31:0] id_raw_instr;
    
    wire [31:0] ex_pc, ex_instr, ex_rs1_data, ex_rs2_data, ex_imm;
    wire [4:0]  ex_alu_ctrl;
    wire        ex_alu_src, ex_alu_src_pc, ex_branch, ex_jump, ex_jalr;
    wire        ex_mem_read, ex_mem_write, ex_reg_write, ex_is_system;
    wire [1:0]  ex_wb_sel;   
    
    // [NEW] EX Stage CSR/Trap Outputs from ID_EX
    wire        ex_is_csr_instr, ex_ecall_instr, ex_ebreak_instr;
    wire        ex_mret_instr, ex_illegal_instr;
    wire [2:0]  ex_csr_op;
    wire [31:0] ex_raw_instr;

    reg  [31:0] ex_alu_result_mock;
    reg  [31:0] ex_csr_rdata_mock; // [NEW] EX Stage CSR Data Input
    
    wire [31:0] mem_pc, mem_instr, mem_alu_result, mem_rs2_data;
    wire        mem_mem_read, mem_mem_write, mem_reg_write, mem_is_system;
    wire [1:0]  mem_wb_sel;  
    wire [31:0] mem_csr_rdata; // [NEW] MEM Stage CSR Data Output

    reg  [31:0] mem_read_data_mock;
    
    wire [31:0] wb_pc, wb_instr, wb_alu_result, wb_read_data;
    wire        wb_reg_write, wb_is_system;
    wire [1:0]  wb_wb_sel;   
    wire [31:0] wb_csr_rdata;  // [NEW] WB Stage CSR Data Output

    // ========================================================================
    // DUT Instantiations
    // ========================================================================
    IF_ID_Reg u_IF_ID (
        .clk(clk), .rst(rst), .stall(stall), .flush(flush),
        .if_pc(if_pc), .if_instr(if_instr),
        .id_pc(id_pc), .id_instr(id_instr)
    );

    ID_EX_Reg u_ID_EX (
        .clk(clk), .rst(rst), .stall(stall), .flush(flush),
        .id_pc(id_pc), .id_instr(id_instr), .id_rs1_data(id_rs1_data), .id_rs2_data(id_rs2_data), .id_imm(id_imm),
        .id_alu_ctrl(id_alu_ctrl), .id_alu_src(id_alu_src), .id_alu_src_pc(id_alu_src_pc),
        .id_branch(id_branch), .id_jump(id_jump), .id_jalr(id_jalr),
        .id_mem_read(id_mem_read), .id_mem_write(id_mem_write), .id_reg_write(id_reg_write),
        .id_wb_sel(id_wb_sel), .id_is_system(id_is_system),
        
        // [NEW] CSR Inputs
        .id_is_csr_instr(id_is_csr_instr), .id_csr_op(id_csr_op), .id_ecall_instr(id_ecall_instr),
        .id_ebreak_instr(id_ebreak_instr), .id_mret_instr(id_mret_instr), .id_illegal_instr(id_illegal_instr),
        .id_raw_instr(id_raw_instr),
        
        .ex_pc(ex_pc), .ex_instr(ex_instr), .ex_rs1_data(ex_rs1_data), .ex_rs2_data(ex_rs2_data), .ex_imm(ex_imm),
        .ex_alu_ctrl(ex_alu_ctrl), .ex_alu_src(ex_alu_src), .ex_alu_src_pc(ex_alu_src_pc),
        .ex_branch(ex_branch), .ex_jump(ex_jump), .ex_jalr(ex_jalr),
        .ex_mem_read(ex_mem_read), .ex_mem_write(ex_mem_write), .ex_reg_write(ex_reg_write),
        .ex_wb_sel(ex_wb_sel), .ex_is_system(ex_is_system),
        
        // [NEW] CSR Outputs
        .ex_is_csr_instr(ex_is_csr_instr), .ex_csr_op(ex_csr_op), .ex_ecall_instr(ex_ecall_instr),
        .ex_ebreak_instr(ex_ebreak_instr), .ex_mret_instr(ex_mret_instr), .ex_illegal_instr(ex_illegal_instr),
        .ex_raw_instr(ex_raw_instr)
    );

    EX_MEM_Reg u_EX_MEM (
        .clk(clk), .rst(rst), .stall(stall),
        .ex_pc(ex_pc), .ex_instr(ex_instr), .ex_alu_result(ex_alu_result_mock), .ex_rs2_data(ex_rs2_data),
        .ex_mem_read(ex_mem_read), .ex_mem_write(ex_mem_write), .ex_reg_write(ex_reg_write),
        .ex_wb_sel(ex_wb_sel), .ex_is_system(ex_is_system),
        .ex_csr_rdata(ex_csr_rdata_mock), // [NEW]
        
        .mem_pc(mem_pc), .mem_instr(mem_instr), .mem_alu_result(mem_alu_result), .mem_rs2_data(mem_rs2_data),
        .mem_mem_read(mem_mem_read), .mem_mem_write(mem_mem_write), .mem_reg_write(mem_reg_write),
        .mem_wb_sel(mem_wb_sel), .mem_is_system(mem_is_system),
        .mem_csr_rdata(mem_csr_rdata)     // [NEW]
    );

    MEM_WB_Reg u_MEM_WB (
        .clk(clk), .rst(rst), .stall(stall),
        .mem_pc(mem_pc), .mem_instr(mem_instr), .mem_alu_result(mem_alu_result), .mem_read_data(mem_read_data_mock),
        .mem_reg_write(mem_reg_write), .mem_wb_sel(mem_wb_sel), .mem_is_system(mem_is_system),
        .mem_csr_rdata(mem_csr_rdata), // [NEW]
        
        .wb_pc(wb_pc), .wb_instr(wb_instr), .wb_alu_result(wb_alu_result), .wb_read_data(wb_read_data),
        .wb_reg_write(wb_reg_write), .wb_wb_sel(wb_wb_sel), .wb_is_system(wb_is_system),
        .wb_csr_rdata(wb_csr_rdata)    // [NEW]
    );

    // ========================================================================
    // Clock Generation (10ns Period)
    // ========================================================================
    always #5 clk = ~clk;

    // ========================================================================
    // Verification Tasks
    // ========================================================================
    task verify_pattern;
        input [31:0] pat32;
        input [4:0]  pat5;
        input [1:0]  pat2;
        input        pat1;
        begin
            // Hold inputs constant to fill the entire pipeline synchronously
            if_pc = pat32; if_instr = pat32;
            id_rs1_data = pat32; id_rs2_data = pat32; id_imm = pat32;
            id_alu_ctrl = pat5; id_alu_src = pat1; id_alu_src_pc = pat1;
            id_branch = pat1; id_jump = pat1; id_jalr = pat1;
            id_mem_read = pat1; id_mem_write = pat1; id_reg_write = pat1;
            id_is_system = pat1; id_wb_sel = pat2;
            
            // [NEW] Populate CSR signals with patterns
            id_is_csr_instr = pat1; id_ecall_instr = pat1; id_ebreak_instr = pat1;
            id_mret_instr = pat1; id_illegal_instr = pat1;
            id_csr_op = pat5[2:0];
            id_raw_instr = pat32;
            
            ex_alu_result_mock = pat32; mem_read_data_mock = pat32;
            ex_csr_rdata_mock = pat32; // [NEW] Ensure CSR Data path toggles

            @(posedge clk); #1; // Cycle 1 (Loaded into IF_ID)
            @(posedge clk); #1; // Cycle 2 (Loaded into ID_EX)
            @(posedge clk); #1; // Cycle 3 (Loaded into EX_MEM)
            @(posedge clk); #1; // Cycle 4 (Loaded into MEM_WB)

            // Verify outputs at MEM_WB boundary (Checks full depth)
            // Also checking new CSR data propagation
            if (wb_pc === pat32 && wb_instr === pat32 && wb_wb_sel === pat2 && 
                wb_reg_write === pat1 && wb_csr_rdata === pat32) begin
                $display("  [PASS] Pattern 0x%h verified perfectly across all pipeline stages.", pat32);
            end else begin
                $display("  [FAIL] Pattern 0x%h corrupted during propagation!", pat32);
                err_cnt = err_cnt + 1;
            end
        end
    endtask

    // ========================================================================
    // Main Test Stimulus
    // ========================================================================
    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; rst = 1; stall = 0; flush = 0;
        
        // Zero initialization
        if_pc = 0; if_instr = 0; id_rs1_data = 0; id_rs2_data = 0; id_imm = 0;
        id_alu_ctrl = 0; id_alu_src = 0; id_alu_src_pc = 0; id_branch = 0; id_jump = 0; id_jalr = 0;
        id_mem_read = 0; id_mem_write = 0; id_reg_write = 0; id_wb_sel = 0; id_is_system = 0;
        
        // [NEW] Zero Init CSRs
        id_is_csr_instr = 0; id_ecall_instr = 0; id_ebreak_instr = 0;
        id_mret_instr = 0; id_illegal_instr = 0; id_csr_op = 0; id_raw_instr = 0;
        
        ex_alu_result_mock = 0; mem_read_data_mock = 0; ex_csr_rdata_mock = 0;

        #15 rst = 0;
        $display("===============================================================");
        $display("[UNIT TEST] Pipeline Regs Exhaustive Wire-Toggle Verification (v2.0)");
        $display("===============================================================");

        // -----------------------------------------------------------
        // [Phase 1] Cross-talk & Stuck-at Fault Injection 
        // -----------------------------------------------------------
        $display("[INFO ] Injecting Extreme Pattern 1: All Zeros (Check for Shorts)");
        verify_pattern(32'h00000000, 5'b00000, 2'b00, 1'b0);
                      
        $display("[INFO ] Injecting Extreme Pattern 2: All Ones (Check for Stuck-at-0)");
        verify_pattern(32'hFFFFFFFF, 5'b11111, 2'b11, 1'b1);

        $display("[INFO ] Injecting Extreme Pattern 3: Alt 0101 (Check for Cross-talk)");
        verify_pattern(32'h55555555, 5'b10101, 2'b01, 1'b0);

        $display("[INFO ] Injecting Extreme Pattern 4: Alt 1010 (Check for Cross-talk)");
        verify_pattern(32'hAAAAAAAA, 5'b01010, 2'b10, 1'b1);

        // -----------------------------------------------------------
        // [Phase 2] Strict Protocol Tests (Stall & Flush)
        // -----------------------------------------------------------
        $display("---------------------------------------------------------------");
        $display("[INFO ] Phase 2: Structural Control (Stall & Flush Dynamics)");
        
        stall = 1;
        // Inject different data while stalled
        if_pc = 32'h12345678; if_instr = 32'h87654321;
        @(posedge clk); #1;
        @(posedge clk); #1;
        
        if (wb_pc === 32'hAAAAAAAA) 
            $display("  [PASS] STALL strictly held the previous state securely.");
        else begin 
            $display("  [FAIL] STALL leaked data."); 
            err_cnt = err_cnt + 1; 
        end

        stall = 0; flush = 1;
        @(posedge clk); #1; // Execute flush
        @(posedge clk); #1; // Allow flush to propagate to next cycle check
        
        if (id_instr === 32'h0000_0013 && ex_reg_write === 1'b0)
            $display("  [PASS] FLUSH perfectly cleared pipeline to NOP / Safe state.");
        else begin 
            $display("  [FAIL] FLUSH failed to clear data."); 
            err_cnt = err_cnt + 1; 
        end

        // -----------------------------------------------------------
        // Final Evaluation & Clean Termination
        // -----------------------------------------------------------
        $display("===============================================================");
        if (err_cnt == 0) begin
            $display(" [UNIT GOLDEN] Datapath Wire Integrity 100%% Verified.");
            $display("               No Cross-talk. No Stuck-at faults. Fully Guaranteed.");
        end else begin
            $display(" [CRITICAL] Found %0d hardware defect(s) in datapath routing.", err_cnt);
        end
        $display("===============================================================");
        
        #10 $finish; 
    end
endmodule
