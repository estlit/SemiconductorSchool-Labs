// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_CSR_Top_Block.v
//   Testbench for CSR Top Block.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_CSR_Top_Block (v2.5 - Misaligned Exception Coverage)
// Description: Full Coverage Integration Testbench for CSR Subsystem.
//              * [NEW] Verifies Misaligned Load/Store exceptions.
//              * Confirms faulting address routing to mtval.
//              * Validates precise trap prioritization and MRET restoration.
// =========================================================================
module tb_CSR_Top_Block;

    // Inputs to Top Block
    reg         clk;
    reg         rst;
    reg  [31:0] instr;
    reg         is_csr_instr;
    reg  [2:0]  csr_op;
    reg  [31:0] rs1_data;
    reg         csr_write_en;
    
    reg         ext_irq;
    reg         illegal_instr_in;
    reg         ecall_instr;
    reg         ebreak_instr;
    reg         mret_instr;
    reg  [31:0] current_pc;
    reg  [31:0] instr_val;

    // [NEW] Misaligned Exception Inputs
    reg         misaligned_load;
    reg         misaligned_store;
    reg  [31:0] mem_addr;

    // Outputs from Top Block
    wire [31:0] csr_read_data;
    wire        trap_req_out;
    wire        do_mret_out;
    wire        pc_override;
    wire [31:0] next_pc;

    integer err_cnt = 0;

    // Instantiate the Top Block
    CSR_Top_Block uut (
        .clk(clk), .rst(rst),
        .instr(instr), .is_csr_instr(is_csr_instr), .csr_op(csr_op), .rs1_data(rs1_data), .csr_write_en(csr_write_en),
        .ext_irq(ext_irq), .illegal_instr_in(illegal_instr_in), .ecall_instr(ecall_instr), .ebreak_instr(ebreak_instr),
        .mret_instr(mret_instr), .current_pc(current_pc), .instr_val(instr_val),
        
        // Connect new alignment exception signals
        .misaligned_load(misaligned_load),
        .misaligned_store(misaligned_store),
        .mem_addr(mem_addr),

        .csr_read_data(csr_read_data), .trap_req_out(trap_req_out), .do_mret_out(do_mret_out),
        .pc_override(pc_override), .next_pc(next_pc)
    );

    always #5 clk = ~clk;

    localparam CSRRW = 3'b001;
    localparam CSRRS = 3'b010;

    function [31:0] build_csr_instr;
        input [11:0] addr;
        input [4:0]  rs1_zimm;
        begin
            build_csr_instr = {addr, rs1_zimm, 3'b000, 5'd0, 7'b1110011};
        end
    endfunction

    // 1. Software Write via Pipeline
    task soft_write;
        input [11:0] addr;
        input [31:0] data;
        begin
            instr = build_csr_instr(addr, 5'd1); 
            is_csr_instr = 1; csr_op = CSRRW; rs1_data = data; csr_write_en = 1;
            @(posedge clk); #1; // Wait for write to complete
            is_csr_instr = 0; csr_write_en = 0; 
        end
    endtask

    // 2. Software Read via Pipeline
    task soft_read_check;
        input [8*60:1] msg;
        input [11:0]   addr;
        input [31:0]   expected;
        begin
            instr = build_csr_instr(addr, 5'd0); 
            is_csr_instr = 1; csr_op = CSRRS; rs1_data = 32'd0; csr_write_en = 0;
            #1; // Combinational read propagation
            if (csr_read_data !== expected) begin
                $display("  [FAIL] %s", msg);
                $display("         Expected: %h, Got: %h", expected, csr_read_data);
                err_cnt = err_cnt + 1;
            end else begin
                $display("  [PASS] %s", msg);
            end
            is_csr_instr = 0; 
        end
    endtask

    initial begin
        $timeformat(-9, 0, " ns", 8);
        clk = 0; rst = 1;
        
        instr = 0; is_csr_instr = 0; csr_op = 0; rs1_data = 0; csr_write_en = 0;
        ext_irq = 0; illegal_instr_in = 0; ecall_instr = 0; ebreak_instr = 0; mret_instr = 0;
        current_pc = 32'h0000_1000; instr_val = 0;
        misaligned_load = 0; misaligned_store = 0; mem_addr = 0;

        #25 rst = 0;
        @(posedge clk); #1; 
        
        $display("===============================================================");
        $display("[SYSTEM INTEGRATION] CSR Top Block Full Organic Verification");
        $display("===============================================================");

        // -----------------------------------------------------------------
        $display("--- Phase 1: Software CSR Setup (ALU & File Sync) ---");
        soft_write(12'h305, 32'h8000_0000); 
        soft_read_check("Verify mtvec Setup", 12'h305, 32'h8000_0000);

        soft_write(12'h300, 32'h0000_1808); 
        soft_read_check("Verify Initial mstatus Setup (MIE=1)", 12'h300, 32'h0000_1808);

        // -----------------------------------------------------------------
        $display("--- Phase 2: Illegal Access Defense & Trap Synergy ---");
        current_pc = 32'h0000_1004; instr_val = 32'hDEAD_BEEF;
        
        instr = build_csr_instr(12'hFFF, 5'd1); 
        is_csr_instr = 1; csr_op = CSRRW; rs1_data = 32'hFFFF_FFFF; csr_write_en = 1;
        #1; 
        
        if (trap_req_out === 1'b1 && next_pc === 32'h8000_0000) 
            $display("  [PASS] Decoder instantly triggered Trap & Redirected PC.");
        else begin 
            $display("  [FAIL] Sub-module synergic trap failed."); err_cnt = err_cnt + 1; 
        end
        
        @(posedge clk); #1; 
        is_csr_instr = 0; csr_write_en = 0; 
        
        soft_read_check("mcause logged Illegal Instruction (2)", 12'h342, 32'd2);
        soft_read_check("mepc logged correct faulting PC", 12'h341, 32'h0000_1004);
        soft_read_check("mtval captured malicious opcode", 12'h343, 32'hDEAD_BEEF);

        soft_write(12'h300, 32'h0000_1808); 

        // -----------------------------------------------------------------
        $display("--- Phase 3: Misaligned Memory Access Exceptions ---");
        
        // Misaligned Load
        current_pc = 32'h0000_1008; 
        mem_addr = 32'h0100_0001; 
        misaligned_load = 1;
        #1;
        if (trap_req_out === 1'b1 && next_pc === 32'h8000_0000) 
            $display("  [PASS] Trap_Ctrl hijacked PC for Misaligned Load.");
        else begin 
            $display("  [FAIL] Trap failed for Misaligned Load."); err_cnt = err_cnt + 1; 
        end
        
        @(posedge clk); #1; 
        misaligned_load = 0; 
        
        soft_read_check("mcause logged Load Misaligned (4)", 12'h342, 32'd4);
        soft_read_check("mtval captured faulting load address", 12'h343, 32'h0100_0001);

        soft_write(12'h300, 32'h0000_1808); 

        // Misaligned Store
        current_pc = 32'h0000_100C; 
        mem_addr = 32'h0100_0003; 
        misaligned_store = 1;
        #1;
        if (trap_req_out === 1'b1 && next_pc === 32'h8000_0000) 
            $display("  [PASS] Trap_Ctrl hijacked PC for Misaligned Store.");
        else begin 
            $display("  [FAIL] Trap failed for Misaligned Store."); err_cnt = err_cnt + 1; 
        end
        
        @(posedge clk); #1; 
        misaligned_store = 0; 
        
        soft_read_check("mcause logged Store Misaligned (6)", 12'h342, 32'd6);
        soft_read_check("mtval captured faulting store address", 12'h343, 32'h0100_0003);

        soft_write(12'h300, 32'h0000_1808); 

        // -----------------------------------------------------------------
        $display("--- Phase 4: Synchronous Pipeline Trap (ECALL) ---");
        current_pc = 32'h0000_2000; ecall_instr = 1;
        #1;
        if (pc_override === 1'b1 && next_pc === 32'h8000_0000)
            $display("  [PASS] Trap_Ctrl hijacked PC for ECALL.");
            
        @(posedge clk); #1; 
        ecall_instr = 0;
        
        soft_read_check("mcause logged ECALL (11)", 12'h342, 32'd11);
        soft_read_check("mepc logged ECALL PC", 12'h341, 32'h0000_2000);
        soft_read_check("mstatus Privilege Shifted (MPIE=1, MIE=0)", 12'h300, 32'h0000_1880);

        // -----------------------------------------------------------------
        $display("--- Phase 5: Trap Return Synergy (MRET) ---");
        mret_instr = 1;
        #1;
        if (do_mret_out === 1'b1 && next_pc === 32'h0000_2000)
            $display("  [PASS] Trap_Ctrl requested MRET PC restoration.");
            
        @(posedge clk); #1; 
        mret_instr = 0;
        
        soft_read_check("mstatus Privilege Restored (MIE=1)", 12'h300, 32'h0000_1888);

        // -----------------------------------------------------------------
        $display("--- Phase 6: Asynchronous External Interrupt Chain ---");
        current_pc = 32'h0000_3000;
        
        soft_write(12'h304, 32'h0000_0800); 
        
        ext_irq = 1;
        @(posedge clk); #1; 
        
        if (trap_req_out === 1'b1)
            $display("  [PASS] External pin successfully broke through MIE/MEIE masks.");
        else begin
            $display("  [FAIL] External interrupt failed to penetrate masking."); err_cnt = err_cnt + 1;
        end
        
        @(posedge clk); #1; 
        ext_irq = 0;
        
        soft_read_check("mcause logged External Interrupt (0x8000000B)", 12'h342, 32'h8000_000B);
        soft_read_check("mepc logged interrupted PC", 12'h341, 32'h0000_3000);

        // -----------------------------------------------------------------
        $display("--- Phase 7: Deterministic Priority Resolution (MRET vs IRQ) ---");
        
        soft_write(12'h300, 32'h0000_1888); 
        current_pc = 32'h0000_4000;
        
        ext_irq = 1;       
        mret_instr = 1;    
        #1; 
        
        if (do_mret_out === 1'b1 && trap_req_out === 1'b0)
            $display("  [PASS] Hardware deterministically prioritized MRET over IRQ.");
        else begin
            $display("  [FAIL] Priority inversion detected! MRET must commit first."); err_cnt = err_cnt + 1;
        end
        
        @(posedge clk); #1; // Commit MRET Instruction
        mret_instr = 0;     // Deassert MRET. IRQ is still asserting.
        
        #1; // Combinational evaluation delay after MRET drops

        if (trap_req_out === 1'b1 && next_pc === 32'h8000_0000)
            $display("  [PASS] IRQ was seamlessly taken on the immediate next cycle after MRET.");
        else begin
            $display("  [FAIL] IRQ failed to trigger after MRET completion."); err_cnt = err_cnt + 1;
        end
        
        ext_irq = 0;

        // -----------------------------------------------------------------
        $display("===============================================================");
        if (err_cnt == 0)
            $display("[ABSOLUTE GOLDEN] CSR Subsystem 100%% Integration Verified.");
        else
            $display("[CRITICAL FAIL] Integration broken! Found %0d Errors.", err_cnt);
        $display("===============================================================");
        $finish;
    end

endmodule
