// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_ImmGen.v
//   Testbench for ImmGen.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_ImmGen
// Description: Unit testbench for Immediate Generator.
//              Strictly verifies Sign Extension logic for positive/negative 
//              values across ALL instruction formats (I, S, B, U, J, Z-Type)
//              to ensure 100% compliance with 40 RV32I instructions.
// =========================================================================
module tb_ImmGen;

    // Port declarations
    reg  [31:0] instr;
    wire [31:0] imm;
    reg         clk;

    integer err_cnt = 0;

    // Module instantiation
    ImmGen u_ImmGen (
        .instr (instr),
        .imm   (imm)
    );

    // Generate 10ns period clock
    always #5 clk = ~clk;

    // Verification scenarios
    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; 
        instr = 32'd0;

        $display("===============================================================");
        $display("[UNIT TEST] ImmGen 100%% Coverage Verification Start");
        $display("===============================================================");

        // -----------------------------------------------------------
        // [TEST 1] I-Type (ADDI x1, x0, -15) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: I-Type (ALU) -> ADDI x1, x0, -15");
        instr = {12'hFF1, 5'd0, 3'b000, 5'd1, 7'h13};
        #0.002; 
        if (imm == 32'hFFFF_FFF1) $display("[PASS ] TEST 1: imm = -15 (0xFFFFFFF1)");
        else begin $display("[FAIL ] TEST 1: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 2] I-Type (LW x2, 2047(x1)) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: I-Type (Load) -> LW x2, 2047(x1)");
        instr = {12'h7FF, 5'd1, 3'b010, 5'd2, 7'h03};
        #0.002;
        if (imm == 32'h0000_07FF) $display("[PASS ] TEST 2: imm = 2047 (0x000007FF)");
        else begin $display("[FAIL ] TEST 2: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 3] I-Type (JALR x1, x2, -4) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: I-Type (Jump) -> JALR x1, x2, -4");
        instr = {12'hFFC, 5'd2, 3'b000, 5'd1, 7'h67};
        #0.002;
        if (imm == 32'hFFFF_FFFC) $display("[PASS ] TEST 3: imm = -4 (0xFFFFFFFC)");
        else begin $display("[FAIL ] TEST 3: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 4] S-Type (SW x2, 16(x1)) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: S-Type (Store) -> SW x2, 16(x1)");
        instr = {7'h00, 5'd2, 5'd1, 3'b010, 5'h10, 7'h23};
        #0.002;
        if (imm == 32'h0000_0010) $display("[PASS ] TEST 4: imm = 16 (0x00000010)");
        else begin $display("[FAIL ] TEST 4: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 5] S-Type (SH x2, -16(x1)) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: S-Type (Store Neg) -> SH x2, -16(x1)");
        instr = {7'h7F, 5'd2, 5'd1, 3'b001, 5'h10, 7'h23};
        #0.002;
        if (imm == 32'hFFFF_FFF0) $display("[PASS ] TEST 5: imm = -16 (0xFFFFFFF0)");
        else begin $display("[FAIL ] TEST 5: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 6] B-Type (BEQ x1, x2, -8) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: B-Type (Branch Neg) -> BEQ x1, x2, -8");
        instr = {1'b1, 6'b111111, 5'd2, 5'd1, 3'b000, 4'b1100, 1'b1, 7'h63};
        #0.002;
        if (imm == 32'hFFFF_FFF8) $display("[PASS ] TEST 6: imm = -8 (0xFFFFFFF8)");
        else begin $display("[FAIL ] TEST 6: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 7] B-Type (BNE x1, x2, +12) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: B-Type (Branch Pos) -> BNE x1, x2, +12");
        instr = {1'b0, 6'b000000, 5'd2, 5'd1, 3'b001, 4'b0110, 1'b0, 7'h63};
        #0.002;
        if (imm == 32'h0000_000C) $display("[PASS ] TEST 7: imm = +12 (0x0000000C)");
        else begin $display("[FAIL ] TEST 7: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 8] U-Type (LUI x1, 0x40000) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: U-Type (LUI) -> LUI x1, 0x40000");
        instr = {20'h40000, 5'd1, 7'h37};
        #0.002;
        if (imm == 32'h4000_0000) $display("[PASS ] TEST 8: imm = 0x40000000");
        else begin $display("[FAIL ] TEST 8: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 9] U-Type (AUIPC x1, 0x12345) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: U-Type (AUIPC) -> AUIPC x1, 0x12345");
        instr = {20'h12345, 5'd1, 7'h17};
        #0.002;
        if (imm == 32'h1234_5000) $display("[PASS ] TEST 9: imm = 0x12345000");
        else begin $display("[FAIL ] TEST 9: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 10] J-Type (JAL x1, -2) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: J-Type (Jump Neg) -> JAL x1, -2");
        instr = {1'b1, 10'b1111111111, 1'b1, 8'b11111111, 5'd1, 7'h6F};
        #0.002;
        if (imm == 32'hFFFF_FFFE) $display("[PASS ] TEST 10: imm = -2 (0xFFFFFFFE)");
        else begin $display("[FAIL ] TEST 10: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 11] J-Type (JAL x1, +1024) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: J-Type (Jump Pos) -> JAL x1, +1024");
        instr = {1'b0, 10'b1000000000, 1'b0, 8'b00000000, 5'd1, 7'h6F};
        #0.002;
        if (imm == 32'h0000_0400) $display("[PASS ] TEST 11: imm = +1024 (0x00000400)");
        else begin $display("[FAIL ] TEST 11: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // [TEST 12] Z-Type (CSRRWI x1, csr, 31) 
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] ID stage prep: Z-Type (CSR System) -> CSRRWI x1, csr, 31");
        instr = {12'h00F, 5'b11111, 3'b101, 5'd1, 7'h73};
        #0.002;
        if (imm == 32'h0000_001F) $display("[PASS ] TEST 12: imm = 31 (0x0000001F)");
        else begin $display("[FAIL ] TEST 12: imm = %h", imm); err_cnt = err_cnt + 1; end

        // -----------------------------------------------------------
        // Final Evaluation
        // -----------------------------------------------------------
        @(posedge clk); #10;
        $display("===============================================================");
        if (err_cnt == 0) begin
            $display(" [PERFECT] No errors. ImmGen is 100%% compliant with 40 instructions.");
            $display("           All instruction formats (I, S, B, U, J, Z) Verified.");
        end else begin
            $display(" [FAIL] Found %0d error(s) in Immediate Generation.", err_cnt);
        end
        $display("===============================================================");
        $finish;
    end

    // Structural log output for students (Executes at every posedge clk)
    always @(posedge clk) begin
        if (instr !== 32'd0) begin
            #0.001; 
            $display("------------------------------------------------");
            $display("[T=%0t] CLK ↑", $time);
            $display("[IMM  ] INSTR: %h (Opcode: %b)", instr, instr[6:0]);
            $display("[IMM  ] -> EXTRACTED IMM: %0d (0x%h)", $signed(imm), imm);
        end
    end

endmodule
