// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_ALU.v
//   Testbench for ALU.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module tb_ALU;

    reg  [31:0] alu_in_a;
    reg  [31:0] alu_in_b;
    reg  [4:0]  alu_ctrl; 
    wire [31:0] alu_result;
    wire        zero;

    ALU u_ALU (
        .alu_in_a  (alu_in_a),
        .alu_in_b  (alu_in_b),
        .alu_ctrl  (alu_ctrl),
        .alu_result(alu_result),
        .zero      (zero)
    );

    initial begin
        $display("===============================================================");
        $display("[UNIT TEST] ALU 100%% Coverage & Extreme Corner Cases Start");
        $display("===============================================================");

        // ---------------------------------------------------------------------
        // 1. Basic Arithmetic & Logical Operations
        // ---------------------------------------------------------------------
        alu_in_a = 32'h0000_000A; alu_in_b = 32'h0000_0005; 
        
        alu_ctrl = 5'b00000; #10;
        if (alu_result == 32'd15) $display("  [PASS] ALU ADD    (10 + 5 = 15)"); else $display("  [FAIL] ALU ADD");
        
        alu_ctrl = 5'b00001; #10;
        if (alu_result == 32'd5)  $display("  [PASS] ALU SUB    (10 - 5 = 5)");  else $display("  [FAIL] ALU SUB");
        
        alu_ctrl = 5'b00010; #10;
        if (alu_result == 32'h0)  $display("  [PASS] ALU AND    (10 & 5 = 0)");  else $display("  [FAIL] ALU AND");
        
        alu_ctrl = 5'b00011; #10;
        if (alu_result == 32'hF)  $display("  [PASS] ALU OR     (10 | 5 = 15)"); else $display("  [FAIL] ALU OR");
        
        alu_ctrl = 5'b00100; #10;
        if (alu_result == 32'hF)  $display("  [PASS] ALU XOR    (10 ^ 5 = 15)"); else $display("  [FAIL] ALU XOR");

        // ---------------------------------------------------------------------
        // 2. Shift Operations 
        // ---------------------------------------------------------------------
        alu_in_a = 32'h0000_0001; alu_in_b = 32'd4; alu_ctrl = 5'b00101; #10;
        if (alu_result == 32'h0000_0010) $display("  [PASS] ALU SLL    (1 << 4 = 16)"); else $display("  [FAIL] ALU SLL");

        alu_in_a = 32'h8000_0000; alu_in_b = 32'd4; alu_ctrl = 5'b00110; #10;
        if (alu_result == 32'h0800_0000) $display("  [PASS] ALU SRL    (Unsigned Shift Right)"); else $display("  [FAIL] ALU SRL");

        alu_in_a = 32'h8000_0000; alu_in_b = 32'd4; alu_ctrl = 5'b00111; #10;
        if (alu_result == 32'hF800_0000) $display("  [PASS] ALU SRA    (Signed Shift Right, MSB maintained)"); else $display("  [FAIL] ALU SRA");

        // ---------------------------------------------------------------------
        // 3. Set Less Than Operations
        // ---------------------------------------------------------------------
        alu_in_a = 32'hFFFF_FFFF; alu_in_b = 32'd1; alu_ctrl = 5'b01000; #10;
        if (alu_result == 32'd1) $display("  [PASS] ALU SLT    (Signed: -1 < 1 -> 1)"); else $display("  [FAIL] ALU SLT");

        alu_in_a = 32'hFFFF_FFFF; alu_in_b = 32'd1; alu_ctrl = 5'b01001; #10;
        if (alu_result == 32'd0) $display("  [PASS] ALU SLTU   (Unsigned: MAX_INT < 1 -> 0)"); else $display("  [FAIL] ALU SLTU");

        // ---------------------------------------------------------------------
        // 4. Data Routing
        // ---------------------------------------------------------------------
        alu_in_a = 32'h0; alu_in_b = 32'hDEAD_BEEF; alu_ctrl = 5'b01010; #10;
        if (alu_result == 32'hDEAD_BEEF) $display("  [PASS] ALU PASS_B (Result = DEAD_BEEF)"); else $display("  [FAIL] ALU PASS_B");

        // ---------------------------------------------------------------------
        // 5. Full Branch Condition Evaluations
        // ---------------------------------------------------------------------
        alu_in_a = 32'd10; alu_in_b = 32'd10; alu_ctrl = 5'b01011; #10;
        if (zero == 1'b1) $display("  [PASS] ALU CMP_EQ (10 == 10 -> Zero Flag Asserted)"); else $display("  [FAIL] ALU CMP_EQ");

        alu_in_a = 32'd10; alu_in_b = 32'd5; alu_ctrl = 5'b01100; #10;
        if (zero == 1'b1) $display("  [PASS] ALU CMP_NE (10 != 5 -> Zero Flag Asserted)"); else $display("  [FAIL] ALU CMP_NE");

        alu_in_a = 32'hFFFF_FFF6; alu_in_b = 32'd5; alu_ctrl = 5'b01101; #10;
        if (zero == 1'b1) $display("  [PASS] ALU CMP_LT (Signed: -10 < 5 -> Zero Flag Asserted)"); else $display("  [FAIL] ALU CMP_LT");

        alu_in_a = 32'hFFFF_FFF6; alu_in_b = 32'd5; alu_ctrl = 5'b01110; #10;
        if (zero == 1'b0) $display("  [PASS] ALU CMP_GE (Signed: -10 >= 5 -> Zero Flag Deasserted)"); else $display("  [FAIL] ALU CMP_GE");

        alu_in_a = 32'hFFFF_FFF6; alu_in_b = 32'd5; alu_ctrl = 5'b01111; #10;
        if (zero == 1'b0) $display("  [PASS] ALU CMP_LTU(Unsigned: Large Val < 5 -> Zero Flag Deasserted)"); else $display("  [FAIL] ALU CMP_LTU");

        alu_in_a = 32'hFFFF_FFF6; alu_in_b = 32'd5; alu_ctrl = 5'b10000; #10;
        if (zero == 1'b1) $display("  [PASS] ALU CMP_GEU(Unsigned: Large Val >= 5 -> Zero Flag Asserted)"); else $display("  [FAIL] ALU CMP_GEU");

        // ---------------------------------------------------------------------
        // 6. [NEW] Extreme Corner Cases (No Coincidences)
        // ---------------------------------------------------------------------
        $display("---------------------------------------------------------------");
        $display(" [CORNER CASE TESTING] Strict RV32I Compliance Checks");
        
        // Corner 1: SLL with shift amount >= 32 (Should only use lower 5 bits, so 32 -> 0)
        alu_in_a = 32'h0000_FFFF; alu_in_b = 32'd32; alu_ctrl = 5'b00101; #10;
        if (alu_result == 32'h0000_FFFF) $display("  [PASS] CORNER: SLL Shift >= 32 (Lower 5-bit Masking OK)"); else $display("  [FAIL] CORNER: SLL Shift >= 32");

        // Corner 2: SRA of Minimum Negative Number (-2147483648 shifted by 31 should be -1)
        alu_in_a = 32'h8000_0000; alu_in_b = 32'd31; alu_ctrl = 5'b00111; #10;
        if (alu_result == 32'hFFFF_FFFF) $display("  [PASS] CORNER: SRA Extreme Sign Extension (most negative >> 31 = -1)"); else $display("  [FAIL] CORNER: SRA Extreme Sign Ext");

        // Corner 3: SLT Min vs Max (Signed: Min Negative < Max Positive is True)
        alu_in_a = 32'h8000_0000; alu_in_b = 32'h7FFF_FFFF; alu_ctrl = 5'b01000; #10;
        if (alu_result == 32'd1) $display("  [PASS] CORNER: SLT Min vs Max (Signed: True)"); else $display("  [FAIL] CORNER: SLT Min vs Max");

        // Corner 4: SLTU Min vs Max (Unsigned: 0x8000_0000 is larger than 0x7FFF_FFFF, so False)
        alu_in_a = 32'h8000_0000; alu_in_b = 32'h7FFF_FFFF; alu_ctrl = 5'b01001; #10;
        if (alu_result == 32'd0) $display("  [PASS] CORNER: SLTU Min vs Max (Unsigned: False)"); else $display("  [FAIL] CORNER: SLTU Min vs Max");

        $display("===============================================================");
        $display("[UNIT GOLDEN] ALU Verification 100%% Completed With Corner Cases.");
        $display("===============================================================");
        $finish;
    end
endmodule
