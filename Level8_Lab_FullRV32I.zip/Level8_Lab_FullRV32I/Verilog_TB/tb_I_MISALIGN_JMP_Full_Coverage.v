// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_I_MISALIGN_JMP_Full_Coverage.v
//   Testbench for I MISALIGN JMP Full Coverage.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_I_MISALIGN_JMP_Full_Coverage
// Description: Fully replicates the Trap Handler loop of Python Spike tests.
//              Catches infinite loops caused by failed MEPC updates during CSRW.
// =========================================================================
module tb_I_MISALIGN_JMP_Full_Coverage;

    reg  clk, rst;
    wire cs_board_io, cs_sonar, cs_camera, cs_npu, cs_oled, cs_motor;
    wire mmio_valid, mmio_write;
    wire [31:0] mmio_addr, mmio_wdata;
    reg  [31:0] mmio_rdata = 0; 

    RV32I_Core_Top u_Top (
        .clk(clk), .rst(rst), .ext_irq(1'b0), 
        .peri_board_ready(1'b1), .peri_sonar_ready(1'b1), .peri_camera_ready(1'b1),
        .peri_npu_ready(1'b1), .peri_oled_ready(1'b1), .peri_motor_ready(1'b1),
        .cs_board_io(cs_board_io), .cs_sonar(cs_sonar), .cs_camera(cs_camera), 
        .cs_npu(cs_npu), .cs_oled(cs_oled), .cs_motor(cs_motor),
        .mmio_valid(mmio_valid), .mmio_write(mmio_write), 
        .mmio_addr(mmio_addr), .mmio_wdata(mmio_wdata), .mmio_rdata(mmio_rdata)
    );

    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; rst = 1; 

        // 0. ADDI x2, x0, 0x20   prepares 0x20 as the handler address
        u_Top.u_IF_Stage.rom[0] = 32'h02000113; 
        // 1. CSRRW x0, mtvec, x2 installs it, so a trap jumps to 0x20
        u_Top.u_IF_Stage.rom[1] = 32'h30511073; 
        // 2, 3. NOPs, so the pipeline settles
        u_Top.u_IF_Stage.rom[2] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[3] = 32'h00000013; 

        // ======================================================
        // 4. JAL x1, +2 at 0x10  a misaligned target, so this must trap
        // ======================================================
        u_Top.u_IF_Stage.rom[4] = 32'h002000ef; 
        
        // 5. 0x14                where MRET should return to
        u_Top.u_IF_Stage.rom[5] = 32'h00100193; // ADDI x3, x0, 1, the marker for a successful return
        u_Top.u_IF_Stage.rom[6] = 32'h00000013;
        u_Top.u_IF_Stage.rom[7] = 32'h00000013;

        // ======================================================
        // 8-11. The handler, from 0x20
        //        the same recovery sequence Spike performs
        // ======================================================
        // 0x20: CSRRS x5, mepc, x0   reads the faulting PC, 0x10
        u_Top.u_IF_Stage.rom[8]  = 32'h341022f3; 
        // 0x24: ADDI x5, x5, 4       computes 0x14, past the JAL
        u_Top.u_IF_Stage.rom[9]  = 32'h00428293; 
        // 0x28: CSRRW x0, mepc, x5   writes 0x14 back into mepc
        u_Top.u_IF_Stage.rom[10] = 32'h34129073; 
        // 0x2C: MRET                 returns to 0x14
        u_Top.u_IF_Stage.rom[11] = 32'h30200073; 

        $display("===============================================================");
        $display("[START] Full Trap Recovery Coverage Test (Python Error Hunter)");
        $display("===============================================================");
        
        #25 rst = 0;
    end

    // Traces the return, and watches for a loop that never ends
    always @(negedge clk) begin 
        if (!rst) begin
            // Did execution resume at 0x14
            if (u_Top.ex_pc == 32'h00000014 && u_Top.ex_instr == 32'h00100193) begin
                $display("------------------------------------------------");
                $display("[T=%0t] execution resumed at 0x14", $time);
                $display("  => PASS : the trap was taken and the handler returned.");
                $display("===============================================================");
                $finish;
            end
            
            // Counts each time the JAL reaches EX, to detect a loop
            if (u_Top.ex_instr == 32'h002000ef) begin
                $display("[T=%0t] the JAL reached EX", $time);
            end
        end
    end
    
    // Timeout watchdog
    initial begin
        #500;
        $display("------------------------------------------------");
        $display("[T=%0t] TIMEOUT", $time);
        $display("  -> the same non-terminating loop the Python run hit");
        $display("  -> the handler ran, but MRET did not return to 0x14");
        $display("  => FAIL : the program did not terminate.");
        $display("===============================================================");
        $finish;
    end
endmodule
