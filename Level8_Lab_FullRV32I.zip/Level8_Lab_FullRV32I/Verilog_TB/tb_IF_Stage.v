// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_IF_Stage.v
//   Testbench for IF Stage.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_IF_Stage
// Description: Unit testbench for Instruction Fetch Stage and ROM.
//              Verifies PC increments, stalls, and branch target tracking.
//              * [UPDATED] Added verification for CSR Trap Overrides and
//                strict Priority checking (Trap vs Branch).
// =========================================================================
module tb_IF_Stage;

    // Port declarations
    reg         clk;
    reg         rst;
    reg         stall;
    reg         branch_taken;
    reg  [31:0] branch_target;
    
    // CSR Trap Interface
    reg         trap_override;
    reg  [31:0] trap_pc;
    
    wire [31:0] pc;
    wire [31:0] instr;

    // Module instantiation
    IF_Stage u_IF_Stage (
        .clk          (clk),
        .rst          (rst),
        .stall        (stall),
        .branch_taken (branch_taken),
        .branch_target(branch_target),
        .trap_override(trap_override), 
        .trap_pc      (trap_pc),       
        .pc           (pc),
        .instr        (instr)
    );

    // Generate 10ns period clock
    always #5 clk = ~clk;

    // Verification scenarios
    initial begin
        $timeformat(-9, 0, " ns", 8); 
        
        // Initialization at 0 ns
        clk = 1;
        rst = 1; 
        stall = 0; branch_taken = 0; branch_target = 32'd0;
        trap_override = 0; trap_pc = 32'd0; 

        $display("===============================================================");
        $display("[UNIT TEST] IF Stage & Instruction ROM Verification Start");
        $display("===============================================================");

        #15 rst = 0; // T=15ns (Reset release)
        $display("[T=%0t][SYS] Reset is released (Active-High)", $time);

        // -----------------------------------------------------------
        // [TEST 1] Normal PC increment sequence
        // -----------------------------------------------------------
        @(posedge clk); #0.002; // T=20ns (First active clock edge -> PC becomes 0x4)
        $display("[INFO ] IF stage prep: Verifying sequential instruction fetch");
        
        // At T=20ns post-edge, PC is already updated to 0x4
        if (pc == 32'h0000_0004) $display("[PASS ] TEST 1.1 (Increment): PC updated to 0x4");
        else                     $display("[FAIL ] TEST 1.1 (Increment): PC=%h", pc);
        
        @(posedge clk); #0.002; // T=30ns (PC becomes 0x8)
        if (pc == 32'h0000_0008) $display("[PASS ] TEST 1.2 (Increment): PC autoincremented to 0x8");
        else                     $display("[FAIL ] TEST 1.2 (Increment): PC=%h", pc);

        // -----------------------------------------------------------
        // [TEST 2] Pipeline Stall Verification 
        // -----------------------------------------------------------
        $display("[INFO ] Stall Control activated: PC must hold at current value (0x00000008)");
        stall = 1; // Assert stall BEFORE the next clock edge
        
        @(posedge clk); #0.002; // T=40ns (Clock edge occurs, but stall is 1)
        stall = 0; 
        // Due to the stall, PC must hold the value from T=30ns (0x8)
        if (pc == 32'h0000_0008) $display("[PASS ] TEST 2 (Stall): PC successfully held at 0x8");
        else                     $display("[FAIL ] TEST 2 (Stall): PC changed to %h", pc);

        // -----------------------------------------------------------
        // [TEST 3] Branch Redirection Verification (Target 0x78)
        // -----------------------------------------------------------
        @(posedge clk); #0.002; // T=50ns (PC naturally increments to 0xC after stall release)
        $display("[INFO ] Branch Control activated: PC must jump to target 0x00000078");
        branch_taken  = 1;
        branch_target = 32'h0000_0078; // Target address mapped from program_por.mem
        
        @(posedge clk); #0.002; // T=60ns (Branch takes effect)
        branch_taken = 0; 
        
        // Verifies if the target instruction is accurately fetched from 0x78
        if (pc == 32'h0000_0078)
             $display("[PASS ] TEST 3 (Branch): Successfully redirected to PC 0x78");
        else $display("[FAIL ] TEST 3 (Branch): PC=%h", pc);

        // -----------------------------------------------------------
        // [TEST 4] CSR Trap Override Verification (Target 0x80000000)
        // -----------------------------------------------------------
        @(posedge clk); #0.002; // T=70ns (PC naturally increments to 0x7C)
        $display("[INFO ] CSR Trap activated: PC must instantly jump to Exception Handler (0x80000000)");
        trap_override = 1;
        trap_pc       = 32'h8000_0000;
        
        @(posedge clk); #0.002; // T=80ns (Trap takes effect)
        trap_override = 0;
        
        if (pc == 32'h8000_0000)
             $display("[PASS ] TEST 4 (Trap): Successfully overrode PC to 0x80000000");
        else $display("[FAIL ] TEST 4 (Trap): PC=%h", pc);

        // -----------------------------------------------------------
        // [TEST 5] Priority Verification (Trap vs Branch Collision)
        // -----------------------------------------------------------
        @(posedge clk); #0.002; // T=90ns (PC naturally increments to 0x80000004)
        $display("[INFO ] Priority Check: Asserting BOTH Branch (Target: 0xA0) AND Trap (Target: 0x200)");
        branch_taken  = 1; branch_target = 32'h0000_00A0; // Pipeline requests Branch
        trap_override = 1; trap_pc       = 32'h0000_0200; // CSR requests Trap
        
        @(posedge clk); #0.002; // T=100ns (Collision occurs!)
        branch_taken = 0; trap_override = 0;
        
        if (pc == 32'h0000_0200)
             $display("[PASS ] TEST 5 (Priority): Trap Override successfully DOMINATED Branch signal!");
        else $display("[FAIL ] TEST 5 (Priority): PC=%h (Expected Trap Dominance 0x200)", pc);

        // -----------------------------------------------------------
        // End of Verification
        // -----------------------------------------------------------
        $display("===============================================================");
        $display("[PASS ] UNIT GOLDEN: IF Stage (v2.0) Verification Completed Successfully.");
        $display("===============================================================");
        
        #10 $finish; 
    end

    // Standard structural log output for pipeline state analysis
    always @(posedge clk) begin
        #0.001; 
        $display("------------------------------------------------");
        $display("[T=%0t] CLK UP", $time);
        $display("[IF   ] rst:%b stall:%b br_tkn:%b target:%h trap_ovr:%b trap_pc:%h", 
                 rst, stall, branch_taken, branch_target, trap_override, trap_pc);
        $display("[IF   ] -> CURRENT_PC: %h | FETCHED_INSTR: %h", pc, instr);
    end

endmodule
