// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_RegisterFile.v
//   Testbench for RegisterFile.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_RegisterFile
// Description: Unit testbench for Register File.
//              Strictly verifies the immutability of the Zero Register (x0),
//              normal Read/Write operations, and the newly added 
//              Same-Cycle Write-Through (Internal Forwarding) logic.
// =========================================================================
module tb_RegisterFile;

    reg         clk;
    reg         rst;
    reg  [4:0]  rs1_addr;
    reg  [4:0]  rs2_addr;
    reg  [4:0]  rd_addr;
    reg  [31:0] wb_data;
    reg         reg_write;
    
    wire [31:0] rs1_data;
    wire [31:0] rs2_data;

    // Instantiate the Unit Under Test (UUT)
    RegisterFile u_RegFile (
        .clk      (clk),
        .rst      (rst),
        .rs1_addr (rs1_addr),
        .rs2_addr (rs2_addr),
        .rd_addr  (rd_addr),
        .wb_data  (wb_data),
        .reg_write(reg_write),
        .rs1_data (rs1_data),
        .rs2_data (rs2_data)
    );

    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8);
        clk = 1; rst = 1;
        reg_write = 0; rs1_addr = 0; rs2_addr = 0; rd_addr = 0; wb_data = 0;
        
        #25 rst = 0;
        $display("===============================================================");
        $display("[UNIT TEST] RegisterFile Verification Start");
        $display("===============================================================");

        // -----------------------------------------------------------
        // Test 1: Normal Register Write & Read (x1)
        // -----------------------------------------------------------
        @(posedge clk); #1;
        rd_addr = 5'd1; wb_data = 32'hDEADBEEF; reg_write = 1; // Write to x1
        
        @(posedge clk); #1;
        reg_write = 0;
        rs1_addr = 5'd1; // Read from x1
        #1;
        if (rs1_data == 32'hDEADBEEF) $display("  [PASS] Normal R/W: x1 updated to 0xDEADBEEF");
        else $display("  [FAIL] Normal R/W failed. x1 = 0x%0h", rs1_data);

        // -----------------------------------------------------------
        // Test 2: Zero Register (x0) Immutability Test
        // -----------------------------------------------------------
        @(posedge clk); #1;
        rd_addr = 5'd0; wb_data = 32'hFFFFFFFF; reg_write = 1; // Malicious Write to x0
        
        @(posedge clk); #1;
        reg_write = 0;
        rs2_addr = 5'd0; // Read from x0
        #1;
        if (rs2_data == 32'd0) $display("  [PASS] Zero Register Immutability: x0 remains 0x00000000 despite write attempt");
        else $display("  [FAIL] Zero Register Corrupted! x0 = 0x%0h", rs2_data);

        // -----------------------------------------------------------
        // [NEW] Test 3: Same-Cycle Read-After-Write (Internal Forwarding)
        // -----------------------------------------------------------
        @(posedge clk); #1;
        rd_addr = 5'd2; wb_data = 32'hCAFEBABE; reg_write = 1; // Write to x2
        rs1_addr = 5'd2; // READ from x2 in the EXACT SAME CYCLE
        
        #1; // Wait for Combinational Path (assign) to evaluate
        if (rs1_data == 32'hCAFEBABE) 
            $display("  [PASS] Same-Cycle Forwarding: rs1 immediately reflects 0xCAFEBABE");
        else 
            $display("  [FAIL] Same-Cycle Forwarding failed. rs1 returned 0x%0h", rs1_data);

        // -----------------------------------------------------------
        // [NEW] Test 4: Same-Cycle Write-Through to x0 (Corner Case)
        // -----------------------------------------------------------
        @(posedge clk); #1;
        rd_addr = 5'd0; wb_data = 32'hBADBAD00; reg_write = 1; // Malicious Write to x0
        rs1_addr = 5'd0; // Read from x0 in the EXACT SAME CYCLE
        
        #1; // Wait for Combinational Path
        if (rs1_data == 32'd0) 
            $display("  [PASS] x0 Write-Through Defense: x0 firmly outputs 0x00000000 during same-cycle write");
        else 
            $display("  [FAIL] x0 Write-Through Defense Failed! rs1 bypassed x0 rules and returned 0x%0h", rs1_data);

        $display("===============================================================");
        $display("[UNIT GOLDEN] RegisterFile Verification Completed Successfully.");
        $display("===============================================================");
        $finish;
    end
endmodule
