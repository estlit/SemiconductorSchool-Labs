// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_csr_file.v
//   Testbench for csr file.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_csr_file
// Description: Rigorous Unit Testbench for csr_file (v2.0).
//              * Fixed TB bugs: Added MIE setup before trap, and 
//                corrected synchronous clock timing for MIP checks.
// =========================================================================
module tb_csr_file;

    reg         clk;
    reg         rst;
    reg  [11:0] csr_addr;
    reg  [31:0] csr_wdata;
    reg         csr_write_en;
    reg         trap_req;
    reg  [31:0] trap_cause;
    reg  [31:0] faulting_pc;
    reg  [31:0] trap_val;
    reg         mret_exec;
    reg         ext_irq;

    wire [31:0] csr_rdata;
    wire [31:0] mstatus_out, mie_out, mip_out, mtvec_out, mepc_out;

    integer err_cnt = 0;

    // Instantiate UUT (v2.0)
    csr_file uut (
        .clk(clk), .rst(rst),
        .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_write_en(csr_write_en), .csr_rdata(csr_rdata),
        .trap_req(trap_req), .trap_cause(trap_cause), .faulting_pc(faulting_pc), .trap_val(trap_val), .mret_exec(mret_exec),
        .ext_irq(ext_irq),
        .mstatus_out(mstatus_out), .mie_out(mie_out), .mip_out(mip_out), .mtvec_out(mtvec_out), .mepc_out(mepc_out)
    );

    always #5 clk = ~clk;

    localparam ADDR_MSTATUS = 12'h300;
    localparam ADDR_MIE     = 12'h304;
    localparam ADDR_MTVEC   = 12'h305;
    localparam ADDR_MEPC    = 12'h341;
    localparam ADDR_MCAUSE  = 12'h342;
    localparam ADDR_MIP     = 12'h344;

    // Dual Verification Task: Checks both muxed data and parallel output lines
    task verify_channels;
        input [8*35:1] test_name;
        input [11:0]   target_addr;
        input [31:0]   expected_val;
        input [31:0]   parallel_wire_val;
        begin
            csr_addr = target_addr;
            #1; // Wait for combinational paths
            if (csr_rdata !== expected_val) begin
                $display("  [FAIL] %s (Muxed Read Error)", test_name);
                $display("         Expected: %h, Got: %h", expected_val, csr_rdata);
                err_cnt = err_cnt + 1;
            end else if (parallel_wire_val !== expected_val) begin
                $display("  [FAIL] %s (Parallel Port Sync Error)", test_name);
                $display("         Expected Parallel: %h, Got: %h", expected_val, parallel_wire_val);
                err_cnt = err_cnt + 1;
            end else begin
                $display("  [PASS] %s", test_name);
            end
        end
    endtask

    initial begin
        $timeformat(-9, 0, " ns", 8);
        clk = 0; rst = 1;
        csr_addr = 0; csr_wdata = 0; csr_write_en = 0;
        trap_req = 0; trap_cause = 0; faulting_pc = 0; trap_val = 0;
        mret_exec = 0; ext_irq = 0;
        
        #25 rst = 0;
        $display("===============================================================");
        $display("[UNIT TEST] CSR_FILE v2.0 Parallel Port Verification Start");
        $display("===============================================================");

        // --- Phase 1: Reset & Parallel Initial Routing ---
        $display("--- Phase 1: Parallel Port Verification after Reset ---");
        verify_channels("mstatus Default Verification", ADDR_MSTATUS, 32'h00001800, mstatus_out);
        verify_channels("mepc Default Verification", ADDR_MEPC, 32'h00000000, mepc_out);

        // --- Phase 2: Software Write & Parallel Update ---
        $display("--- Phase 2: Software Write Propagation ---");
        @(posedge clk); #1;
        csr_addr = ADDR_MTVEC; csr_wdata = 32'h80000000; csr_write_en = 1;
        @(posedge clk); #1;
        csr_write_en = 0;
        verify_channels("mtvec Parallel Update Check", ADDR_MTVEC, 32'h80000000, mtvec_out);

        // [FIXED] Must set MIE=1 before trap so MPIE becomes 1 during the trap!
        @(posedge clk); #1;
        csr_addr = ADDR_MSTATUS; csr_wdata = 32'h00001808; csr_write_en = 1; // Bit 3 = 1
        @(posedge clk); #1;
        csr_write_en = 0;

        // --- Phase 3: Hardware Trap & Parallel Core Dumping ---
        $display("--- Phase 3: Hardware Trap Core Dump Routing ---");
        @(posedge clk); #1;
        trap_req = 1; faulting_pc = 32'h00005554; trap_cause = 32'd2; // Illegal Instruction
        @(posedge clk); #1;
        trap_req = 0;
        verify_channels("mepc Hardware Capture Sync", ADDR_MEPC, 32'h00005554, mepc_out);
        verify_channels("mstatus Privilege Shifting Check", ADDR_MSTATUS, 32'h00001880, mstatus_out);

        // --- Phase 4: External Interrupt Asynchronous Mirroring ---
        $display("--- Phase 4: External Interrupt Pin Matching ---");
        ext_irq = 1;
        @(posedge clk); #1; // [FIXED] Must wait for posedge clock to latch ext_irq into mip
        verify_channels("mip MEIP Bit Parallel Injection", ADDR_MIP, 32'h00000800, mip_out);
        
        ext_irq = 0;
        @(posedge clk); #1; // [FIXED] Wait for posedge clock to clear
        verify_channels("mip MEIP Bit Parallel Clearing", ADDR_MIP, 32'h00000000, mip_out);

        // --- Final Evaluation ---
        $display("===============================================================");
        if (err_cnt == 0)
            $display("[ABSOLUTE GOLDEN] csr_file v2.0 100%% Dual-Channel Verified.");
        else
            $display("[CRITICAL FAIL] Parallel Port Synchronization Failed with %0d Errors!", err_cnt);
        $display("===============================================================");
        $finish;
    end

endmodule
