// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_calc.v
//   Testbench for calc.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_calc
// Description: Interactive Calculator Scenario Testbench & Pipeline Trace Monitor
//              (Perfectly matched with 6-Bit FPGA_Arty_S7_Top wrapper)
// =========================================================================
module tb_calc;

    // 1. Clock & Reset
    reg clk;
    reg i_rst_btn; // Active-High Reset (Mapped to BTN2)

    // 2. Physical I/O Pins for Calculator
    reg  [3:0] i_sw;       // Input A: 4-Bit (0~15)
    reg  [1:0] i_btn_b;    // Input B: 2-Bit (0~3) - Reduced for physical pins
    reg        i_btn_mode; // Mode Select (0: ADD, 1: SUB)
    wire [5:0] o_led;      // Result Output: 6-Bit

    // 3. DUT (Design Under Test) Instantiation
    FPGA_Arty_S7_Top u_Top (
        .clk        (clk),
        .i_rst_btn  (i_rst_btn),
        .i_sw       (i_sw),
        .i_btn_b    (i_btn_b),
        .i_btn_mode (i_btn_mode),
        .o_led      (o_led)
    );

    // 4. Clock Generation (100MHz)
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // =========================================================================
    // [Anti-Deception Monitor] Real-time trace of retired instructions in WB stage
    // =========================================================================
    always @(posedge clk) begin
        if (!i_rst_btn) begin // Active when reset is released
            // Exclude NOP (0x13) and initial pipeline garbage (0x00) from trace
            if (u_Top.u_CPU_Core.wb_instr != 32'h00000013 && u_Top.u_CPU_Core.wb_instr != 32'h00000000) begin
                
                // Decode Opcode and Funct3/7 to print instruction name
                case (u_Top.u_CPU_Core.wb_instr[6:0])
                    7'b0110111: $display("[%6t ns] [TRACE] LUI    executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    7'b0100011: $display("[%6t ns] [TRACE] SW     executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    7'b0000011: $display("[%6t ns] [TRACE] LW     executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    7'b0010011: begin
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b111) $display("[%6t ns] [TRACE] ANDI   executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        else if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b000) $display("[%6t ns] [TRACE] ADDI   executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    end
                    7'b0110011: begin
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b000 && u_Top.u_CPU_Core.wb_instr[31:25] == 7'b0000000) $display("[%6t ns] [TRACE] ADD    executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b000 && u_Top.u_CPU_Core.wb_instr[31:25] == 7'b0100000) $display("[%6t ns] [TRACE] SUB    executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b111) $display("[%6t ns] [TRACE] AND    executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b110) $display("[%6t ns] [TRACE] OR     executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b100) $display("[%6t ns] [TRACE] XOR    executed/retired  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    end
                    7'b1100011: begin
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b000) $display("[%6t ns] [TRACE] BEQ    branch evaluated  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                        if (u_Top.u_CPU_Core.wb_instr[14:12] == 3'b001) $display("[%6t ns] [TRACE] BNE    branch evaluated  -> Hex: 0x%08x", $time, u_Top.u_CPU_Core.wb_instr);
                    end
                endcase
            end
        end
    end

    // =========================================================================
    // Main Simulation Control Block (Calculator Scenario)
    // =========================================================================
    initial begin
        // Initialization
        i_rst_btn  = 1'b1; // Active-High Reset applied
        i_sw       = 4'd0;
        i_btn_b    = 2'd0;
        i_btn_mode = 1'b0;
        #25;
        i_rst_btn  = 1'b0; // Reset released

        $display("===============================================================");
        $display(" [INFO] TinyRV32I Calculator Scenario Simulation Started.");
        $display(" [INFO] Hardware Wrapped in FPGA_Arty_S7_Top (6-Bit, 2-Btn Mode)");
        $display("===============================================================");

        // -----------------------------------------------------------
        // Scenario 1: 3 + 2 = 5 (ADD Mode)
        // -----------------------------------------------------------
        // Wait 300ns for pipeline stabilization before applying input
        #300; 
        $display("\n[%6t ns] [INPUT] >>> Setting Inputs: A=3, B=2, Mode=ADD <<<", $time);
        i_sw       = 4'd3;
        i_btn_b    = 2'd2; // Max value for 2-bit B is 3
        i_btn_mode = 1'b0;
        
        #400; // Wait for pipeline execution and WB to MMIO
        $display("[%6t ns] [OUTPUT] Expected: 5 (0x05) | Actual LED: 0x%02x", $time, o_led);
        if (o_led == 6'h05) $display("         -> [PASS] ADD Operation Correct!");
        else                $display("         -> [FAIL] ADD Operation Incorrect!");

        // -----------------------------------------------------------
        // Scenario 2: 1 - 3 = -2 (SUB Mode, Negative Result)
        // -----------------------------------------------------------
        #300;
        $display("\n[%6t ns] [INPUT] >>> Setting Inputs: A=1, B=3, Mode=SUB <<<", $time);
        i_sw       = 4'd1;
        i_btn_b    = 2'd3; 
        i_btn_mode = 1'b1;
        
        #400;
        // The 6-bit two's complement representation of -2 is 0x3E (11_1110)
        $display("[%6t ns] [OUTPUT] Expected: -2 (0x3E) | Actual LED: 0x%02x", $time, o_led);
        if (o_led == 6'h3E) $display("         -> [PASS] SUB (Negative) Operation Correct!");
        else                $display("         -> [FAIL] SUB (Negative) Operation Incorrect!");

        $display("===============================================================");
        $display(" [INFO] Simulation Finished. Review the Trace Log above.");
        $display("===============================================================");
        $finish;
    end
endmodule
