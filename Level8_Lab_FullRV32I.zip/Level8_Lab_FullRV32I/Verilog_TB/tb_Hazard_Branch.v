// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_Hazard_Branch.v
//   Testbench for Hazard Branch.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module tb_Hazard_Branch;

    // Inputs
    reg  [31:0] ex_pc;
    reg  [31:0] ex_imm;
    reg         ex_branch;
    reg         ex_zero_flag;
    reg         system_stall;
    reg         clk;

    // Outputs
    wire [31:0] branch_target;
    wire        branch_taken;
    wire        pipe_stall;
    wire        pipe_flush;

    // Instantiate Module
    Hazard_Branch_Unit u_Hazard (
        .ex_pc        (ex_pc),
        .ex_imm       (ex_imm),
        .ex_branch    (ex_branch),
        .ex_zero_flag (ex_zero_flag),
        .system_stall (system_stall),
        .branch_target(branch_target),
        .branch_taken (branch_taken),
        .pipe_stall   (pipe_stall),
        .pipe_flush   (pipe_flush)
    );

    // Clock Generation (10ns period)
    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; 
        ex_pc = 32'd0; ex_imm = 32'd0;
        ex_branch = 0; ex_zero_flag = 0; system_stall = 0;

        // -----------------------------------------------------------
        // [TEST 1] Branch Not Taken (Condition False) at 10 ns edge
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 1: Branch Instruction, but Condition Not Met (zero=0)");
        ex_pc        = 32'h0000_0010;
        ex_imm       = 32'h0000_0008; // Target should be 0x18
        ex_branch    = 1'b1;
        ex_zero_flag = 1'b0;          // ALU evaluated false
        
        #0.002;
        if (branch_target == 32'h0000_0018 && branch_taken == 1'b0 && pipe_flush == 1'b0)
             $display("[PASS ] TEST 1: Target Calculated(0x18). Branch NOT taken. Flush=0.");
        else $display("[FAIL ] TEST 1: target=%h, taken=%b", branch_target, branch_taken);

        // -----------------------------------------------------------
        // [TEST 2] Branch Taken (Condition True) at 20 ns edge
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 2: Branch Instruction, Condition Met (zero=1)");
        ex_pc        = 32'h0000_0020;
        ex_imm       = 32'hFFFF_FFF0; // -16 (Target should be 0x10)
        ex_branch    = 1'b1;
        ex_zero_flag = 1'b1;          // ALU evaluated true
        
        #0.002;
        if (branch_target == 32'h0000_0010 && branch_taken == 1'b1 && pipe_flush == 1'b1)
             $display("[PASS ] TEST 2: Target Calculated(0x10). Branch TAKEN! Flush=1.");
        else $display("[FAIL ] TEST 2: target=%h, taken=%b", branch_target, branch_taken);

        // -----------------------------------------------------------
        // [TEST 3] Normal Instruction + System Stall at 30 ns edge
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 3: Normal Instruction with MMIO Stall");
        ex_branch    = 1'b0;
        system_stall = 1'b1;
        
        #0.002;
        if (pipe_stall == 1'b1 && branch_taken == 1'b0)
             $display("[PASS ] TEST 3: Pipe Stall activated correctly.");
        else $display("[FAIL ] TEST 3: pipe_stall=%b", pipe_stall);

        #20 $finish;
    end

    // Monitor Log
    always @(posedge clk) begin
        #0.001; 
        $display("------------------------------------------------");
        $display("[T=%0t] CLK ↑ | Branch_Inst: %b | ALU_Zero: %b | Sys_Stall: %b", 
                 $time, ex_branch, ex_zero_flag, system_stall);
        $display("[HZRD ] -> TARGET: %h | TAKEN(FLUSH): %b | PIPE_STALL: %b", 
                 branch_target, branch_taken, pipe_stall);
    end

endmodule
