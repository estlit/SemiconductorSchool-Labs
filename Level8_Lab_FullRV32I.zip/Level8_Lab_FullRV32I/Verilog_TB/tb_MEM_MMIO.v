// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_MEM_MMIO.v
//   Testbench for MEM MMIO.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_MEM_MMIO
// Description: Unit testbench for MEM_MMIO_Decoder
//              * [UPDATED] Verifies 4-bit Byte Enable (Sub-word Access)
//              * Verifies MMIO Routing and Stall Generation
// =========================================================================
module tb_MEM_MMIO;

    // Inputs
    reg         clk;
    reg  [31:0] mem_instr; // [NEW] Added to extract funct3
    reg  [31:0] alu_result;
    reg  [31:0] rs2_data;
    reg         mem_read;
    reg         mem_write;
    reg         peri_npu_ready;
    reg         peri_sonar_ready;

    // Outputs (RAM)
    wire        ram_en;
    wire [3:0]  ram_we;    // [FIX] Updated to 4-bit width
    wire [31:0] ram_addr;
    wire [31:0] ram_wdata;

    // Outputs (MMIO)
    wire        mmio_valid;
    wire        mmio_write;
    wire        cs_board_io, cs_sonar, cs_camera, cs_npu, cs_oled, cs_motor;
    wire        system_stall;

    // Instantiate Module
    MEM_MMIO_Decoder u_Decoder (
        .mem_instr       (mem_instr), // [NEW]
        .alu_result      (alu_result),
        .rs2_data        (rs2_data),
        .mem_read        (mem_read),
        .mem_write       (mem_write),
        .peri_npu_ready  (peri_npu_ready),
        .peri_sonar_ready(peri_sonar_ready),
        
        .ram_en          (ram_en),
        .ram_we          (ram_we),
        .ram_addr        (ram_addr),
        .ram_wdata       (ram_wdata),
        
        .mmio_valid      (mmio_valid),
        .mmio_write      (mmio_write),
        .mmio_addr       (),
        .mmio_wdata      (),
        
        .cs_board_io     (cs_board_io),
        .cs_sonar        (cs_sonar),
        .cs_camera       (cs_camera),
        .cs_npu          (cs_npu),
        .cs_oled         (cs_oled),
        .cs_motor        (cs_motor),
        .system_stall    (system_stall)
    );

    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; 
        mem_instr = 32'd0; alu_result = 0; rs2_data = 0; 
        mem_read = 0; mem_write = 0;
        peri_npu_ready = 1; peri_sonar_ready = 1; // Default to Ready

        $display("===============================================================");
        $display("[UNIT TEST] MEM_MMIO_Decoder Sub-word & Peripheral Routing");
        $display("===============================================================");

        // -----------------------------------------------------------
        // [TEST 1.1] Store Word (SW) - All 4 bytes enabled
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 1.1: Store Word (SW) -> Expect ram_we = 1111");
        mem_instr  = 32'h0000_2023; // funct3 = 010 (SW)
        alu_result = 32'h0000_1024; // Aligned address
        rs2_data   = 32'hDEAD_BEEF; 
        mem_write  = 1'b1; mem_read = 1'b0;
        
        #0.002;
        if (ram_we == 4'b1111 && ram_wdata == 32'hDEAD_BEEF)
             $display("[PASS ] TEST 1.1: SW verified.");
        else $display("[FAIL ] TEST 1.1: we=%b, wdata=%h", ram_we, ram_wdata);

        // -----------------------------------------------------------
        // [TEST 1.2] Store Byte (SB) at offset 1 -> ram_we = 0010
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 1.2: Store Byte (SB) at Offset 1 -> Expect ram_we = 0010");
        mem_instr  = 32'h0000_0023; // funct3 = 000 (SB)
        alu_result = 32'h0000_1025; // Address ends in 01
        rs2_data   = 32'h0000_00AA; // Byte to write is 0xAA
        
        #0.002;
        if (ram_we == 4'b0010 && ram_wdata == 32'hAAAA_AAAA)
             $display("[PASS ] TEST 1.2: SB Offset 1 verified.");
        else $display("[FAIL ] TEST 1.2: we=%b, wdata=%h", ram_we, ram_wdata);

        // -----------------------------------------------------------
        // [TEST 1.3] Store Halfword (SH) at offset 2 -> ram_we = 1100
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 1.3: Store Halfword (SH) at Offset 2 -> Expect ram_we = 1100");
        mem_instr  = 32'h0000_1023; // funct3 = 001 (SH)
        alu_result = 32'h0000_1026; // Address ends in 10
        rs2_data   = 32'h0000_BBAA; // Halfword to write is 0xBBAA
        
        #0.002;
        if (ram_we == 4'b1100 && ram_wdata == 32'hBBAA_BBAA)
             $display("[PASS ] TEST 1.3: SH Offset 2 verified.");
        else $display("[FAIL ] TEST 1.3: we=%b, wdata=%h", ram_we, ram_wdata);

        // -----------------------------------------------------------
        // [TEST 2] MMIO Board I/O Write (LED Control)
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 2: MMIO LED Write (Base 0x4000_0000)");
        mem_instr  = 32'h0000_2023; // SW
        alu_result = 32'h4000_0000; // LED base address
        rs2_data   = 32'h0000_0005; 
        
        #0.002;
        if (ram_en == 0 && mmio_valid == 1 && cs_board_io == 1)
             $display("[PASS ] TEST 2: Routed to Board I/O correctly.");
        else $display("[FAIL ] TEST 2: Routing failed.");

        // -----------------------------------------------------------
        // [TEST 3] MMIO NPU Access & Stall Generation
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 3: NPU Write -> NPU goes BUSY (Ready=0)");
        alu_result = 32'h4000_2000; // NPU base address 
        peri_npu_ready = 1'b0;      // NPU goes busy 
        
        #0.002;
        if (cs_npu == 1 && system_stall == 1)
             $display("[PASS ] TEST 3: NPU Selected and SYSTEM STALL activated!");
        else $display("[FAIL ] TEST 3: Stall generation failed.");

        // -----------------------------------------------------------
        // [TEST 4] NPU Ready Recovery
        // -----------------------------------------------------------
        @(posedge clk); #0.002;
        $display("[INFO ] TEST 4: NPU finishes computation (Ready=1)");
        peri_npu_ready = 1'b1; 
        
        #0.002;
        if (system_stall == 0)
             $display("[PASS ] TEST 4: SYSTEM STALL cleanly deactivated.");
        else $display("[FAIL ] TEST 4: Stall did not release.");

        $display("===============================================================");
        #20 $finish;
    end

    // Monitor Log
    always @(posedge clk) begin
        #0.001; 
        $display("------------------------------------------------");
        $display("[T=%0t] CLK ↑ | Addr: %h | funct3: %b | NPU_RDY: %b", 
                 $time, alu_result, mem_instr[14:12], peri_npu_ready);
        $display("[MMIO ] -> RAM_EN:%b | **RAM_WE:%b** | WDATA:%h | SYS_STALL:%b", 
                 ram_en, ram_we, ram_wdata, system_stall);
    end

endmodule
