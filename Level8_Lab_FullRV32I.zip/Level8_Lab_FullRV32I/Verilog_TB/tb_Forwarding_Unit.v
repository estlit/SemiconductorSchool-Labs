// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_Forwarding_Unit.v
//   Testbench for Forwarding Unit.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
// ============================================================================
// Module      : tb_Forwarding_Unit
// Description : 100% Coverage Verification Testbench for Forwarding Unit.
//               Automatically verifies 7 critical data hazard scenarios.
// ============================================================================
module tb_Forwarding_Unit();

    // Testbench Signals
    reg  [4:0] tb_ex_rs1;
    reg  [4:0] tb_ex_rs2;
    reg  [4:0] tb_mem_rd;
    reg        tb_mem_regwrite;
    reg  [4:0] tb_wb_rd;
    reg        tb_wb_regwrite;

    wire [1:0] tb_forward_a;
    wire [1:0] tb_forward_b;

    // Error tracking
    integer error_count = 0;

    // Instantiate Device Under Test (DUT)
    Forwarding_Unit DUT (
        .ex_rs1       (tb_ex_rs1),
        .ex_rs2       (tb_ex_rs2),
        .mem_rd       (tb_mem_rd),
        .mem_regwrite (tb_mem_regwrite),
        .wb_rd        (tb_wb_rd),
        .wb_regwrite  (tb_wb_regwrite),
        .forward_a    (tb_forward_a),
        .forward_b    (tb_forward_b)
    );

    // Task for checking expected results
    task check_results;
        input [1:0] exp_fwd_a;
        input [1:0] exp_fwd_b;
        input [80:0] test_name;
        begin
            #1; // Wait for combinational logic
            if ((tb_forward_a !== exp_fwd_a) || (tb_forward_b !== exp_fwd_b)) begin
                $display("[ERROR] %s FAILED.", test_name);
                $display("        Expected: FwdA=%b, FwdB=%b", exp_fwd_a, exp_fwd_b);
                $display("        Got     : FwdA=%b, FwdB=%b", tb_forward_a, tb_forward_b);
                error_count = error_count + 1;
            end else begin
                $display("[OK   ] %s passed.", test_name);
            end
        end
    endtask

    // Test Sequence
    initial begin
        $display("============================================================");
        $display(" STARTING VERIFICATION: Forwarding_Unit");
        $display("============================================================");

        // Initialize
        tb_ex_rs1 = 5'd0; tb_ex_rs2 = 5'd0;
        tb_mem_rd = 5'd0; tb_mem_regwrite = 1'b0;
        tb_wb_rd  = 5'd0; tb_wb_regwrite  = 1'b0;
        #10;

        // -------------------------------------------------------------
        // Case 1: No Hazard (Default state, no forwarding)
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd7; tb_mem_regwrite = 1'b1;
        tb_wb_rd  = 5'd8; tb_wb_regwrite  = 1'b1;
        check_results(2'b00, 2'b00, "Case 1: No Hazard                  ");
        #10;

        // -------------------------------------------------------------
        // Case 2: EX Hazard on RS1 (MEM stage forwarding)
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd5; tb_mem_regwrite = 1'b1; // Matches rs1
        tb_wb_rd  = 5'd8; tb_wb_regwrite  = 1'b0;
        check_results(2'b10, 2'b00, "Case 2: EX Hazard on RS1         ");
        #10;

        // -------------------------------------------------------------
        // Case 3: EX Hazard on RS2 (MEM stage forwarding)
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd6; tb_mem_regwrite = 1'b1; // Matches rs2
        tb_wb_rd  = 5'd8; tb_wb_regwrite  = 1'b0;
        check_results(2'b00, 2'b10, "Case 3: EX Hazard on RS2         ");
        #10;

        // -------------------------------------------------------------
        // Case 4: MEM Hazard on RS1 (WB stage forwarding)
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd7; tb_mem_regwrite = 1'b0;
        tb_wb_rd  = 5'd5; tb_wb_regwrite  = 1'b1; // Matches rs1
        check_results(2'b01, 2'b00, "Case 4: MEM Hazard on RS1        ");
        #10;

        // -------------------------------------------------------------
        // Case 5: MEM Hazard on RS2 (WB stage forwarding)
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd7; tb_mem_regwrite = 1'b0;
        tb_wb_rd  = 5'd6; tb_wb_regwrite  = 1'b1; // Matches rs2
        check_results(2'b00, 2'b01, "Case 5: MEM Hazard on RS2        ");
        #10;

        // -------------------------------------------------------------
        // Case 6: Double Hazard on RS1 (Priority Test)
        // Both MEM and WB want to write to the same register.
        // MEM stage is more recent, so it MUST take priority (2'b10).
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd5; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd5; tb_mem_regwrite = 1'b1; // More recent
        tb_wb_rd  = 5'd5; tb_wb_regwrite  = 1'b1; // Older
        check_results(2'b10, 2'b00, "Case 6: Double Hazard (Priority) ");
        #10;

        // -------------------------------------------------------------
        // Case 7: Ignore x0 Register
        // No forwarding should occur if the destination register is x0.
        // -------------------------------------------------------------
        tb_ex_rs1 = 5'd0; tb_ex_rs2 = 5'd6;
        tb_mem_rd = 5'd0; tb_mem_regwrite = 1'b1;
        tb_wb_rd  = 5'd0; tb_wb_regwrite  = 1'b1;
        check_results(2'b00, 2'b00, "Case 7: Ignore x0 Register       ");
        #10;

        $display("============================================================");
        // Final Output
        if (error_count == 0) begin
            $display("[PASS] All verification cases completed successfully.");
        end else begin
            $display("[FAIL] Verification failed with %d errors.", error_count);
        end
        $display("============================================================");
        
        $finish;
    end
endmodule
