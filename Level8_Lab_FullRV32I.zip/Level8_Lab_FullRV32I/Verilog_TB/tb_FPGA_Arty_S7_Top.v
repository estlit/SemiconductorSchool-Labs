// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_FPGA_Arty_S7_Top.v
//   Testbench for FPGA Arty S7 Top.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_FPGA_Arty_S7_Top
// Description: Interactive verification testbench optimized for the 
//              Assembly-based real-time Calculator Demo (calc_demo_full.s).
//              It continuously monitors real-time ADD/SUB ALU responses.
// =========================================================================
module tb_FPGA_Arty_S7_Top;

    reg        clk;
    reg        i_rst_btn;
    reg  [3:0] i_sw;        // Input A (Max 15)
    reg  [1:0] i_btn_b;     // Input B (Max 3)
    reg        i_btn_mode;  // Mode (0: ADD, 1: SUB)
    wire [5:0] o_led;       // Result Output

    // -------------------------------------------------------------------------
    // Instantiate Device Under Test (DUT)
    // -------------------------------------------------------------------------
    FPGA_Arty_S7_Top u_DUT (
        .clk        (clk),
        .i_rst_btn  (i_rst_btn),
        .i_sw       (i_sw),
        .i_btn_b    (i_btn_b),
        .i_btn_mode (i_btn_mode),
        .o_led      (o_led)
    );

    // -------------------------------------------------------------------------
    // Free-Running Hardware Clock (100MHz = 10ns period)
    // -------------------------------------------------------------------------
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk; 
    end

    // -------------------------------------------------------------------------
    // Main Verification Scenario
    // -------------------------------------------------------------------------
    initial begin
        $timeformat(-9, 0, " ns", 10);
        
        $display("===============================================================");
        $display("[SYSTEM] Initializing Standard RV32I Real-Time Calculator TB");
        $display("===============================================================");

        // Step 1: System Initialization
        i_rst_btn  = 1'b1;            
        i_sw       = 4'b0000;
        i_btn_b    = 2'b00;
        i_btn_mode = 1'b0; // Default: ADD Mode
        
        #100;
        i_rst_btn  = 1'b0;            
        $display("[%0t] [HARDWARE] Reset Released. Fetching Assembly Firmware...", $time);
        
        // Wait for pipeline to fill and first loop to execute
        #500; 

        // ---------------------------------------------------------------------
        // Scenario 1: Basic Addition (A=5, B=2) -> Result = 7
        // ---------------------------------------------------------------------
        $display("--- Scenario 1: ADD Mode (5 + 2) ---");
        i_btn_mode = 1'b0;       // ADD
        i_sw       = 4'b0101;    // A = 5
        i_btn_b    = 2'b10;      // B = 2
        
        #500; // Firmware loop takes ~10 cycles (100ns). 500ns is plenty.
        if (o_led == 6'b000111) $display("[PASS] SCENARIO 1: LED Output is 7 (000111)");
        else                    $display("[FAIL] SCENARIO 1: Expected 7, got %d", o_led);

        // ---------------------------------------------------------------------
        // Scenario 2: Subtraction (A=10, B=3) -> Result = 7
        // ---------------------------------------------------------------------
        $display("--- Scenario 2: SUB Mode (10 - 3) ---");
        i_btn_mode = 1'b1;       // SUB
        i_sw       = 4'b1010;    // A = 10
        i_btn_b    = 2'b11;      // B = 3
        
        #500;
        if (o_led == 6'b000111) $display("[PASS] SCENARIO 2: LED Output is 7 (000111)");
        else                    $display("[FAIL] SCENARIO 2: Expected 7, got %d", o_led);

        // ---------------------------------------------------------------------
        // Scenario 3: Real-time Input Change in ADD Mode (A=15, B=1) -> Result = 16
        // ---------------------------------------------------------------------
        $display("--- Scenario 3: Real-Time Input Change (15 + 1) ---");
        i_btn_mode = 1'b0;       // ADD
        i_sw       = 4'b1111;    // A = 15
        i_btn_b    = 2'b01;      // B = 1
        
        #500;
        if (o_led == 6'b010000) $display("[PASS] SCENARIO 3: LED Output is 16 (010000)");
        else                    $display("[FAIL] SCENARIO 3: Expected 16, got %d", o_led);

        $display("===============================================================");
        $display("[PASS] ALL REAL-TIME CALCULATOR VERIFICATION SCENARIOS COMPLETED.");
        $display("===============================================================");
        
        $finish;
    end

    // -------------------------------------------------------------------------
    // Hardware Monitor (LED Output Tracker)
    // -------------------------------------------------------------------------
    reg [5:0] prev_led;
    initial prev_led = 6'b111111; // Dummy initial value to trigger first display

    always @(o_led) begin
        if (o_led !== 6'bx && o_led !== 6'bz && o_led !== prev_led) begin
            $display("[%0t] [PIN_OUTPUT] Physical LED Output Updated -> %b (Dec: %0d)", $time, o_led, o_led);
            prev_led = o_led;
        end
    end

endmodule
