// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_csr_alu.v
//   Testbench for csr alu.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_csr_alu
// Description: Full Coverage Unit Testbench for csr_alu.v
//              Verifies all 6 Zicsr instructions with step-by-step logging.
// =========================================================================
module tb_csr_alu;

    // Inputs
    reg  [31:0] csr_rdata;
    reg  [31:0] rs1_data;
    reg  [4:0]  zimm;
    reg  [2:0]  csr_op;

    // Outputs
    wire [31:0] csr_wdata;
    wire [31:0] rd_data;

    // Error Counter
    integer err_cnt = 0;

    // Instantiate the Unit Under Test (UUT)
    csr_alu uut (
        .csr_rdata(csr_rdata),
        .rs1_data(rs1_data),
        .zimm(zimm),
        .csr_op(csr_op),
        .csr_wdata(csr_wdata),
        .rd_data(rd_data)
    );

    // Operation Codes
    localparam CSRRW  = 3'b001;
    localparam CSRRS  = 3'b010;
    localparam CSRRC  = 3'b011;
    localparam CSRRWI = 3'b101;
    localparam CSRRSI = 3'b110;
    localparam CSRRCI = 3'b111;

    // Task for checking results
    task check_result;
        input [8*20:1] test_name;
        input [31:0]   expected_wdata;
        input [31:0]   expected_rd_data;
        begin
            #1; // Wait for combinational logic
            if (csr_wdata !== expected_wdata || rd_data !== expected_rd_data) begin
                $display("  [FAIL] %s", test_name);
                $display("         Expected: WDATA=%h, RD=%h", expected_wdata, expected_rd_data);
                $display("         Got     : WDATA=%h, RD=%h", csr_wdata, rd_data);
                err_cnt = err_cnt + 1;
            end else begin
                $display("  [PASS] %s", test_name);
            end
        end
    endtask

    initial begin
        $display("===============================================================");
        $display("[UNIT TEST] CSR_ALU Full Coverage Verification Start");
        $display("===============================================================");

        // -----------------------------------------------------------------
        // [Test 1] CSRRW (Read and Write)
        // Operation: Write rs1_data to CSR. Read old CSR to rd.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRW ---");
        csr_rdata = 32'hAAAAAAAA; rs1_data = 32'h55555555; zimm = 5'd0; csr_op = CSRRW;
        check_result("CSRRW Standard Write", 32'h55555555, 32'hAAAAAAAA);

        // -----------------------------------------------------------------
        // [Test 2] CSRRS (Read and Set)
        // Operation: Set bits in CSR according to rs1_data. Read old CSR.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRS ---");
        csr_rdata = 32'h0000000F; rs1_data = 32'h000000F0; zimm = 5'd0; csr_op = CSRRS;
        check_result("CSRRS Set Bits", 32'h000000FF, 32'h0000000F);

        csr_rdata = 32'h12345678; rs1_data = 32'h00000000; zimm = 5'd0; csr_op = CSRRS;
        check_result("CSRRS Zero rs1 (No effect)", 32'h12345678, 32'h12345678);

        // -----------------------------------------------------------------
        // [Test 3] CSRRC (Read and Clear)
        // Operation: Clear bits in CSR according to rs1_data. Read old CSR.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRC ---");
        csr_rdata = 32'hFFFFFFFF; rs1_data = 32'h0000000F; zimm = 5'd0; csr_op = CSRRC;
        check_result("CSRRC Clear Bits", 32'hFFFFFFF0, 32'hFFFFFFFF);

        // -----------------------------------------------------------------
        // [Test 4] CSRRWI (Read and Write Immediate)
        // Operation: Write zero-extended zimm to CSR. Read old CSR.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRWI ---");
        csr_rdata = 32'hCAFEBABE; rs1_data = 32'h0; zimm = 5'h1A; csr_op = CSRRWI;
        check_result("CSRRWI Immediate Write", 32'h0000001A, 32'hCAFEBABE);

        // -----------------------------------------------------------------
        // [Test 5] CSRRSI (Read and Set Immediate)
        // Operation: Set bits in CSR according to zimm. Read old CSR.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRSI ---");
        csr_rdata = 32'h00000010; rs1_data = 32'h0; zimm = 5'h0F; csr_op = CSRRSI;
        check_result("CSRRSI Set Imm Bits", 32'h0000001F, 32'h00000010);

        // -----------------------------------------------------------------
        // [Test 6] CSRRCI (Read and Clear Immediate)
        // Operation: Clear bits in CSR according to zimm. Read old CSR.
        // -----------------------------------------------------------------
        $display("--- Testing CSRRCI ---");
        csr_rdata = 32'h000000FF; rs1_data = 32'h0; zimm = 5'h0F; csr_op = CSRRCI;
        check_result("CSRRCI Clear Imm Bits", 32'h000000F0, 32'h000000FF);

        // -----------------------------------------------------------------
        // Final Status Evaluation
        // -----------------------------------------------------------------
        $display("===============================================================");
        if (err_cnt == 0)
            $display("[ABSOLUTE GOLDEN] csr_alu 100%% Verified. Ready for integration.");
        else
            $display("[CRITICAL FAIL] csr_alu has %0d errors. Do not integrate!", err_cnt);
        $display("===============================================================");
        $finish;
    end

endmodule
