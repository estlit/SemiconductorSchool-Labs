// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_I_MISALIGN_JMP_Sim.v
//   Testbench for I MISALIGN JMP Sim.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_I_MISALIGN_JMP_Sim
// Description: Replicates the core scenario of Python test 'I-MISALIGN_JMP-01.S'.
//              Tests if a JAL instruction targeting a misaligned address 
//              correctly triggers a trap and calculates the exact faulting address.
// =========================================================================
module tb_I_MISALIGN_JMP_Sim;

    reg  clk, rst;
    
    wire cs_board_io, cs_sonar, cs_camera, cs_npu, cs_oled, cs_motor;
    wire mmio_valid, mmio_write;
    wire [31:0] mmio_addr, mmio_wdata;
    reg  [31:0] mmio_rdata = 0; 

    // Instantiate Top Module
    RV32I_Core_Top u_Top (
        .clk(clk), .rst(rst), .ext_irq(1'b0), 
        .peri_board_ready(1'b1), .peri_sonar_ready(1'b1), .peri_camera_ready(1'b1),
        .peri_npu_ready(1'b1), .peri_oled_ready(1'b1), .peri_motor_ready(1'b1),
        .cs_board_io(cs_board_io), .cs_sonar(cs_sonar), .cs_camera(cs_camera), 
        .cs_npu(cs_npu), .cs_oled(cs_oled), .cs_motor(cs_motor),
        .mmio_valid(mmio_valid), .mmio_write(mmio_write), 
        .mmio_addr(mmio_addr), .mmio_wdata(mmio_wdata), .mmio_rdata(mmio_rdata)
    );

    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; rst = 1; 

        // The case from I-MISALIGN_JMP-01.S: a JAL to a misaligned target
        // PC = 0x0, Instruction = JAL x1, +2 (0x002000ef)
        u_Top.u_IF_Stage.rom[0] = 32'h002000ef; 

        // NOPs, so the pipeline settles first
        u_Top.u_IF_Stage.rom[1] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[2] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[3] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[4] = 32'h00000013; 

        $display("===============================================================");
        $display("[START] I-MISALIGN_JMP-01.S Core Scenario Test");
        $display("===============================================================");
        
        #25 rst = 0;
        #150 $finish;
    end

    // Traces the JAL and the trap it should raise
    always @(negedge clk) begin 
        if (!rst) begin
            if (u_Top.ex_instr == 32'h002000ef) begin
                $display("------------------------------------------------");
                $display("[T=%0t] [JAL Misaligned Jump Detected in EX Stage]", $time);
                $display("  -> Spike expects trap_req = 1 and mtval = 0x00000002");
                $display("  -> trap_req  : %b", u_Top.trap_req_out);
                $display("  -> target    : 0x%08x", u_Top.raw_branch_target);
                
                if (u_Top.trap_req_out == 1'b1 && u_Top.raw_branch_target == 32'h00000002) begin
                    $display("  => PASS : the misaligned target was detected.");
                end else begin
                    $display("  => FAIL : the computed target is not the expected value.");
                end
                $display("===============================================================");
            end
        end
    end
endmodule
