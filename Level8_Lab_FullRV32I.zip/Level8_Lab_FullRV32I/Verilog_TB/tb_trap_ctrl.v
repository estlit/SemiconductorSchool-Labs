// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_trap_ctrl.v
//   Testbench for trap ctrl.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_trap_ctrl (v2.3 - Misaligned Exception Coverage)
// Description: Full Coverage Unit Testbench for trap_ctrl.v.
//              * [FIXED] Corrected expected 'next_pc' value to 0 during 
//                normal/masked execution (when override is 0).
//              * [NEW] Added verification for Misaligned Load (Cause 4) and
//                Misaligned Store (Cause 6) exceptions, including mtval checks.
// =========================================================================
module tb_trap_ctrl;

    // Inputs to UUT
    reg         ext_irq;
    reg         mstatus_mie;
    reg  [31:0] mie;
    reg  [31:0] mip;
    reg  [31:0] mtvec;
    reg  [31:0] mepc;
    
    reg         illegal_instr;
    reg         ecall_instr;
    reg         ebreak_instr;
    reg         mret_instr;
    reg  [31:0] current_pc;
    reg  [31:0] instr_val;

    // [NEW] Misaligned Exception Inputs
    reg         misaligned_load;
    reg         misaligned_store;
    reg  [31:0] mem_addr;

    // Outputs from UUT
    wire        trap_req;
    wire [31:0] trap_cause;
    wire [31:0] trap_pc_save;
    wire [31:0] trap_val;
    wire        do_mret;
    wire        pc_override;
    wire [31:0] next_pc;

    // Error Counter
    integer err_cnt = 0;

    // Instantiate the Unit Under Test (UUT)
    trap_ctrl uut (
        .ext_irq(ext_irq),
        .mstatus_mie(mstatus_mie),
        .mie(mie),
        .mip(mip),
        .mtvec(mtvec),
        .mepc(mepc),
        .illegal_instr(illegal_instr),
        .ecall_instr(ecall_instr),
        .ebreak_instr(ebreak_instr),
        .mret_instr(mret_instr),
        .current_pc(current_pc),
        .instr_val(instr_val),
        
        // [NEW] Connect Misaligned Signals
        .misaligned_load(misaligned_load),
        .misaligned_store(misaligned_store),
        .mem_addr(mem_addr),

        .trap_req(trap_req),
        .trap_cause(trap_cause),
        .trap_pc_save(trap_pc_save),
        .trap_val(trap_val),
        .do_mret(do_mret),
        .pc_override(pc_override),
        .next_pc(next_pc)
    );

    // ---------------------------------------------------------------------
    // Verification Task
    // ---------------------------------------------------------------------
    task check_result;
        input [8*45:1] test_name;
        input          exp_trap_req;
        input [31:0]   exp_cause;
        input          exp_override;
        input [31:0]   exp_next_pc;
        input          exp_do_mret;
        begin
            #1; // Wait for combinational logic to settle
            if (trap_req !== exp_trap_req || trap_cause !== exp_cause || 
                pc_override !== exp_override || next_pc !== exp_next_pc || do_mret !== exp_do_mret) begin
                $display("  [FAIL] %s", test_name);
                $display("         Expected: Trap=%b Cause=%h Ovr=%b NextPC=%h MRET=%b", 
                         exp_trap_req, exp_cause, exp_override, exp_next_pc, exp_do_mret);
                $display("         Got     : Trap=%b Cause=%h Ovr=%b NextPC=%h MRET=%b", 
                         trap_req, trap_cause, pc_override, next_pc, do_mret);
                err_cnt = err_cnt + 1;
            end else begin
                $display("  [PASS] %s", test_name);
            end
        end
    endtask

    // ---------------------------------------------------------------------
    // Initialization & Stimulus
    // ---------------------------------------------------------------------
    initial begin
        $timeformat(-9, 0, " ns", 8);
        
        // Default State (Normal Execution)
        ext_irq = 0; mstatus_mie = 0; mie = 0; mip = 0;
        mtvec = 32'h8000_0000; mepc = 32'h0000_4000;
        illegal_instr = 0; ecall_instr = 0; ebreak_instr = 0; mret_instr = 0;
        current_pc = 32'h0000_1000; instr_val = 32'h0000_0000;
        
        misaligned_load = 0; misaligned_store = 0; mem_addr = 32'd0;

        $display("===============================================================");
        $display("[UNIT TEST] TRAP_CTRL Full Coverage Verification Start (v2.3)");
        $display("===============================================================");

        // -----------------------------------------------------------------
        // [Phase 1] Normal Execution (No Traps)
        // -----------------------------------------------------------------
        $display("--- Phase 1: Normal Execution ---");
        check_result("Normal Execution (No overrides)", 0, 32'd0, 0, 32'd0, 0);

        // -----------------------------------------------------------------
        // [Phase 2] Synchronous Exceptions
        // -----------------------------------------------------------------
        $display("--- Phase 2: Synchronous Exceptions ---");
        // 2-1: ECALL
        ecall_instr = 1;
        check_result("ECALL from M-Mode", 1, 32'd11, 1, 32'h8000_0000, 0);
        ecall_instr = 0;

        // 2-2: EBREAK
        ebreak_instr = 1;
        check_result("EBREAK Exception", 1, 32'd3, 1, 32'h8000_0000, 0);
        ebreak_instr = 0;

        // 2-3: Illegal Instruction
        illegal_instr = 1; instr_val = 32'hDEAD_BEEF;
        check_result("Illegal Instruction", 1, 32'd2, 1, 32'h8000_0000, 0);
        if (trap_val !== 32'hDEAD_BEEF) begin
            $display("  [FAIL] mtval did not capture the illegal instruction!"); err_cnt = err_cnt + 1;
        end else $display("  [PASS] mtval correctly captured illegal instruction.");
        illegal_instr = 0; instr_val = 0;

        // 2-4: Misaligned Load Exception
        misaligned_load = 1; mem_addr = 32'h0100_0001; // Odd memory address
        check_result("Misaligned Load Exception", 1, 32'd4, 1, 32'h8000_0000, 0);
        if (trap_val !== 32'h0100_0001) begin
            $display("  [FAIL] mtval did not capture the faulting load address!"); err_cnt = err_cnt + 1;
        end else $display("  [PASS] mtval correctly captured faulting load address.");
        misaligned_load = 0; mem_addr = 0;

        // 2-5: Misaligned Store Exception
        misaligned_store = 1; mem_addr = 32'h0100_0003; // Unaligned word address
        check_result("Misaligned Store Exception", 1, 32'd6, 1, 32'h8000_0000, 0);
        if (trap_val !== 32'h0100_0003) begin
            $display("  [FAIL] mtval did not capture the faulting store address!"); err_cnt = err_cnt + 1;
        end else $display("  [PASS] mtval correctly captured faulting store address.");
        misaligned_store = 0; mem_addr = 0;

        // -----------------------------------------------------------------
        // [Phase 3] External Interrupts & Masking
        // -----------------------------------------------------------------
        $display("--- Phase 3: External Interrupts & Masking ---");
        mip[11] = 1; 

        // 3-1: Globally Masked (MIE=0)
        mstatus_mie = 0; mie[11] = 1;
        check_result("Interrupt Globally Masked (MIE=0)", 0, 32'd0, 0, 32'd0, 0);

        // 3-2: Locally Masked (MEIE=0)
        mstatus_mie = 1; mie[11] = 0;
        check_result("Interrupt Locally Masked (MEIE=0)", 0, 32'd0, 0, 32'd0, 0);

        // 3-3: Fully Enabled Interrupt
        mstatus_mie = 1; mie[11] = 1;
        check_result("Interrupt Triggered & Taken", 1, {1'b1, 31'd11}, 1, 32'h8000_0000, 0);

        // -----------------------------------------------------------------
        // [Phase 4] Priority Resolution (Interrupt vs Exception)
        // -----------------------------------------------------------------
        $display("--- Phase 4: Priority Resolution ---");
        ecall_instr = 1;
        check_result("Priority: Interrupt > Sync Exception", 1, {1'b1, 31'd11}, 1, 32'h8000_0000, 0);
        
        mip[11] = 0; ecall_instr = 0;

        // -----------------------------------------------------------------
        // [Phase 5] MRET Execution & Collisions
        // -----------------------------------------------------------------
        $display("--- Phase 5: MRET Execution ---");
        mret_instr = 1;
        check_result("Standard MRET Execution", 0, 32'd0, 1, 32'h0000_4000, 1);

        mip[11] = 1; 
        check_result("Collision: MRET executes first (restores context)", 0, 32'd0, 1, 32'h0000_4000, 1);

        // -----------------------------------------------------------------
        // Final Evaluation
        // -----------------------------------------------------------------
        $display("===============================================================");
        if (err_cnt == 0)
            $display("[ABSOLUTE GOLDEN] trap_ctrl (v2.3) 100%% Verified. Ready for integration.");
        else
            $display("[CRITICAL FAIL] trap_ctrl has %0d errors. Do not integrate!", err_cnt);
        $display("===============================================================");
        $finish;
    end

endmodule
