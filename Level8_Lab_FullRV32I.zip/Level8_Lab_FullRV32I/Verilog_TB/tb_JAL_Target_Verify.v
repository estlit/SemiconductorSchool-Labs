// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_JAL_Target_Verify.v
//   Testbench for JAL Target Verify.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: tb_JAL_Target_Verify
// Description: Verifies the correct target address routing for JAL vs JALR.
//              Ensures JAL uses the HBU target (PC+imm) instead of the ALU
//              result (which is reserved exclusively for JALR).
// =========================================================================
module tb_JAL_Target_Verify;

    reg  clk, rst;
    
    wire cs_board_io, cs_sonar, cs_camera, cs_npu, cs_oled, cs_motor;
    wire mmio_valid, mmio_write;
    wire [31:0] mmio_addr, mmio_wdata;
    reg  [31:0] mmio_rdata = 0; 

    // Instantiate Top Module
    RV32I_Core_Top u_Top (
        .clk(clk), .rst(rst), .ext_irq(1'b0), 
        .peri_board_ready(1'b1), .peri_sonar_ready(1'b1), .peri_camera_ready(1'b1),
        .peri_npu_ready(1'b1), .peri_oled_ready(1'b1), .peri_motor_ready(1'b1),
        .cs_board_io(cs_board_io), .cs_sonar(cs_sonar), .cs_camera(cs_camera), 
        .cs_npu(cs_npu), .cs_oled(cs_oled), .cs_motor(cs_motor),
        .mmio_valid(mmio_valid), .mmio_write(mmio_write), 
        .mmio_addr(mmio_addr), .mmio_wdata(mmio_wdata), .mmio_rdata(mmio_rdata)
    );

    always #5 clk = ~clk;

    initial begin
        $timeformat(-9, 0, " ns", 8); 
        clk = 1; rst = 1; 

        // 1. JAL x1, +2 (Misaligned Target Address: PC(0) + 2 = 0x00000002)
        // Opcode: 1101111, rd: 00001, imm: 0x00002
        u_Top.u_IF_Stage.rom[0] = 32'h002000ef; 

        // Pipeline stabilization NOPs
        u_Top.u_IF_Stage.rom[1] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[2] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[3] = 32'h00000013; 
        u_Top.u_IF_Stage.rom[4] = 32'h00000013; 

        $display("===============================================================");
        $display("[START] JAL vs JALR Target Address Routing Verification TB");
        $display("===============================================================");
        
        #25 rst = 0;
        #150 $finish;
    end

    // X-Ray Monitoring: Check EX stage for the JAL instruction
    always @(negedge clk) begin 
        if (!rst) begin
            // 002000ef is the JAL instruction we injected
            if (u_Top.ex_instr == 32'h002000ef) begin
                $display("------------------------------------------------");
                $display("[T=%0t] [JAL Instruction Detected in EX Stage]", $time);
                $display("  -> Expected Target: 0x00000002 (PC+2, Misaligned)");
                $display("  -> Actual Target  : 0x%08x", u_Top.raw_branch_target);
                
                if (u_Top.raw_branch_target == 32'h00000002) begin
                    $display("  => PASS : JAL takes its target from the Hazard_Branch_Unit.");
                end else begin
                    $display("  => FAIL : JAL took the ALU result instead of the branch target.");
                end
                $display("===============================================================");
            end
        end
    end
endmodule
