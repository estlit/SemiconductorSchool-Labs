// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_Hazard_Detection_Unit.v
//   Testbench for Hazard Detection Unit.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
// ============================================================================
// Module      : tb_Hazard_Detection_Unit
// Description : 100% Coverage Verification Testbench for Hazard Detection Unit.
//               Automatically verifies 5 critical corner cases.
// ============================================================================
module tb_Hazard_Detection_Unit();

    // Testbench Signals
    reg  [4:0] tb_id_rs1;
    reg  [4:0] tb_id_rs2;
    reg  [4:0] tb_ex_rd;
    reg        tb_ex_memread;
    reg        tb_ext_stall;

    wire       tb_pc_write;
    wire       tb_if_id_write;
    wire       tb_ctrl_mux;

    // Error tracking
    integer error_count = 0;

    // Instantiate Device Under Test (DUT)
    Hazard_Detection_Unit DUT (
        .id_rs1      (tb_id_rs1),
        .id_rs2      (tb_id_rs2),
        .ex_rd       (tb_ex_rd),
        .ex_memread  (tb_ex_memread),
        .ext_stall   (tb_ext_stall),
        .pc_write    (tb_pc_write),
        .if_id_write (tb_if_id_write),
        .ctrl_mux    (tb_ctrl_mux)
    );

    // Task for checking expected results
    task check_results;
        input exp_pc_write;
        input exp_if_id_write;
        input exp_ctrl_mux;
        input [80:0] test_name; // String for test description
        begin
            #1; // Wait for combinational logic propagation
            if ((tb_pc_write !== exp_pc_write) || 
                (tb_if_id_write !== exp_if_id_write) || 
                (tb_ctrl_mux !== exp_ctrl_mux)) begin
                $display("[ERROR] %s FAILED.", test_name);
                $display("        Expected: PC_W=%b, IF_ID_W=%b, CTRL_MUX=%b", exp_pc_write, exp_if_id_write, exp_ctrl_mux);
                $display("        Got     : PC_W=%b, IF_ID_W=%b, CTRL_MUX=%b", tb_pc_write, tb_if_id_write, tb_ctrl_mux);
                error_count = error_count + 1;
            end else begin
                $display("[OK   ] %s passed.", test_name);
            end
        end
    endtask

    // Test Sequence
    initial begin
        $display("============================================================");
        $display(" STARTING VERIFICATION: Hazard_Detection_Unit");
        $display("============================================================");

        // Initialize inputs
        tb_id_rs1     = 5'd0;
        tb_id_rs2     = 5'd0;
        tb_ex_rd      = 5'd0;
        tb_ex_memread = 1'b0;
        tb_ext_stall  = 1'b0;
        #10;

        // -------------------------------------------------------------
        // Case 1: Normal Operation (No Hazard, No Stall)
        // -------------------------------------------------------------
        tb_id_rs1     = 5'd5;
        tb_id_rs2     = 5'd6;
        tb_ex_rd      = 5'd7;
        tb_ex_memread = 1'b0;
        tb_ext_stall  = 1'b0;
        check_results(1'b1, 1'b1, 1'b1, "Case 1: Normal Operation   ");
        #10;

        // -------------------------------------------------------------
        // Case 2: Load-Use Hazard (id_rs1 matches ex_rd)
        // -------------------------------------------------------------
        tb_id_rs1     = 5'd10;
        tb_id_rs2     = 5'd6;
        tb_ex_rd      = 5'd10;
        tb_ex_memread = 1'b1;
        tb_ext_stall  = 1'b0;
        check_results(1'b0, 1'b0, 1'b0, "Case 2: Load-Use on RS1    ");
        #10;

        // -------------------------------------------------------------
        // Case 3: Load-Use Hazard (id_rs2 matches ex_rd)
        // -------------------------------------------------------------
        tb_id_rs1     = 5'd5;
        tb_id_rs2     = 5'd15;
        tb_ex_rd      = 5'd15;
        tb_ex_memread = 1'b1;
        tb_ext_stall  = 1'b0;
        check_results(1'b0, 1'b0, 1'b0, "Case 3: Load-Use on RS2    ");
        #10;

        // -------------------------------------------------------------
        // Case 4: External Stall (No internal hazard)
        // -------------------------------------------------------------
        tb_id_rs1     = 5'd5;
        tb_id_rs2     = 5'd6;
        tb_ex_rd      = 5'd7;
        tb_ex_memread = 1'b0;
        tb_ext_stall  = 1'b1;
        check_results(1'b0, 1'b0, 1'b1, "Case 4: External Stall     ");
        #10;

        // -------------------------------------------------------------
        // Case 5: Ignore x0 Register Dependency
        // Even if ex_memread is 1 and ex_rd matches rs1, if ex_rd is x0,
        // it should NOT cause a hazard (x0 is always 0).
        // -------------------------------------------------------------
        tb_id_rs1     = 5'd0;
        tb_id_rs2     = 5'd6;
        tb_ex_rd      = 5'd0;
        tb_ex_memread = 1'b1;
        tb_ext_stall  = 1'b0;
        check_results(1'b1, 1'b1, 1'b1, "Case 5: Ignore x0 Hazard   ");
        #10;

        $display("============================================================");
        // Final PASS/FAIL Output
        if (error_count == 0) begin
            $display("[PASS] All verification cases completed successfully.");
        end else begin
            $display("[FAIL] Verification failed with %d errors.", error_count);
        end
        $display("============================================================");
        
        $finish;
    end
endmodule
