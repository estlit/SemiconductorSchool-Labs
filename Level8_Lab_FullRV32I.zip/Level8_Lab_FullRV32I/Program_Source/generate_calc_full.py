# =========================================================================
# Semiconductor School
# Author: Roger Kim
# Copyright (c) 2026 Roger Kim & EdgeChipLab
#
# generate_calc_full.py
#   Builds program_calc_full.mem from calc_demo_full.s.
#
#   objcopy's Verilog output writes one byte per entry, which is not what
#   $readmemh expects for a 32-bit ROM. So the flow extracts a raw binary
#   instead and regroups it here: four bytes at a time, little endian,
#   one 32-bit word per line.
#
#   Needs riscv64-unknown-elf-gcc and riscv64-unknown-elf-objcopy. On
#   Windows these usually live inside WSL; set USE_WSL accordingly.
# =========================================================================

import os
import subprocess
import sys

USE_WSL = True

LINKER_SCRIPT = """
OUTPUT_ARCH(riscv)
ENTRY(_start)
SECTIONS
{
  . = 0x00000000;
  .text : { *(.text) }
  .data : { *(.data) }
}
"""


def wrap(cmd):
    """Run through WSL when the toolchain lives there."""
    return ["wsl"] + cmd if USE_WSL else cmd


def compile_app(asm_file, output_mem):
    print("=" * 50)
    print("Building %s" % asm_file)
    print("=" * 50)

    if not os.path.exists(asm_file):
        print("error: %s not found" % asm_file)
        return False

    print("[1/3] assembling and linking")
    with open("link_app.ld", "w", encoding="utf-8") as f:
        f.write(LINKER_SCRIPT)

    gcc = wrap([
        "riscv64-unknown-elf-gcc", "-march=rv32i", "-mabi=ilp32", "-nostdlib",
        "-T", "link_app.ld", asm_file, "-o", "app.elf",
    ])
    try:
        subprocess.run(gcc, check=True, capture_output=True,
                       text=True, encoding="utf-8")
    except subprocess.CalledProcessError as e:
        print("error: gcc failed")
        print(e.stderr)
        return False

    print("[2/3] extracting the raw machine code")
    subprocess.run(wrap([
        "riscv64-unknown-elf-objcopy", "-O", "binary", "-j", ".text",
        "app.elf", "app.bin",
    ]), check=True)

    print("[3/3] regrouping into 32-bit words -> %s" % output_mem)
    with open("app.bin", "rb") as f:
        data = f.read()

    with open(output_mem, "w", encoding="utf-8") as f:
        f.write("@00000000\n")
        for i in range(0, len(data), 4):
            chunk = data[i:i + 4].ljust(4, b"\x00")
            f.write("%08x\n" % int.from_bytes(chunk, byteorder="little"))

    words = (len(data) + 3) // 4
    print("")
    print("done: %s, %d words" % (output_mem, words))
    return True


if __name__ == "__main__":
    ok = compile_app("calc_demo_full.s", "program_calc_full.mem")
    sys.exit(0 if ok else 1)
