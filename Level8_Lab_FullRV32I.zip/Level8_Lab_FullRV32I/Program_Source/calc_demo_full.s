# =========================================================================
# Semiconductor School
# Author: Roger Kim
# Copyright (c) 2026 Roger Kim & EdgeChipLab
#
# calc_demo_full.s
#   A calculator for the Full RV32I core.
#
#   Reads two operands and a mode from memory-mapped I/O, adds or
#   subtracts them, writes the result to the LEDs, and repeats.
#
#   MMIO map, decoded in FPGA_Arty_S7_Top.v:
#
#       0x4000_0000   input A     slide switches, 4 bits
#       0x4000_0004   input B     push buttons, 2 bits
#       0x4000_0008   mode        one button; 0 adds, 1 subtracts
#       0x4000_000C   output      LEDs, 6 bits
#
#   Each read returns a 32-bit word with the switch or button value in
#   the low bits and zeros above.
# =========================================================================

    .text
    .globl _start
_start:
    # ---------------------------------------------------------------
    # Build the MMIO base address, 0x4000_0000
    # ---------------------------------------------------------------
    lui x10, 0x40000

read_inputs:
    # ---------------------------------------------------------------
    # Read A, B and the mode.
    #
    # A load result is used a few instructions later, so the hardware's
    # load-use interlock covers the dependency. No spacing instructions
    # are needed here.
    # ---------------------------------------------------------------
    lw  x11, 0(x10)         # x11 = input A, from the switches
    lw  x12, 4(x10)         # x12 = input B, from the buttons
    lw  x13, 8(x10)         # x13 = mode, 0 adds and 1 subtracts

    # ---------------------------------------------------------------
    # Select the operation.
    #
    # When a branch is taken, the instructions already fetched behind it
    # are invalidated and the PC is redirected to the target. This core
    # has no branch predictor.
    # ---------------------------------------------------------------
    bne x13, x0, do_sub

do_add:
    add x14, x11, x12       # x14 = A + B
    beq x0, x0, write_out

do_sub:
    sub x14, x11, x12       # x14 = A - B

write_out:
    # ---------------------------------------------------------------
    # Write the result and start over.
    # ---------------------------------------------------------------
    sw  x14, 12(x10)        # the low six bits reach the LEDs
    beq x0, x0, read_inputs
