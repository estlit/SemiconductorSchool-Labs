=========================================================================
Semiconductor School
Author: Roger Kim
Copyright (c) 2026 Roger Kim & EdgeChipLab

Level 8 Lab - Full RV32I
=========================================================================

Board   Arty S7-25
Part    xc7s25csga324-1
Vivado  2023.1 or later

The core implements the RV32I base integer instruction set together with
the Zicsr control and status registers, machine-mode traps and external
interrupts. It is a five-stage in-order pipeline with forwarding and a
load-use interlock.

This is not a claim of full RISC-V architectural compliance. It is the
instruction set the course builds and verifies.


FOLDERS
-------------------------------------------------------------------------
Verilog_RTL/      The CPU. Add every file to Design Sources.
                  FPGA_Arty_S7_Top.v is the top module for the board.
                  RV32I_Core_Top.v is the top module for simulation.

Verilog_TB/       Testbenches. Add the one for the lab you are running
                  to Simulation Sources and set it as the simulation top.

Golden_Data/      program_calc_full.mem, the program the CPU runs.
                  Add it to the project as a Memory File.
                  Keep the name. IF_Stage.v looks for it by that name.

Program_Source/   The files that produce program_calc_full.mem.
                  calc_demo_full.s       the calculator in RISC-V assembly
                  generate_calc_full.py  assembles and links it, then
                                         writes the memory image

Vivado_xdc/       TinyRV32I.xdc, the pin assignments. Add to Constraints.


WHAT THE PROGRAM DOES
-------------------------------------------------------------------------
The calculator reads two operands and a mode from memory-mapped I/O,
adds or subtracts them, and writes the result to the LEDs.

    0x4000_0000   input A     slide switches, 4 bits
    0x4000_0004   input B     push buttons, 2 bits
    0x4000_0008   mode        one button; 0 adds, 1 subtracts
    0x4000_000C   output      LEDs, 6 bits

FPGA_Arty_S7_Top.v decodes these four addresses. A read returns a 32-bit
word with the switch or button value in the low bits and zeros above.


RUNNING A SIMULATION
-------------------------------------------------------------------------
1  Open the project.
2  Right click the testbench and set it as the top for simulation.
3  Run Simulation.
4  Read the Tcl Console. Each check prints PASS or FAIL with the value
   it saw. The last line reports the totals.

Every testbench here checks the core and reports PASS or FAIL. None of
them reproduces a defect, and none runs only to print a trace.


VERIFIED
-------------------------------------------------------------------------
All 20 testbenches compile and run. None reports a FAIL.

    tb_Decoder                        45     tb_csr_decode          14
    tb_CSR_Top_Block                  23     tb_ImmGen              12
    tb_ALU                            21     tb_IF_Stage             7
    tb_trap_ctrl                      15     tb_csr_alu              7
    tb_csr_file                        7     tb_MEM_MMIO             6
    tb_PipelineRegs                    6     tb_JAL_Target_Verify    5
    tb_I_MISALIGN_JMP_Sim              5     tb_RegisterFile         4
    tb_FPGA_Arty_S7_Top                4     tb_Hazard_Branch        3
    tb_calc                            2     tb_Forwarding_Unit      1
    tb_Hazard_Detection_Unit           1     tb_I_MISALIGN_JMP_Full_Coverage  1

These figures come from Icarus Verilog. Vivado's simulator runs the same
checks; the wording of the console output differs.


REBUILDING THE PROGRAM
-------------------------------------------------------------------------
Golden_Data/program_calc_full.mem is already built, so the toolchain is
only needed if you change the program.

    cd Program_Source
    python3 generate_calc_full.py

This needs riscv64-unknown-elf-gcc and riscv64-unknown-elf-objcopy. On
Windows they usually live inside WSL; the script has a USE_WSL switch at
the top.

The build writes program_calc_full.mem into Program_Source. Copy it over
the copy in Golden_Data to run the new program.
