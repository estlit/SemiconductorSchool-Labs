# From Data to Circuits

**Semiconductor School / EdgeChipLab**
Author: Roger Kim
Copyright (c) 2026 EdgeChipLab

A hands-on machine learning course for hardware engineers. Fifteen Jupyter
notebooks, one dataset, and one question asked over and over: *what does this
computation cost on a chip?*

Target board for every cost figure: **Digilent Arty S7-25 (XC7S25-1CSGA324C)** —
14,600 look-up tables, 3,650 slices, 29,200 flip-flops, 80 DSP slices, and
1,620 Kb of block RAM (202.5 KB). Figures taken from the Arty S7 FPGA Board
Reference Manual, Digilent, revised 2019-10-25.

There is no Verilog in this volume. Verilog begins at Level 5.

---

# 1. Start here

**Open `Lab01_data_as_array.ipynb` and run every cell, top to bottom.**

Lab 01 begins with a setup cell that installs the three libraries this book
uses. Running it once prepares all fifteen labs — you will not be asked to
install anything again.

```
jupyter notebook Lab01_data_as_array.ipynb
```

Then work through Lab 02, Lab 03, and so on in order. Each lab ends with two
exercises and their worked answers.

If Jupyter is not installed yet:

```
pip install jupyter
```

---

# 2. What is in this folder

## Files you open and work in

| File | What it is | What you do with it |
|---|---|---|
| `Lab01` … `Lab15` (`.ipynb`) | The fifteen labs, in order | **This is the course.** Open, run top to bottom, do the exercises. |
| `README.md` | This file | Read once. |

## Files the labs use

| File | What it is | What you do with it |
|---|---|---|
| `ss_ml.py` | Shared helper module — loads the dataset, draws digits, writes `.mem` files, prints the cost report | Nothing. The labs import it. Open it if you are curious. |
| `data/digits8x8.npz` | The dataset, frozen to a fixed train/test split | Nothing. Never edit it — every lab's numbers depend on it being identical. |

Only these two are shared. **No lab reads the output of another lab**, so you
can run them in any order, or re-run one on its own, and nothing breaks.

## Files each lab produces

| Path | What it is | What you do with it |
|---|---|---|
| `out/labNN/` | Whatever that lab wrote — `.mem` memory images, config text | Look at them. Labs 13 and 14 produce the kind of files that go into an FPGA. Safe to delete; re-running the lab recreates them. |

## Files for checking everything at once (optional)

You never need these to learn from the course. They exist so you can confirm
the whole set runs correctly on your machine.

| File / folder | What it is | What you do with it |
|---|---|---|
| `run_all.py` | Runs all fifteen labs and checks their output | `python run_all.py` |
| `python/Lab01…Lab15.py` | The same labs as plain scripts | Run one directly if you prefer a terminal to a notebook. |
| `expected/*.log` | The output each lab is supposed to produce | Nothing. `run_all.py` compares against these. |
| `logs/*.log` | Output from your most recent check | Read it if a lab fails. |

---

# 3. Checking your installation

One command runs all fifteen labs and verifies them:

```
python run_all.py
```

### What a good run looks like

```
[11/15] Lab11_int8_quantization
        execute ............ OK        (1.3 s)
        log lines .......... 44
        numeric tokens ..... 35
        mismatches ......... 0         PASS

====================================================================
 Labs run               15
 Labs passed            15
 Lines compared         798
 Numeric tokens       1,009
--------------------------------------------------------------------
 Mismatch Count         0
 FINAL RESULT           100% PASS
====================================================================
```

### What a failure looks like

```
 mismatches ......... 1         FAIL
   first at line 30 (integer differs: 680 vs 681)
   expected: Memory        :        681 B
   got     : Memory        :        680 B
```

The exact line is named. Open `logs/LabNN.log` to see the full output.

### How the comparison works

- **Integer tokens must match exactly** — MAC counts, byte counts, node counts,
  mismatch counts. These come from integer arithmetic, so any difference is a
  real difference.
- **Other numbers get 2% relative tolerance.** Floating-point results shift
  slightly between library versions and CPUs; that is not a fault in the lab.
- **Anything that is not a number must match exactly.**
- **Lines beginning with `env |` are skipped** — they report your library
  versions, which naturally differ from machine to machine.

---

# 4. The labs

### Part 1 — Learning as arithmetic

| # | Lab | Hardware point |
|---|---|---|
| 01 | Data is an Array | pixel position becomes a memory address |
| 02 | Multiply and Accumulate | the atom every accelerator is built from |
| 03 | The Direction That Reduces Error | training holds 42% of the board, inference holds 64 bytes |
| 04 | Splitting Into Ten | softmax never changes the argmax |

### Part 2 — Different arithmetic, different circuit

| # | Lab | Hardware point |
|---|---|---|
| 05 | A Classifier With No Multiplier | MAC = 0, comparators only |
| 06 | Fifty Trees | independent trees parallelise, boosting cannot |
| 07 | The Classifier That Remembers | most accurate, 42% of the board |
| 08 | Grouping Without Answers | argmin is argmax with the sign flipped |
| 09 | Sixty-Four Down to Sixteen | PCA loses here, and we say so |
| 10 | Filling In The Table | three families: DSP, LUT, block RAM |

### Part 3 — Integers, then silicon

| # | Lab | Hardware point |
|---|---|---|
| 11 | From Real Numbers to Integers | INT8 costs no accuracy at all |
| 12 | Shifting Down, and Breaking It | wrap is not saturation |
| 13 | Writing the Answer Key | compare scores, never just the class |
| 14 | The First Real One | the Level 5 classifier, in Python |
| 15 | The 28x28 Threshold | why convolution exists |

---

# 5. Measured on the Arty S7-25

Every figure below comes out of the notebooks, not from a table someone typed.

| Algorithm | MAC | Compare | Memory | BRAM | Accuracy |
|---|---|---|---|---|---|
| Logistic regression | 640 | 9 | 2,600 B | 1.3 % | 96.2 % |
| PCA-16 + logistic | 1,184 | 9 | 4,736 B | 2.3 % | 94.2 % |
| Decision tree | 0 | 7 | 1,590 B | 0.8 % | 82.0 % |
| Random forest (50) | 0 | 394 | 95,892 B | 46.2 % | 98.0 % |
| k-NN (k=3) | 86,208 | 1,347 | 87,555 B | 42.2 % | 98.4 % |
| k-means (k=10) | 640 | 9 | 640 B | 0.3 % | 77.3 % |

The most accurate model is also the one that takes a large share of the board.
That tension is the course.

Tree memory allows six bytes per node — a deliberately generous figure, since
a tight encoding fits a node in 31 bits. It is fixed once in Lab 05 and used
unchanged afterwards, so the comparisons stay fair. Whether the forest or k-NN is larger
depends on it, so treat both as "expensive" rather than ranking them.

---

# 6. House rules

- **Accuracy is always printed next to its baseline.** On an unbalanced task a
  number on its own means nothing.
- **Anything tuned is tuned on a validation set.** The test set is opened once,
  at the end (Lab 12).
- **Only measured numbers appear in tables.** Where a figure could not be
  measured, the column is left out rather than filled from memory (Lab 15).
- **Assumptions are stated where they are made** and never quietly changed.

---

# 7. Where this leads

- **Level 5** — the Lab 14 line classifier, in Verilog on the Arty S7
- **Level 6** — the Lab 15 convolution, as a full MNIST CNN

---

Semiconductor School · www.SemiconductorSchool.co.kr
