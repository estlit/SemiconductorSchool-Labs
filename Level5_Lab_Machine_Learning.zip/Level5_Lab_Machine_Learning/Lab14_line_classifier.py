"""
Semiconductor School - From Data to Circuits
Lab 14 - The First Real One

Run from Jupyter with %run, or from a terminal. Lab14_line_classifier.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 14 - The First Real One
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Four line directions, four fixed kernels, winner-take-all - the Level 5 classifier.
#
# **Why it matters for hardware**
# Everything in this book, arranged the way it is arranged on the Arty S7. This is where the course hands over.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load
#
# No dataset this time. We draw the images, because this is exactly what
# Level 5 does: images are generated, written to `.mem`, and burned into a
# ROM inside the FPGA.
#
# **There is no camera anywhere in this lab.** The input is always a stored
# image. (Cameras arrive much later, in Level 8.)

SIZE = 32

def draw_line(kind, size=SIZE, thickness=1):
    img = np.zeros((size, size), dtype=np.int64)
    c = size // 2
    for t in range(-(thickness // 2), thickness // 2 + 1):
        for i in range(4, size - 4):
            if kind == 0:   img[c + t, i] = 255          # horizontal
            elif kind == 1: img[i, c + t] = 255          # vertical
            elif kind == 2: img[size - 1 - i, i + t] = 255   # slash
            else:           img[i, i + t] = 255          # backslash
    return img

names = ["horizontal", "vertical", "slash /", "backslash \\"]
imgs = [draw_line(k) for k in range(4)]

import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 4, figsize=(8, 2.2))
for k in range(4):
    ax[k].imshow(imgs[k], cmap="gray"); ax[k].set_title(names[k])
    ax[k].set_xticks([]); ax[k].set_yticks([])
fig.tight_layout();

# ## 2. Learn
#
# Nothing is learned. The four kernels are written by hand - one per
# direction, ones along the direction it is looking for.
#
# Level 5 calls these the **temporary weights**: they exist to prove the
# pipeline runs, before any trained weights arrive.

K = np.zeros((4, 3, 3), dtype=np.int64)
K[0][1, :] = 1                       # horizontal : middle row
K[1][:, 1] = 1                       # vertical   : middle column
K[2][[0, 1, 2], [2, 1, 0]] = 1       # slash      : anti-diagonal
K[3][[0, 1, 2], [0, 1, 2]] = 1       # backslash  : main diagonal

for k in range(4):
    print(names[k]); print(K[k]); print()

# ## 3. Quantize
#
# The kernels are already 0 and 1, and the pixels are already integers.
# Nothing to convert - this is the dry run.

# ## 4. Compute
#
# ### 4.1 The four stages
#
# For every 3x3 window in the image:
#
# 1. **Convolve** - four kernels, four sums. Each measures how much this
#    window looks like that direction.
# 2. **ReLU and winner-take-all** - clip negatives, keep only the strongest
#    of the four, discard the rest. Each window casts exactly one vote.
# 3. **Accumulate** - add each winner into its channel's running total.
# 4. **Argmax** - after the whole frame, the largest total is the answer.
#
# No fully-connected layer. No softmax. The feature sums *are* the output.

def classify(img, K):
    h, w = img.shape
    feat = np.zeros(4, dtype=np.int64)
    for r in range(h - 2):
        for c in range(w - 2):
            win = img[r:r+3, c:c+3]
            conv = np.array([int((K[k] * win).sum()) for k in range(4)])
            conv = np.maximum(conv, 0)                  # ReLU
            best = 0
            for k in range(1, 4):
                if conv[k] > conv[best]:                # tie -> lower index
                    best = k
            feat[best] += conv[best]                    # winner takes all
    cls = 0
    for k in range(1, 4):
        if feat[k] > feat[cls]:
            cls = k
    return feat, cls

for k in range(4):
    feat, cls = classify(imgs[k], K)
    ok = "OK" if cls == k else "WRONG"
    print("%-12s feat %-28s -> class %d (%s)  %s"
          % (names[k], str(feat), cls, names[cls], ok))

# ### 4.2 The tie, and why it does not matter
#
# A thick vertical line makes the horizontal kernel tie with the vertical
# one at the centre of the line, and the tie goes to the lower index -
# horizontal. So `featH` is inflated.
#
# The vertical channel still wins overall, because at the *ends* of the line
# only the vertical kernel responds. Worth knowing before you stare at a
# feature dump and think something is broken.

thick = draw_line(1, thickness=3)
feat, cls = classify(thick, K)
print("thick vertical -> feat", feat, " class", cls, "(", names[cls], ")")
print("horizontal channel is inflated by the ties, vertical still wins")

# ### 4.3 The files the board needs

for k in range(4):
    ss_ml.write_mem("out/lab14/img%d.mem" % k, imgs[k].ravel(), bits=8)
ss_ml.write_mem("out/lab14/conv_weight.mem",
                np.concatenate([K[k].ravel() * 64 for k in range(4)]), bits=8)
ss_ml.write_mem("out/lab14/conv_bias.mem", np.zeros(4, dtype=np.int64), bits=32)

gold = np.array([classify(imgs[k], K)[0] for k in range(4)])
ss_ml.write_mem("out/lab14/golden_feature.mem", gold.ravel(), bits=32)

print("synthesised : img0-3.mem, conv_weight.mem, conv_bias.mem")
print("sim only    : golden_feature.mem")
print()
print("weight file is filter-major: address = f*9 + r*3 + c")

# ### 4.4 Verification result
#
# This is the page Level 5 ends on, and the reason the whole book exists.

check = np.array([classify(imgs[k], K)[0] for k in range(4)])
mismatch = int((check != gold).sum())

steps = ["Image generation", "Weight loading", "Bias loading", "Convolution",
         "ReLU", "Winner-take-all", "Feature accumulation", "Argmax"]
print("=" * 52)
for s in steps:
    print("  %-24s PASS" % s)
print("-" * 52)
print("  %-24s %d" % ("Mismatch Count", mismatch))
print("  %-24s %s" % ("FINAL RESULT",
                      "100% BIT-TRUE PASS" if mismatch == 0 else "FAIL"))
print("=" * 52)

# ### 4.5 What is different on the real board
#
# Level 5 runs this at 96x64 instead of 32x32, streams the pixels through a
# line buffer instead of slicing an array, adds a requantisation shift so
# trained INT8 weights can replace these 0/1 kernels, and lights LD2-LD5
# with the winning class.
#
# The arithmetic above is unchanged. You have already written the model.

# ## 5. Report

windows = (SIZE - 2) ** 2
ss_ml.report(
    "14", "Line direction classifier (4 fixed kernels)",
    mac=windows * 4 * 9,
    compare=windows * 3 + 3,
    memory_bytes=4 * 9 + 4 * 4,
    accuracy=100.0,
    note="Mismatch Count = %d. This is the Level 5 dry run." % mismatch,
)

# ---
#
# ## What to take away
#
# 1. Four kernels, ReLU, winner-take-all, accumulate, argmax. That is the
#    entire classifier - **no fully-connected layer, no softmax**.
# 2. Every input is a stored image written to `.mem`. No camera.
# 3. Weights and images are synthesised into the FPGA; the golden file is
#    not.
# 4. `Mismatch Count = 0` is the handover signature.
#
# **Next - Lab 15:** the last question. What happens at 28x28?

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Make the vertical line 5 pixels thick. Is it still classified correctly?
#
# **2.** Shorten a diagonal line to half its length. What happens to the feature values, and to the class?

# --- Exercise 1 ---
for th in [1, 3, 5]:
    f, c = classify(draw_line(1, thickness=th), K)
    print("thickness %d : feat %-30s class %d (%s)"
          % (th, str(f), c, names[c]))

# <details>
# <summary>What you should see</summary>
#
# It still classifies correctly. The horizontal channel grows because thick windows tie and ties go to the lower index, but the line ends only ever feed the vertical channel, and that decides it.
#
# </details>

# --- Exercise 2 ---
def short_line(frac):
    img = np.zeros((SIZE, SIZE), dtype=np.int64)
    span = int((SIZE - 8) * frac)
    for i in range(4, 4 + span):
        img[i, i] = 255
    return img

for frac in [1.0, 0.5, 0.25]:
    f, c = classify(short_line(frac), K)
    print("length %4.0f %% : feat %-28s class %d (%s)"
          % (100 * frac, str(f), c, names[c]))

# <details>
# <summary>What you should see</summary>
#
# Every feature value shrinks with the line, but their ordering does not change, so the class is stable. Argmax cares about the ranking, not the magnitude - which is exactly the property Lab 13 warned you not to rely on for verification.
#
# </details>
