"""
Semiconductor School - From Data to Circuits
Lab 09 - Sixty-Four Down to Sixteen

Run from Jupyter with %run, or from a terminal. Lab09_pca.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 09 - Sixty-Four Down to Sixteen
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# PCA compresses the input - and in this case it does not pay off.
#
# **Why it matters for hardware**
# Compression saves bandwidth but costs arithmetic. Whether that is a win depends entirely on the size of the input, and here it is not.

import numpy as np
import ss_ml

ss_ml.board_summary()

# > **Every cost in this lab is the cost of one inference.**
# >
# > The notebook calls `fit()` as well as `predict()`, but only the second one
# > describes what runs on a chip. Training happens once, on a PC, and Lab 03
# > measured what it would cost to move it: the training data alone needs 42% of
# > the board's memory, against 64 bytes for a single inference.
# >
# > So when a table below says 640 MAC, read it as *640 multiply-accumulates to
# > classify one image* - not the cost of producing the model.

# ## 1. Load

ds = ss_ml.load_digits8x8()
xtr, xte = ds.x_train / 16.0, ds.x_test / 16.0

# ## 2. Learn
#
# Most of the 64 pixels are boring. Corners are almost always dark; the
# centre carries the information.
#
# PCA finds the directions along which the images actually vary and lets us
# describe each digit with 16 numbers instead of 64.

from sklearn.decomposition import PCA

N_COMP = 16
pca = PCA(n_components=N_COMP).fit(xtr)

print("components :", pca.components_.shape, " (each is a 64-pixel pattern)")
print("variance kept : %.1f %%" % (100 * pca.explained_variance_ratio_.sum()))
ss_ml.show_grid(pca.components_, ["pc%d" % i for i in range(N_COMP)], n=N_COMP);

# ### Rebuilt from 16 numbers
#
# Top row: original. Bottom row: thrown away and rebuilt from 16 values.

import matplotlib.pyplot as plt
recon = pca.inverse_transform(pca.transform(xte[:8]))
fig, axes = plt.subplots(2, 8, figsize=(8, 2.2))
for i in range(8):
    ss_ml.show_digit(xte[i] * 16, None, ax=axes[0, i])
    ss_ml.show_digit(np.clip(recon[i], 0, 1) * 16, None, ax=axes[1, i])
axes[0, 0].set_ylabel("orig"); axes[1, 0].set_ylabel("16")
fig.tight_layout();

# ## 3. Quantize
#
# Not in this lab.

# ## 4. Compute
#
# ### 4.1 Classify from the compressed form

from sklearn.linear_model import LogisticRegression

ztr, zte = pca.transform(xtr), pca.transform(xte)
clf = LogisticRegression(max_iter=2000).fit(ztr, ds.y_train)
acc = 100.0 * clf.score(zte, ds.y_test)

print("PCA-16 + logistic : %.1f %%" % acc)
print("plain logistic    : 96.2 %%  (Lab 04)")

# ### 4.2 Count honestly
#
# Projecting is itself a matrix multiply. 64 inputs to 16 outputs is
# 1,024 MACs - before the classifier has done anything.

mac_proj = 64 * N_COMP
mac_clf = N_COMP * 10
mac_total = mac_proj + mac_clf

print("projection      : {:>6,} MAC".format(mac_proj))
print("classifier      : {:>6,} MAC".format(mac_clf))
print("total           : {:>6,} MAC".format(mac_total))
print("plain logistic  : {:>6,} MAC   (Lab 04)".format(640))
print()
print("PCA costs {:.0f}%% MORE arithmetic, and scores {:.1f} points lower."
      .format(100 * (mac_total / 640 - 1), 96.2 - acc))

# ### 4.3 So PCA loses here. Say so.
#
# More arithmetic, less accuracy. On this problem, at this size, PCA is the
# wrong choice and there is no way to dress that up.
#
# It is worth knowing exactly **why**, because the answer is not "PCA is
# bad":
#
# - The projection costs `input x components`. With 64 inputs that is
#   already larger than the classifier it feeds.
# - The saving only appears when the input is much larger than the
#   reduced form. At 64 pixels there is nothing to save.
# - Where PCA does pay off is when the raw input has to travel - off-chip,
#   over a bus, through a sensor interface. Fewer numbers moved means less
#   bandwidth and less power, and *that* saving does not show up in a MAC
#   count at all.
#
# **Reporting a technique that loses is part of the job.** A cost model you
# only run when you already like the answer is not a cost model.

for n_img in [1, 100, len(ds.y_train)]:
    raw = n_img * 64
    comp = n_img * N_COMP + 64 * N_COMP        # compressed data + projection matrix
    winner = "PCA wins" if comp < raw else "raw wins"
    print("store {:>5,} images : raw {:>8,} B | PCA {:>8,} B | {}".format(
        n_img, raw, comp, winner))

# ## 5. Report

mem = pca.components_.size * 4 + clf.coef_.size * 4

ss_ml.report(
    "09", "PCA-%d + logistic regression" % N_COMP,
    mac=mac_total,
    compare=9,
    memory_bytes=mem,
    accuracy=acc,
    note="More MACs than plain logistic, and lower accuracy. PCA loses here.",
)

# ---
#
# ## What to take away
#
# 1. 16 numbers hold enough of an 8x8 digit to rebuild it recognisably.
# 2. But projection is a matrix multiply, and at 64 inputs it costs more
#    than the classifier it replaces.
# 3. **On this problem PCA is a net loss** - more arithmetic, lower accuracy.
# 4. Compression pays when data has to move, not when it is already on chip
#    and small.
#
# **Next - Lab 10:** everything measured so far, in one table.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Try 4, 8, 16 and 32 components. Where does accuracy stop improving?
#
# **2.** How many components are needed to keep 95% of the variance?

# --- Exercise 1 ---
for nc in [4, 8, 16, 32]:
    p2 = PCA(n_components=nc).fit(xtr)
    c2 = LogisticRegression(max_iter=2000).fit(p2.transform(xtr), ds.y_train)
    print("%2d components : accuracy %.1f %%   MAC %5d   variance %.0f %%"
          % (nc, 100 * c2.score(p2.transform(xte), ds.y_test),
             64 * nc + nc * 10, 100 * p2.explained_variance_ratio_.sum()))

# <details>
# <summary>What you should see</summary>
#
# Accuracy flattens well before 32 components, but the MAC count keeps climbing. More components buy variance, not necessarily accuracy.
#
# </details>

# --- Exercise 2 ---
full = PCA().fit(xtr)
cum = np.cumsum(full.explained_variance_ratio_)
need = int(np.argmax(cum >= 0.95) + 1)
print("components for 95 %% variance :", need)
print("MAC for that projection      :", 64 * need + need * 10)

# <details>
# <summary>What you should see</summary>
#
# Around 28 components - and the projection then costs nearly three times the plain classifier. PCA is not free.
#
# </details>
