"""
Semiconductor School - From Data to Circuits
Lab 08 - Grouping Without Answers

Run from Jupyter with %run, or from a terminal. Lab08_kmeans.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 08 - Grouping Without Answers
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# k-means finds structure with no labels at all - and argmin picks the winner.
#
# **Why it matters for hardware**
# Argmin is argmax with the comparison flipped. The same comparator tree that ends the Level 5 classifier.

import numpy as np
import ss_ml

ss_ml.board_summary()

# > **Every cost in this lab is the cost of one inference.**
# >
# > The notebook calls `fit()` as well as `predict()`, but only the second one
# > describes what runs on a chip. Training happens once, on a PC, and Lab 03
# > measured what it would cost to move it: the training data alone needs 42% of
# > the board's memory, against 64 bytes for a single inference.
# >
# > So when a table below says 640 MAC, read it as *640 multiply-accumulates to
# > classify one image* - not the cost of producing the model.

# ## 1. Load

ds = ss_ml.load_digits8x8()

# ## 2. Learn
#
# Everything so far used labels. k-means does not. It is handed the images
# with no answers and told to sort them into ten piles.
#
# Two steps, repeated:
#
# 1. **Assign** - put each image in the pile whose centre is nearest.
# 2. **Update** - move each centre to the average of its pile.
#
# That is the whole algorithm, written out below.

rng = np.random.default_rng(0)
X = ds.x_train.astype(np.float64)
K = 10

centres = X[rng.choice(len(X), K, replace=False)].copy()

for step in range(25):
    d = ((X[:, None, :] - centres[None, :, :]) ** 2).sum(axis=2)
    assign = d.argmin(axis=1)                       # <-- argmin
    moved = 0.0
    for k in range(K):
        if (assign == k).any():
            new = X[assign == k].mean(axis=0)
            moved += np.abs(new - centres[k]).sum()
            centres[k] = new
    if step % 8 == 0:
        print("step %2d  centres moved %.2f" % (step, moved))
print("converged")

# ### What did it find?
#
# Nobody told it what a digit is. Ten averaged images came out anyway.

ss_ml.show_grid(centres, ["c%d" % k for k in range(K)], n=K);

# ## 3. Quantize
#
# Not in this lab.

# ## 4. Compute
#
# ### 4.1 Scoring it
#
# To measure accuracy we have to attach a label to each cluster after the
# fact - whichever digit is most common inside it. The clustering itself
# never saw a label.

cluster_label = np.zeros(K, dtype=int)
for k in range(K):
    members = ds.y_train[assign == k]
    cluster_label[k] = np.bincount(members).argmax() if len(members) else 0

dte = ((ds.x_test[:, None, :] - centres[None, :, :]) ** 2).sum(axis=2)
pred = cluster_label[dte.argmin(axis=1)]
acc = 100.0 * (pred == ds.y_test).mean()
print("accuracy after labelling the clusters : %.1f %%" % acc)

# ### 4.2 The cost, and the contrast that matters
#
# Distance against **ten** centres, not thirteen hundred images.

mac = K * ss_ml.N_PIXEL
mem = K * ss_ml.N_PIXEL

print("k-means : {:>6,} MAC   {:>7,} B".format(mac, mem))
print("k-NN    : {:>6,} MAC   {:>7,} B   (Lab 07)".format(
    len(ds.y_train) * 64, ds.x_train.size + len(ds.y_train)))
print()
print("ratio   : {:.0f}x less arithmetic, {:.0f}x less memory".format(
    len(ds.y_train) / K, (ds.x_train.size + len(ds.y_train)) / mem))

# Same distance arithmetic. Same comparator at the end. The only difference
# is **how many things you compare against** - and that one number decides
# whether the design fits on the board.
#
# ### 4.3 Argmin is argmax with the sign flipped
#
# Lab 04 took the largest score. This lab takes the smallest distance. The
# circuit is identical apart from which way the comparator points.
#
# When you reach the Level 5 classifier and meet its winner-take-all stage,
# this is the block you are looking at.

def argmin_tree(v):
    best, best_i = v[0], 0
    for i in range(1, len(v)):
        if v[i] < best:          # '>' in Lab 04, '<' here. That is the whole diff.
            best, best_i = v[i], i
    return best_i

print("argmin picks cluster", argmin_tree(dte[0]),
      "-> label", cluster_label[argmin_tree(dte[0])],
      " (true", ds.y_test[0], ")")
print("compares:", K - 1)

# ## 5. Report

ss_ml.report(
    "08", "k-means clustering (k=%d)" % K,
    mac=mac,
    compare=K - 1,
    memory_bytes=mem,
    accuracy=acc,
    note="Same distance maths as k-NN against 10 vectors instead of 1,347.",
)

# ---
#
# ## What to take away
#
# 1. k-means needs no labels - structure alone is enough to separate digits.
# 2. Distance plus argmin, exactly the arithmetic of Lab 07.
# 3. Ten centres instead of 1,347 images: two orders of magnitude cheaper,
#    and it drops from half the board to a rounding error.
# 4. **Argmin and argmax are the same comparator tree.** You will meet it
#    again in Level 5.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Run k-means with 5 clusters instead of 10. What happens to accuracy, and why?
#
# **2.** Change the argmin tie-break from `<` to `<=`. Does any prediction change?

# --- Exercise 1 ---
for kk in [5, 10, 20]:
    c = X[np.random.default_rng(0).choice(len(X), kk, replace=False)].copy()
    for _ in range(25):
        asg = ((X[:, None, :] - c[None, :, :]) ** 2).sum(2).argmin(1)
        for j in range(kk):
            if (asg == j).any():
                c[j] = X[asg == j].mean(axis=0)
    lb = np.array([np.bincount(ds.y_train[asg == j]).argmax()
                   if (asg == j).any() else 0 for j in range(kk)])
    a = 100.0 * (lb[((ds.x_test[:, None, :] - c[None, :, :]) ** 2)
                    .sum(2).argmin(1)] == ds.y_test).mean()
    print("k=%2d : accuracy %.1f %%" % (kk, a))

# <details>
# <summary>What you should see</summary>
#
# With 5 clusters two digits have to share a pile, so accuracy falls hard. With 20 it rises, because a digit may be written in several distinct ways.
#
# </details>

# --- Exercise 2 ---
def argmin_le(v):
    best, best_i = v[0], 0
    for i in range(1, len(v)):
        if v[i] <= best:
            best, best_i = v[i], i
    return best_i

diff = sum(argmin_tree(row) != argmin_le(row) for row in dte)
print("predictions changed :", diff, "of", len(dte))

# <details>
# <summary>What you should see</summary>
#
# Zero, because exact ties between float distances essentially never happen. With integers they happen constantly - which is why Level 5 fixes the tie-break explicitly.
#
# </details>
