"""
Semiconductor School - From Data to Circuits
Lab 06 - Fifty Trees

Run from Jupyter with %run, or from a terminal. Lab06_random_forest.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 06 - Fifty Trees
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Many weak trees, each voting, beat one strong tree.
#
# **Why it matters for hardware**
# Fifty trees run at the same time in the same clock cycle - spend area, keep the latency. Boosting cannot do this, and the reason is worth knowing.

import numpy as np
import ss_ml

ss_ml.board_summary()

# > **Every cost in this lab is the cost of one inference.**
# >
# > The notebook calls `fit()` as well as `predict()`, but only the second one
# > describes what runs on a chip. Training happens once, on a PC, and Lab 03
# > measured what it would cost to move it: the training data alone needs 42% of
# > the board's memory, against 64 bytes for a single inference.
# >
# > So when a table below says 640 MAC, read it as *640 multiply-accumulates to
# > classify one image* - not the cost of producing the model.

# ## 1. Load

ds = ss_ml.load_digits8x8()

# ## 2. Learn
#
# Grow fifty trees, each on a slightly different slice of the data, and let
# them vote. Errors that one tree makes, the other forty-nine usually do not.

from sklearn.ensemble import RandomForestClassifier

N_TREES = 50
forest = RandomForestClassifier(n_estimators=N_TREES, random_state=0)
forest.fit(ds.x_train, ds.y_train)

acc = 100.0 * forest.score(ds.x_test, ds.y_test)
nodes = sum(t.tree_.node_count for t in forest.estimators_)

print("trees      :", N_TREES)
print("total nodes:", nodes)
print("accuracy   : %.1f %%   (one tree in Lab 05: 82.0 %%)" % acc)

# ## 3. Quantize
#
# Nothing to do, same as Lab 05.

# ## 4. Compute
#
# ### 4.1 Fifty walks and a vote

votes = np.zeros(10, dtype=int)
for t in forest.estimators_:
    votes[int(t.predict(ds.x_test[:1])[0])] += 1

print("true label:", ds.y_test[0])
for d in range(10):
    if votes[d]:
        print("  digit %d : %2d votes  %s" % (d, votes[d], "#" * votes[d]))

# ### 4.2 The part that makes hardware people happy
#
# The fifty trees **do not depend on each other**. Tree 7 does not need
# tree 6's answer. Build fifty comparator paths side by side and they all
# finish in the same cycle count as one.
#
# Fifty times the area. The same latency. On an FPGA, where area is what
# you have and latency is what you are fighting, that is a very good trade.

# same counting rule as Lab 05: average path length, not maximum depth
avg_path = np.mean([t.decision_path(ds.x_test).sum(axis=1).mean() - 1
                    for t in forest.estimators_])

print("one tree             : %.1f compares, %.1f steps" % (avg_path, avg_path))
print("50 trees in parallel : %.1f compares each, still %.1f steps"
      % (avg_path, avg_path))
print("50 trees in sequence : %.0f compares, %.0f steps"
      % (50 * avg_path, 50 * avg_path))

# ### 4.3 Boosting cannot do that
#
# Boosting also combines many trees, and often scores a little higher. But
# it builds each tree **to correct the previous one's mistakes**. Tree 7
# is meaningless until tree 6 has run.
#
# Sequential dependency. No amount of area buys you speed. Same family of
# models, opposite hardware behaviour - and you can only see it once you
# stop looking at accuracy and start looking at the dependency graph.

from sklearn.ensemble import HistGradientBoostingClassifier

boost = HistGradientBoostingClassifier(max_iter=30, random_state=0)
boost.fit(ds.x_train, ds.y_train)
print("boosting accuracy : %.1f %%" % (100.0 * boost.score(ds.x_test, ds.y_test)))
print("random forest     : %.1f %%" % acc)
print()
print("forest   : 50 trees, parallel   -> depth of ONE tree")
print("boosting : 30 rounds, sequential -> depth of ALL rounds")

# ### 4.4 What fifty trees cost to store

NODE_BYTES = 6          # same assumption as Lab 05
mem = nodes * NODE_BYTES
avg_cmp = 50 * avg_path

print("nodes  : {:,}".format(nodes))
print("compares per image : {:.0f}   (50 trees x {:.1f})".format(avg_cmp, avg_path))
print("memory : {:,} B".format(mem))
print("that is {:.1f} %% of the board's block RAM".format(
    100 * mem / ss_ml.BOARD_BRAM_BYTES))

# ### 4.5 Fifty parallel walks, fifty scattered reads
#
# Lab 05 noted that one tree jumps around its memory instead of reading in
# order. Fifty trees do it fifty times at once, and each one wants a different
# address in the same cycle.
#
# Block RAM has two ports. Fifty simultaneous readers do not fit through two
# ports, so a real design either gives each tree its own small memory - which is
# why the per-tree size matters as much as the total - or accepts serialisation
# and gives back some of the parallelism.
#
# This does not change any number in the report. It changes what "fifty in
# parallel" costs to actually build, and it is the reason ensembles on FPGAs are
# usually built from many *small* trees rather than a few large ones.

# ## 5. Report

ss_ml.report(
    "06", "Random forest (%d trees)" % N_TREES,
    mac=0,
    compare=int(round(avg_cmp)),
    memory_bytes=mem,
    accuracy=acc,
    note="Fifty trees in parallel cost the latency of one. Boosting cannot.",
)

# ---
#
# ## What to take away
#
# 1. Fifty weak trees beat one strong tree by a wide margin.
# 2. Still **zero multipliers**.
# 3. They are independent, so area buys parallelism directly - fifty trees,
#    one tree's worth of latency.
# 4. Boosting is sequential and gets none of that.
# 5. The cost moved: no multipliers, but the memory bill went up sharply.
#
# **Next - Lab 07:** an algorithm that does no training at all, and pays for
# it in memory.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Try 10 trees instead of 50. How much accuracy do you lose, and how much memory do you save?
#
# **2.** At how many trees would the forest fill the whole block RAM?

# --- Exercise 1 ---
for nt in [10, 50]:
    f2 = RandomForestClassifier(n_estimators=nt, random_state=0).fit(
        ds.x_train, ds.y_train)
    nd = sum(t.tree_.node_count for t in f2.estimators_)
    print("%2d trees : accuracy %.1f %%   memory %7,d B  (%.1f %% of BRAM)"
          .replace("%7,d", "{:>7,}").format(nd * NODE_BYTES)
          % (nt, 100 * f2.score(ds.x_test, ds.y_test),
             100 * nd * NODE_BYTES / ss_ml.BOARD_BRAM_BYTES))

# <details>
# <summary>What you should see</summary>
#
# Ten trees give up very little accuracy for a fifth of the memory. Ensembles hit diminishing returns quickly, and on a chip that matters.
#
# </details>

# --- Exercise 2 ---
per_tree = nodes / N_TREES * NODE_BYTES
print("bytes per tree : %.0f" % per_tree)
print("trees that fit : %.0f" % (ss_ml.BOARD_BRAM_BYTES / per_tree))

# <details>
# <summary>What you should see</summary>
#
# Around 108 trees, and that would leave nothing for anything else on the board.
#
# </details>
