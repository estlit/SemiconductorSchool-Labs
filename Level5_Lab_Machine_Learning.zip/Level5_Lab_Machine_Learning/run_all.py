"""
Semiconductor School - From Data to Circuits
Batch runner and log verifier.

Author: Roger Kim
Copyright (c) 2026 EdgeChipLab

Runs every lab script, captures its output, and compares it against the
expected log stored in expected/. Reports a stage-by-stage result for each
lab and a single final verdict.

    python run_all.py

COMPARISON RULE
    Integer tokens must match EXACTLY. These are the counts the course is
    built on - MAC, compares, bytes, mismatches - and they are the result of
    integer arithmetic, so any difference is a real difference.

    Non-integer tokens are allowed 2% relative tolerance. Floating-point
    results can move slightly between library versions and CPUs, and that is
    not a fault in the lab.

    Everything that is not a number must match exactly.

    Lines beginning with "env |" report library versions and are skipped.
"""

import os
import re
import sys
import glob
import time
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
PYDIR = HERE
LOGDIR = os.path.join(HERE, "logs")
EXPDIR = os.path.join(HERE, "expected")

RTOL = 0.02
SKIP = "env |"          # informational lines, not compared

NUMBER = re.compile(r"^[+-]?[\d,]*\.?\d+(?:[eE][+-]?\d+)?$")
LINE = "=" * 68
THIN = "-" * 68


def as_number(tok):
    """Return a float if the token is a number, else None."""
    t = tok.strip().rstrip("%,.:;")
    t = t.replace(",", "")
    if not t or not NUMBER.match(t):
        return None
    try:
        return float(t)
    except ValueError:
        return None


def compare_line(got, want):
    """Return (ok, n_numeric, reason)."""
    g, w = got.split(), want.split()
    if len(g) != len(w):
        return False, 0, "different number of fields"
    n_num = 0
    for a, b in zip(g, w):
        na, nb = as_number(a), as_number(b)
        if na is None or nb is None:
            if a != b:
                return False, n_num, "text differs: %r vs %r" % (a, b)
            continue
        n_num += 1
        if float(nb).is_integer() and float(na).is_integer():
            if na != nb:
                return False, n_num, "integer differs: %s vs %s" % (a, b)
        else:
            if abs(na - nb) > RTOL * max(1.0, abs(nb)):
                return False, n_num, "value differs: %s vs %s" % (a, b)
    return True, n_num, ""


def compare(got_text, want_text):
    got = got_text.rstrip("\n").split("\n")
    want = want_text.rstrip("\n").split("\n")
    mismatches, numeric, skipped = 0, 0, 0
    first = None
    for i in range(max(len(got), len(want))):
        g = got[i] if i < len(got) else "<missing>"
        w = want[i] if i < len(want) else "<extra line>"
        # informational lines carry machine-specific versions
        if g.startswith(SKIP) or w.startswith(SKIP):
            skipped += 1
            continue
        ok, n, why = compare_line(g, w)
        numeric += n
        if not ok:
            mismatches += 1
            if first is None:
                first = (i + 1, g, w, why)
    return dict(lines=max(len(got), len(want)), numeric=numeric,
                mismatches=mismatches, skipped=skipped, first=first)


def run(script):
    t0 = time.time()
    proc = subprocess.run([sys.executable, script], cwd=HERE,
                          capture_output=True, text=True)
    return proc.returncode, proc.stdout, proc.stderr, time.time() - t0


def main():
    os.makedirs(LOGDIR, exist_ok=True)

    scripts = sorted(glob.glob(os.path.join(PYDIR, "Lab*.py")))
    if not scripts:
        print("No lab scripts found in this folder.")
        return 1

    print(LINE)
    print(" Semiconductor School - From Data to Circuits: batch verification")
    print(" Running %d labs and checking against expected logs" % len(scripts))
    print(LINE)

    tot_lines = tot_num = tot_mis = 0
    failed = []

    for i, script in enumerate(scripts, 1):
        name = os.path.splitext(os.path.basename(script))[0]
        print("\n[%2d/%d] %s" % (i, len(scripts), name))

        code, out, err, secs = run(script)
        open(os.path.join(LOGDIR, name + ".log"), "w").write(out)

        if code != 0:
            print("        execute ............ CRASHED (exit %d)" % code)
            tail = (err or out).strip().split("\n")
            for line in tail[-3:]:
                print("          " + line[:64])
            failed.append(name)
            tot_mis += 1
            continue
        print("        execute ............ OK        (%.1f s)" % secs)

        exp_path = os.path.join(EXPDIR, name + ".log")
        if not os.path.exists(exp_path):
            print("        expected log ....... MISSING")
            failed.append(name)
            tot_mis += 1
            continue

        r = compare(out, open(exp_path).read())
        tot_lines += r["lines"]
        tot_num += r["numeric"]
        tot_mis += r["mismatches"]

        print("        log lines .......... %d%s" % (
            r["lines"],
            "   (%d informational, not compared)" % r["skipped"]
            if r["skipped"] else ""))
        print("        numeric tokens ..... %d" % r["numeric"])
        if r["mismatches"] == 0:
            print("        mismatches ......... 0         PASS")
        else:
            n, g, w, why = r["first"]
            print("        mismatches ......... %d         FAIL"
                  % r["mismatches"])
            print("          first at line %d (%s)" % (n, why))
            print("          expected: %s" % w.strip()[:58])
            print("          got     : %s" % g.strip()[:58])
            failed.append(name)

    print("\n" + LINE)
    print(" %-22s %s" % ("Labs run", len(scripts)))
    print(" %-22s %s" % ("Labs passed", len(scripts) - len(failed)))
    print(" %-22s %s" % ("Lines compared", "{:,}".format(tot_lines)))
    print(" %-22s %s" % ("Numeric tokens", "{:,}".format(tot_num)))
    print(THIN)
    print(" %-22s %s" % ("Mismatch Count", tot_mis))
    print(" %-22s %s" % ("FINAL RESULT",
                         "100% PASS" if tot_mis == 0 else "FAIL"))
    if failed:
        print(THIN)
        print(" failing labs: %s" % ", ".join(failed))
    print(LINE)
    print(" integers compared exactly; other numbers within %.0f%%"
          % (RTOL * 100))
    return 0 if tot_mis == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
