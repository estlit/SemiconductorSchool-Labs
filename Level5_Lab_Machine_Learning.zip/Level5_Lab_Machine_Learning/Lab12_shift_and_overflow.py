"""
Semiconductor School - From Data to Circuits
Lab 12 - Shifting Down, and Breaking It

Run from Jupyter with %run, or from a terminal. Lab12_shift_and_overflow.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 12 - Shifting Down, and Breaking It
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Accumulators grow. A shift brings them back - and the wrong shift destroys the model.
#
# **Why it matters for hardware**
# This is SHIFT_CONV. Getting it wrong is one of the most common ways a working Python model turns into a broken circuit.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

from sklearn.linear_model import LogisticRegression

ds = ss_ml.load_digits8x8()

# three sets, not two: we are about to CHOOSE something
x_tr, y_tr, x_val, y_val = ss_ml.train_val_split(ds, frac=0.2)

clf = LogisticRegression(max_iter=2000).fit(x_tr / 16.0, y_tr)
Wf, bf = clf.coef_, clf.intercept_

print("train      : %d" % len(y_tr))
print("validation : %d   <- every decision in this lab is made here" % len(y_val))
print("test       : %d   <- looked at once, at the very end" % len(ds.y_test))

scale = 127.0 / np.abs(Wf).max()
Wq = np.round(Wf * scale).astype(np.int32)
bq = np.round(bf * scale * 16).astype(np.int32)

xval = x_val.astype(np.int32)
xte = ds.x_test.astype(np.int32)
print("INT8 model rebuilt (Lab 11)")

# ## 2. Learn
#
# Nothing new.

# ## 3. Quantize
#
# ### 3.0 Why there are three sets now
#
# This lab picks a number - the shift. The moment you choose something by
# looking at a score, that score stops being an honest estimate of how the
# model behaves on data it has never seen.
#
# So the training set fits the weights, the **validation set** chooses the
# shift, and the test set is opened once at the end to report a result. If
# we swept the shift against the test set and then reported the best test
# accuracy we found, we would be reporting the best of nine attempts and
# calling it one.
#
# ### 3.1 Accumulators grow
#
# An 8-bit weight times a 5-bit pixel is 13 bits. Add 64 of them and you
# need 6 more. The product of small numbers is not a small number.

acc = xval @ Wq.T + bq          # validation set
peak = int(np.abs(acc).max())
bits = int(np.ceil(np.log2(peak + 1))) + 1        # +1 for the sign

print("largest |accumulator| : {:,}".format(peak))
print("bits required         : {}".format(bits))
print()
for w in [8, 16, 32]:
    lim = 2 ** (w - 1) - 1
    print("  signed {:2d}-bit holds +/- {:>11,}  ->  {}".format(
        w, lim, "OK" if peak <= lim else "OVERFLOW"))

# ### 3.2 The shift
#
# Carrying 32 bits everywhere is expensive. Shift the accumulator right by
# `SHIFT` bits and it fits in 16, at the cost of throwing away the low bits.
#
#     requantised = accumulator >> SHIFT
#
# An arithmetic right shift is a divide by a power of two, and in hardware
# it is free - just wiring.

SHIFT = 3
req = acc >> SHIFT
print("before shift : max {:>8,}".format(int(np.abs(acc).max())))
print("after  >> {}  : max {:>8,}".format(SHIFT, int(np.abs(req).max())))
print("fits in signed 16-bit :", int(np.abs(req).max()) <= 32767)

# ### 3.3 The shift, in bits
#
# An arithmetic right shift moves every bit one place to the right and drops
# what falls off the end. In hardware that is not an operation at all - it is
# which wires you connect to which. It costs nothing.
#
# What it costs is the low bits, and you can see exactly which ones go.

def show_bits(v, n):
    s = format(int(v) & ((1 << n) - 1), "0%db" % n)
    return " ".join(s[i:i + 4] for i in range(0, n, 4))

sample = int(np.abs(acc).max())
print("  accumulator        {}   = {:>8,}".format(show_bits(sample, 20), sample))
for sh in [1, 2, 3]:
    print("  >> {}               {}   = {:>8,}".format(
        sh, show_bits(sample >> sh, 20), sample >> sh))
print()
print("  each shift halves the value and discards one bit from the right")

# ## 4. Compute
#
# ### 4.1 Wrap is not saturation
#
# If the shifted value still does not fit in 16 bits, what happens depends
# on the circuit - and the default is the bad one.
#
# - **Saturation** clamps to the largest value. Expensive, needs a comparator.
# - **Wrap** keeps the low 16 bits and discards the rest. Free, and it turns
#   a large positive number into a large *negative* one.
#
# Verilog does the second unless you tell it otherwise. `s[15:0]` wraps.
# The Level 5 requant stage wraps.

def wrap16(v):
    return ((v + 32768) & 0xFFFF) - 32768

for v in [30000, 32767, 32768, 40000, 100000]:
    print("%7d -> wrap16 %7d %s" % (v, wrap16(v),
          "  <-- sign flipped!" if wrap16(v) < 0 < v else ""))

# ### 4.1b Wrapping, in bits
#
# Wrapping keeps the low 16 bits and throws the rest away. If bit 15 of what
# remains happens to be 1, the result reads as negative - and the class that
# score belonged to can never win an argmax again.

print("  value    low 16 bits              read as signed")
print("  " + "-" * 52)
for v in [30000, 32767, 32768, 40000, 100000]:
    print("  {:>6,}   {}   {:>8,}{}".format(
        v, show_bits(v, 16), wrap16(v),
        "   <-- sign flipped" if wrap16(v) < 0 < v else ""))
print()
print("  32,767 is the largest value 16 signed bits can hold.")
print("  one more, and the leading bit turns the number negative.")

# ### 4.2 Sweep the shift

print(" SHIFT   max |value|   fits 16b   accuracy")
print(" " + "-" * 44)
results = []
for s in range(0, 9):
    r = acc >> s
    fits = int(np.abs(r).max()) <= 32767
    a = 100.0 * (wrap16(r).argmax(axis=1) == y_val).mean()
    results.append((s, a, fits))
    print("  {:2d}   {:>11,}   {:>8}   {:6.1f} %".format(
        s, int(np.abs(r).max()), "yes" if fits else "NO", a))

# **Nothing overflows.** Every shift is safe, including no shift at all.
#
# Say that plainly rather than manufacturing a failure. The reason is worth
# understanding: the weights reach 127 but most of them are small, and most
# pixels in a digit are zero. The peak accumulator came out near eight
# thousand - well inside a signed 16-bit range of 32,767.
#
# The accuracy differences in that table are one test image out of 450.
# That is noise, not a trend.
#
# So on this model the shift is free, and it is chosen for a different
# reason: **headroom**. Inputs you have not tested yet may be brighter or
# denser than anything in this dataset.
#
# ### 4.3 Now break it on purpose
#
# To see what overflow actually does, narrow the accumulator instead. Same
# model, same weights - only the register width changes.

def wrap(v, bits):
    half = 1 << (bits - 1)
    return ((v + half) & ((1 << bits) - 1)) - half

print(" width   holds up to   accuracy")
print(" " + "-" * 36)
for b in range(18, 7, -1):
    a = 100.0 * (wrap(acc, b).argmax(axis=1) == y_val).mean()
    print("  {:2d}b   {:>11,}   {:6.1f} %".format(b, (1 << (b - 1)) - 1, a))

# There is the cliff.
#
# Accuracy does not sag as the register narrows - it holds perfectly, and
# then falls off in a single step. A wrapped score becomes a large
# *negative* number, so that class can never win the argmax again.
#
# **And nothing reports it.** No exception, no NaN, no warning. The Python
# model was right, the weights were right, and the circuit is wrong.
#
# This is why the Level 5 requant stage is described as wrapping rather than
# saturating: `s[15:0]` in Verilog keeps the low bits and discards the sign.
# Knowing which of the two your hardware does is not a detail.
#
# ### 4.4 Choosing the shift
#
# The rule Level 5 uses:
#
# 1. Reject any shift that overflows.
# 2. Among the survivors, keep the best accuracy.
# 3. On a tie, take the **larger** shift - more headroom.

safe = [(s, a) for s, a, fits in results if fits]
best_acc = max(a for _, a in safe)
chosen = max(s for s, a in safe if a >= best_acc - 1e-9)

print("safe shifts    :", [s for s, _ in safe])
print("best accuracy  : %.1f %%" % best_acc)
print("CHOSEN SHIFT   : %d  (largest shift that keeps the accuracy)" % chosen)

# ### 4.4 The shift is not in the weight file
#
# This is the part that bites people.
#
# `conv_weight.mem` holds the weights. The shift is **not in it** - it is a
# parameter on the RTL module. Swap the weights and forget the shift, and
# you get a model that still runs, still outputs classes, and is quietly
# wrong.
#
# Weights, bias, and SHIFT are **one set**. They travel together or not at
# all. Level 5 ships the value in a separate `quant_config.txt` for exactly
# this reason.

# ## 5. Report

# the shift is now fixed. ONLY NOW do we touch the test set.
test_scores = xte @ Wq.T + bq
final = wrap16(test_scores >> chosen)
acc_final = 100.0 * (final.argmax(axis=1) == ds.y_test).mean()

print("SHIFT chosen on validation : %d" % chosen)
print("accuracy on the test set   : %.1f %%" % acc_final)

ss_ml.report(
    "12", "INT8 + requantisation (SHIFT=%d)" % chosen,
    mac=640, compare=9,
    memory_bytes=Wq.size + bq.size * 4,
    accuracy=acc_final,
    note="Weights, bias and SHIFT are one set. Never ship them apart.",
)

# ---
#
# ## What to take away
#
# 1. Accumulators need far more bits than the values feeding them.
# 2. `>> SHIFT` is free in hardware and brings the width back down.
# 3. On this model nothing overflows - and reporting that honestly is
#    better than inventing a failure.
# 4. **Wrap is not saturation.** Narrow the accumulator and accuracy falls
#    off a cliff, silently, with no error raised anywhere.
# 5. Pick the largest shift that keeps the accuracy, for headroom.
# 6. Weights + bias + SHIFT are inseparable.
#
# **Next - Lab 13:** how do you prove the circuit computes what Python
# computed?

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** At what accumulator width does accuracy first fall below 90%?
#
# **2.** If the hardware saturated instead of wrapping, would a 12-bit accumulator still work?

# --- Exercise 1 ---
for b in range(18, 7, -1):
    a = 100.0 * (wrap(acc, b).argmax(axis=1) == y_val).mean()
    if a < 90:
        print("first failure at %d bits (%.1f %%)" % (b, a))
        break
    print("%2d bits : %.1f %%" % (b, a))

# <details>
# <summary>What you should see</summary>
#
# It holds perfectly and then fails in one step. There is no warning band - which is why you size the accumulator from the peak, not from experiment.
#
# </details>

# --- Exercise 2 ---
def sat(v, bits):
    lim = (1 << (bits - 1)) - 1
    return np.clip(v, -lim - 1, lim)

for b in [16, 14, 12, 10]:
    aw = 100.0 * (wrap(acc, b).argmax(axis=1) == y_val).mean()
    as_ = 100.0 * (sat(acc, b).argmax(axis=1) == y_val).mean()
    print("%2d bits : wrap %5.1f %%   saturate %5.1f %%" % (b, aw, as_))

# <details>
# <summary>What you should see</summary>
#
# Saturation degrades gently while wrapping collapses. Saturation costs a comparator per value, and this table is the argument for paying it.
#
# </details>
