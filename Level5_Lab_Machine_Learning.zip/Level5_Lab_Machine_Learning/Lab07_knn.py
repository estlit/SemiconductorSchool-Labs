"""
Semiconductor School - From Data to Circuits
Lab 07 - The Classifier That Remembers

Run from Jupyter with %run, or from a terminal. Lab07_knn.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# ss_ml.py and data/ sit beside this script
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
try:                            # inside Jupyter, leave the backend alone
    get_ipython()               # so %run shows the figures inline
except NameError:               # batch run from a terminal: no display
    matplotlib.use("Agg")


# # Lab 07 - The Classifier That Remembers
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# k-nearest neighbours does not learn anything. It keeps the data.
#
# **Why it matters for hardware**
# The most accurate model in this book, and the one that fits worst. Memory, not arithmetic, is the wall.

import numpy as np
import ss_ml

ss_ml.board_summary()

# > **Every cost in this lab is the cost of one inference.**
# >
# > The notebook calls `fit()` as well as `predict()`, but only the second one
# > describes what runs on a chip. Training happens once, on a PC, and Lab 03
# > measured what it would cost to move it: the training data alone needs 42% of
# > the board's memory, against 64 bytes for a single inference.
# >
# > So when a table below says 640 MAC, read it as *640 multiply-accumulates to
# > classify one image* - not the cost of producing the model.

# ## 1. Load

ds = ss_ml.load_digits8x8()

# ## 2. Learn
#
# There is no training step. None.
#
# k-nearest neighbours stores the training set and, when asked about a new
# image, finds the closest stored images and copies their label.
#
# `fit()` below does nothing but keep a reference to the data.

from sklearn.neighbors import KNeighborsClassifier

K = 3
knn = KNeighborsClassifier(n_neighbors=K).fit(ds.x_train, ds.y_train)

acc = 100.0 * knn.score(ds.x_test, ds.y_test)
print("stored samples :", len(ds.y_train))
print("accuracy       : %.1f %%   <- the best in this book" % acc)

# ## 3. Quantize
#
# Nothing to quantize - there are no weights. The stored pixels are already
# the integers we loaded.

# ## 4. Compute
#
# ### 4.1 Distance, written out
#
# Squared distance between two images: subtract, square, add up. The square
# is a multiply, so this is a MAC in disguise - 64 of them per stored image.

def sq_dist(a, b):
    total = 0
    for i in range(len(a)):
        d = int(a[i]) - int(b[i])
        total += d * d          # <-- one multiply, one add
    return total

query = ds.x_test[0]
print("distance to training sample 0 :", sq_dist(query, ds.x_train[0]))
print("MACs for that one comparison  :", len(query))

# ### 4.2 Now do that against every stored image

diff = ds.x_train.astype(np.int32) - query.astype(np.int32)
dist = (diff * diff).sum(axis=1)

order = np.argsort(dist)[:K]
print("true label:", ds.y_test[0])
for r, idx in enumerate(order):
    print("  neighbour %d : distance %6d  label %d" % (r + 1, dist[idx],
                                                       ds.y_train[idx]))
print("  vote ->", np.bincount(ds.y_train[order]).argmax())

n_train = len(ds.y_train)
mac = n_train * ss_ml.N_PIXEL
mem = ds.x_train.size + ds.y_train.size

LOGISTIC_MAC = 640         # Lab 04
LOGISTIC_MEM = 2600        # Lab 04, float32 weights

print("MAC per image : {:,}".format(mac))
print("compares      : {:,}  (to find the smallest distances)".format(n_train))
print("memory        : {:,} B".format(mem))
print()
print("versus logistic regression (Lab 04):")
print("   arithmetic : {:.0f}x more".format(mac / LOGISTIC_MAC))
print("   memory     : {:.0f}x more".format(mem / LOGISTIC_MEM))

# ### 4.3 It fits. Barely.
#
# Run the report and watch the block RAM line.
#
# Almost half the board, for a classifier that handles 8x8 images and does
# nothing else. No room left for a camera path, a display, or a CPU.
#
# And this is the *small* version of the problem. Lab 15 asks the same
# question about 28x28 MNIST, where the training set is sixty thousand
# images instead of thirteen hundred. Hold that number in mind.

print("8x8 digits, 1,347 stored : {:,} B -> {:.1f} %% of block RAM".format(
    mem, 100 * mem / ss_ml.BOARD_BRAM_BYTES))

mnist = 60000 * 784
print("28x28 MNIST, 60,000 stored: {:,} B -> {:,.0f} %% of block RAM".format(
    mnist, 100 * mnist / ss_ml.BOARD_BRAM_BYTES))

# ### 4.4 Accuracy is not the only score
#
# Compare against Lab 04's logistic regression, which stores 2,600 bytes
# of float32 weights. (Lab 11 will shrink that to 680 bytes, and the gap
# gets far worse.)
#
# k-NN wins on accuracy by about two points. It pays for those two points
# with about thirty-four times the memory and a hundred and thirty-five
# times the arithmetic per image. The exact ratios are printed above rather
# than quoted here, so they can never drift out of date.
#
# On a PC, k-NN looks like the obvious choice. On a chip it is close to
# unusable. **Same algorithm, opposite verdict** - and the only thing that
# changed was where it has to run.

# ## 5. Report

ss_ml.report(
    "07", "k-nearest neighbours (k=%d)" % K,
    mac=mac,
    compare=n_train,
    memory_bytes=mem,
    accuracy=acc,
    note="Best accuracy in the book. Nearly half the board to hold it.",
)

# ---
#
# ## What to take away
#
# 1. k-NN has no training and no weights - it keeps the whole dataset.
# 2. Highest accuracy in this book.
# 3. It costs roughly 34x the memory and 135x the arithmetic of logistic
#    regression, to gain about two points.
# 4. **Memory is the bottleneck here, not multiplication.** That is a
#    different failure mode from anything in Part 1.
#
# **Next - Lab 08:** the same distance arithmetic, but storing ten vectors
# instead of thirteen hundred.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Compare k = 1, 3 and 7. Does more neighbours mean more accuracy?
#
# **2.** If we allowed k-NN only 25% of the block RAM, how many training images could it keep?

# --- Exercise 1 ---
for k in [1, 3, 7]:
    m = KNeighborsClassifier(n_neighbors=k).fit(ds.x_train, ds.y_train)
    print("k=%d : accuracy %.1f %%" % (k, 100 * m.score(ds.x_test, ds.y_test)))

# <details>
# <summary>What you should see</summary>
#
# More neighbours is not automatically better. Beyond a small k the vote starts including images that are not really similar.
#
# </details>

# --- Exercise 2 ---
budget = 0.25 * ss_ml.BOARD_BRAM_BYTES
keep = int(budget // (ss_ml.N_PIXEL + 1))
print("budget : {:,} B".format(int(budget)))
print("images : {:,} of {:,}".format(keep, n_train))
sub = np.random.default_rng(0).choice(n_train, keep, replace=False)
m = KNeighborsClassifier(n_neighbors=3).fit(ds.x_train[sub], ds.y_train[sub])
print("accuracy with that subset : %.1f %%" % (100 * m.score(ds.x_test, ds.y_test)))

# <details>
# <summary>What you should see</summary>
#
# Roughly 790 images, and the accuracy barely moves. Which raises the obvious question: were all 1,347 ever needed?
#
# </details>
