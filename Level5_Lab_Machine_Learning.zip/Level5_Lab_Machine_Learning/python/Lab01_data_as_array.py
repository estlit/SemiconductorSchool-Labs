"""
Semiconductor School - From Data to Circuits
Lab 01 - Data is an Array

Generated from Lab01_data_as_array.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 01 - Data is an Array
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# Every lab in this book runs on its own. Open this notebook, run it top to
# bottom, and Lab 01 is finished. Nothing here depends on another lab.
#
# **What you learn**
# A handwritten digit is not a picture. It is 64 numbers in a row.
#
# **Why it matters for hardware**
# Those 64 numbers become the initial contents of a memory inside the FPGA.
# The pixel position becomes an address. That is the whole idea, and every
# later lab stands on it.
#
# **Skeleton** - every notebook in this book has the same five sections:
# Load, Learn, Quantize, Compute, Report. A section that a lab does not need
# is still there, and says so.

# ## 0. Setup - run this once
#
# This book uses three libraries and nothing else. The cell below installs any
# that are missing, so **running Lab 01 prepares every one of the fifteen labs**.
#
# | library | used for |
# |---|---|
# | `numpy` | all the arithmetic |
# | `scikit-learn` | training the models (Labs 04 onward) |
# | `matplotlib` | drawing digits and charts |
#
# Lines that start with `env |` report your machine's versions. They are
# informational only and are ignored by the batch verifier, because versions
# differ from machine to machine.

import importlib.util
import subprocess
import sys

REQUIRED = {"numpy": "numpy",
            "sklearn": "scikit-learn",
            "matplotlib": "matplotlib"}

missing = [pkg for mod, pkg in REQUIRED.items()
           if importlib.util.find_spec(mod) is None]

if missing:
    print("env | installing:", ", ".join(missing))
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q"] + missing)
else:
    print("env | all required libraries are already present")

import numpy
import sklearn
import matplotlib

print("env | python       %s" % sys.version.split()[0])
print("env | numpy        %s" % numpy.__version__)
print("env | scikit-learn %s" % sklearn.__version__)
print("env | matplotlib   %s" % matplotlib.__version__)

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load
#
# `load_digits8x8()` gives the same train/test split to every lab, so the
# numbers you collect can be compared across labs later.
#
# Pixels stay as integers 0 to 16. They are **not** scaled to 0.0-1.0.
# We start from the integers the hardware would actually see.

ds = ss_ml.load_digits8x8()

print(ds)
print("x_train shape :", ds.x_train.shape, ds.x_train.dtype)
print("x_test  shape :", ds.x_test.shape)
print("pixel range   :", ds.x_train.min(), "to", ds.x_train.max())
print("classes       :", np.unique(ds.y_train))

# ### One digit, as numbers
#
# Look at the grid before the picture. The picture is for us; the grid is
# what the circuit gets.

ss_ml.print_digit(ds.x_train[0], ds.y_train[0])

ss_ml.show_grid(ds.x_train, ds.y_train, n=20);

# ## 2. Learn
#
# Nothing is learned in this lab. We are only opening the data.
#
# Training starts in Lab 02.

# ## 3. Quantize
#
# Nothing is quantized in this lab either - the data already arrives as
# integers.
#
# One thing is worth noticing now. The pixel range is 0 to 16, which needs
# **5 bits**. We are storing each pixel in 8 bits, so 3 bits out of every 8
# are wasted. On a PC nobody cares. On a chip, that waste is 37.5% of the
# memory you paid for.

bits_needed = int(np.ceil(np.log2(int(ds.x_train.max()) + 1)))
print("largest pixel value :", ds.x_train.max())
print("bits needed         :", bits_needed)
print("bits we are using   : 8")
print("wasted              : {:.1f} %".format(100 * (8 - bits_needed) / 8))

# ## 4. Compute
#
# ### 4.1 A pixel position becomes an address
#
# The image looks two-dimensional, but memory is one long line of words.
# Row `r`, column `c` lives at address `r * 8 + c`.
#
# This single line is how every image in this book enters the FPGA.

def to_addr(row, col):
    return row * ss_ml.IMG_W + col

for (r, c) in [(0, 0), (0, 7), (1, 0), (7, 7)]:
    print("pixel (row {}, col {}) -> address {:2d}".format(r, c, to_addr(r, c)))

# ### 4.2 Writing a digit as a memory image
#
# `.mem` is the plain text format Vivado reads with `$readmemh` to fill a
# block RAM at startup. One hex word per line, address 0 on the first line.
#
# You are not writing any Verilog in this book. But this file is exactly
# what Level 5 loads into the board, so it is worth seeing the moment the
# data stops being a NumPy array and becomes hardware contents.

digit = ds.x_train[0]
path = ss_ml.write_mem("out/lab01/digit0.mem", digit, bits=8)

print("wrote:", path)
print()
with open(path) as f:
    lines = f.read().split()
for r in range(ss_ml.IMG_H):
    row = lines[r * 8:(r + 1) * 8]
    print("addr {:2d}-{:2d} :".format(r * 8, r * 8 + 7), " ".join(row))

# ### 4.3 How much memory is this?
#
# Two different questions, and the answer matters later:
#
# - one digit - what a circuit must hold to classify a single image
# - the whole training set - what a circuit must hold if it wants to keep
#   the data around (Lab 07 will need exactly this)

one_digit = ss_ml.N_PIXEL                       # 64 bytes
train_set = ds.x_train.size + ds.y_train.size   # pixels plus labels

print("one digit        : {:,} B".format(one_digit))
print("training set     : {:,} B".format(train_set))
print("board block RAM  : {:,} B".format(ss_ml.BOARD_BRAM_BYTES))
print("training set is {:.1f} % of the board's block RAM".format(
    100 * train_set / ss_ml.BOARD_BRAM_BYTES))

# ### 4.4 Train and test - a method with no circuit
#
# We split the data so we can measure honestly: the model is fitted on the
# training set and graded on data it has never seen.
#
# **This step has no hardware side at all.** There is no circuit for
# "holding data back". It happens once, on a PC, before anything is built.
#
# This book will point that out whenever it happens. A machine learning
# idea that leaves no mark on the silicon is still worth knowing - it is
# just not a hardware topic, and pretending otherwise would waste your time.

print("train samples :", len(ds.y_train))
print("test  samples :", len(ds.y_test))
print("class balance :", np.bincount(ds.y_train))

# ## 5. Report
#
# Every lab ends with the same block. Collect these across the labs and, by
# Lab 10, you will have built the comparison table yourself - which
# algorithm costs multiplies, which costs comparisons, which costs memory.
#
# Lab 01 has no classifier yet, so MAC, Compare and Accuracy are empty. Only
# the memory line is real.

ss_ml.report(
    "01", "Data as an Array (no classifier yet)",
    mac=None,
    compare=None,
    memory_bytes=one_digit,
    accuracy=None,
    note="64 bytes per digit. Address = row * 8 + col.",
)

# ---
#
# ## What to take away
#
# 1. An image is a one-dimensional array of integers. The picture is a
#    convenience for humans.
# 2. Pixel position becomes a memory address: `addr = row * 8 + col`.
# 3. Values are 0 to 16, so 5 bits are enough - and the 8-bit storage we
#    used wastes over a third of the memory. Bit width is a cost.
# 4. Splitting train and test is a method, not a circuit.
#
# **Next - Lab 02: Multiply and Accumulate.** We give each of the 64 pixels
# a weight, add the results up, and get one number out. That single
# operation is the atom every AI accelerator is built from.

# ---
#
# ## Appendix - the NumPy you need for this book
#
# Five operations cover all fifteen labs. If these read clearly, nothing later
# will surprise you.
#
# | operation | what it does |
# |---|---|
# | `a.shape` | how many rows and columns |
# | `a.reshape(8, 8)` | same numbers, different arrangement |
# | `a.T` | swap rows and columns |
# | `a[mask]` | keep only the rows where `mask` is True |
# | `A @ v` | matrix times vector - the MAC of Lab 02 |
# | `a.argmax()` | position of the largest value - the decision of Lab 04 |

x = ds.x_train[0]
print("one digit          :", x.shape, "  64 numbers in a row")
print("as a picture       :", x.reshape(8, 8).shape)
print("whole training set :", ds.x_train.shape, "  1,347 digits x 64 pixels")
print("transposed         :", ds.x_train.T.shape, "  same data, other way round")
print()

zeros_only = ds.x_train[ds.y_train == 0]
print("boolean mask       :", zeros_only.shape, "  just the zeros")
print()

W = np.ones((10, 64))              # ten fake weight rows
scores = W @ x                     # ten scores from one digit
print("W @ x              :", scores.shape, "  (10, 64) @ (64,) -> (10,)")
print("argmax             :", int(scores.argmax()), "  the winning class")
print()
print("broadcasting: adding a (10,) bias to a (10,) score works elementwise,")
print("and adding a (64,) row to a (1347, 64) block applies it to every row.")

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Pixels only need 5 bits. How many bytes would the whole training set take if we packed it at 5 bits per pixel instead of 8?
#
# **2.** Which address holds the pixel at row 3, column 5? Check it against the memory image you wrote.

# --- Exercise 1 ---
packed = int(np.ceil(ds.x_train.size * 5 / 8))
loose = ds.x_train.size
print("8 bits per pixel : {:,} B".format(loose))
print("5 bits per pixel : {:,} B".format(packed))
print("saved            : {:.1f} %".format(100 * (1 - packed / loose)))

# <details>
# <summary>What you should see</summary>
#
# About 37% smaller. Packing costs extra logic to unpack, which is why it is usually only worth doing when memory is the binding constraint.
#
# </details>

# --- Exercise 2 ---
addr = to_addr(3, 5)
print("address :", addr)
print("value from the array :", ds.x_train[0][addr])
print("value from digit0.mem:", int(open("out/lab01/digit0.mem").read().split()[addr], 16))

# <details>
# <summary>What you should see</summary>
#
# Address 29. Both numbers must match - the .mem file is just the array written out in address order.
#
# </details>
