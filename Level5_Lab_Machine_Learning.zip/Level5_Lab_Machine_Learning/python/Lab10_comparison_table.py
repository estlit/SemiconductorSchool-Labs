"""
Semiconductor School - From Data to Circuits
Lab 10 - Filling In The Table

Generated from Lab10_comparison_table.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 10 - Filling In The Table
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Every algorithm from Part 2, measured the same way, side by side.
#
# **Why it matters for hardware**
# This is the table that decides which circuit you build. You have been collecting it for nine labs.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load
#
# This lab rebuilds every model from Labs 04 to 09 so it stays
# self-contained. It takes about half a minute.

ds = ss_ml.load_digits8x8()
xtr, xte = ds.x_train / 16.0, ds.x_test / 16.0
n_train = len(ds.y_train)
NODE_BYTES = 6          # six bytes per tree node, the assumption fixed in Lab 05
rows = []

# ## 2. Learn
#
# Six models, one cell.

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.decomposition import PCA

lr = LogisticRegression(max_iter=2000).fit(xtr, ds.y_train)
tree = DecisionTreeClassifier(random_state=0).fit(ds.x_train, ds.y_train)
forest = RandomForestClassifier(n_estimators=50, random_state=0).fit(
    ds.x_train, ds.y_train)
knn = KNeighborsClassifier(n_neighbors=3).fit(ds.x_train, ds.y_train)
pca = PCA(n_components=16).fit(xtr)
lr_pca = LogisticRegression(max_iter=2000).fit(pca.transform(xtr), ds.y_train)
print("all models trained")

# k-means, same loop as Lab 08
rng = np.random.default_rng(0)
X = ds.x_train.astype(np.float64)
centres = X[rng.choice(len(X), 10, replace=False)].copy()
for _ in range(25):
    assign = ((X[:, None, :] - centres[None, :, :]) ** 2).sum(2).argmin(1)
    for k in range(10):
        if (assign == k).any():
            centres[k] = X[assign == k].mean(axis=0)
lab = np.array([np.bincount(ds.y_train[assign == k]).argmax()
                if (assign == k).any() else 0 for k in range(10)])
km_acc = 100.0 * (lab[((ds.x_test[:, None, :] - centres[None, :, :]) ** 2)
                      .sum(2).argmin(1)] == ds.y_test).mean()
print("k-means accuracy: %.1f %%" % km_acc)

# ## 3. Quantize
#
# Part 3's job. Everything here is still floating point.

# ## 4. Compute
#
# ### 4.1 Cost of each model

rows.append(dict(name="Logistic regression", group="multiply",
                 mac=640, compare=9,
                 memory_bytes=lr.coef_.size * 4 + 10 * 4,
                 accuracy=100 * lr.score(xte, ds.y_test)))

rows.append(dict(name="PCA-16 + logistic", group="multiply",
                 mac=64 * 16 + 16 * 10, compare=9,
                 memory_bytes=pca.components_.size * 4 + lr_pca.coef_.size * 4,
                 accuracy=100 * lr_pca.score(pca.transform(xte), ds.y_test)))

rows.append(dict(name="Decision tree", group="compare",
                 mac=0,
                 compare=int(round(tree.decision_path(ds.x_test).sum(1).mean() - 1)),
                 memory_bytes=tree.tree_.node_count * NODE_BYTES,
                 accuracy=100 * tree.score(ds.x_test, ds.y_test)))

f_nodes = sum(t.tree_.node_count for t in forest.estimators_)
rows.append(dict(name="Random forest (50)", group="compare",
                 mac=0,
                 compare=int(round(50 * np.mean(
                     [t.decision_path(ds.x_test).sum(axis=1).mean() - 1
                      for t in forest.estimators_]))),
                 memory_bytes=f_nodes * NODE_BYTES,
                 accuracy=100 * forest.score(ds.x_test, ds.y_test)))

rows.append(dict(name="k-NN (k=3)", group="distance",
                 mac=n_train * 64, compare=n_train,
                 memory_bytes=ds.x_train.size + n_train,
                 accuracy=100 * knn.score(ds.x_test, ds.y_test)))

rows.append(dict(name="k-means (k=10)", group="distance",
                 mac=10 * 64, compare=9,
                 memory_bytes=10 * 64,
                 accuracy=km_acc))

ss_ml.report_table(rows, "Part 2 - what each algorithm costs")

# ### 4.2 Three families
#
# Read the MAC column and the Compare column together. The models fall into
# three groups, and the groups are not about accuracy - they are about
# **which unit on the chip does the work**.

for g, what in [("multiply", "DSP slices"),
                ("compare", "LUTs / comparators"),
                ("distance", "DSP + block RAM")]:
    sel = [r for r in rows if r["group"] == g]
    print("%-9s -> %-22s  %s" % (g, what,
          ", ".join(r["name"] for r in sel)))

# ### 4.2b Which resource actually runs out first?
#
# The three families say *what kind* of work each model does. A second question
# decides how fast it can go: for every model, is the bottleneck the arithmetic
# or getting the numbers out of memory?
#
# Count both sides in cycles.
#
# - **Compute cycles** - the board has 80 DSP slices, so 80 MACs per cycle.
# - **Memory cycles** - a block RAM has two ports, so at 8 bits per port we can
#   read 2 bytes per cycle.
#
# The memory figure assumes everything sits in **one** dual-port memory. That is
# the simplest possible arrangement, and stating it matters, because the standard
# fix is exactly to break that assumption - spread the data across many block
# RAMs and read them at once.

print("{:<22}{:>16}{:>16}   {}".format(
    "Model", "compute cycles", "memory cycles", "limited by"))
print("-" * 70)
for r in rows:
    comp = -(-r["mac"] // ss_ml.BOARD["dsp"])
    memc = -(-r["memory_bytes"] // 2)
    print("{:<22}{:>16,}{:>16,}   {}".format(
        r["name"], comp, memc,
        "memory" if memc > comp else "compute"))

# **Every model on this list is memory-bound.** Not one of them is held back by
# multiplication.
#
# That is worth sitting with. Nine labs were spent counting MACs, and on this
# board the MACs are never the problem - 80 multipliers chew through the largest
# model here in about a thousand cycles, while reading its data takes forty
# times longer.
#
# This is why accelerator design is mostly about **moving data**, not about
# multiplying. Wider memories, more block RAMs in parallel, keeping weights on
# chip, reusing a value once it has been fetched - convolution in Lab 15 is
# exactly that last idea, and now you can see what it is buying.
#
# A model only becomes compute-bound when it does a great deal of arithmetic per
# byte fetched. None of the classical algorithms here do. Deep networks are the
# first ones that get close.

# - **Multiply family** - fixed cost, fixed latency, wants DSP slices.
#   Logistic regression is 640 MACs on every image, always.
# - **Compare family** - no multiplier at all, wants LUTs, and the latency
#   moves with the input.
# - **Distance family** - MACs *and* memory, and the memory is what hurts.
#
# Three families, three different pieces of the FPGA. **This is what "the
# hardware choice diverges here" means.**
#
# ### 4.3 Seen as a picture

import matplotlib.pyplot as plt
names = [r["name"] for r in rows]
fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
for a, key, t in zip(ax, ["mac", "memory_bytes", "accuracy"],
                     ["MAC per image", "memory (bytes)", "accuracy %"]):
    v = [r[key] for r in rows]
    a.barh(names, v, color="#0E7490")
    a.set_title(t)
    if key != "accuracy":
        a.set_xscale("log")
ax[2].set_xlim(70, 100)
fig.tight_layout();

# ### 4.4 The board's verdict

for r in sorted(rows, key=lambda r: -r["memory_bytes"]):
    pct = 100 * r["memory_bytes"] / ss_ml.BOARD_BRAM_BYTES
    flag = "  <-- half the board" if pct > 30 else ""
    print("{:<22} {:>8,} B  {:>6.1f} % of BRAM{}".format(
        r["name"], r["memory_bytes"], pct, flag))

# ## 5. Report
#
# The table above **is** this lab's report.

best_acc = max(rows, key=lambda r: r["accuracy"])
best_fit = min(rows, key=lambda r: r["memory_bytes"])

print("most accurate : %-22s %.1f %%  (%.1f %% of BRAM)" % (
    best_acc["name"], best_acc["accuracy"],
    100 * best_acc["memory_bytes"] / ss_ml.BOARD_BRAM_BYTES))
print("cheapest      : %-22s %.1f %%  (%.1f %% of BRAM)" % (
    best_fit["name"], best_fit["accuracy"],
    100 * best_fit["memory_bytes"] / ss_ml.BOARD_BRAM_BYTES))

# ---
#
# ## What to take away
#
# 1. Accuracy alone never picks the design. The most accurate model here is
#    also the one that nearly fills the board.
# 2. Algorithms split into three families by **which resource** they consume:
#    DSP, LUT, or block RAM.
# 3. A tree uses no multiplier. k-NN uses no training. Neither fact is
#    visible from an accuracy score.
# 4. You built this table yourself, one lab at a time.
#
# **Part 3 asks the last question:** all of these are floating point. Real
# hardware is not. What has to change, and what does it cost?

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Which model gives the most accuracy per byte of memory?
#
# **2.** Which models fit in 10% of the block RAM and still score above 90%?

# --- Exercise 1 ---
for r in sorted(rows, key=lambda r: -r["accuracy"] / r["memory_bytes"]):
    print("%-22s %.4f accuracy points per byte"
          % (r["name"], r["accuracy"] / r["memory_bytes"]))

# <details>
# <summary>What you should see</summary>
#
# k-means wins this metric by a wide margin and is the least accurate model in the table. A ratio is not a decision - it is one column of the decision.
#
# </details>

# --- Exercise 2 ---
limit = 0.10 * ss_ml.BOARD_BRAM_BYTES
for r in rows:
    if r["memory_bytes"] <= limit and r["accuracy"] > 90:
        print("%-22s %6,d B   %.1f %%".replace("%6,d", "{:>6,}")
              .format(r["memory_bytes"]) % (r["name"], r["accuracy"]))

# <details>
# <summary>What you should see</summary>
#
# Only the logistic models. Everything accurate and cheap in this table is built from multiply-accumulate - which is a large part of why accelerators are built around MAC.
#
# </details>
