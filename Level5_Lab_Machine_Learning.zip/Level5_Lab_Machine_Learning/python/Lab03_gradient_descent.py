"""
Semiconductor School - From Data to Circuits
Lab 03 - The Direction That Reduces Error

Generated from Lab03_gradient_descent.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 03 - The Direction That Reduces Error
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Loss, gradient, learning rate - gradient descent written out by hand.
#
# **Why it matters for hardware**
# Training costs hundreds of thousands of times more arithmetic than inference. That single ratio is why the PC trains and the FPGA only infers.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

ds = ss_ml.load_digits8x8()

target = 0
xtr = ds.x_train / 16.0                 # scale to 0..1 so the gradient behaves
ytr = (ds.y_train == target).astype(np.float64)
xte = ds.x_test / 16.0
yte = (ds.y_test == target).astype(np.float64)

print("train", xtr.shape, " positives:", int(ytr.sum()))

# ## 2. Learn
#
# This is the lab. No library does the work - the loop below is the whole
# of gradient descent.
#
# **Three pieces:**
#
# 1. **Predict.** `p = sigmoid(x . w + b)` - the MAC from Lab 02, squashed
#    into 0..1 so we can read it as a probability.
# 2. **Measure the error.** Loss is one number saying how wrong we are.
# 3. **Step downhill.** Adjust every weight a little, in the direction that
#    makes the error smaller.
#
# Repeat. That is all training is.
#
# ### How one weight gets adjusted
#
# Before the matrix version, look at a single weight and a single image.
#
#     error      = prediction - truth
#     adjustment = error x pixel[i]
#
# Read it in words. If the prediction was **too high** and pixel `i` was
# **bright**, then pixel `i` helped push the score up, so its weight comes
# down. If the pixel was dark it contributed nothing, and its weight does
# not move.
#
# That is the entire gradient. The line `grad_w = xtr.T @ err / n` in the
# next cell is this same rule applied to all 64 weights and all 1,347
# images at once, then averaged - nothing more.

def sigmoid(z):
    z = np.clip(z, -30, 30)
    return 1.0 / (1.0 + np.exp(-z))

def loss_fn(p, y):
    p = np.clip(p, 1e-9, 1 - 1e-9)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))

w = np.zeros(ss_ml.N_PIXEL)
b = 0.0
lr = 0.5
epochs = 300
n = len(ytr)

history = []
for ep in range(epochs):
    p = sigmoid(xtr @ w + b)            # forward : n x 64 MACs
    err = p - ytr
    grad_w = xtr.T @ err / n            # backward: n x 64 MACs
    grad_b = err.mean()
    w -= lr * grad_w                    # the step
    b -= lr * grad_b
    history.append(loss_fn(p, ytr))
    if ep % 50 == 0 or ep == epochs - 1:
        print("epoch %3d   loss %.4f" % (ep, history[-1]))

import matplotlib.pyplot as plt
plt.figure(figsize=(5, 2.6))
plt.plot(history)
plt.xlabel("epoch"); plt.ylabel("loss"); plt.title("The loss goes down")
plt.tight_layout();

# ### The weights it found
#
# Compare this map with the hand-made one from Lab 02. Same idea, sharper
# edges - the machine kept adjusting until the loss stopped falling.

ss_ml.show_digit(w, "learned weights");

# ## 3. Quantize
#
# Not in this lab.

# ## 4. Compute
#
# ### 4.1 Does it work?
#
# The baseline is printed alongside, as in Lab 02. This task is unbalanced -
# 90% of the images are not zeros - so the accuracy is only meaningful as a
# distance above 90%.

pred = sigmoid(xte @ w + b) > 0.5
acc = 100.0 * (pred == (yte > 0.5)).mean()
baseline = 100.0 * (yte < 0.5).mean()

print("test accuracy : %.1f %%" % acc)
print("baseline      : %.1f %%   <- always answering 'not zero'" % baseline)
print("gain          : %.1f points" % (acc - baseline))
print()
print("Lab 02, weights by hand : 98.0 %")
print("Lab 03, weights learned : %.1f %%" % acc)

# ### 4.2 The number that decides the whole course
#
# Count the multiply-accumulates.
#
# **Inference** is one pass over 64 weights: 64 MACs.
#
# **Training** did a forward pass and a backward pass, for every sample, for
# every epoch. Count them.

mac_infer = ss_ml.N_PIXEL
mac_train = epochs * n * ss_ml.N_PIXEL * 2      # forward + backward

print("inference : {:>15,} MAC".format(mac_infer))
print("training  : {:>15,} MAC".format(mac_train))
print("ratio     : {:>15,} x".format(mac_train // mac_infer))

# ### 4.3 So why does the FPGA not train?
#
# The ratio above is striking, but on its own it is not the argument. Eight
# hundred thousand times a very small number is still a small number, and a
# board with 80 multipliers would chew through this particular training run
# without complaining.
#
# The real obstacle is **memory**, and it is easy to measure.
#
# Training must hold the entire dataset while it runs. Inference holds one
# image. Look at what that costs on this board.

data_train = n * ss_ml.N_PIXEL              # every image, held while training
data_infer = ss_ml.N_PIXEL                 # one image

print("held during inference : {:>12,} B   {:>7.2f} % of BRAM".format(
    data_infer, 100 * data_infer / ss_ml.BOARD_BRAM_BYTES))
print("held during training  : {:>12,} B   {:>7.2f} % of BRAM".format(
    data_train, 100 * data_train / ss_ml.BOARD_BRAM_BYTES))
print()
mnist = 60000 * 784
print("and at MNIST scale    : {:>12,} B   {:>7,.0f} % of BRAM".format(
    mnist, 100 * mnist / ss_ml.BOARD_BRAM_BYTES))

# A third of the board just to hold 8x8 images, before a single multiplier
# is placed. At MNIST scale the dataset wants two hundred times the memory
# the part contains.
#
# Two more costs sit on top of that:
#
# - gradients are small fractional numbers, so training wants floating point
#   or a fixed-point scheme carefully designed for it
# - the backward pass needs values from the forward pass kept alive, so
#   intermediate results pile up instead of streaming through
#
# Inference has none of these. One image in, finished weights already
# stored, one pass, answer out.
#
# **So the split across this whole curriculum is: the PC learns, the FPGA
# infers.** Not a limitation - a division of labour. Everything from Lab 11
# onward exists to move a finished set of weights from one side to the other
# without changing a single answer.

# ## 5. Report

ss_ml.report(
    "03", "Gradient descent, digit 0 vs rest",
    mac=mac_infer,
    compare=1,
    memory_bytes=w.size * 4 + 4,
    accuracy=acc,
    note="Training cost {:,} MAC - {:,}x the inference cost.".format(
        mac_train, mac_train // mac_infer),
)

# ---
#
# ## What to take away
#
# 1. Training is a loop: predict, measure the error, step downhill. Nothing
#    more mysterious than that.
# 2. The learned weights beat the hand-made ones from Lab 02.
# 3. Training costs hundreds of thousands of times the arithmetic of a
#    single inference - and needs the whole dataset in memory besides.
# 4. **PC trains, FPGA infers.** Remember this sentence; the rest of the
#    book is built on it.
#
# **Next - Lab 04:** one score told us "zero or not". Ten scores tell us
# which digit it is.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Run the same loop with a learning rate of 0.05 instead of 0.5. Does it reach the same loss in 300 epochs?
#
# **2.** Training here cost about 52 million MAC. What would 1,000 epochs cost, and how many inferences is that?

# --- Exercise 1 ---
for rate in [0.05, 0.5]:
    ww, bb = np.zeros(ss_ml.N_PIXEL), 0.0
    for _ in range(epochs):
        pp = sigmoid(xtr @ ww + bb)
        ee = pp - ytr
        ww -= rate * (xtr.T @ ee / n)
        bb -= rate * ee.mean()
    print("lr %.2f -> final loss %.4f" % (rate, loss_fn(sigmoid(xtr @ ww + bb), ytr)))

# <details>
# <summary>What you should see</summary>
#
# The smaller rate is still descending when the epochs run out. It is not wrong, just slower - it would get there with more steps.
#
# </details>

# --- Exercise 2 ---
for ep in [300, 1000]:
    m = ep * n * ss_ml.N_PIXEL * 2
    print("%4d epochs : {:>15,} MAC = {:>12,} inferences".format(m, m // 64) % ep)

# <details>
# <summary>What you should see</summary>
#
# About 172 million MAC, or 2.7 million inferences. Training cost scales linearly with epochs; inference cost never moves.
#
# </details>
