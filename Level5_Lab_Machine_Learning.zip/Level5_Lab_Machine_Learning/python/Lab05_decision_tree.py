"""
Semiconductor School - From Data to Circuits
Lab 05 - A Classifier With No Multiplier

Generated from Lab05_decision_tree.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 05 - A Classifier With No Multiplier
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# A decision tree asks yes/no questions about single pixels.
#
# **Why it matters for hardware**
# Zero multipliers. Only comparators and branches - a completely different shape of circuit from everything in Part 1.

import numpy as np
import ss_ml

ss_ml.board_summary()

# > **Every cost in this lab is the cost of one inference.**
# >
# > The notebook calls `fit()` as well as `predict()`, but only the second one
# > describes what runs on a chip. Training happens once, on a PC, and Lab 03
# > measured what it would cost to move it: the training data alone needs 42% of
# > the board's memory, against 64 bytes for a single inference.
# >
# > So when a table below says 640 MAC, read it as *640 multiply-accumulates to
# > classify one image* - not the cost of producing the model.

# ## 1. Load

ds = ss_ml.load_digits8x8()

# ## 2. Learn
#
# A tree does not weigh all 64 pixels. It looks at **one** pixel, compares
# it against a threshold, and goes left or right. Then it asks another
# question. After a dozen questions it has an answer.
#
# Training decides which pixel to ask about at each node, and where to put
# the threshold.

from sklearn.tree import DecisionTreeClassifier, export_text

tree = DecisionTreeClassifier(random_state=0).fit(ds.x_train, ds.y_train)

acc = 100.0 * tree.score(ds.x_test, ds.y_test)
print("depth      :", tree.get_depth())
print("nodes      :", tree.tree_.node_count)
print("accuracy   : %.1f %%" % acc)

# ### The tree, printed as code
#
# This is the entire classifier. Not weights - **branches**. Read the first
# few lines out loud and you can follow exactly what the circuit does.

rules = export_text(tree, feature_names=["px%02d" % i for i in range(64)])
print("\n".join(rules.split("\n")[:22]))
print("   ... (%d lines total)" % len(rules.split("\n")))

# ### It ignores most of the image

used = int((tree.feature_importances_ > 0).sum())
print("pixels actually used : %d out of 64" % used)
print("pixels never looked at: %d" % (64 - used))

# ## 3. Quantize
#
# Nothing to do. The thresholds are already integers, because the pixels
# were integers. **A tree arrives quantized.**
#
# That is worth pausing on. Everything in Part 3 exists to drag a
# floating-point model down to integers without breaking it. A tree never
# left.

# ## 4. Compute
#
# ### 4.1 Walking the tree by hand

def walk(tree, x):
    t = tree.tree_
    node, compares = 0, 0
    while t.children_left[node] != -1:
        compares += 1
        if x[t.feature[node]] <= t.threshold[node]:
            node = t.children_left[node]
        else:
            node = t.children_right[node]
    return int(np.argmax(t.value[node])), compares

pred, n_cmp = walk(tree, ds.x_test[0])
print("true:", ds.y_test[0], " predicted:", pred, " compares used:", n_cmp)

# ### 4.2 The cost, counted
#
# Zero multiplies. Not "few" - zero. There is no multiplier anywhere in
# this classifier.
#
# To count memory we need to decide how one node is stored. The code below
# allows six bytes, and shows the bit budget it is based on.
#
# That is an assumption, not a fact. A tight encoding would fit a node in
# 31 bits, so six bytes is a generous estimate rather than a minimal one.
# Different encodings give different totals, which is why the figure is
# stated once here and used unchanged for the rest of the book - and why
# Lab 10 does not rank models whose ordering depends on it.

# what one tree node has to hold, in bits:
#   feature index    6 bits   (64 features to choose from)
#   threshold        5 bits   (pixels run 0..16, not 0..255)
#   left child      10 bits   (the largest tree here has 365 nodes)
#   right child     10 bits
#                  --------
#                   31 bits
#
# We allow 6 bytes - comfortably more than the 31 bits a tight encoding
# needs. The estimate is deliberately generous, and it is used unchanged
# for the rest of the book so the comparisons stay consistent.
NODE_BYTES = 6

path = tree.decision_path(ds.x_test)
avg_cmp = path.sum(axis=1).mean() - 1        # nodes visited, minus the leaf
mem = tree.tree_.node_count * NODE_BYTES

print("MAC per image     : 0")
print("compares per image: %.1f (average path length)" % avg_cmp)
print("worst case        : %d (tree depth)" % tree.get_depth())
print("memory            : {:,} nodes x {} B = {:,} B".format(
    tree.tree_.node_count, NODE_BYTES, mem))

# ### 4.3 The catch: the delay is not fixed
#
# Part 1's classifier took the same time on every image - 640 MACs, always.
# This one takes 9 compares on an easy digit and 14 on a hard one.
#
# For a pipeline that is awkward. You cannot schedule around a latency you
# do not know in advance, so a hardware tree is usually built for the worst
# case and the easy images just finish early and wait.
#
# **This is the trade.** No multipliers, but no fixed timing either.

depths = np.asarray(path.sum(axis=1)).ravel() - 1
print("compares per image: min %d, mean %.1f, max %d" %
      (depths.min(), depths.mean(), depths.max()))

# ### 4.4 Capacity is not the only memory cost
#
# The report counts **how many bytes** the tree needs. On real hardware there is
# a second question: **how those bytes are reached.**
#
# A MAC pipeline reads weights in address order - 0, 1, 2, 3 - which is the
# pattern block RAM is built for. One read per cycle, no stalls.
#
# A tree jumps. Which node it reads next depends on the comparison it just made,
# so the address is not known until the previous read has come back and been
# compared. Consecutive reads land in unrelated places.
#
# For a design that fits comfortably in on-chip block RAM, as ours does, this
# costs little - block RAM is genuinely random access. It becomes the dominant
# cost when the model no longer fits on chip and those jumps turn into external
# memory transactions, where a scattered access can cost tens of cycles instead
# of one.
#
# **So a small tree is cheap twice over,** and a tree large enough to spill off
# chip is expensive twice over. The byte count in the report is only half the
# picture.

# ## 5. Report

ss_ml.report(
    "05", "Decision tree (single)",
    mac=0,
    compare=int(round(avg_cmp)),
    memory_bytes=mem,
    accuracy=acc,
    note="Zero multipliers. Comparators and branches only.",
)

# ---
#
# ## What to take away
#
# 1. **MAC = 0.** A tree needs no multiplier at all, only comparators.
# 2. It reads a handful of pixels and ignores the rest.
# 3. It arrives already quantized - integer thresholds, no conversion needed.
# 4. In exchange, the latency varies with the input.
# 5. On its own it is the least accurate model in this book. **Lab 06 fixes
#    that, and the fix is very hardware-friendly.**

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Limit the tree to depth 6. What happens to accuracy and to the node count?
#
# **2.** We assumed 6 bytes per node. What is the memory if a node fits in 4 bytes?

# --- Exercise 1 ---
for d in [6, None]:
    t2 = DecisionTreeClassifier(max_depth=d, random_state=0).fit(
        ds.x_train, ds.y_train)
    print("max_depth %-4s : accuracy %.1f %%   nodes %d"
          % (str(d), 100 * t2.score(ds.x_test, ds.y_test), t2.tree_.node_count))

# <details>
# <summary>What you should see</summary>
#
# A shallower tree is far smaller and only a little less accurate. Depth is the main dial between circuit size and performance here.
#
# </details>

# --- Exercise 2 ---
for nb in [4, 6, 8]:
    m = tree.tree_.node_count * nb
    print("%d B/node : {:>7,} B  ({:.2f} %% of BRAM)".format(
        m, 100 * m / ss_ml.BOARD_BRAM_BYTES) % nb)

# <details>
# <summary>What you should see</summary>
#
# The memory scales directly with the encoding you choose. This is why the assumption is stated once and kept fixed - so the comparisons stay fair.
#
# </details>
