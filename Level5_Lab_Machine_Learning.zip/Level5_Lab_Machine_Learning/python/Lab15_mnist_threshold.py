"""
Semiconductor School - From Data to Circuits
Lab 15 - The 28x28 Threshold

Generated from Lab15_mnist_threshold.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 15 - The 28x28 Threshold
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# What breaks when the image gets bigger - and why convolution is the answer.
#
# **Why it matters for hardware**
# Every cost in this book was measured at 64 pixels. At 784 the answers change, and one model stops fitting entirely.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load
#
# No new data. This lab is arithmetic - we scale the numbers you already
# measured up to MNIST size and see what survives.

SMALL, BIG = 8 * 8, 28 * 28
N_MNIST = 60000

print("this book : %d pixels" % SMALL)
print("MNIST     : %d pixels  (%.1fx larger)" % (BIG, BIG / SMALL))

# ## 2. Learn
#
# Nothing. This is a costing exercise.

# ## 3. Quantize
#
# Everything below assumes INT8 weights, as in Lab 11.

# ## 4. Compute
#
# ### 4.1 Linear classifier: it scales fine

for px, tag in [(SMALL, "8x8"), (BIG, "28x28")]:
    mac = px * 10
    mem = px * 10 + 40
    print("{:<6} : {:>8,} MAC   {:>8,} B   {:>5.1f} % of BRAM".format(
        tag, mac, mem, 100 * mem / ss_ml.BOARD_BRAM_BYTES))

# Twelve times the arithmetic, still a rounding error in memory. A linear
# model grows gracefully.
#
# ### 4.2 k-NN: it does not

for n, px, tag in [(1347, SMALL, "this book"), (N_MNIST, BIG, "MNIST")]:
    mem = n * px
    pct = 100 * mem / ss_ml.BOARD_BRAM_BYTES
    verdict = "fits" if pct <= 100 else "DOES NOT FIT"
    print("{:<10} : {:>12,} B   {:>10,.0f} % of BRAM   {}".format(
        tag, mem, pct, verdict))

# Lab 07 warned about this. At 8x8 k-NN took 42% of the board and we called
# it "barely". At MNIST scale it wants **over two hundred times** the block
# RAM that exists on the part.
#
# There is no clever engineering that fixes that. The algorithm is simply
# the wrong shape for a chip.
#
# ### 4.3 Fully connected on 28x28: the weights are the problem
#
# A single linear layer is fine. A *deep* network is not - and the reason is
# not the multiplies, it is the weights.

hidden = 128
fc_w = BIG * hidden + hidden * 10
print("784 -> %d -> 10" % hidden)
print("  weights : {:>10,}  ({:>8,} B at INT8)".format(fc_w, fc_w))
print("  MAC     : {:>10,}".format(fc_w))
print("  BRAM    : {:>10.1f} %".format(100 * fc_w / ss_ml.BOARD_BRAM_BYTES))

# ### 4.4 Convolution: reuse the same weights everywhere
#
# A 3x3 kernel has nine weights. It is applied at every position in the
# image - so the arithmetic is large but the **storage is tiny**.
#
# That is the trade convolution makes: lots of multiplies, almost no
# weights. And multiplies are what an FPGA has 80 of.

n_filt, ksz = 8, 3
out = (28 - ksz + 1) ** 2          # 26 x 26 = 676 window positions
conv_mac = out * n_filt * ksz * ksz
conv_w = n_filt * ksz * ksz        # nine weights per filter, reused everywhere

print("conv 3x3, %d filters on 28x28" % n_filt)
print("  window positions : {:>10,}".format(out))
print("  weights : {:>10,}  ({:>6,} B)   <- tiny".format(conv_w, conv_w))
print("  MAC     : {:>10,}              <- large".format(conv_mac))
print("  BRAM    : {:>10.4f} %".format(100 * conv_w / ss_ml.BOARD_BRAM_BYTES))
print()
print("fully connected : {:>8,} weights".format(fc_w))
print("convolution     : {:>8,} weights   ({:.0f}x fewer)".format(
    conv_w, fc_w / conv_w))

# **That ratio is why CNNs exist**, and it is a hardware answer as much as a
# statistical one. You have 80 multipliers and 202 kilobytes. Convolution
# spends the resource you have and saves the one you do not.
#
# ### 4.5 Four designs at MNIST scale
#
# One thing this table deliberately does **not** have is an accuracy column.
#
# We cannot measure accuracy here - this notebook never downloads MNIST, and
# quoting numbers from memory would be guessing dressed up as data. Every
# figure below is arithmetic you can check by hand.
#
# If a table mixes measured numbers with remembered ones and does not say
# which is which, it is not a cost model. Leaving the column out is the
# honest option.

# a conv layer does not classify on its own - a linear head reads its output
conv_out = out * n_filt            # 676 positions x 8 filters = feature values
head_w = conv_out * 10             # linear head: every feature to 10 classes

print("conv output values : {:>10,}".format(conv_out))
print("linear head weights: {:>10,}".format(head_w))
print()

designs = [
    ("Linear (INT8)",        BIG * 10,           BIG * 10 + 40),
    ("Conv 3x3 x8 + head",   conv_mac + head_w,  conv_w + head_w),
    ("Fully connected 128",  fc_w,               fc_w),
    ("k-NN (60,000 stored)", N_MNIST * BIG,      N_MNIST * BIG),
]

print("{:<22}{:>14}{:>14}{:>10}   {}".format(
    "Design", "MAC", "Memory B", "BRAM %", "verdict"))
print("-" * 74)
for name, mac, mem in designs:
    pct = 100 * mem / ss_ml.BOARD_BRAM_BYTES
    print("{:<22}{:>14,}{:>14,}{:>10,.1f}   {}".format(
        name, mac, mem, pct, "fits" if pct <= 100 else "DOES NOT FIT"))

# ## 5. Report

ss_ml.report(
    "15", "MNIST-scale cost estimate",
    mac=conv_mac, compare=9, memory_bytes=conv_w,
    accuracy=None,
    note="Convolution: many multiplies, few weights. That is the trade.",
)

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Use 16 convolution filters instead of 8. What happens to the MAC count and to the weight storage?
#
# **2.** Add 2x2 pooling after the convolution. How much smaller does the linear head become?

# --- Exercise 1 ---
for nf in [8, 16, 32]:
    mac = out * nf * ksz * ksz
    w = nf * ksz * ksz
    print("%2d filters : MAC {:>9,}   conv weights {:>5,} B".format(mac, w) % nf)

# <details>
# <summary>What you should see</summary>
#
# MAC grows with the filter count but the weights stay tiny. Convolution spends the resource an FPGA has plenty of.
#
# </details>

# --- Exercise 2 ---
pooled = (26 // 2) ** 2 * n_filt
head_pooled = pooled * 10
print("no pooling  : head {:>8,} weights  ({:>5.1f} %% of BRAM)".format(
    head_w, 100 * head_w / ss_ml.BOARD_BRAM_BYTES))
print("2x2 pooling : head {:>8,} weights  ({:>5.1f} %% of BRAM)".format(
    head_pooled, 100 * head_pooled / ss_ml.BOARD_BRAM_BYTES))
print("reduction   : {:.0f}x".format(head_w / head_pooled))

# <details>
# <summary>What you should see</summary>
#
# Four times smaller. Pooling is usually introduced as a way to gain translation tolerance; on a chip its more immediate effect is shrinking the layer that follows. Level 6 relies on this.
#
# </details>

# ---
#
# ## What to take away
#
# 1. A linear model scales to 28x28 without trouble.
# 2. **k-NN does not fit, by a factor of over two hundred.** The warning in
#    Lab 07 was real.
# 3. Fully-connected layers are limited by weight storage, not arithmetic.
# 4. Convolution reuses nine weights across the whole image - it spends
#    multipliers, which the FPGA has, and saves memory, which it does not.
# 5. No accuracy figure appears in this lab, because none could be measured
#    here. Say what you measured, and nothing more.
#
# ---
#
# ## End of the course
#
# You started with 64 integers in a row and ended holding a cost model for
# every classical machine learning algorithm, measured against a real part.
#
# What you can now do that you could not before:
#
# - read an algorithm and say which resource it will consume
# - quantize a trained model to INT8 without losing accuracy
# - pick a requantisation shift, and know what happens when it is wrong
# - write an integer golden model and verify against it
# - say `Mismatch Count = 0` and mean something precise by it
#
# **Level 5** takes the line classifier of Lab 14 and runs it on the Arty
# S7 in Verilog. **Level 6** takes the convolution of this lab and builds
# the full MNIST CNN.
#
# The Python is behind you. The silicon starts now.
