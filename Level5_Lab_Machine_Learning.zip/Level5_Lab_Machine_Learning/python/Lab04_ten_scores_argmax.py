"""
Semiconductor School - From Data to Circuits
Lab 04 - Splitting Into Ten

Generated from Lab04_ten_scores_argmax.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 04 - Splitting Into Ten
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# Ten scores, and the largest one wins.
#
# **Why it matters for hardware**
# Argmax is a comparator tree. Softmax is an exponential - expensive in silicon, and it turns out you never need it.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

ds = ss_ml.load_digits8x8()
xtr, xte = ds.x_train / 16.0, ds.x_test / 16.0

# ## 2. Learn
#
# Lab 03 showed what the training loop actually does. From here on we let
# scikit-learn run that same loop, so each lab can spend its time on the
# part that is new.
#
# Ten classes means ten weight vectors - one per digit. Each produces its
# own score.

from sklearn.linear_model import LogisticRegression

clf = LogisticRegression(max_iter=2000).fit(xtr, ds.y_train)
W, bias = clf.coef_, clf.intercept_

print("W    :", W.shape, "  -> one row of 64 weights per digit")
print("bias :", bias.shape)
ss_ml.show_grid(W, list(range(10)), n=10);

# ## 3. Quantize
#
# Not yet - Part 3. Note the weights are float64 here, which is why the
# memory number in the report is large. Lab 11 shrinks it.

# ## 4. Compute
#
# ### 4.1 Ten MAC blocks, then one winner

def classify(x, W, bias):
    scores = W @ x + bias          # 10 x 64 = 640 MAC
    best, best_i = scores[0], 0
    for i in range(1, len(scores)):
        if scores[i] > best:       # 9 compares
            best, best_i = scores[i], i
    return best_i, scores

i = 0
pred, scores = classify(xte[i], W, bias)
print("true label:", ds.y_test[i], "  predicted:", pred)
print()
for d in range(10):
    bar = "#" * max(0, int(scores[d] + 12))
    print("  digit %d : %8.3f  %s" % (d, scores[d], bar))

pred_all = (xte @ W.T + bias).argmax(axis=1)
acc = 100.0 * (pred_all == ds.y_test).mean()
print("accuracy: %.1f %%" % acc)
print("MAC per image: %d x %d = %d" % (10, 64, 640))
print("compares per image: 9")

# ### 4.2 Softmax does not change the answer
#
# Textbooks put softmax at the end of a classifier, so it is easy to assume
# the hardware needs one. It does not.
#
# Softmax turns scores into probabilities. It is **monotonic** - it never
# reorders anything. The largest score is still the largest probability.
#
# If all you want is the predicted class, softmax is arithmetic you paid for
# and threw away. Check it below: the two agree on every single test image.

raw = xte @ W.T + bias
e = np.exp(raw - raw.max(axis=1, keepdims=True))
soft = e / e.sum(axis=1, keepdims=True)

same = (raw.argmax(1) == soft.argmax(1)).all()
print("argmax(scores) == argmax(softmax) on all", len(raw), "images :", same)

# An exponential in silicon means a lookup table, or a piecewise
# approximation, plus a divider. All of it to compute numbers we then throw
# away by taking the largest.
#
# **This is why the Level 5 classifier has no softmax and no
# fully-connected layer** - it accumulates features and takes the argmax
# directly. When you get there it will look like a shortcut. It is not. It
# is the correct circuit.
#
# ### 4.3 Argmax is a comparator tree
#
# Nine sequential compares, or a tree four levels deep. No multipliers at
# all - argmax is nearly free next to the 640 MACs feeding it.

print("sequential : 9 compares, 9 steps")
print("tree       : 9 compares, 4 levels deep")

# ## 5. Report

ss_ml.report(
    "04", "Logistic regression, 10 classes (float)",
    mac=640,
    compare=9,
    memory_bytes=W.size * 4 + bias.size * 4,
    accuracy=acc,
    note="No softmax needed. Argmax gives the same answer for free.",
)

# ---
#
# ## What to take away
#
# 1. Ten classes means ten MAC blocks: 640 MACs, then 9 compares.
# 2. **Softmax never changes the argmax.** For a classifier, it is pure cost.
# 3. Argmax is a comparator tree - cheap next to the multipliers.
# 4. Weights in float32 cost 2,600 bytes here. Lab 11 gets the same accuracy
#    in a quarter of that.
#
# **Part 1 is done.** You have the atom (MAC), the training loop, and a real
# classifier. Part 2 asks a different question: what happens when the
# algorithm is not made of multiplies at all?

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Which digit does this classifier get wrong most often, and what does it confuse it with?
#
# **2.** Argmax over 10 classes needs 9 compares. How many for 100 classes, and how deep is the comparator tree?

# --- Exercise 1 ---
wrong = pred_all != ds.y_test
pairs = {}
for t, p in zip(ds.y_test[wrong], pred_all[wrong]):
    pairs[(int(t), int(p))] = pairs.get((int(t), int(p)), 0) + 1
for (t, p), c in sorted(pairs.items(), key=lambda kv: -kv[1])[:5]:
    print("true %d -> predicted %d : %d times" % (t, p, c))

# <details>
# <summary>What you should see</summary>
#
# The confusions are between digits that share strokes. A linear model sees only pixel brightness, so digits that overlap in position confuse it.
#
# </details>

# --- Exercise 2 ---
for k in [10, 100]:
    print("%3d classes : %3d compares, tree depth %d"
          % (k, k - 1, int(np.ceil(np.log2(k)))))

# <details>
# <summary>What you should see</summary>
#
# 99 compares, 7 levels deep. Compares grow linearly but the tree depth grows with the logarithm - which is why argmax stays cheap.
#
# </details>
