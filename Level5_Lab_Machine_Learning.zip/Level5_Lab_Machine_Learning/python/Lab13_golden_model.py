"""
Semiconductor School - From Data to Circuits
Lab 13 - Writing the Answer Key

Generated from Lab13_golden_model.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 13 - Writing the Answer Key
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# An integer golden model: Python that computes exactly what the RTL will.
#
# **Why it matters for hardware**
# This is how a design is proven correct. Mismatch = 0 or it is not done.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

from sklearn.linear_model import LogisticRegression

ds = ss_ml.load_digits8x8()
clf = LogisticRegression(max_iter=2000).fit(ds.x_train / 16.0, ds.y_train)
Wf, bf = clf.coef_, clf.intercept_
acc_float = 100.0 * clf.score(ds.x_test / 16.0, ds.y_test)
print("float model ready - accuracy %.1f %%" % acc_float)

scale = 127.0 / np.abs(Wf).max()
Wq = np.round(Wf * scale).astype(np.int32)
bq = np.round(bf * scale * 16).astype(np.int32)
SHIFT = 3
print("model + SHIFT = %d ready" % SHIFT)

# ## 2. Learn
#
# Nothing new. Part 3 only moves a finished model.

# ## 3. Quantize
#
# Done in Labs 11 and 12. This lab is about **proving** the move was exact.

# ## 4. Compute
#
# ### 4.1 What a golden model is
#
# The hardware will compute in a fixed order, with fixed widths, wrapping
# where it wraps. A golden model is Python written to do **the same thing in
# the same order** - not a cleaner version, not a better version. A mirror.
#
# Then you run both on the same inputs and compare. If every number matches,
# the circuit is right.
#
# Note the direction: the RTL structure is decided first and the Python is
# written to match it. Not the other way round.

def golden(x, Wq, bq, shift):
    """Integer forward pass in the order the hardware will use."""
    n_class = Wq.shape[0]
    scores = np.zeros(n_class, dtype=np.int64)
    for c in range(n_class):
        a = np.int64(bq[c])
        for i in range(len(x)):
            a += np.int64(x[i]) * np.int64(Wq[c, i])   # MAC, 32-bit accumulator
        a = a >> shift                                  # requantise
        a = ((a + 32768) & 0xFFFF) - 32768              # 16-bit wrap
        scores[c] = a
    best = 0
    for c in range(1, n_class):
        if scores[c] > scores[best]:                    # tie -> lower index
            best = c
    return scores, best

s0, c0 = golden(ds.x_test[0].astype(np.int64), Wq, bq, SHIFT)
print("scores :", s0)
print("class  :", c0, "  truth:", ds.y_test[0])

# ### 4.2 The trap: matching the class proves nothing
#
# Argmax is blind to positive scaling. Two models with completely different
# score values can agree on every class.
#
# So if you check only the predicted class, a wrong shift passes your test.

sA, cA = golden(ds.x_test[0].astype(np.int64), Wq, bq, 3)
sB, cB = golden(ds.x_test[0].astype(np.int64), Wq, bq, 4)

print("SHIFT=3 scores:", sA)
print("SHIFT=4 scores:", sB)
print()
print("same class ? ", cA == cB, "   <- looks fine")
print("same scores? ", bool((sA == sB).all()), "   <- it is NOT fine")

# **Check the scores, not the class.** Level 5 learned this the hard way: a
# frame-boundary bug left the classes correct while the feature values were
# wrong, and four clean test images never caught it.
#
# ### 4.3 The answer key files
#
# Three files, and they are not all the same kind of thing.

N = 32
imgs = ds.x_test[:N].astype(np.int64)
gold = np.array([golden(im, Wq, bq, SHIFT)[0] for im in imgs])

ss_ml.write_mem("out/lab13/weight.mem", Wq.ravel(), bits=8)
ss_ml.write_mem("out/lab13/bias.mem", bq, bits=32)
ss_ml.write_mem("out/lab13/images.mem", imgs.ravel(), bits=8)
ss_ml.write_mem("out/lab13/golden_score.mem", gold.ravel(), bits=32)

with open("out/lab13/quant_config.txt", "w") as f:
    f.write("SHIFT = %d\n" % SHIFT)
    f.write("SCALE = %.6f\n" % scale)

print("weight.mem       %5d words" % Wq.size)
print("bias.mem         %5d words" % bq.size)
print("images.mem       %5d words" % imgs.size)
print("golden_score.mem %5d words" % gold.size)
print()
print(open("out/lab13/quant_config.txt").read())

# ### 4.4 Which files go into the chip
#
# A rule worth memorising, because it decides what you register in Vivado:
#
# **Synthesised - they become real memory inside the FPGA**
#
# - `weight.mem` - becomes the weight ROM
# - `bias.mem` - becomes the bias ROM
# - `images.mem` - becomes the input image ROM
#
# **Not synthesised - simulation only**
#
# - `golden_score.mem` - the answer key. The testbench reads it to grade the
#   result. It never enters the hardware.
#
# The distinction is simple: *would the circuit still work if this file
# vanished?* If yes, it is a test file.
#
# And note there is no `golden_class.mem`. The class is `argmax(scores)`, so
# storing it would duplicate information already present - the testbench can
# compute it.
#
# ### 4.5 Grading

check = np.array([golden(im, Wq, bq, SHIFT)[0] for im in imgs])
mismatch = int((check != gold).sum())

print("images checked   :", N)
print("scores compared  :", check.size)
print("Mismatch Count   :", mismatch)
print()
print("FINAL RESULT     :", "100% BIT-TRUE PASS" if mismatch == 0 else "FAIL")

# That comparison is trivial here because both sides are the same function.
# The point is the **shape** of the check. In Level 5 the left side is
# Python and the right side is Verilog running in `xsim`, and the line that
# matters reads exactly the same:
#
#     Mismatch Count = 0
#     FINAL RESULT   = 100% BIT-TRUE PASS

# ## 5. Report

pred_g = np.array([golden(im, Wq, bq, SHIFT)[1]
                   for im in ds.x_test.astype(np.int64)])
acc_g = 100.0 * (pred_g == ds.y_test).mean()

ss_ml.report(
    "13", "Integer golden model",
    mac=640, compare=9,
    memory_bytes=Wq.size + bq.size * 4,
    accuracy=acc_g,
    note="Mismatch Count = %d. Compare scores, never just the class." % mismatch,
)

# ---
#
# ## What to take away
#
# 1. A golden model mirrors the hardware's order and widths on purpose.
# 2. **Comparing predicted classes is not verification.** Compare the scores.
# 3. Weight and bias files are synthesised; the golden file is not.
# 4. `Mismatch Count = 0` is the only acceptable result.
#
# **Next - Lab 14:** the same machinery, on the images that actually run on
# the board.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Change one weight by a small amount and re-run. Do the classes change? Do the scores?
#
# **2.** Compare the explicit loop against a vectorised NumPy version. Are they bit-identical?

# --- Exercise 1 ---
# pick a pixel that is actually bright - a corner pixel is almost always
# zero, and a weight multiplied by zero changes nothing
hot = int(ds.x_test.mean(axis=0).argmax())
print("perturbing the weight on pixel", hot,
      "(mean value %.1f)" % ds.x_test[:, hot].mean())

Wbad = Wq.copy()
Wbad[0, hot] += 3

cls_same = score_same = 0
for im in imgs:
    s1, c1 = golden(im, Wq, bq, SHIFT)
    s2, c2 = golden(im, Wbad, bq, SHIFT)
    cls_same += (c1 == c2)
    score_same += bool((s1 == s2).all())

print("images                   :", len(imgs))
print("same predicted class     :", cls_same)
print("same scores (bit-true)   :", score_same)

# <details>
# <summary>What you should see</summary>
#
# Every class still matches, but the scores do not. A test that only checked the class would have passed a circuit with a corrupted weight.
#
# </details>

# --- Exercise 2 ---
vec = ((imgs.astype(np.int64) @ Wq.T.astype(np.int64)
        + bq.astype(np.int64)) >> SHIFT)
vec = ((vec + 32768) & 0xFFFF) - 32768
print("mismatches vs the explicit loop :", int((vec != gold).sum()))

# <details>
# <summary>What you should see</summary>
#
# Zero. The vectorised path and the loop agree exactly - which is the real check, because the two were written independently.
#
# </details>
