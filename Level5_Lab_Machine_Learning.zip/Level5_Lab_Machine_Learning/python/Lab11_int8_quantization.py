"""
Semiconductor School - From Data to Circuits
Lab 11 - From Real Numbers to Integers

Generated from Lab11_int8_quantization.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 11 - From Real Numbers to Integers
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# INT8 quantization: one scale factor, a rounding, and the model still works.
#
# **Why it matters for hardware**
# Silicon has no floating point unit unless you pay for one. Multiplier area grows with the square of the bit width, so 8 bits costs a sixteenth of 32 bits.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

from sklearn.linear_model import LogisticRegression

ds = ss_ml.load_digits8x8()
clf = LogisticRegression(max_iter=2000).fit(ds.x_train / 16.0, ds.y_train)
Wf, bf = clf.coef_, clf.intercept_
acc_float = 100.0 * clf.score(ds.x_test / 16.0, ds.y_test)
print("float model ready - accuracy %.1f %%" % acc_float)

# ## 2. Learn
#
# Already done. Part 3 never trains anything new - it takes a finished
# model and moves it onto hardware without changing its answers.

# ## 3. Quantize
#
# ### 3.1 Why bother
#
# A float32 multiplier is a large, slow block. An 8-bit integer multiplier
# is small and fast, and the FPGA has 80 of them built in.
#
# Multiplier area grows roughly with the **square** of the bit width:
#
# | width | relative area |
# |---|---|
# | 32 bit | 16 |
# | 16 bit | 4 |
# | 8 bit  | 1 |
#
# Same silicon, sixteen times the multipliers. That is the whole argument.
#
# ### 3.2 One number does it
#
# Find the largest weight, and stretch the range so it lands on 127 - the
# largest value a signed byte can hold.
#
#     scale = 127 / max|W|
#     Wq    = round(W * scale)

scale = 127.0 / np.abs(Wf).max()
Wq = np.round(Wf * scale).astype(np.int32)
bq = np.round(bf * scale * 16).astype(np.int32)     # pixels are 0..16, not 0..1

print("largest float weight : %.5f" % np.abs(Wf).max())
print("scale                : %.2f" % scale)
print("integer range        : %d to %d" % (Wq.min(), Wq.max()))
print("bias range           : %d to %d" % (bq.min(), bq.max()))

# ### 3.2a What the scale actually does, as a picture
#
# Quantisation lays a fixed grid over a continuous range. The scale decides how
# wide the grid squares are: stretch the weights until the largest one lands on
# 127, then round everything to the nearest grid line.

hi = float(np.abs(Wf).max())
step = 1.0 / scale

print("  continuous float weights")
print("  {:+.3f} {} 0 {} {:+.3f}".format(-hi, "-" * 20, "-" * 20, hi))
print()
print("  {:^47}".format("x %.2f" % scale))
print()
print("  256 integer levels, evenly spaced")
print("  {:>6} {} 0 {} {:<6}".format(-127, "|" * 20, "|" * 20, +127))
print()
print("  one step  = {:.5f} in float terms".format(step))
print("  a weight is rounded to the nearest step, so the most it can")
print("  move is half a step: {:.5f}".format(step / 2))

# ### 3.2b Watch it happen, one weight at a time
#
# Quantisation is easier to trust once you have seen the bits. Each row below is
# one weight: the original float, the same value stretched by the scale, the
# rounded integer, and the eight bits that integer occupies.
#
# Negative values are stored in two's complement - the leading bit is 1.

def bits8(v):
    s = format(int(v) & 0xFF, "08b")
    return s[:4] + " " + s[4:]

print("  float weight    x scale   rounded   stored as INT8")
print("  " + "-" * 52)
for i in [20, 21, 22, 30, 31]:
    f = Wf[0, i]
    print("  {:+10.6f}  {:+9.2f}    {:+5d}     {}".format(
        f, f * scale, int(np.round(f * scale)), bits8(np.round(f * scale))))
print()
print("  the widest weight in the model reaches +/-127, which is the")
print("  largest value 8 bits can hold - that is what the scale is for")

# ### 3.3 What rounding threw away

back = Wq / scale
err = np.abs(back - Wf)
print("largest weight error : %.6f" % err.max())
print("mean weight error    : %.6f" % err.mean())
print("relative             : %.3f %%" % (100 * err.mean() / np.abs(Wf).mean()))

# ## 4. Compute
#
# ### 4.1 Integer inference, start to finish
#
# No division, no float anywhere. Raw pixels 0..16 go straight in.

xte_int = ds.x_test.astype(np.int32)
scores_int = xte_int @ Wq.T + bq
pred_int = scores_int.argmax(axis=1)
acc_int = 100.0 * (pred_int == ds.y_test).mean()

print("float accuracy : %.1f %%" % acc_float)
print("INT8  accuracy : %.1f %%" % acc_int)
print("difference     : %.1f points" % (acc_float - acc_int))

# ### 4.2 That is the headline
#
# The integer model matches the float model. Not "close enough" - the same.
#
# The usual worry about quantization is that accuracy falls off a cliff. It
# can, in deep networks with many layers stacked. For a single linear layer
# followed by an argmax there is almost nothing to lose, because **argmax
# does not care about scale**. Multiply every score by the same positive
# number and the winner is unchanged.
#
# Keep that sentence. It is also the trap in Lab 13.
#
# ### 4.3 Where the pictures differ

diff = np.where(pred_int != clf.predict(ds.x_test / 16.0))[0]
print("images where float and int disagree :", len(diff))
if len(diff):
    i = diff[0]
    print("  index %d: float says %d, int says %d, truth %d"
          % (i, clf.predict(ds.x_test[i:i+1] / 16.0)[0], pred_int[i],
             ds.y_test[i]))

# ### 4.4 The memory bill

mem_f = Wf.size * 4 + bf.size * 4
mem_q = Wq.size * 1 + bq.size * 4

print("float32 weights : {:>6,} B".format(mem_f))
print("INT8    weights : {:>6,} B".format(mem_q))
print("saving          : {:.1f}x".format(mem_f / mem_q))

# ## 5. Report

ss_ml.report(
    "11", "Logistic regression (INT8)",
    mac=640, compare=9, memory_bytes=mem_q, accuracy=acc_int,
    note="Same accuracy as float32, in a quarter of the memory.",
)

# ---
#
# ## What to take away
#
# 1. `scale = 127 / max|W|` is the whole quantization step.
# 2. Accuracy did not move. Argmax is blind to a positive scale factor.
# 3. Memory dropped 4x, and the multipliers got 16x cheaper in area.
# 4. This is exactly what Level 5 does to produce `conv_weight.mem`.
#
# **Next - Lab 12:** integers do not overflow gracefully. Let us break one
# on purpose.

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Quantize to 4 bits instead of 8 (largest value 7). Does accuracy survive?
#
# **2.** What happens if you forget the x16 on the bias?

# --- Exercise 1 ---
for bits in [8, 6, 4, 2]:
    lim = 2 ** (bits - 1) - 1
    sc = lim / np.abs(Wf).max()
    Wt = np.round(Wf * sc).astype(np.int32)
    bt = np.round(bf * sc * 16).astype(np.int32)
    a = 100.0 * ((xte_int @ Wt.T + bt).argmax(1) == ds.y_test).mean()
    print("%d-bit weights (max %3d) : accuracy %.1f %%" % (bits, lim, a))

# <details>
# <summary>What you should see</summary>
#
# Even 4 bits holds up well here. A single linear layer is very forgiving; deep networks are not, which is why Level 6 checks this carefully.
#
# </details>

# --- Exercise 2 ---
wrong_b = np.round(bf * scale).astype(np.int32)
a = 100.0 * ((xte_int @ Wq.T + wrong_b).argmax(1) == ds.y_test).mean()
print("bias scaled correctly : %.1f %%" % acc_int)
print("bias missing the x16  : %.1f %%" % a)

# <details>
# <summary>What you should see</summary>
#
# The bias ends up 16 times too small relative to the weights, so it stops doing its job. The pixel range and the weight scale must be accounted for together.
#
# </details>
