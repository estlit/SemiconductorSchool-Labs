"""
Semiconductor School - From Data to Circuits
Lab 02 - Multiply and Accumulate

Generated from Lab02_multiply_accumulate.ipynb
Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
"""

import os
import sys

# the lab scripts live in python/, but ss_ml.py and data/ live one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib
matplotlib.use("Agg")          # no display needed for a batch run


# # Lab 02 - Multiply and Accumulate
#
# **Semiconductor School - From Data to Circuits**
# Author: Roger Kim / Copyright (c) 2026 EdgeChipLab
#
# ---
#
# This notebook runs on its own. Open it, run it top to bottom, and the lab
# is finished. It reads no output from any other lab.
#
# **What you learn**
# One weight per pixel, all products added up, one number out.
#
# **Why it matters for hardware**
# This is the atom. Every AI accelerator ever built is a pile of these.

import numpy as np
import ss_ml

ss_ml.board_summary()

# ## 1. Load

ds = ss_ml.load_digits8x8()
print(ds)

# ## 2. Learn
#
# Nothing is learned in this lab. We build the weights **by hand** so that
# the arithmetic stays visible. Learning arrives in Lab 03.
#
# Our question is the simplest one possible: **is this digit a zero?**
#
# A zero has ink around the edge and a hole in the middle. So take the
# average zero, subtract the average non-zero, and use the difference as a
# weight per pixel. Pixels that are bright in zeros get a positive weight,
# pixels that are bright in everything else get a negative one.

target = 0
is_t = ds.y_train == target

w = ds.x_train[is_t].mean(axis=0) - ds.x_train[~is_t].mean(axis=0)
b = 0.0

print("weights:", w.shape, " min %.2f  max %.2f" % (w.min(), w.max()))
ss_ml.show_digit(w, "weight map");

# ## 3. Quantize
#
# Not in this lab. The weights stay as floats until Part 3.

# ## 4. Compute
#
# ### 4.1 The operation, written out
#
# Multiply one pixel by one weight, add it to a running total, repeat.
# Multiply-accumulate. MAC.
#
# Below is the loop with nothing hidden. NumPy does the same thing in one
# call, and we check that the two agree.

def mac_score(x, w, b):
    total = 0.0
    for i in range(len(x)):
        total = total + x[i] * w[i]      # <-- one MAC
    return total + b

x0 = ds.x_test[0].astype(np.float64)

by_hand = mac_score(x0, w, b)
by_numpy = float(np.dot(x0, w) + b)

print("by hand  : %.4f" % by_hand)
print("by numpy : %.4f" % by_numpy)
print("MAC count: %d" % len(x0))

# ### 4.2 One number, one decision
#
# The score is high for zeros and low for everything else. Put a threshold
# between the two groups and we have a classifier: 64 MACs and 1 compare.
#
# **Always print the baseline next to the accuracy.** Only one digit in ten
# is a zero, so a model that answers "not zero" every single time is already
# right 90% of the time and has learned nothing. An accuracy figure on an
# unbalanced task means nothing on its own - what matters is how far above
# the baseline it sits.

scores_tr = ds.x_train @ w + b
threshold = 0.5 * (scores_tr[ds.y_train == target].mean()
                   + scores_tr[ds.y_train != target].mean())

scores_te = ds.x_test @ w + b
pred = scores_te > threshold
truth = ds.y_test == target
acc = 100.0 * (pred == truth).mean()

baseline = 100.0 * (~truth).mean()

print("threshold      : %.2f" % threshold)
print("mean score, 0  : %.2f" % scores_te[truth].mean())
print("mean score, not: %.2f" % scores_te[~truth].mean())
print()
print("accuracy       : %.1f %%" % acc)
print("baseline       : %.1f %%   <- a model that always answers 'not zero'"
      % baseline)
print("gain           : %.1f points" % (acc - baseline))

# ### 4.3 What this costs on a chip
#
# 64 MACs is not one number - it is a choice.
#
# - **1 multiplier**, used 64 times: 64 cycles, tiny area
# - **64 multipliers**, used once: 1 cycle, 64x the area
# - **8 multipliers**: 8 cycles
#
# Area and time trade against each other, and nothing else changes. This
# trade is the whole business of accelerator design, and you are looking at
# it in its smallest possible form.

for n_mult in [1, 8, 64, ss_ml.BOARD["dsp"]]:
    print("%3d multipliers -> %3d cycles" % (n_mult, -(-64 // n_mult)))

# ## 5. Report

weight_bytes = w.size * 4 + 4          # float32 weights plus one bias

ss_ml.report(
    "02", "MAC template, digit 0 vs rest",
    mac=64,
    compare=1,
    memory_bytes=weight_bytes,
    accuracy=acc,
    note="One multiplier: 64 cycles. Sixty-four multipliers: 1 cycle.",
)

# ---
#
# ## What to take away
#
# 1. `total += x[i] * w[i]` is the multiply-accumulate, and it is the atom.
# 2. 64 MACs plus 1 compare is already a working classifier.
# 3. How many multipliers you build decides how many cycles it takes.
#    Nothing else about the maths changes.
# 4. We picked these weights by hand and got a decent result. **Lab 03 makes
#    the machine find them instead.**

# ---
#
# ## Exercises
#
# Try each one before running the answer cell underneath it.
#
# **1.** Build the same template classifier for digit 1 instead of digit 0. Is it better or worse, and what is the baseline?
#
# **2.** With 16 multipliers instead of 1, how many cycles does one score take?

# --- Exercise 1 ---
for tgt in [0, 1]:
    m = ds.y_train == tgt
    ww = ds.x_train[m].mean(0) - ds.x_train[~m].mean(0)
    s_tr = ds.x_train @ ww
    th = 0.5 * (s_tr[m].mean() + s_tr[~m].mean())
    tr = ds.y_test == tgt
    a = 100.0 * (((ds.x_test @ ww) > th) == tr).mean()
    print("digit %d : accuracy %.1f %%   baseline %.1f %%   gain %.1f"
          % (tgt, a, 100 * (~tr).mean(), a - 100 * (~tr).mean()))

# <details>
# <summary>What you should see</summary>
#
# Digit 1 is harder. Zeros have a distinctive ring; ones look like part of several other digits, so a single template separates them less well. Always read the gain over baseline, not the raw accuracy.
#
# </details>

# --- Exercise 2 ---
for n_mult in [1, 16, 64]:
    print("%2d multipliers -> %2d cycles" % (n_mult, -(-64 // n_mult)))

# <details>
# <summary>What you should see</summary>
#
# Four cycles. Cycles and multipliers trade off exactly - halve one and the other doubles.
#
# </details>
