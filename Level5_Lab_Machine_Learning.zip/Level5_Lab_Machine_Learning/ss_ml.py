"""
Semiconductor School - From Data to Circuits
Shared plumbing library for all labs.

Author: Roger Kim
Copyright (c) 2026 EdgeChipLab

This module holds ONLY the parts that repeat in every lab:
dataset loading, digit rendering, .mem file I/O, and the report block.

The algorithm itself is never hidden here. Whatever a lab teaches
stays visible inside that lab's notebook.

RULE: functions may be ADDED to this file, but an existing signature
must never change. Lab 01 fixes the contract for all later labs.
"""

import os
import numpy as np

__version__ = "1.0"

# ---------------------------------------------------------------------------
# Target board: Digilent Arty S7-25
#
# Every figure below is taken from the Arty S7 FPGA Board Reference Manual
# (Digilent, revised 2019-10-25), variant table and Overview section.
# ---------------------------------------------------------------------------
BOARD_NAME = "Arty S7-25"

BOARD = {
    "part":       "XC7S25-1CSGA324C",
    "luts":          14600,
    "slices":         3650,
    "flip_flops":    29200,
    "cmt":               3,   # clock management tiles
    "dsp":              80,   # DSP48E1 slices, one MAC per slice per cycle
    "bram_kbits":     1620,   # fast block RAM, quoted as 202.5 KB in the manual
}

BOARD_BRAM_BITS = BOARD["bram_kbits"] * 1024
BOARD_BRAM_BYTES = BOARD_BRAM_BITS // 8

_DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "data", "digits8x8.npz")

# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
IMG_H = 8
IMG_W = 8
N_PIXEL = IMG_H * IMG_W
N_CLASS = 10
PIXEL_MAX = 16          # pixel values run 0..16, so 5 bits are enough


class Dataset:
    """Fixed train/test split shared by every lab, so numbers compare."""

    def __init__(self, x_train, y_train, x_test, y_test):
        self.x_train = x_train
        self.y_train = y_train
        self.x_test = x_test
        self.y_test = y_test

    def __repr__(self):
        return ("Dataset(train={}, test={}, pixels={}, classes={})"
                .format(len(self.y_train), len(self.y_test),
                        N_PIXEL, N_CLASS))


def load_digits8x8(seed=42):
    """Return the 8x8 handwritten digit set as uint8 arrays.

    Pixels are integers 0..16 and are NOT normalised. Every lab starts
    from the same integers the hardware would see.
    """
    if os.path.exists(_DATA_FILE):
        d = np.load(_DATA_FILE)
        return Dataset(d["x_train"], d["y_train"], d["x_test"], d["y_test"])

    from sklearn.datasets import load_digits
    from sklearn.model_selection import train_test_split

    raw = load_digits()
    x = raw.data.astype(np.uint8)
    y = raw.target.astype(np.uint8)
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.25, random_state=seed, stratify=y)
    return Dataset(x_train, y_train, x_test, y_test)


def train_val_split(ds, frac=0.2, seed=42):
    """Carve a validation set out of the training set.

    Returns (x_train, y_train, x_val, y_val). The test set is untouched.

    Anything you tune - a shift, a threshold, a number of components - is
    chosen on the validation set. The test set is looked at once, at the
    end, and never used to make a decision.
    """
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(ds.y_train))
    n_val = int(round(len(order) * frac))
    val, tr = order[:n_val], order[n_val:]
    return (ds.x_train[tr], ds.y_train[tr],
            ds.x_train[val], ds.y_train[val])


def save_dataset(ds, path=_DATA_FILE):
    """Freeze the split to disk so labs never depend on scikit-learn."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path,
                        x_train=ds.x_train, y_train=ds.y_train,
                        x_test=ds.x_test, y_test=ds.y_test)
    return path


# ---------------------------------------------------------------------------
# Looking at a digit
# ---------------------------------------------------------------------------
def print_digit(vec, label=None):
    """Print one digit as the raw 8x8 integer grid."""
    grid = np.asarray(vec).reshape(IMG_H, IMG_W)
    if label is not None:
        print("label = {}".format(label))
    for row in grid:
        print(" ".join("{:2d}".format(int(v)) for v in row))


def show_digit(vec, label=None, ax=None):
    """Draw one digit."""
    import matplotlib.pyplot as plt
    grid = np.asarray(vec).reshape(IMG_H, IMG_W)
    if ax is None:
        _, ax = plt.subplots(figsize=(2.2, 2.2))
    ax.imshow(grid, cmap="gray_r", vmin=0, vmax=PIXEL_MAX)
    ax.set_xticks([])
    ax.set_yticks([])
    if label is not None:
        ax.set_title(str(label))
    return ax


def show_grid(x, y=None, n=10, cols=10):
    """Draw the first n digits in a grid."""
    import matplotlib.pyplot as plt
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 0.9, rows * 1.0))
    for i, ax in enumerate(np.ravel(axes)):
        if i < n:
            show_digit(x[i], None if y is None else y[i], ax=ax)
        else:
            ax.axis("off")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# Memory image files (.mem) - the format Vivado reads with $readmemh
# ---------------------------------------------------------------------------
def write_mem(path, values, bits=8):
    """Write integers as one hex word per line, two's complement if negative."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    digits = (bits + 3) // 4
    mask = (1 << bits) - 1
    with open(path, "w") as f:
        for v in np.ravel(np.asarray(values)):
            f.write("{:0{w}X}\n".format(int(v) & mask, w=digits))
    return path


def read_mem(path, bits=8, signed=False):
    """Read a .mem file back as an integer array."""
    with open(path) as f:
        words = [int(line.strip(), 16) for line in f if line.strip()]
    arr = np.array(words, dtype=np.int64)
    if signed:
        limit = 1 << (bits - 1)
        arr = np.where(arr >= limit, arr - (1 << bits), arr)
    return arr


# ---------------------------------------------------------------------------
# The report block - identical in every lab
# ---------------------------------------------------------------------------
_LINE = "=" * 60
_THIN = "-" * 60


def report(lab, title, mac=None, compare=None,
           memory_bytes=None, accuracy=None, note=None):
    """Print the standard cost report for one lab.

    mac           multiply-accumulate operations for ONE inference
    compare       comparisons for ONE inference
    memory_bytes  everything the circuit must hold on chip
    accuracy      test accuracy in percent
    """
    print(_LINE)
    print(" [Lab {}] {}".format(lab, title))
    print(_THIN)
    print("  {:<14}: {:>12}".format("MAC", _fmt(mac)))
    print("  {:<14}: {:>12}".format("Compare", _fmt(compare)))
    print("  {:<14}: {:>12}".format(
        "Memory", "-" if memory_bytes is None else "{:,} B".format(int(memory_bytes))))
    print("  {:<14}: {:>12}".format(
        "Accuracy", "-" if accuracy is None else "{:.1f} %".format(accuracy)))
    print(_THIN)
    print("  On {} ({})".format(BOARD_NAME, BOARD["part"]))
    if mac is not None:
        cycles = -(-int(mac) // BOARD["dsp"])
        print("  {:<14}: {:>12}   ({} DSP in parallel)".format(
            "MAC cycles", "{:,}".format(cycles), BOARD["dsp"]))
    if memory_bytes is not None:
        pct = 100.0 * int(memory_bytes) / BOARD_BRAM_BYTES
        print("  {:<14}: {:>11.1f} %   (of {} Kb block RAM)".format(
            "BRAM used", pct, BOARD["bram_kbits"]))
        if pct > 100.0:
            print("  {:<14}: {:>12}".format("VERDICT", "DOES NOT FIT"))
    if note:
        print(_THIN)
        print("  " + note)
    print(_LINE)


def _fmt(v):
    return "-" if v is None else "{:,}".format(int(v))


def report_table(rows, title="Cost comparison"):
    """Print many labs side by side. Each row is a dict with keys:
    name, group, mac, compare, memory_bytes, accuracy
    """
    print(_LINE)
    print(" {}  (target: {})".format(title, BOARD_NAME))
    print(_THIN)
    head = "{:<26}{:>10}{:>9}{:>11}{:>8}{:>8}"
    print(head.format("Algorithm", "MAC", "Compare", "Memory B", "BRAM%", "Acc%"))
    print(_THIN)
    for r in rows:
        pct = 100.0 * r["memory_bytes"] / BOARD_BRAM_BYTES
        print(head.format(
            r["name"][:26],
            "{:,}".format(int(r["mac"])),
            "{:,}".format(int(r["compare"])),
            "{:,}".format(int(r["memory_bytes"])),
            "{:.1f}".format(pct),
            "{:.1f}".format(r["accuracy"])))
    print(_LINE)


def board_summary():
    """Print the target board resources once, at the top of a lab."""
    print(_LINE)
    print(" Target board: {} ({})".format(BOARD_NAME, BOARD["part"]))
    print(_THIN)
    print("  Look-up tables: {:>10,}".format(BOARD["luts"]))
    print("  Slices        : {:>10,}".format(BOARD["slices"]))
    print("  Flip-flops    : {:>10,}".format(BOARD["flip_flops"]))
    print("  DSP slices    : {:>10,}   (1 MAC per slice per cycle)".format(BOARD["dsp"]))
    print("  Block RAM     : {:>10,} Kb  = {:,} bytes  ({:.1f} KB)".format(
        BOARD["bram_kbits"], BOARD_BRAM_BYTES, BOARD_BRAM_BYTES / 1024))
    print(_LINE)
