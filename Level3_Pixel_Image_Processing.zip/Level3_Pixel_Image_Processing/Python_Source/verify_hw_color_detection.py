import cv2
import numpy as np
import os

# ============================================================================
# 교재 출력용 파라미터 설정
# ============================================================================
IMAGE_FILES = ['color1.jpg', 'color2.jpg']
TUNE_EN = False  # True: 마진 적용(버튼 ON), False: 기본(버튼 OFF)
MARGIN_VAL = 8 if TUNE_EN else 0

def add_label(img, text):
    """이미지 하단에 교재용 흰색 레이블 배너를 추가합니다."""
    h, w = img.shape[:2]
    banner = np.ones((40, w, 3), dtype=np.uint8) * 255
    # 텍스트 중앙 정렬 계산
    text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
    text_x = (w - text_size[0]) // 2
    cv2.putText(banner, text, (text_x, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
    return cv2.vconcat([img, banner])

def to_bgr8(r5, g6, b5):
    """5-6-5 비트 데이터를 PC 모니터 출력을 위해 8-8-8 BGR로 확장합니다."""
    # 하드웨어 특성상 하위 비트를 0으로 채우는 것과 동일한 비트 쉬프트 적용
    r8 = (r5 << 3).astype(np.uint8)
    g8 = (g6 << 2).astype(np.uint8)
    b8 = (b5 << 3).astype(np.uint8)
    return cv2.merge([b8, g8, r8])

def process_image(image_path):
    print(f"[{image_path}] 비트 트루(Bit-True) 연산 및 이미지 추출 시작...")
    img = cv2.imread(image_path)
    if img is None:
        print(f"[Error] {image_path} 파일을 찾을 수 없습니다.")
        return

    # OpenCV BGR -> 채널 분리
    b_img, g_img, r_img = cv2.split(img)

    # ----------------------------------------------------------------------
    # 0. 하드웨어 RGB565 양자화 (Quantization)
    # ----------------------------------------------------------------------
    r = r_img >> 3  # 5-bit
    g = g_img >> 2  # 6-bit
    b = b_img >> 3  # 5-bit

    outputs = []
    mode_names = [
        "0. Original (RGB565)", "1. Grayscale", "2. Invert", "3. Brightness (+)",
        "4. Brightness (-)", "5. Threshold", "6. Red Detect (Tuned)", "7. Green Detect (Tuned)"
    ]

    # Mode 000: Original
    out_0 = to_bgr8(r, g, b)
    outputs.append(out_0)

    # Mode 001: Grayscale
    rgb_sum = r.astype(np.uint16) + (g >> 1).astype(np.uint16) + b.astype(np.uint16)
    gray6 = np.clip(rgb_sum // 3, 0, 63).astype(np.uint8)
    out_1 = to_bgr8(gray6 >> 1, gray6, gray6 >> 1)
    outputs.append(out_1)

    # Mode 010: Invert
    out_2 = to_bgr8(31 - r, 63 - g, 31 - b)
    outputs.append(out_2)

    # Mode 011: Brightness Plus
    bp_r = np.clip(r.astype(np.uint16) + 8, 0, 31).astype(np.uint8)
    bp_g = np.clip(g.astype(np.uint16) + 16, 0, 63).astype(np.uint8)
    bp_b = np.clip(b.astype(np.uint16) + 8, 0, 31).astype(np.uint8)
    out_3 = to_bgr8(bp_r, bp_g, bp_b)
    outputs.append(out_3)

    # Mode 100: Brightness Minus
    bm_r = np.clip(r.astype(np.int16) - 8, 0, 31).astype(np.uint8)
    bm_g = np.clip(g.astype(np.int16) - 16, 0, 63).astype(np.uint8)
    bm_b = np.clip(b.astype(np.int16) - 8, 0, 31).astype(np.uint8)
    out_4 = to_bgr8(bm_r, bm_g, bm_b)
    outputs.append(out_4)

    # Mode 101: Threshold (12/63)
    th_mask = gray6 > 12
    th_r = np.where(th_mask, 31, 0).astype(np.uint8)
    th_g = np.where(th_mask, 63, 0).astype(np.uint8)
    th_b = np.where(th_mask, 31, 0).astype(np.uint8)
    out_5 = to_bgr8(th_r, th_g, th_b)
    outputs.append(out_5)

    # Hardware Tuning Variables
    g5 = g >> 1
    
    # Mode 110: Red Detect
    g5_margin = np.clip(g5.astype(np.uint16) + MARGIN_VAL, 0, 31).astype(np.uint8)
    red_detect = (r > 4) & (r > g5_margin) & (r > b)
    out_6 = to_bgr8(np.where(red_detect, r, 0), np.where(red_detect, g, 0), np.where(red_detect, b, 0))
    outputs.append(out_6)

    # Mode 111: Green Detect
    r_margin = np.clip(r.astype(np.uint16) + MARGIN_VAL, 0, 31).astype(np.uint8)
    green_detect = (g5 > 4) & (g5 > r_margin) & (g5 > b)
    out_7 = to_bgr8(np.where(green_detect, r, 0), np.where(green_detect, g, 0), np.where(green_detect, b, 0))
    outputs.append(out_7)

    # ----------------------------------------------------------------------
    # 개별 파일 및 2x4 그리드 저장
    # ----------------------------------------------------------------------
    base_name = os.path.splitext(image_path)[0]
    labeled_outputs = []

    for i, (out_img, name) in enumerate(zip(outputs, mode_names)):
        # 1. 개별 파일 저장 (교재 단독 삽입용)
        cv2.imwrite(f"{base_name}_mode{i}.jpg", out_img)
        # 2. 그리드용 레이블 추가
        labeled_outputs.append(add_label(out_img, name))

    # 2x4 형태의 그리드 생성
    row1 = cv2.hconcat(labeled_outputs[:4])
    row2 = cv2.hconcat(labeled_outputs[4:])
    grid_img = cv2.vconcat([row1, row2])

    cv2.imwrite(f"{base_name}_grid_composite.jpg", grid_img)
    print(f" -> '{base_name}_grid_composite.jpg' 생성 완료 (총 8개 개별 파일 포함)\n")

# 실행
for file in IMAGE_FILES:
    process_image(file)

print("모든 교재용 시각 자료 추출이 완료되었습니다!")