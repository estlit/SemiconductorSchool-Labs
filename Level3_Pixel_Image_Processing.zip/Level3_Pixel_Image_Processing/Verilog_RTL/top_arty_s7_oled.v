/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_arty_s7_oled (Top-Level Controller)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : ROM -> Pixel Processor -> OLED FSM
 * Description  : Integrated Level 3 pipeline using LAB3 baseline.
 * sw[0]   : ROM Bank Select (Image 1 or 2)
 * sw[3:1] : Filter Mode Select
 * btn1    : Dynamic Margin Tuning Trigger
 * ====================================================================== */

`timescale 1ns / 1ps

module top_arty_s7_oled (
    input  wire       CLK100MHZ,   // 100 MHz onboard system clock
    input  wire       btn0,        // Active-high Reset
    input  wire       btn1,        // Active-high Tune Enable (Dynamic Margin)
    input  wire [3:0] sw,          // sw[0]: Image Select, sw[3:1]: Filter Mode

    // Pmod OLEDrgb (SSD1331) Physical Connections
    output wire       oled_mosi,
    output wire       oled_sck,
    output wire       oled_cs_n,
    output wire       oled_dc,
    output wire       oled_res,
    output wire       oled_vccen,
    output wire       oled_pmoden
);

    wire reset = btn0;
    
    // ----------------------------------------------------------------------
    // 1. Clock Generation (100 MHz -> 6.25 MHz)
    // ----------------------------------------------------------------------
    reg [3:0] div_cnt = 4'd0;
    
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    wire spi_clk = div_cnt[3];

    // ----------------------------------------------------------------------
    // 2. Internal Interconnect Signals
    // ----------------------------------------------------------------------
    wire        spi_start;
    wire        spi_busy;
    wire [7:0]  spi_data;
    wire [12:0] oled_pix_addr;
    
    wire [15:0] rom_data_raw;        // Original pixel from ROM
    wire [15:0] rom_data_processed;  // Filtered pixel from Processor

    // ----------------------------------------------------------------------
    // 3. SPI Master
    // ----------------------------------------------------------------------
    spi_master u_spi (
        .clk     (spi_clk), 
        .reset   (reset), 
        .start   (spi_start),
        .data_in (spi_data), 
        .busy    (spi_busy),
        .sclk    (oled_sck), 
        .mosi    (oled_mosi), 
        .cs_n    (oled_cs_n)
    );

    // ----------------------------------------------------------------------
    // 4. Synchronous ROM (BRAM) - sw[0] used for Bank Switching
    // ----------------------------------------------------------------------
    oled_combined_rom u_rom (
        .clk  (spi_clk), 
        .addr ({sw[0], oled_pix_addr}), 
        .data (rom_data_raw)
    );

    // ----------------------------------------------------------------------
    // 5. Pixel Processing Core (Combinational Filtering)
    // ----------------------------------------------------------------------
    pixel_proc_core u_pixel_proc (
        .tune_en   (btn1),              // Press to apply dynamic margin
        .mode      (sw[3:1]),           // Select filter mode
        .pixel_in  (rom_data_raw),      // Raw pixel from BRAM
        .pixel_out (rom_data_processed) // Processed pixel to OLED
    );

    // ----------------------------------------------------------------------
    // 6. OLED Display Controller (FSM)
    // ----------------------------------------------------------------------
    oled_test #(
        .H_RES(96), 
        .V_RES(64)
    ) u_oled (
        .clk         (spi_clk), 
        .reset       (reset),
        .spi_start   (spi_start), 
        .spi_data    (spi_data), 
        .spi_busy    (spi_busy),
        .oled_dc     (oled_dc), 
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen), 
        .oled_pmoden (oled_pmoden),
        .rom_addr    (oled_pix_addr), 
        .rom_data    (rom_data_processed) // Feed the filtered data
    );

endmodule