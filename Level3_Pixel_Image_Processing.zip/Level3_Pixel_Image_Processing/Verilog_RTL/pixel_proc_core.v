/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : pixel_proc_core (Level 3: Pixel Image Processing)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : 1D Combinational Pixel Pipeline
 * Description  : Interactive Margin Tuning via Push Button (tune_en).
 * Demonstrates real-time hardware color boundary adjustment.
 * ====================================================================== */

`timescale 1ns / 1ps

module pixel_proc_core (
    input  wire        tune_en,   // BTN1: Hardware Tuning Enable (Dynamic Margin)
    input  wire [2:0]  mode,      // SW[3:1] : 8 Filter Modes Select
    input  wire [15:0] pixel_in,  // Original 16-bit RGB565 pixel from BRAM
    output reg  [15:0] pixel_out  // Processed 16-bit RGB565 pixel to OLED FSM
);

    // ----------------------------------------------------------------------
    // 0. RGB Channel Extraction (RGB565 format)
    // ----------------------------------------------------------------------
    wire [4:0] r = pixel_in[15:11]; // Red: 5 bits
    wire [5:0] g = pixel_in[10:5];  // Green: 6 bits
    wire [4:0] b = pixel_in[4:0];   // Blue: 5 bits

    // ----------------------------------------------------------------------
    // 1~5. Default Filters (Grayscale, Invert, Brightness, Threshold)
    // ----------------------------------------------------------------------
    wire [6:0] rgb_sum = {2'b00, r} + {1'b0, g} + {2'b00, b};
    wire [5:0] gray6   = rgb_sum / 3; 
    wire [15:0] gray_px = {gray6[5:1], gray6, gray6[5:1]};

    wire [15:0] inv_px = ~pixel_in;

    wire [5:0] r_add = {1'b0, r} + 6'd8;
    wire [6:0] g_add = {1'b0, g} + 7'd16;
    wire [5:0] b_add = {1'b0, b} + 6'd8;
    wire [4:0] r_bp = (r_add > 6'd31) ? 5'd31 : r_add[4:0];
    wire [5:0] g_bp = (g_add > 7'd63) ? 6'd63 : g_add[5:0];
    wire [4:0] b_bp = (b_add > 6'd31) ? 5'd31 : b_add[4:0];
    wire [15:0] bp_px = {r_bp, g_bp, b_bp};

    wire [4:0] r_bm = (r < 5'd8)  ? 5'd0 : (r - 5'd8);
    wire [5:0] g_bm = (g < 6'd16) ? 6'd0 : (g - 6'd16);
    wire [4:0] b_bm = (b < 5'd8)  ? 5'd0 : (b - 5'd8);
    wire [15:0] bm_px = {r_bm, g_bm, b_bm};

    wire [15:0] th_px = (gray6 > 6'd12) ? 16'hFFFF : 16'h0000;

    // ----------------------------------------------------------------------
    // 6 & 7. Color Detection with Interactive Hardware Tuning
    // ----------------------------------------------------------------------
    wire [4:0] g5 = g[5:1]; // Green scale alignment (6-bit -> 5-bit)

    // Dynamic Margin Calculation based on 'tune_en' (BTN1)
    // If tune_en is HIGH, inject a margin of 8 to strengthen the boundary.
    wire [4:0] margin_val = tune_en ? 5'd8 : 5'd0;
    
    // Prevent 5-bit overflow using a 6-bit temporary adder
    wire [5:0] g5_with_margin = {1'b0, g5} + {1'b0, margin_val};
    wire [4:0] g5_tuned = (g5_with_margin > 6'd31) ? 5'd31 : g5_with_margin[4:0];

    // Apply strictly tuned condition for Red detection
    wire red_detect   = (r > 5'd4) && (r > g5_tuned) && (r > b);
    
    // Apply symmetrical tuning for Green detection to reject yellow/cyan overlap
    wire [5:0] r_with_margin = {1'b0, r} + {1'b0, margin_val};
    wire [4:0] r_tuned = (r_with_margin > 6'd31) ? 5'd31 : r_with_margin[4:0];
    
    wire green_detect = (g5 > 5'd4) && (g5 > r_tuned) && (g5 > b);

    // Mux outputs for the detected pixels
    wire [15:0] r_px = red_detect   ? pixel_in : 16'h0000;
    wire [15:0] g_px = green_detect ? pixel_in : 16'h0000;

    // ----------------------------------------------------------------------
    // Output Multiplexer
    // ----------------------------------------------------------------------
    always @(*) begin
        case (mode)
            3'b000: pixel_out = pixel_in;  
            3'b001: pixel_out = gray_px;   
            3'b010: pixel_out = inv_px;    
            3'b011: pixel_out = bp_px;     
            3'b100: pixel_out = bm_px;     
            3'b101: pixel_out = th_px;     
            3'b110: pixel_out = r_px;      // Red Detection (Tunable)
            3'b111: pixel_out = g_px;      // Green Detection (Tunable)
            default: pixel_out = pixel_in; 
        endcase
    end

endmodule