/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_arty_s7_oled (System-Level Testbench)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Simulator    : Vivado XSIM
 * Description  : System-level verification environment for the top-level 
 * OLED controller (Level 3 Upgraded). Simulates clock generation, 
 * asynchronous hardware reset, ROM bank switching, and real-time 
 * pixel processing filter modes via 4-bit SW input.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top_arty_s7_oled;

    // ----------------------------------------------------------------------
    // Signal Declarations
    // ----------------------------------------------------------------------
    // Inputs (Registers for driving stimulus)
    reg CLK100MHZ;
    reg btn0;
    reg [3:0] sw; // [UPDATED] sw[0]: Image Select, sw[3:1]: Filter Mode

    // Outputs (Wires for observing Unit Under Test - UUT)
    wire oled_mosi;
    wire oled_sck;
    wire oled_cs_n;
    wire oled_dc;
    wire oled_res;
    wire oled_vccen;
    wire oled_pmoden;

    // ----------------------------------------------------------------------
    // Unit Under Test (UUT) Instantiation
    // ----------------------------------------------------------------------
    top_arty_s7_oled uut (
        .CLK100MHZ  (CLK100MHZ),
        .btn0       (btn0),
        .sw         (sw), // [UPDATED] Connected to 4-bit switch array
        .oled_mosi  (oled_mosi),
        .oled_sck   (oled_sck),
        .oled_cs_n  (oled_cs_n),
        .oled_dc    (oled_dc),
        .oled_res   (oled_res),
        .oled_vccen (oled_vccen),
        .oled_pmoden(oled_pmoden)
    );

    // ----------------------------------------------------------------------
    // 1. System Clock Generation
    // ----------------------------------------------------------------------
    // Generates a 100 MHz clock signal (10 ns total period: 5 ns HIGH, 5 ns LOW)
    initial begin
        CLK100MHZ = 1'b0;
        forever #5 CLK100MHZ = ~CLK100MHZ; 
    end

    // ----------------------------------------------------------------------
    // 2. Main Stimulus & Verification Sequence
    // ----------------------------------------------------------------------
    initial begin
        // Initialize Default States
        btn0 = 1'b0;
        sw   = 4'b0000; // Default: ROM Bank 0 (Image 1), Filter Mode 0 (Original)

        // Wait 100 ns for global reset routing to settle
        #100;
        
        // Assert Active-High Asynchronous Reset
        $display("[%0t] [TESTBENCH] Asserting System Reset...", $time);
        btn0 = 1'b1;
        #200;
        btn0 = 1'b0;
        $display("[%0t] [TESTBENCH] Reset Released. Initiating OLED Power-on Sequence...", $time);

        // =========================================================================
        // [CRITICAL SIMULATION NOTE]
        // The FSM within 'oled_test.v' utilizes a LONG_WAIT_CNT (2,000,000 clocks 
        // at a 6.25 MHz domain) to ensure physical OLED VCC stabilization. 
        // This process requires approximately 320 ms of real-world time.
        // Therefore, the simulation must advance at least 350 ms before 
        // valid SPI traffic can be observed on the waveforms.
        // =========================================================================
        
        // Advance simulation time by 350 milliseconds (350,000,000 ns)
        #350_000_000;
        $display("[%0t] [TESTBENCH] Power-on Initialization complete. Rendering Image 1 (Original).", $time);

        // Advance 20 milliseconds to observe one full frame rendering
        #20_000_000;

        // [TEST 1] Toggle Image Select
        $display("[%0t] [TESTBENCH] Toggling SW[0] to 1 (Switching to ROM Bank 1: Image 2)...", $time);
        sw[0] = 1'b1; 
        #20_000_000;
        
        // [TEST 2] Apply Grayscale Filter (Mode 1)
        $display("[%0t] [TESTBENCH] Applying Grayscale Filter (SW[3:1] = 001)...", $time);
        sw[3:1] = 3'b001;
        #20_000_000;

        // [TEST 3] Apply Invert Filter (Mode 2)
        $display("[%0t] [TESTBENCH] Applying Color Invert Filter (SW[3:1] = 010)...", $time);
        sw[3:1] = 3'b010;
        #20_000_000;

        // [TEST 4] Apply Brightness + Filter (Mode 3)
        $display("[%0t] [TESTBENCH] Applying Brightness Increase Filter (SW[3:1] = 011)...", $time);
        sw[3:1] = 3'b011;
        #20_000_000;
        
        // Terminate Simulation gracefully
        $display("[%0t] [TESTBENCH] Level 3 Verification Sequence Finished. Terminating Simulation.", $time);
        $finish;
    end

endmodule