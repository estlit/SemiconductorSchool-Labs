/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_pixel_proc_core (Testbench)
 * Target Board : Simulation Only
 * Description  : Testbench for the 1D Pixel Processing Core.
 * Applies a fixed RGB565 pixel and sweeps through all 8 operation 
 * modes (0 to 7) to verify combinational arithmetic logic.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_pixel_proc_core();

    // ------------------------------------------------------------------
    // 1. Testbench Signals
    // ------------------------------------------------------------------
    reg  [2:0]  mode;
    reg  [15:0] pixel_in;
    wire [15:0] pixel_out;

    // ------------------------------------------------------------------
    // 2. DUT (Device Under Test) Instantiation
    // ------------------------------------------------------------------
    pixel_proc_core uut (
        .mode      (mode),
        .pixel_in  (pixel_in),
        .pixel_out (pixel_out)
    );

    // ------------------------------------------------------------------
    // 3. Helper Wires for Easy Waveform Viewing
    // ------------------------------------------------------------------
    // Extract RGB channels from the output to easily verify the math
    wire [4:0] out_r = pixel_out[15:11];
    wire [5:0] out_g = pixel_out[10:5];
    wire [4:0] out_b = pixel_out[4:0];

    // ------------------------------------------------------------------
    // 4. Stimulus Generation and Verification
    // ------------------------------------------------------------------
    initial begin
        // Initialize Inputs
        mode = 3'd0;
        
        // Define a test pixel. Let's use a distinct color:
        // R = 10, G = 30, B = 20
        // RGB565: {5'd10, 6'd30, 5'd20} -> HEX: 53D4
        pixel_in = {5'd10, 6'd30, 5'd20}; 

        $display("==================================================");
        $display(" [TB] pixel_proc_core Verification Started");
        $display("==================================================");
        $display(" Input Pixel : R=%0d, G=%0d, B=%0d (HEX: %04X)", 10, 30, 20, pixel_in);
        $display("--------------------------------------------------");

        // Mode 0: Original
        mode = 3'd0; #10;
        $display(" Mode 0 (Orig)  : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 1: Grayscale 
        // Expected: (10 + 30 + 20) / 3 = 20. 
        // G=20, R=20/2=10, B=20/2=10
        mode = 3'd1; #10;
        $display(" Mode 1 (Gray)  : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 2: Invert
        // Expected: R=31-10=21, G=63-30=33, B=31-20=11
        mode = 3'd2; #10;
        $display(" Mode 2 (Invert): R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 3: Brightness + (Saturation Test)
        // Expected: R=10+8=18, G=30+16=46, B=20+8=28
        mode = 3'd3; #10;
        $display(" Mode 3 (Bri +) : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 4: Brightness - (Underflow Test)
        // Expected: R=10-8=2, G=30-16=14, B=20-8=12
        mode = 3'd4; #10;
        $display(" Mode 4 (Bri -) : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 5: Threshold
        // Expected: Gray value is 20 (<=31), so it should output Black (0,0,0)
        mode = 3'd5; #10;
        $display(" Mode 5 (Thres) : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 6: Red Extraction
        // Expected: R=10, G=0, B=0
        mode = 3'd6; #10;
        $display(" Mode 6 (Red)   : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        // Mode 7: Green Extraction
        // Expected: R=0, G=30, B=0
        mode = 3'd7; #10;
        $display(" Mode 7 (Green) : R=%0d, G=%0d, B=%0d (HEX: %04X)", out_r, out_g, out_b, pixel_out);

        $display("==================================================");
        $display(" [TB] Verification Finished");
        $display("==================================================");
        
        $finish;
    end

endmodule