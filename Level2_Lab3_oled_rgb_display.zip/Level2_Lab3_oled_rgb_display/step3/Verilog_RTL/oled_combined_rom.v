/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_combined_rom (Synchronous BRAM)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Synchronous Read (1-Clock Latency)
 * Description  : FPGA Block RAM (BRAM) inference module for storing 
 * multiple RGB565 (16-bit) image patterns. 
 *
 * Target Specifications & Memory Mapping:
 * - Resolution : 96 x 64 pixels (RGB565)
 * - Depth      : 16,384 words (14-bit address space)
 * - Bank Select: addr[13] linked to hardware SW0
 * - Pixel Index: addr[12:0] managed by OLED controller
 *
 * Address Space Allocation:
 * - Bank 0 (0x0000 - 0x1FFF): Image Pattern 1 (e.g., Dog Photo 1)
 * - Bank 1 (0x2000 - 0x3FFF): Image Pattern 2 (e.g., Dog Photo 2)
 * ====================================================================== */

`timescale 1ns / 1ps

module oled_combined_rom (
    // System Interfaces
    input  wire        clk,   // Synchronous system clock (SPI clock domain)
    
    // Memory Interfaces
    input  wire [13:0] addr,  // 14-bit concatenated address bus {sw0, oled_pix_addr}
    output reg  [15:0] data   // 16-bit registered RGB565 pixel data output
);

    // ----------------------------------------------------------------------
    // 1. Memory Array Declaration
    // ----------------------------------------------------------------------
    // Allocates 16,384 words of 16-bit data.
    // Accommodates two symmetrical 8192-word boundary-aligned memory banks.
    reg [15:0] memory [0:16383];

    // ----------------------------------------------------------------------
    // 2. ROM Initialization (Memory Loading)
    // ----------------------------------------------------------------------
    // Initializes the memory array by loading the pre-computed hexadecimal 
    // data file generated via Python preprocessing. 
    // [CRITICAL WARNING] Absolute path is strictly recommended to prevent 
    // Vivado synthesis errors regarding file locations.
    initial begin
        $readmemh("dog_rom.mem", memory); 
    end

    // ----------------------------------------------------------------------
    // 3. Synchronous Read Logic (BRAM Inference)
    // ----------------------------------------------------------------------
    // Synchronous read block enforcing hardware Block RAM (BRAM) inference.
    // This design introduces exactly a 1-clock cycle read latency to the 
    // data path, significantly minimizing logic utilization (LUTs) and 
    // improving timing slack across the FPGA fabric.
    always @(posedge clk) begin
        data <= memory[addr];
    end

endmodule