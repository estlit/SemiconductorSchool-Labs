/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_arty_s7_oled (Top-Level Controller)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Synchronous ROM (BRAM) Integration with Bank Switching
 * Description  : Top-level wrapper for the SSD1331 OLED controller.
 * Integrates clock generation, SPI master, synchronous block RAM,
 * and the main OLED FSM. Includes SW0 for hardware-level image toggling.
 * ====================================================================== */

module top_arty_s7_oled (
    // System Interfaces
    input  wire CLK100MHZ,   // 100 MHz onboard system clock
    input  wire btn0,        // Active-high asynchronous reset
    input  wire sw0,         // ROM Bank Select (0: Bank 0, 1: Bank 1)

    // Pmod OLEDrgb (SSD1331) Physical Connections
    output wire oled_mosi,
    output wire oled_sck,
    output wire oled_cs_n,
    output wire oled_dc,
    output wire oled_res,
    output wire oled_vccen,
    output wire oled_pmoden
);

    wire reset = btn0;
    
    // ----------------------------------------------------------------------
    // 1. Clock Generation (100 MHz -> 6.25 MHz)
    // ----------------------------------------------------------------------
    // A 4-bit counter divides the 100 MHz clock by 16 to generate a 
    // 6.25 MHz clock domain for SPI and OLED FSM operations.
    reg [3:0] div_cnt = 4'd0;
    
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    
    wire spi_clk = div_cnt[3];

    // ----------------------------------------------------------------------
    // 2. Internal Interconnect Signals
    // ----------------------------------------------------------------------
    wire        spi_start;
    wire        spi_busy;
    wire [7:0]  spi_data;
    wire [12:0] oled_pix_addr; // 13-bit Pixel address (from OLED controller)
    wire [15:0] rom_data;      // 16-bit Synchronous data (from BRAM)

    // ----------------------------------------------------------------------
    // 3. SPI Master Instantiation
    // ----------------------------------------------------------------------
    spi_master u_spi (
        .clk     (spi_clk), 
        .reset   (reset), 
        .start   (spi_start),
        .data_in (spi_data), 
        .busy    (spi_busy),
        .sclk    (oled_sck), 
        .mosi    (oled_mosi), 
        .cs_n    (oled_cs_n)
    );
    
    // ----------------------------------------------------------------------
    // 4. Synchronous ROM (BRAM) Instantiation
    // ----------------------------------------------------------------------
    // Memory is mapped with 'clk' to strictly infer FPGA Block RAM (BRAM).
    // The 14-bit address is constructed by concatenating 'sw0' (MSB) 
    // and 'oled_pix_addr' (LSBs) for instant hardware bank switching.
    oled_combined_rom u_rom (
        .clk  (spi_clk), 
        .addr ({sw0, oled_pix_addr}), 
        .data (rom_data)
    );

    // ----------------------------------------------------------------------
    // 5. OLED Display Controller (FSM) Instantiation
    // ----------------------------------------------------------------------
    // State machine configured for a 96x64 display. Accounts for the 
    // 1-clock read latency introduced by the synchronous BRAM.
    oled_test #(
        .H_RES(96), 
        .V_RES(64)
    ) u_oled (
        .clk         (spi_clk), 
        .reset       (reset),
        .spi_start   (spi_start), 
        .spi_data    (spi_data), 
        .spi_busy    (spi_busy),
        .oled_dc     (oled_dc), 
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen), 
        .oled_pmoden (oled_pmoden),
        .rom_addr    (oled_pix_addr), 
        .rom_data    (rom_data)
    );
    
endmodule