"""
====================================================================
[Deterministic System ROM] OLED 14-bit (16384) 통합 메모리 변환기
====================================================================
- 목적: 14비트 주소 공간(16,384 워드)을 100% 완벽하게 채우는 메모리 파일 생성
- 특징: Vivado의 자동 채움 기능에 의존하지 않고, Python에서 직접 
        더미(Dummy) 공간을 '0000'으로 패딩(Padding)하여 
        비트 수준의 정확도(Bit-Accurate)를 보장하는 결정론적 방식.
- 요구사항: pip install Pillow
====================================================================
"""
from PIL import Image

def make_perfect_dual_rom(image_path1, image_path2, output_mem_name):
    
    # 1. 중앙 크롭(Center Crop) 알고리즘 (비율 유지)
    def process_image(img_path):
        img = Image.open(img_path).convert('RGB')
        orig_w, orig_h = img.size
        target_aspect = 96.0 / 64.0
        orig_aspect = orig_w / orig_h
        
        if orig_aspect > target_aspect:
            new_w = int(orig_h * target_aspect)
            left = (orig_w - new_w) // 2
            crop_box = (left, 0, left + new_w, orig_h)
        else:
            new_h = int(orig_w / target_aspect)
            top = (orig_h - new_h) // 2
            crop_box = (0, top, orig_w, top + new_h)
            
        img_cropped = img.crop(crop_box).resize((96, 64))
        return img_cropped.load()

    try:
        pixels1 = process_image(image_path1)
        pixels2 = process_image(image_path2)

        # 2. 16,384 라인을 기록할 .mem 파일 생성
        with open(output_mem_name, "w") as f:
            
            line_count = 0 # 검증을 위한 라인 카운터
            
            # --- [Bank 0] 첫 번째 사진 데이터 기록 (6,144줄) ---
            for y in range(64):
                for x in range(96):
                    r, g, b = pixels1[x, y]
                    r5 = (r >> 3) & 0x1F
                    g6 = (g >> 2) & 0x3F
                    b5 = (b >> 3) & 0x1F
                    rgb565 = (r5 << 11) | (g6 << 5) | b5
                    f.write(f"{rgb565:04X}\n")
                    line_count += 1
            
            # --- [Padding 1] Bank 1 주소(8192)까지 빈 공간 채우기 (2,048줄) ---
            while line_count < 8192:
                f.write("0000\n") # 검은색 픽셀(Dummy)로 채움
                line_count += 1

            # --- [Bank 1] 두 번째 사진 데이터 기록 (6,144줄) ---
            for y in range(64):
                for x in range(96):
                    r, g, b = pixels2[x, y]
                    r5 = (r >> 3) & 0x1F
                    g6 = (g >> 2) & 0x3F
                    b5 = (b >> 3) & 0x1F
                    rgb565 = (r5 << 11) | (g6 << 5) | b5
                    f.write(f"{rgb565:04X}\n")
                    line_count += 1

            # --- [Padding 2] 14-bit 최대 주소(16384)까지 빈 공간 채우기 (2,048줄) ---
            while line_count < 16384:
                f.write("0000\n")
                line_count += 1

        print(f"✅ 완벽한 메모리 덤프 완료: [{output_mem_name}]")
        print(f"📊 총 생성된 데이터 라인 수: {line_count}줄 (14-bit 주소 공간과 100% 일치)")
        
    except Exception as e:
        print(f"❌ 오류 발생: {e}")

# ---------------------------------------------------------
# 실행 영역: 첫 번째 사진, 두 번째 사진, 생성될 롬 파일 이름
make_perfect_dual_rom("my_dog1.jpg", "my_dog2.jpg", "dog_rom.mem")