`timescale 1ns / 1ps
/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Top-Level Core Architecture (System Integration)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * ====================================================================== */

module top_arty_s7_oled (
    // System Inputs
    input  wire CLK100MHZ,   // 100 MHz onboard oscillator
    input  wire btn0,        // BTN0: Active-high global reset
    input  wire sw0,         // SW0: 0 = Green Square, 1 = Upright Blue A

    // Pmod OLEDrgb J1 Connections (JA Header)
    output wire oled_mosi,   // SPI Master Out Slave In
    output wire oled_sck,    // SPI Serial Clock
    output wire oled_cs_n,   // SPI Chip Select (Active-low)
    output wire oled_dc,     // Data/Command Control (0: Command, 1: Data)
    output wire oled_res,    // Hardware Reset (Active-low)
    output wire oled_vccen,  // Power Enable for VCC
    output wire oled_pmoden  // Power Enable for V_PMOD
);

    // Reset signal assignment
    wire reset = btn0;
    
    // =================================================================
    // [Clock Divider] 100 MHz -> ~6.25 MHz (100MHz / 16)
    // =================================================================
    reg [3:0] div_cnt = 4'd0;
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset)
            div_cnt <= 4'd0;
        else
            div_cnt <= div_cnt + 1'b1;
    end

    // Use MSB of the counter as the SPI clock domain
    wire spi_clk = div_cnt[3];

    // =================================================================
    // [Internal Interconnects] Signal wires for SPI and ROM interfaces
    // =================================================================
    wire        spi_start;
    wire [7:0]  spi_data;
    wire        spi_busy;

    wire [12:0] oled_rom_addr;
    wire [15:0] oled_rom_data_sq; // Data bus for Green Square ROM
    wire [15:0] oled_rom_data_A;  // Data bus for Upright Blue A ROM
    wire [15:0] oled_rom_data;    // Multiplexed data for OLED Controller

    // =================================================================
    // [SPI Master] Handles 8-bit serial transmission in Mode 3
    // =================================================================
    spi_master u_spi (
        .clk    (spi_clk),
        .reset  (reset),
        .start  (spi_start),
        .data_in(spi_data),
        .busy   (spi_busy),
        .sclk   (oled_sck),
        .mosi   (oled_mosi),
        .cs_n   (oled_cs_n)
    );
    
    // =================================================================
    // [ROM Instances] Image data storage blocks
    // =================================================================
    
    // 1. Green Square ROM (32x32 square at center)
    oled_image_rom_sq u_rom_sq (
        .addr (oled_rom_addr),
        .data (oled_rom_data_sq)
    );
    
    // 2. Upright Blue A ROM (Character 'A' orientation)
    oled_image_rom_A u_rom_A (
        .addr (oled_rom_addr),
        .data (oled_rom_data_A)
    );
    
    // =================================================================
    // [Hardware Multiplexer] Select image output based on SW0 state
    // =================================================================
    assign oled_rom_data = sw0 ? oled_rom_data_A : oled_rom_data_sq;

    // =================================================================
    // [OLED Controller] Configures SSD1331 registers and manages flow
    // =================================================================
    oled_test #(
        .H_RES(96), // Horizontal resolution set to 96
        .V_RES(64)  // Vertical resolution set to 64
    ) u_oled (
        .clk        (spi_clk),
        .reset      (reset),
        .spi_start  (spi_start),
        .spi_data   (spi_data),
        .spi_busy   (spi_busy),
        
        .oled_dc    (oled_dc),
        .oled_res   (oled_res),
        .oled_vccen (oled_vccen),
        .oled_pmoden(oled_pmoden),
        
        .rom_addr   (oled_rom_addr),
        .rom_data   (oled_rom_data) // Connected to MUX output
    );
    
endmodule