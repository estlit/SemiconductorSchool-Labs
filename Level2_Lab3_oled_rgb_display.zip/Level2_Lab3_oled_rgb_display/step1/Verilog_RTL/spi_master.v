`timescale 1ns / 1ps
/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : 8-bit SPI Master Interface (Mode 3)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * ====================================================================== */

// 8-bit SPI master, Mode 3 (CPOL=1, CPHA=1), MSB first
module spi_master (
    input  wire clk,        // SPI clock domain
    input  wire reset,      // Active-high reset
    input  wire start,      // 1-cycle transmission trigger pulse
    input  wire [7:0] data_in,
    output reg  busy,       // High when transmission is in progress
    output reg  sclk,       // SPI Serial Clock
    output reg  mosi,       // SPI Master Out Slave In
    output reg  cs_n        // SPI Chip Select (Active-low)
);

    // Internal registers
    reg [3:0] bit_cnt;      // Counter for remaining bits
    reg [7:0] shreg;        // Shift register for data payload

    // State Machine Encoding
    localparam IDLE = 2'd0,
               LOAD = 2'd1,
               SEND = 2'd2,
               DONE = 2'd3;

    reg [1:0] state;
    reg       phase;        // 0: Falling edge phase, 1: Rising edge phase

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state   <= IDLE;
            bit_cnt <= 4'd0;
            shreg   <= 8'd0;
            busy    <= 1'b0;
            sclk    <= 1'b1;   // SPI Mode 3: SCLK is high in idle state
            mosi    <= 1'b0;
            cs_n    <= 1'b1;   // Deselect slave (Active-low)
            phase   <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    if (start) begin
                        busy  <= 1'b1;
                        state <= LOAD;
                    end
                end

                LOAD: begin
                    shreg   <= data_in;
                    bit_cnt <= 4'd7;   // 8-bit transmission (7 down to 0)
                    cs_n    <= 1'b0;   // Select OLED controller
                    sclk    <= 1'b1;   // Maintain high idle state
                    phase   <= 1'b0;   // Initialize to falling edge phase
                    state   <= SEND;
                end

                SEND: begin
                    if (phase == 1'b0) begin
                        // Falling Edge: SCLK transitions 1 -> 0, update MOSI line
                        sclk  <= 1'b0;
                        mosi  <= shreg[7]; // Transmit MSB first
                        phase <= 1'b1;     // Transition to rising edge phase
                    end else begin
                        // Rising Edge: SCLK transitions 0 -> 1, Slave (SSD1331) samples data here
                        sclk  <= 1'b1;
                        
                        // Check if payload transmission is complete
                        if (bit_cnt == 0) begin
                            state <= DONE;
                        end else begin
                            bit_cnt <= bit_cnt - 1'b1;      // Decrement bit counter
                            shreg   <= {shreg[6:0], 1'b0};  // Shift register left
                            phase   <= 1'b0;                // Return to falling edge phase for next bit
                        end
                    end
                end

                DONE: begin
                    sclk  <= 1'b1;  // Return SCLK to idle high state
                    cs_n  <= 1'b1;  // Deselect slave
                    busy  <= 1'b0;  // Clear busy flag
                    state <= IDLE;  // Return to IDLE state
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule