`timescale 1ns / 1ps
/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Static Image ROM Configurations for OLED Display
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Description  : Contains fixed image data mapped to RGB565 format.
 * Aligned to the physical 'Pmod OLEDrgb' label orientation.
 * ====================================================================== */

// ======================================================================
// [ROM Module 1] Test Pattern: Red Border, Yellow Background, Green Square
// ======================================================================
module oled_image_rom_sq (
    input  wire [12:0] addr, // 13-bit address bus for 6144 pixels (96x64)
    output wire [15:0] data  // 16-bit RGB565 data output
);
    
    // Resolution Parameters
    localparam H_RES = 96;
    localparam V_RES = 64;
    
    // RGB565 Color Space Definitions
    localparam YELLOW = 16'hFFE0; // R(31), G(63), B(0)
    localparam RED    = 16'hF800; // R(31), G(0),  B(0)
    localparam GREEN  = 16'h07E0; // R(0),  G(63), B(0)

    // Memory Array Initialization
    reg [15:0] memory [0:6143]; 
    integer i, row, col;
    
    initial begin
        // 1. Initialize memory array with yellow background
        for (i = 0; i < (H_RES * V_RES); i = i + 1) begin
            memory[i] = YELLOW;
        end

        // 2. Render boundary border in red (Top, Bottom, Left, Right edges)
        for (row = 0; row < V_RES; row = row + 1) begin
            for (col = 0; col < H_RES; col = col + 1) begin
                // Identify boundary coordinates
                if (row == 0 || row == (V_RES - 1) || col == 0 || col == (H_RES - 1)) begin
                    i = row * H_RES + col;
                    memory[i] = RED;
                end
            end
        end

        // 3. Render central 32x32 green square geometry
        // Vertical boundary: [16, 47], Horizontal boundary: [32, 63]
        for (row = 16; row < 48; row = row + 1) begin
            for (col = 32; col < 64; col = col + 1) begin
                i = row * H_RES + col;
                memory[i] = GREEN;
            end
        end
    end

    // Asynchronous memory read access
    assign data = memory[addr];
endmodule

// ======================================================================
// [ROM Module 2] Character Pattern: 'A' (Standard Upright Orientation)
// ======================================================================
module oled_image_rom_A ( 
    input  wire [12:0] addr, // 13-bit address bus for 6144 pixels (96x64)
    output wire [15:0] data  // 16-bit RGB565 data output
);
    
    // Resolution Parameters
    localparam H_RES = 96;
    localparam V_RES = 64;
    localparam TOTAL_PIXELS = H_RES * V_RES; 
    
    // RGB565 Color Space Definitions
    localparam BLACK = 16'h0000; // Background color
    localparam BLUE  = 16'h001F; // Primary character color
    localparam RED   = 16'hF800; // Diagnostic origin indicator
    
    // Memory Array Initialization
    reg [15:0] memory [0:6143]; 
    integer i, row, col;
    
    initial begin
        // 1. Initialize memory array with black background
        for (i = 0; i < TOTAL_PIXELS; i = i + 1) begin
            memory[i] = BLACK;
        end

        // 2. Diagnostic Pixel: Render red pixel at geometric origin (0,0)
        memory[0 * H_RES + 0] = RED; 

        // 3. Render uppercase 'A' character architecture
        // Character bounds - Height: [15, 49], Width: [35, 59]
        
        // Render Left Vertical Segment (Leg)
        for (row = 15; row < 50; row = row + 1) begin
            for (col = 35; col < 40; col = col + 1) begin 
                i = row * H_RES + col;
                memory[i] = BLUE;
            end
        end

        // Render Right Vertical Segment (Leg)
        for (row = 15; row < 50; row = row + 1) begin
            for (col = 55; col < 60; col = col + 1) begin 
                 i = row * H_RES + col;
                 memory[i] = BLUE;
            end
        end

        // Render Superior Horizontal Connector (Top Crossbar)
        for (row = 15; row < 20; row = row + 1) begin 
            for (col = 40; col < 55; col = col + 1) begin 
                i = row * H_RES + col;
                memory[i] = BLUE;
            end
        end

        // Render Medial Horizontal Connector (Middle Crossbar)
        for (row = 32; row < 37; row = row + 1) begin 
            for (col = 40; col < 55; col = col + 1) begin 
                i = row * H_RES + col;
                memory[i] = BLUE;
            end
        end
    end

    // Asynchronous memory read access
    assign data = memory[addr];
endmodule