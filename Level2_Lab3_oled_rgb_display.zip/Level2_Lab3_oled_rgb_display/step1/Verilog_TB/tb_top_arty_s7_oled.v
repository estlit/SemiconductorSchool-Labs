`timescale 1ns / 1ps
/* ======================================================================
 * Semiconductor School | System-on-Chip (SoC) Verification Lab
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_arty_s7_oled
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7 FPGA)
 * Description  : System-Level Integration Testbench for OLED Controller.
 * Features a Non-Intrusive SPI Spy Protocol Analyzer and 
 * an Internal ROM VRAM-Mapping ASCII Art Visualizer.
 * ====================================================================== */

module tb_top_arty_s7_oled;

    // -----------------------------------------------------------------
    // System Interface Signals (Stimulus & Monitor)
    // -----------------------------------------------------------------
    reg  CLK100MHZ;     // Master Clock Source (100 MHz, Period: 10 ns)
    reg  btn0;          // Active-High System Synchronous Reset
    reg  sw0;           // Display Content Select Switch (0: Pattern, 1: Character)

    wire oled_mosi;     // SPI Master Output Slave Input
    wire oled_sck;      // SPI Serial Clock
    wire oled_cs_n;     // SPI Chip Select (Active-Low)
    wire oled_dc;       // OLED Data/Command Control (0: Command, 1: Data)
    wire oled_res;      // OLED Hardware Reset Signal
    wire oled_vccen;    // OLED Panel Charge Pump Power Enable
    wire oled_pmoden;   // OLED VCC Power Supply Enable

    // -----------------------------------------------------------------
    // Device Under Test (DUT) Instance
    // -----------------------------------------------------------------
    top_arty_s7_oled uut (
        .CLK100MHZ  (CLK100MHZ),
        .btn0       (btn0),
        .sw0        (sw0),
        .oled_mosi  (oled_mosi),
        .oled_sck   (oled_sck),
        .oled_cs_n  (oled_cs_n),
        .oled_dc    (oled_dc),
        .oled_res   (oled_res),
        .oled_vccen (oled_vccen),
        .oled_pmoden(oled_pmoden)
    );

    // -----------------------------------------------------------------
    // Non-Intrusive SPI Command & Data Spy Analyzer
    // -----------------------------------------------------------------
    reg [7:0] spi_shift_reg;       // 8-bit Deserializer Shift Register
    integer   bit_cnt;             // Bit Stream Counter
    integer   cmd_idx;             // Captured Command Index
    integer   blue_pixel_byte_cnt; // Counter for Post-Mutation (SW0=1) Pixel Data
    reg       sim_done_flag;       // Simulation Termination Handshake Flag

    initial begin
        spi_shift_reg       = 8'h00;
        bit_cnt             = 0;
        cmd_idx             = 1;
        blue_pixel_byte_cnt = 0;
        sim_done_flag       = 1'b0; // Initialize termination flag
    end

    // Protocol Sniffing: Synchronized with the Master SPI Clock Edge
    always @(posedge oled_sck or posedge oled_cs_n) begin
        if (oled_cs_n) begin
            bit_cnt <= 0;
        end else begin
            spi_shift_reg <= {spi_shift_reg[6:0], oled_mosi};
            bit_cnt       <= bit_cnt + 1;
        end
    end

    // Packet Verification: Decode 8-bit SPI Stream & Check Termination Count
    always @(posedge oled_sck) begin
        if (!oled_cs_n && bit_cnt == 7) begin
            
            // [CASE A] Command Mode (D/C# = 0)
            if (oled_dc == 1'b0) begin
                $display("  [%0t ns] Boot Cmd #%02d : 8'h%h", $time, cmd_idx, {spi_shift_reg[6:0], oled_mosi});
                cmd_idx = cmd_idx + 1;
            end
            
            // [CASE B] Data Mode (D/C# = 1)
            else if (oled_dc == 1'b1) begin
                // Capture and count incoming Blue pixels via SPI lines when SW0 = 1
                if (sw0 == 1'b1) begin
                    blue_pixel_byte_cnt = blue_pixel_byte_cnt + 1;
                    $display("  [%0t ns] [SW0=1] SPI Blue Pixel Streaming... Byte #%0d : 8'h%h", $time, blue_pixel_byte_cnt, {spi_shift_reg[6:0], oled_mosi});
                    
                    // Raise handshake flag once exactly 100 bytes are transferred
                    if (blue_pixel_byte_cnt >= 100) begin
                        sim_done_flag = 1'b1;
                    end
                end
            end
            
        end
    end

    // -----------------------------------------------------------------
    // Behavioral VRAM Monitoring Task (ASCII Art Rendering)
    // -----------------------------------------------------------------
    task print_oled_screen;
        input current_sw;
        integer row, col, idx;
        reg [15:0] pixel_data;
        begin
            $display("\n================================================================================================");
            $display(" OLED SCREEN MONITOR (SW0 = %b)", current_sw);
            $display("================================================================================================");
            
            for (row = 0; row < 64; row = row + 1) begin
                for (col = 0; col < 96; col = col + 1) begin
                    idx = row * 96 + col;
                    
                    if (current_sw == 1'b0) 
                        pixel_data = uut.u_rom_sq.memory[idx];
                    else                    
                        pixel_data = uut.u_rom_A.memory[idx];
                    
                    case (pixel_data)
                        16'h0000: $write(" ");  // Black
                        16'hFFE0: $write(".");  // Yellow
                        16'hF800: $write("R");  // Red
                        16'h07E0: $write("G");  // Green
                        16'h001F: $write("B");  // Blue
                        default:  $write("?");  
                    endcase
                end
                $display(""); 
            end
            $display("================================================================================================\n");
        end
    endtask

    // -----------------------------------------------------------------
    // Deterministic System Clock Generator (100 MHz Source)
    // -----------------------------------------------------------------
    initial begin
        CLK100MHZ = 1'b0;
        forever #5 CLK100MHZ = ~CLK100MHZ; 
    end

    // -----------------------------------------------------------------
    // Verification Test Vector Stimulus
    // -----------------------------------------------------------------
    initial begin
        // Display Hardware 40ms Initialization Interval Warning First
        $display("\n[%0t ns] [NOTICE] Entering 40ms delay for OLED hardware hardware initialization/reset...", $time);
        $display("[%0t ns] [NOTICE] Please wait for the simulation to process the 40ms interval...", $time);

        btn0 = 1'b0;
        sw0  = 1'b0;
        #100;
        
        $display("\n[%0t ns] Applying Reset...", $time/1000);
        btn0 = 1'b1;
        #200;
        btn0 = 1'b0;
        $display("[%0t ns] Reset Released. Capturing Bootup Sequence Commands...\n", $time/1000);
        $display("--- [OLED INITIALIZATION COMMAND LOG] ---------------------------------------------------------");

        // Wait interval for FSM initialization setup
        #40_000; 
        $display("-----------------------------------------------------------------------------------------------\n");
        $display("[%0t ns] Boot Initialization Sequence Complete!", $time/1000);
        
        // Verify default Green pattern output
        print_oled_screen(sw0);

        #5_000;
        $display("\n[%0t ns] Changing SW0 to 1 (Blue A)...", $time/1000);
        sw0 = 1'b1;

        #100; 
        // Render internal VRAM snapshot immediately after context switch
        print_oled_screen(sw0);

        // Wait securely until 100 bytes of Blue pixel data are streamed over SPI
        wait(sim_done_flag == 1'b1);

        $display("------------------------------------------------------------------------------------------------");
        $display("\n[SUCCESS] Verification Target Reached!");
        $display("[SUCCESS] SW0 Context Switch & SPI Blue Pixel Streaming (100 Bytes) fully captured.");
        $display("[NOTICE] Technical Exit: Skipping remaining frame data to save simulation resources.\n");
        $finish; 
    end

endmodule