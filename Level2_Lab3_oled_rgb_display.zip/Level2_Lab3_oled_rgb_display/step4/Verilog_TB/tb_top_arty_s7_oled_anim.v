`timescale 1ns / 1ps

/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_arty_s7_oled_anim (Animation Testbench)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Simulator    : Vivado XSIM
 * Description  : System-level testbench for the hardware animation 
 * controller. Verifies the OLED VCC power-on initialization sequence, 
 * 10 FPS (100ms) hardware timer switching, SW0 Play/Pause functionality, 
 * and the 9-frame boundary loop (Frame 8 -> Frame 0).
 * ====================================================================== */

module tb_top_arty_s7_oled_anim;

    // ----------------------------------------------------------------------
    // Signal Declarations
    // ----------------------------------------------------------------------
    // Inputs (Registers for driving stimulus)
    reg CLK100MHZ;
    reg btn0;
    reg sw0;

    // Outputs (Wires for observing Unit Under Test - UUT)
    wire oled_mosi;
    wire oled_sck;
    wire oled_cs_n;
    wire oled_dc;
    wire oled_res;
    wire oled_vccen;
    wire oled_pmoden;

    // ----------------------------------------------------------------------
    // Unit Under Test (UUT) Instantiation
    // ----------------------------------------------------------------------
    top_arty_s7_oled_anim uut (
        .CLK100MHZ  (CLK100MHZ),
        .btn0       (btn0),
        .sw0        (sw0),
        .oled_mosi  (oled_mosi),
        .oled_sck   (oled_sck),
        .oled_cs_n  (oled_cs_n),
        .oled_dc    (oled_dc),
        .oled_res   (oled_res),
        .oled_vccen (oled_vccen),
        .oled_pmoden(oled_pmoden)
    );

    // ----------------------------------------------------------------------
    // 1. Clock Generation
    // ----------------------------------------------------------------------
    // Generates a 100 MHz deterministic system clock (10 ns period)
    initial begin
        CLK100MHZ = 1'b0;
        forever #5 CLK100MHZ = ~CLK100MHZ; 
    end

    // ----------------------------------------------------------------------
    // 2. Main Stimulus & Verification Sequence
    // ----------------------------------------------------------------------
    initial begin
        // Initialize Default States
        btn0 = 1'b0;
        sw0  = 1'b1; // Default: Play Animation (Timer Enabled)

        // Wait 100 ns for global reset routing to settle
        #100;
        
        // Assert Active-High System Reset
        $display("[%0t] [TESTBENCH] Applying System Reset...", $time);
        btn0 = 1'b1;
        #200;
        btn0 = 1'b0;
        $display("[%0t] [TESTBENCH] Reset Released. OLED Power-on Sequence started.", $time);

        // -----------------------------------------------------------------
        // Phase 1: OLED Initialization Wait Time
        // The SSD1331 requires ~320 ms for physical VCC stabilization.
        // Advancing simulation by 350 ms (350,000,000 ns) to observe SPI traffic.
        // -----------------------------------------------------------------
        #350_000_000;
        $display("[%0t] [TESTBENCH] Initialization complete. Frame 0 drawing should commence.", $time);

        // -----------------------------------------------------------------
        // Phase 2: Frame Transition Observation (10 FPS)
        // One frame requires exactly 100 ms (100,000,000 ns).
        // Wait 250 ms to observe continuous transitions: Frame 0 -> 1 -> 2.
        // -----------------------------------------------------------------
        #250_000_000;
        $display("[%0t] [TESTBENCH] Frame transitions observed. Testing Pause function...", $time);

        // -----------------------------------------------------------------
        // Phase 3: Pause Functionality Test
        // Pull SW0 low to pause the hardware timer.
        // -----------------------------------------------------------------
        sw0 = 1'b0;
        $display("[%0t] [TESTBENCH] SW0 set to 0 (Pause). Hardware timer should halt.", $time);
        
        // Wait 150 ms to ensure no further frame transitions occur while paused.
        #150_000_000;
        
        // -----------------------------------------------------------------
        // Phase 4: Resume & 9-Frame Boundary Loop Verification
        // Set SW0 high to resume. Wait 750 ms to ensure cumulative play time 
        // exceeds 900 ms, triggering the boundary rollover (Frame 8 -> Frame 0).
        // -----------------------------------------------------------------
        $display("[%0t] [TESTBENCH] SW0 set to 1 (Play). Hardware timer should resume.", $time);
        sw0 = 1'b1;

        // Advance simulation time by 750 milliseconds (750,000,000 ns)
        #750_000_000;
        
        // Terminate Simulation gracefully
        $display("[%0t] [TESTBENCH] 9-Frame loop hardware simulation successfully finished.", $time);
        $finish;
    end

endmodule