"""
====================================================================
[ROM Decoder] 16-bit MEM 파일을 GIF 애니메이션으로 역변환
====================================================================
- 목적: 9프레임 하드웨어 ROM 파일(.mem)을 읽어 PC에서 미리보기(GIF) 생성
- 원리: 16진수 텍스트를 읽어 RGB565 포맷을 RGB888(일반 모니터용)로 복원
- 요구사항: pip install Pillow
====================================================================
"""
from PIL import Image

# [수정됨] frames=11 에서 frames=9 로 변경
def mem_to_gif(mem_filepath, output_gif, frames=9, width=96, height=64):
    try:
        images = []
        pixels_per_frame = width * height
        
        # MEM 파일 읽기
        with open(mem_filepath, 'r') as f:
            lines = f.readlines()
            
        print(f"📂 파일 읽기 완료. 총 {frames}프레임 디코딩을 시작합니다...")

        # 각 프레임별로 이미지 복원
        for i in range(frames):
            img = Image.new('RGB', (width, height))
            pixels = img.load()
            
            start_idx = i * pixels_per_frame
            
            for y in range(height):
                for x in range(width):
                    hex_str = lines[start_idx + (y * width) + x].strip()
                    if not hex_str: continue
                    
                    # 1. 16진수 문자열을 정수(Integer)로 변환
                    val = int(hex_str, 16)
                    
                    # 2. RGB565 포맷에서 R(5), G(6), B(5) 비트 추출
                    r5 = (val >> 11) & 0x1F
                    g6 = (val >> 5)  & 0x3F
                    b5 = val         & 0x1F
                    
                    # 3. PC 모니터용 8비트(0~255) 스케일로 복원(업샘플링)
                    r8 = (r5 * 255) // 31
                    g8 = (g6 * 255) // 63
                    b8 = (b5 * 255) // 31
                    
                    pixels[x, y] = (r8, g8, b8)
                    
            images.append(img)
            print(f"  -> 프레임 {i+1} 복원 완료")

        # 추출된 이미지들을 0.1초(100ms) 간격의 GIF로 묶어서 저장 (10 FPS)
        images[0].save(
            output_gif,
            save_all=True,
            append_images=images[1:],
            duration=100,
            loop=0
        )
        
        print(f"\n✅ 애니메이션 복원 성공! [{output_gif}] 파일을 확인해 보세요.")
        
    except Exception as e:
        print(f"❌ 오류 발생: {e}")

# ---------------------------------------------------------
# 실행 영역: 변환할 MEM 파일 이름과 출력할 GIF 파일 이름 지정
mem_to_gif("sunrise_anim.mem", "sunrise_preview.gif")