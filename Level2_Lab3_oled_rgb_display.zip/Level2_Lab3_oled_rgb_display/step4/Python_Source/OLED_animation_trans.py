"""
====================================================================
[Animation ROM] OLED 16-bit (65,536) 애니메이션 메모리 변환기
====================================================================
- 목적: 9장의 사진(프레임)을 16비트 물리적 한계 내에 완벽하게 매핑
- 특징: 9프레임(55,296줄) 기록 후 남는 공간을 0으로 패딩하여 65,536줄 완벽 생성
- 효과: Arty S7-25 BRAM 용량 내 안착 및 16-bit 주소 버스 최적화
====================================================================
"""
from PIL import Image

def make_animation_rom(image_list, output_mem_name):
    # 중앙 크롭 함수
    def process_image(img_path):
        img = Image.open(img_path).convert('RGB')
        orig_w, orig_h = img.size
        target_aspect = 96.0 / 64.0
        orig_aspect = orig_w / orig_h
        
        if orig_aspect > target_aspect:
            new_w = int(orig_h * target_aspect)
            left = (orig_w - new_w) // 2
            crop_box = (left, 0, left + new_w, orig_h)
        else:
            new_h = int(orig_w / target_aspect)
            top = (orig_h - new_h) // 2
            crop_box = (0, top, orig_w, top + new_h)
            
        return img.crop(crop_box).resize((96, 64)).load()

    try:
        line_count = 0
        
        with open(output_mem_name, "w") as f:
            # 1. 리스트에 있는 9장의 사진을 순서대로 변환하여 기록
            for i, img_path in enumerate(image_list):
                pixels = process_image(img_path)
                for y in range(64):
                    for x in range(96):
                        r, g, b = pixels[x, y]
                        r5 = (r >> 3) & 0x1F
                        g6 = (g >> 2) & 0x3F
                        b5 = (b >> 3) & 0x1F
                        rgb565 = (r5 << 11) | (g6 << 5) | b5
                        f.write(f"{rgb565:04X}\n")
                        line_count += 1
                print(f"[{i+1}/{len(image_list)}] {img_path} 프레임 처리 완료")
                
            # 2. [핵심 수정] 16-bit 최대 주소(65,536)까지 빈 공간을 '0000'으로 채우기
            while line_count < 65536:
                f.write("0000\n")
                line_count += 1

        print(f"\n✅ 16-bit 애니메이션 ROM 생성 완료: [{output_mem_name}]")
        print(f"📊 총 생성된 라인 수: {line_count}줄 (16-bit 주소 공간 100% 일치)")
        
    except Exception as e:
        print(f"❌ 오류 발생: {e}")

# ---------------------------------------------------------
# 실행 영역:  9장의 파일 이름을 순서대로 리스트에 넣습니다.
frame_files = [
    "sun01.jpg", "sun02.jpg", "sun03.jpg", "sun04.jpg",
    "sun05.jpg", "sun06.jpg", "sun07.jpg", "sun08.jpg",
    "sun09.jpg"
]

make_animation_rom(frame_files, "sunrise_anim.mem")