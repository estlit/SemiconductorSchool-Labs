/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_combined_rom (Animation BRAM)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Synchronous Read (1-Clock Latency)
 * Description  : FPGA Block RAM (BRAM) inference module for storing 
 * continuous animation frame sequences. 
 *
 * Target Specifications & Memory Mapping:
 * - Resolution : 96 x 64 pixels (RGB565)
 * - Depth      : 65,536 words (16-bit address space)
 * - Alignment  : Continuous memory mapping for 9 frames
 * - Offset     : Base Address = frame_index * 6144
 *
 * Address Space Allocation:
 * - 9 Image Frames (Total 55,296 words)
 * - Zero-padded (Dummy data) up to address 65,535
 * ====================================================================== */

`timescale 1ns / 1ps

module oled_combined_rom (
    // System Interfaces
    input  wire        clk,   // Synchronous system clock (SPI clock domain)
    
    // Memory Interfaces
    input  wire [15:0] addr,  // 16-bit concatenated address bus for animation
    output reg  [15:0] data   // 16-bit registered RGB565 pixel data output
);

    // ----------------------------------------------------------------------
    // 1. Memory Array Declaration
    // ----------------------------------------------------------------------
    // Allocates 65,536 words of 16-bit data.
    // Accommodates 9 continuous frames (each 6,144 words) and zero-padding 
    // up to the physical 16-bit address boundary (65,535).
    reg [15:0] memory [0:65535];
    
    // ----------------------------------------------------------------------
    // 2. ROM Initialization (Memory Loading)
    // ----------------------------------------------------------------------
    // Initializes the memory array by loading the pre-computed hexadecimal 
    // data file generated via Python preprocessing.
    // [CRITICAL WARNING] Absolute path is strictly recommended to prevent 
    // Vivado synthesis errors regarding file locations.
    initial begin
        $readmemh("sunrise_anim.mem", memory); 
    end

    // ----------------------------------------------------------------------
    // 3. Synchronous Read Logic (BRAM Inference)
    // ----------------------------------------------------------------------
    // Synchronous read block enforcing hardware Block RAM (BRAM) inference.
    // This design introduces exactly a 1-clock cycle read latency to the 
    // data path, significantly minimizing logic utilization (LUTs) and 
    // improving timing slack across the FPGA fabric.
    always @(posedge clk) begin
        data <= memory[addr];
    end

endmodule