/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_arty_s7_oled_anim (Animation Controller Top)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Hardware Animation Controller via BRAM
 * Description  : Top-level module for Arty S7-25 and Pmod OLEDrgb (SSD1331).
 * Features a 10 FPS hardware timer for automatic frame 
 * switching, 16-bit dynamic memory address generation for 
 * 9 sequence frames, and Play/Pause control via SW0.
 * ====================================================================== */

`timescale 1ns / 1ps

module top_arty_s7_oled_anim (
    input  wire CLK100MHZ,   // 100 MHz onboard oscillator
    input  wire btn0,        // Active-high asynchronous reset
    input  wire sw0,         // Animation Enable (1: Play, 0: Pause)

    // Pmod OLEDrgb Physical Connections
    output wire oled_mosi,
    output wire oled_sck,
    output wire oled_cs_n,
    output wire oled_dc,
    output wire oled_res,
    output wire oled_vccen,
    output wire oled_pmoden
);

    // ----------------------------------------------------------------------
    // Internal Routing
    // ----------------------------------------------------------------------
    wire reset = btn0;
    
    // ----------------------------------------------------------------------
    // 1. Clock Divider (100MHz -> 6.25MHz for SPI domain)
    // ----------------------------------------------------------------------
    reg [3:0] div_cnt = 4'd0;
    
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) 
            div_cnt <= 4'd0;
        else       
            div_cnt <= div_cnt + 1'b1;
    end
    
    wire spi_clk = div_cnt[3];

    // ----------------------------------------------------------------------
    // 2. Hardware Animation Timer (10 FPS Frame Controller)
    // ----------------------------------------------------------------------
    // Target: 10 FPS (100 ms per frame)
    // Calculation: 100MHz system clock -> 10,000,000 cycles = 0.1 seconds
    reg [23:0] timer_cnt = 24'd0;
    reg [3:0]  frame_idx = 4'd0;

    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) begin
            timer_cnt <= 24'd0;
            frame_idx <= 4'd0;
        end else if (sw0) begin 
            // Play state: Timer active when SW0 is HIGH
            if (timer_cnt >= 24'd10_000_000 - 1) begin
                timer_cnt <= 24'd0;
                
                // Boundary Loop: Return to frame 0 after the 9th frame (index 8)
                if (frame_idx == 4'd8)
                    frame_idx <= 4'd0;
                else
                    frame_idx <= frame_idx + 1'b1;
            end else begin
                timer_cnt <= timer_cnt + 1'b1;
            end
        end
        // Pause state: When SW0 is LOW, timer_cnt and frame_idx hold their values.
    end

    // ----------------------------------------------------------------------
    // 3. Dynamic Address Generation (16-bit Space Optimization)
    // ----------------------------------------------------------------------
    wire [15:0] rom_addr;      // 16-bit global memory address
    wire [12:0] oled_pix_addr; // 13-bit local pixel address (0 to 6143)

    // Memory map calculation: 
    // 16'd6144 is the footprint of a single 96x64 frame.
    // Base address (frame_idx * 6144) + local pixel offset (oled_pix_addr)
    assign rom_addr = (frame_idx * 16'd6144) + oled_pix_addr;

    // Internal Interconnects for SPI and ROM
    wire        spi_start, spi_busy;
    wire [7:0]  spi_data;
    wire [15:0] rom_data;      

    // ----------------------------------------------------------------------
    // 4. SPI Master Controller Instantiation
    // ----------------------------------------------------------------------
    spi_master u_spi (
        .clk     (spi_clk), 
        .reset   (reset), 
        .start   (spi_start),
        .data_in (spi_data), 
        .busy    (spi_busy),
        .sclk    (oled_sck), 
        .mosi    (oled_mosi), 
        .cs_n    (oled_cs_n)
    );
    
    // ----------------------------------------------------------------------
    // 5. Combined Synchronous ROM Instantiation (65,536 Words)
    // ----------------------------------------------------------------------
    oled_combined_rom u_rom (
        .clk  (spi_clk),      // Synchronous read using SPI clock domain
        .addr (rom_addr),     // Optimized 16-bit animation address
        .data (rom_data)
    );

    // ----------------------------------------------------------------------
    // 6. OLED State Machine Controller Instantiation
    // ----------------------------------------------------------------------
    oled_test #(
        .H_RES(96), 
        .V_RES(64)
    ) u_oled (
        .clk         (spi_clk), 
        .reset       (reset),
        .spi_start   (spi_start), 
        .spi_data    (spi_data), 
        .spi_busy    (spi_busy),
        .oled_dc     (oled_dc), 
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen), 
        .oled_pmoden (oled_pmoden),
        .rom_addr    (oled_pix_addr), 
        .rom_data    (rom_data)
    );
    
endmodule