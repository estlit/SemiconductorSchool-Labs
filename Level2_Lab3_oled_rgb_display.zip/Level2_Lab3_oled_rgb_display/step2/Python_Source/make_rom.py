# make_rom.py
# 이 스크립트는 외부 이미지 없이 논리 연산만으로 combined_rom.mem 파일을 생성합니다.
# 외부 라이브러리 설치가 필요 없습니다.

# 해상도 및 메모리 설정
H_RES = 96
V_RES = 64
BANK_SIZE = 8192

# RGB565 색상 코드 (16진수 문자열)
BLACK  = "0000"
RED    = "F800"
GREEN  = "07E0"
BLUE   = "001F"
YELLOW = "FFE0"

def create_mem_file(filename):
    with open(filename, 'w') as f:
        print(f"[{filename}] 생성을 시작합니다...")

        # ==========================================
        # Bank 0: 노란 배경 + 빨간 테두리 + 녹색 사각형
        # ==========================================
        for row in range(V_RES):
            for col in range(H_RES):
                if row == 0 or row == (V_RES - 1) or col == 0 or col == (H_RES - 1):
                    f.write(RED + "\n")
                elif 16 <= row < 48 and 32 <= col < 64:
                    f.write(GREEN + "\n")
                else:
                    f.write(YELLOW + "\n")
                    
        # Bank 0 패딩 (6144 ~ 8191번지)
        for _ in range(BANK_SIZE - (H_RES * V_RES)):
            f.write(BLACK + "\n")

        # ==========================================
        # Bank 1: 빨간 원점 + 똑바로 선 파란색 'A'
        # ==========================================
        for row in range(V_RES):
            for col in range(H_RES):
                # 1. 원점(0,0) 빨간 점
                if row == 0 and col == 0:
                    f.write(RED + "\n")
                
                # 2. 파란색 'A' 형상
                elif 15 <= row < 50 and 35 <= col < 40: # 왼쪽 다리
                    f.write(BLUE + "\n")
                elif 15 <= row < 50 and 55 <= col < 60: # 오른쪽 다리
                    f.write(BLUE + "\n")
                elif 15 <= row < 20 and 40 <= col < 55: # 상단 가로바
                    f.write(BLUE + "\n")
                elif 32 <= row < 37 and 40 <= col < 55: # 중간 가로바
                    f.write(BLUE + "\n")
                
                # 3. 나머지 배경은 검은색
                else:
                    f.write(BLACK + "\n")

        # Bank 1 패딩 (14336 ~ 16383번지)
        for _ in range(BANK_SIZE - (H_RES * V_RES)):
            f.write(BLACK + "\n")

    print(f"완료! 총 16384줄의 메모리 파일이 성공적으로 생성되었습니다.")

# 실행
if __name__ == "__main__":
    create_mem_file("combined_rom.mem")