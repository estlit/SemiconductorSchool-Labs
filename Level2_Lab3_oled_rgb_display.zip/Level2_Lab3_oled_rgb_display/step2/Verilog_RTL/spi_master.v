/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : spi_master (8-bit SPI Master Controller)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Description  : 8-bit SPI Master operating in Mode 3 (CPOL=1, CPHA=1).
 * Transmits data MSB first. Designed to interface with
 * the SSD1331 OLED display driver.
 * ====================================================================== */

module spi_master (
    input  wire       clk,      // System clock (SPI clock domain)
    input  wire       reset,    // Active-high asynchronous reset
    input  wire       start,    // 1-cycle pulse to initiate transmission
    input  wire [7:0] data_in,  // 8-bit parallel data to transmit
    output reg        busy,     // High while transmission is in progress
    output reg        sclk,     // SPI Serial Clock output
    output reg        mosi,     // SPI Master Out Slave In (Data output)
    output reg        cs_n      // SPI Active-low Chip Select
);

    // ----------------------------------------------------------------------
    // Internal Registers & Parameters
    // ----------------------------------------------------------------------
    reg [3:0] bit_cnt;          // Counter for the 8 bits (7 down to 0)
    reg [7:0] shreg;            // Shift register for serialization

    // FSM State Encodings
    localparam IDLE = 2'd0,
               LOAD = 2'd1,
               SEND = 2'd2,
               DONE = 2'd3;

    reg [1:0] state;            // Current FSM state
    reg       phase;            // 0: Transition (Falling Edge), 1: Sample (Rising Edge)

    // ----------------------------------------------------------------------
    // State Machine & SPI Logic
    // ----------------------------------------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state   <= IDLE;
            bit_cnt <= 4'd0;
            shreg   <= 8'd0;
            busy    <= 1'b0;
            sclk    <= 1'b1;    // Mode 3 (CPOL=1): SCLK idles high
            mosi    <= 1'b0;
            cs_n    <= 1'b1;    // Deselect peripheral (Active-low)
            phase   <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    if (start) begin
                        busy  <= 1'b1;
                        state <= LOAD;
                    end
                end

                LOAD: begin
                    shreg   <= data_in; // Latch parallel data
                    bit_cnt <= 4'd7;    // Prepare to send 8 bits (MSB first)
                    cs_n    <= 1'b0;    // Assert Chip Select
                    sclk    <= 1'b1;    // Ensure SCLK starts high (CPOL=1)
                    phase   <= 1'b0;    // Phase 0: First edge will be falling
                    state   <= SEND;
                end

                SEND: begin
                    if (phase == 1'b0) begin
                        // Phase 0: Falling edge (SCLK 1 -> 0)
                        // In SPI Mode 3, data transitions on the falling edge.
                        sclk  <= 1'b0;
                        mosi  <= shreg[7]; // Drive MSB to MOSI line
                        phase <= 1'b1;     // Next phase is rising edge
                    end else begin
                        // Phase 1: Rising edge (SCLK 0 -> 1)
                        // Peripheral (SSD1331) samples data on this edge.
                        sclk <= 1'b1;
                        
                        // Check if all 8 bits have been transmitted
                        if (bit_cnt == 0) begin
                            state <= DONE;
                        end else begin
                            bit_cnt <= bit_cnt - 1'b1;
                            shreg   <= {shreg[6:0], 1'b0}; // Shift left for next bit
                            phase   <= 1'b0;               // Return to Phase 0 for next bit
                        end
                    end
                end

                DONE: begin
                    sclk  <= 1'b1; // Return SCLK to idle high state
                    cs_n  <= 1'b1; // Deassert Chip Select
                    busy  <= 1'b0; // Clear busy flag
                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule