/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_combined_rom (Synchronous BRAM with Bank Switching)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Description  : Synchronous ROM module optimized for FPGA Block RAM (BRAM) 
 * inference. Stores multiple RGB565 image patterns using a 
 * 14-bit address space (16,384 words) with bank switching.
 *
 * Memory Map   : [Bank 0] 0x0000 - 0x1FFF : Pattern 0 (e.g., Green Square)
 * [Bank 1] 0x2000 - 0x3FFF : Pattern 1 (e.g., Blue 'A')
 * * addr[13] is linked to hardware SW0 for bank selection.
 * ====================================================================== */

`timescale 1ns / 1ps

module oled_combined_rom (
    input  wire        clk,   // Synchronous system clock (SPI clock domain)
    input  wire [13:0] addr,  // 14-bit concatenated address {sw0, oled_pix_addr}
    output reg  [15:0] data   // 16-bit registered RGB565 pixel data output
);

    // ----------------------------------------------------------------------
    // Memory Array Declaration
    // ----------------------------------------------------------------------
    // Allocates 16,384 words of 16-bit data.
    // Accommodates two symmetrical 8,192-word boundary-aligned memory banks.
    reg [15:0] memory [0:16383];

    // ----------------------------------------------------------------------
    // Memory Initialization
    // ----------------------------------------------------------------------
    // Loads the pre-computed hexadecimal data file.
    // The data file is generated via Python script for bit-true verification.
    initial begin
        $readmemh("combined_rom.mem", memory);
    end

    // ----------------------------------------------------------------------
    // Synchronous Read Logic (Block RAM Inference)
    // ----------------------------------------------------------------------
    // Enforces hardware Block RAM (BRAM) inference by registering the output.
    // Introduces exactly a 1-clock cycle read latency to the data path,
    // which significantly minimizes logic utilization and improves timing slack.
    always @(posedge clk) begin
        data <= memory[addr];
    end

endmodule