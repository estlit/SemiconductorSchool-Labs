/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_arty_s7_oled (Top-Level System Integration)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Description  : Top-level architecture integrating the SPI Master,
 * Synchronous BRAM (with hardware bank switching), and
 * the OLED FSM controller for the SSD1331 display.
 * ====================================================================== */

module top_arty_s7_oled (
    input  wire CLK100MHZ,   // 100 MHz primary system oscillator
    input  wire btn0,        // Active-high asynchronous system reset
    input  wire sw0,         // Hardware ROM bank selector (MSB of address)

    // Pmod OLEDrgb Physical Interface (SSD1331)
    output wire oled_mosi,   // Master Out Slave In (Serial Data)
    output wire oled_sck,    // Serial Clock
    output wire oled_cs_n,   // Active-low Chip Select
    output wire oled_dc,     // Data/Command control signal
    output wire oled_res,    // Active-low hardware reset for OLED module
    output wire oled_vccen,  // VCC logic enable control
    output wire oled_pmoden  // Logic power supply enable control
);

    // ----------------------------------------------------------------------
    // Signal Declarations & Clock Generation
    // ----------------------------------------------------------------------
    wire reset = btn0;
    
    // Clock Frequency Divider: 
    // Downsamples the 100 MHz system oscillator to a 6.25 MHz operating 
    // frequency for the SPI bus and FSM operations.
    reg [3:0] div_cnt = 4'd0;
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    wire spi_clk = div_cnt[3];

    // Internal Interconnect Routing
    wire        spi_start, spi_busy;
    wire [7:0]  spi_data;
    wire [12:0] oled_pix_addr; // Pixel coordinate address from FSM
    wire [15:0] rom_data;      // Synchronous pixel data retrieved from BRAM

    // ----------------------------------------------------------------------
    // Module Instantiations
    // ----------------------------------------------------------------------

    // 1. SPI Master Controller Interface
    // Manages the serialization of configuration commands and pixel data.
    spi_master u_spi (
        .clk     (spi_clk), 
        .reset   (reset), 
        .start   (spi_start),
        .data_in (spi_data), 
        .busy    (spi_busy),
        .sclk    (oled_sck), 
        .mosi    (oled_mosi), 
        .cs_n    (oled_cs_n)
    );
    
    // 2. Synchronous Block RAM (BRAM) Integration
    // Integrates block memory for pixel storage. Features hardware-level 
    // bank switching via 'sw0', operating as the Most Significant Bit (MSB).
    oled_combined_rom u_rom (
        .clk  (spi_clk), 
        .addr ({sw0, oled_pix_addr}), // 14-bit concatenated address mapping
        .data (rom_data)
    );

    // 3. OLED FSM Controller
    // Orchestrates the SSD1331 power-on sequence, initialization commands, 
    // and continuous RGB565 pixel streaming. Designed to accommodate the 
    // 1-clock cycle latency introduced by synchronous BRAM read operations.
    oled_test #(
        .H_RES(96), .V_RES(64)
    ) u_oled (
        .clk         (spi_clk), 
        .reset       (reset),
        .spi_start   (spi_start), 
        .spi_data    (spi_data), 
        .spi_busy    (spi_busy),
        .oled_dc     (oled_dc), 
        .oled_res    (oled_res),
        .oled_vccen  (oled_vccen), 
        .oled_pmoden (oled_pmoden),
        .rom_addr    (oled_pix_addr), 
        .rom_data    (rom_data)
    );
    
endmodule