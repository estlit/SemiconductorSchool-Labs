/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_arty_s7_oled (System-Level Testbench)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Simulator    : Vivado XSIM
 * Description  : Verification environment for the top-level OLED 
 * controller. Simulates clock generation, asynchronous 
 * hardware reset, and SW0-based ROM bank switching.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top_arty_s7_oled;

    // ----------------------------------------------------------------------
    // Signal Declarations
    // ----------------------------------------------------------------------
    // Inputs (Registers for driving stimulus)
    reg CLK100MHZ;
    reg btn0;
    reg sw0;

    // Outputs (Wires for observing Unit Under Test - UUT)
    wire oled_mosi;
    wire oled_sck;
    wire oled_cs_n;
    wire oled_dc;
    wire oled_res;
    wire oled_vccen;
    wire oled_pmoden;

    // ----------------------------------------------------------------------
    // Unit Under Test (UUT) Instantiation
    // ----------------------------------------------------------------------
    top_arty_s7_oled uut (
        .CLK100MHZ  (CLK100MHZ),
        .btn0       (btn0),
        .sw0        (sw0),
        .oled_mosi  (oled_mosi),
        .oled_sck   (oled_sck),
        .oled_cs_n  (oled_cs_n),
        .oled_dc    (oled_dc),
        .oled_res   (oled_res),
        .oled_vccen (oled_vccen),
        .oled_pmoden(oled_pmoden)
    );

    // ----------------------------------------------------------------------
    // 1. System Clock Generation
    // ----------------------------------------------------------------------
    // Generates a 100 MHz clock signal (10 ns total period: 5 ns HIGH, 5 ns LOW)
    initial begin
        CLK100MHZ = 1'b0;
        forever #5 CLK100MHZ = ~CLK100MHZ; 
    end

    // ----------------------------------------------------------------------
    // 2. Main Stimulus & Verification Sequence
    // ----------------------------------------------------------------------
    initial begin
        // Initialize Default States
        btn0 = 1'b0;
        sw0  = 1'b0; // Default ROM Bank 0 (Green Square)

        // Wait 100 ns for global reset routing to settle
        #100;
        
        // Assert Active-High Asynchronous Reset
        $display("[%0t] [TESTBENCH] Asserting System Reset...", $time);
        btn0 = 1'b1;
        #200;
        btn0 = 1'b0;
        $display("[%0t] [TESTBENCH] Reset Released. Initiating OLED Power-on Sequence...", $time);

        // =========================================================================
        // [CRITICAL SIMULATION NOTE]
        // The FSM within 'oled_test.v' utilizes a LONG_WAIT_CNT (2,000,000 clocks 
        // at a 6.25 MHz domain) to ensure physical OLED VCC stabilization. 
        // This process requires approximately 320 ms of real-world time.
        // Therefore, the simulation must advance at least 350 ms before 
        // valid SPI traffic can be observed on the waveforms.
        // =========================================================================
        
        // Advance simulation time by 350 milliseconds (350,000,000 ns)
        #350_000_000;
        $display("[%0t] [TESTBENCH] Power-on Initialization complete. Expecting SPI traffic.", $time);

        // Advance another 50 milliseconds to observe continuous frame rendering
        #50_000_000;

        // Toggle SW0 to verify hardware ROM bank switching (Data Multiplexing)
        $display("[%0t] [TESTBENCH] Toggling SW0 to 1 (Switching to ROM Bank 1: Blue 'A')...", $time);
        sw0 = 1'b1;

        // Observe behavioral response for the new image frame
        #50_000_000;
        
        // Terminate Simulation gracefully
        $display("[%0t] [TESTBENCH] Verification Sequence Finished. Terminating Simulation.", $time);
        $finish;
    end

endmodule