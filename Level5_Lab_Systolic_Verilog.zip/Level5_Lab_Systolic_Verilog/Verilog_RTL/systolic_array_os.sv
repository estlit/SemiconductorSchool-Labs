/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : systolic_array_os
 * Target Board : FPGA / ASIC (Generic)
 * Architecture : Output-Stationary (OS)
 * Description  : Top-level wrapper for the Output-Stationary systolic array.
 * Both operands (Data A and Weights B) stream across the array,
 * while Partial Sums (C) are accumulated locally within each PE.
 * ====================================================================== */

`timescale 1ns / 1ps

module systolic_array_os #(
    parameter A_WIDTH    = 8,
    parameter B_WIDTH    = 8,
    parameter C_WIDTH    = 32,
    parameter ARRAY_SIZE = 3
) (
    input  logic clk,
    input  logic reset,
    input  logic clear, // Global signal to clear internal accumulators
    
    // External interfaces for streaming inputs
    input  logic [A_WIDTH-1:0] a_horizontal_in [ARRAY_SIZE-1:0],
    input  logic [B_WIDTH-1:0] b_vertical_in   [ARRAY_SIZE-1:0],
    
    // Output-Stationary Mode: Matrix output of final accumulation values from each PE
    output logic [C_WIDTH-1:0] pe_c_matrix [ARRAY_SIZE-1:0][ARRAY_SIZE-1:0]
);

    // Internal propagation network (Both A and B stream across the fabric)
    logic [A_WIDTH-1:0] a_net [ARRAY_SIZE-1:0][ARRAY_SIZE:0];
    logic [B_WIDTH-1:0] b_net [ARRAY_SIZE:0][ARRAY_SIZE-1:0];

    genvar i, j;
    generate
        // Assignment for streaming input data and weights
        for (i = 0; i < ARRAY_SIZE; i++) assign a_net[i][0] = a_horizontal_in[i];
        for (j = 0; j < ARRAY_SIZE; j++) assign b_net[0][j] = b_vertical_in[j];

        // Generation of the PE Matrix
        for (i = 0; i < ARRAY_SIZE; i++) begin : row_gen
            for (j = 0; j < ARRAY_SIZE; j++) begin : col_gen
                PE_OS #(A_WIDTH, B_WIDTH, C_WIDTH) pe_inst (
                    .clk  (clk),
                    .reset(reset),
                    .clear(clear),
                    .a_in (a_net[i][j]),
                    .b_in (b_net[i][j]),
                    .a_out(a_net[i][j+1]),
                    .b_out(b_net[i+1][j]),
                    .c_acc(pe_c_matrix[i][j]) // Mapping accumulation result from each PE
                );
            end
        end
    endgenerate

endmodule

/* ======================================================================
 * Module       : PE_OS
 * Description  : Output-Stationary Processing Element
 * Both input data and weight stream through, accumulating the partial 
 * sum locally.
 * ====================================================================== */
`timescale 1ns/1ps

module PE_OS #(
    parameter integer A_WIDTH = 8, 
    parameter integer B_WIDTH = 8, 
    parameter integer C_WIDTH = 32
) (
    input  logic clk, reset, clear,
    input  logic [A_WIDTH-1:0] a_in, b_in,
    output logic [A_WIDTH-1:0] a_out, b_out,
    output logic [C_WIDTH-1:0] c_acc // Internal accumulation value output
);
    logic [A_WIDTH-1:0] a_reg, b_reg;
    
    // Declare internal register as signed to safely handle sign extension during accumulation
    logic signed [C_WIDTH-1:0] acc_reg;

    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            a_reg <= '0; b_reg <= '0; acc_reg <= '0;
        end else if (clear) begin
            acc_reg <= '0; // Initialization before starting a new matrix operation
        end else begin
            a_reg <= a_in; 
            b_reg <= b_in;
            
            // Output-Stationary Mode: Accumulate result in local register
            if (a_in != 0 && b_in != 0) begin
                // Apply Mixed-sign Multiplication
                // Zero-pad a_in (Unsigned) to a 9-bit positive number, then cast to signed
                // Directly cast b_in (Signed int8) to signed to maintain its sign
                acc_reg <= acc_reg + ($signed({1'b0, a_in}) * $signed(b_in));
            end
        end
    end

    // Forwarding logic for the systolic pulse
    assign a_out = a_reg; 
    assign b_out = b_reg; 
    assign c_acc = acc_reg;

endmodule