/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_systolic_array_os
 * Target Board : FPGA / ASIC (Generic)
 * Architecture : Testbench for Output-Stationary (OS) Array
 * Description  : Verification environment for the 3x3 systolic array core.
 * Injects skewed matrix data, monitors cycle-by-cycle PE 
 * utilization, and verifies outputs against golden reference.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_systolic_array_os;
    // Parameters for bit-width and array dimensions
    parameter A_WIDTH = 8, B_WIDTH = 8, C_WIDTH = 32, ARRAY_SIZE = 3, K_SIZE = 3;
    
    // Total number of Processing Elements (PEs)
    localparam TOTAL_PES = ARRAY_SIZE * ARRAY_SIZE;
    
    // Total active computation cycles (N + M + K - 2 = 7)
    localparam CALC_CYCLES = ARRAY_SIZE + K_SIZE + ARRAY_SIZE - 2; 

    // Control and Data signals
    logic clk, reset, clear; 
    logic [A_WIDTH-1:0] a_horizontal_in [ARRAY_SIZE-1:0];
    logic [B_WIDTH-1:0] b_vertical_in   [ARRAY_SIZE-1:0];
    logic [C_WIDTH-1:0] pe_c_matrix [ARRAY_SIZE-1:0][ARRAY_SIZE-1:0];

    // Golden Reference Data (Based on image_0baaf4)
    logic [C_WIDTH-1:0] golden_c [0:2][0:2] = '{ '{30, 24, 18}, '{84, 69, 54}, '{138, 114, 90} };
    logic [A_WIDTH-1:0] matrix_a [0:2][0:2] = '{ '{1, 2, 3}, '{4, 5, 6}, '{7, 8, 9} };
    logic [B_WIDTH-1:0] matrix_b [0:2][0:2] = '{ '{9, 8, 7}, '{6, 5, 4}, '{3, 2, 1} };

    // Performance and Verification counters
    integer total_errors = 0, total_verified = 0;
    integer active_pes_accumulator = 0; // Accumulator for utilization calculation

    // Device Under Test (DUT) Instantiation
    systolic_array_os #(A_WIDTH, B_WIDTH, C_WIDTH, ARRAY_SIZE) dut (.*);

    // Clock generation (100MHz / 10ns period)
    initial begin 
        clk = 0; 
        $timeformat(-9, 3, " ns", 15); 
        forever #5 clk = ~clk; 
    end

    // Main Test Sequence
    initial begin
        $display("\n======= NPU CORE-1 UTILIZATION & PERFORMANCE REPORT START =======");
        // [Important] Initialize control signals to clear 'x' (unknown) states
        reset = 1; clear = 1; #15;
        reset = 0; clear = 0;
        
        run_simulation();
        print_final_report();
        $finish;
    end

    // Simulation Task: Skewing data injection and monitoring
    task run_simulation();
        integer t, i, j;
        integer current_active_pes; 
        
        // Loop through 12 cycles, calculating utilization only during active window
        for (t = 0; t < 12; t++) begin
            // Data skewing logic for Systolic Array input
            for (i = 0; i < ARRAY_SIZE; i++) begin
                if (t >= i && (t - i) < K_SIZE) begin
                    a_horizontal_in[i] = matrix_a[i][t-i];
                    b_vertical_in[i]   = matrix_b[t-i][i];
                end else begin
                    a_horizontal_in[i] = 0; b_vertical_in[i] = 0;
                end
            end
            
            // Capture status at Rising Edge (Start of Cycle)
            @(posedge clk); 
            // 1. Calculate utilization for current cycle (Count only T=0 to 6)
            current_active_pes = 0;
            if (t < CALC_CYCLES) begin
                for (i = 0; i < ARRAY_SIZE; i++) begin
                    for (j = 0; j < ARRAY_SIZE; j++) begin
                        if (t >= (i+j) && t <= (i+j+K_SIZE-1)) current_active_pes++;
                    end
                end
                active_pes_accumulator += current_active_pes;
            end

            $display("\n[Cycle T=%0d] @ %t ------------------------------------------", t, $time);
            $display("  > Utilization: %0d/%0d (%0.1f%%)", 
                     current_active_pes, TOTAL_PES, (current_active_pes * 100.0) / TOTAL_PES);

            // Sample data at Falling Edge for stability
            @(negedge clk); 
            // Output data only during active computation (T=0 to 6)
            if (t < CALC_CYCLES) begin
                for (i = 0; i < ARRAY_SIZE; i++) begin
                    for (j = 0; j < ARRAY_SIZE; j++) begin
                        if (t >= (i+j) && t <= (i+j+K_SIZE-1))
                            $display("    PE(%0d,%0d) Data: %d", i, j, pe_c_matrix[i][j]);
                    end
                end
            end
            
            // Final Verification at T=8
            if (t == 8) begin
                for (i = 0; i < ARRAY_SIZE; i++) begin
                    for (j = 0; j < ARRAY_SIZE; j++) begin
                        total_verified++;
                        if (pe_c_matrix[i][j] !== golden_c[i][j]) total_errors++;
                    end
                end
            end
        end
    endtask

    // Performance Summary Report Task
    task print_final_report();
        // Calculate average based on the actual CALC_CYCLES (7)
        real avg_util = (active_pes_accumulator * 100.0) / (CALC_CYCLES * TOTAL_PES);

        $display("\n===============================================================");
        $display("  SYSTOLIC ARRAY PERFORMANCE SUMMARY");
        $display("===============================================================");
        $display("  > Total Calculation Cycles : %0d (T=0 to T=6)", CALC_CYCLES);
        $display("  > Total PE Operations      : %0d (Ideal: %0d)", active_pes_accumulator, TOTAL_PES * K_SIZE);
        $display("  > Average Utilization      : %0.1f%%", avg_util);
        $display("  > Verification Status      : %s", (total_errors == 0 && total_verified == 9) ? "SUCCESS" : "FAILED");
        $display("===============================================================\n");
    endtask
endmodule