/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Timebase Generator Testbench (Virtual Verification Environment)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7) - Simulation Only
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_counter1mh;

    // ---------------------------------------------------------
    // 1. System Signals & Clock Generation Infrastructure
    // ---------------------------------------------------------
    reg  clk;           // 100MHz Primary Reference Clock
    reg  reset;         // Synchronous Active-High Global Reset
    wire tc;            // Terminal Count Output (1MHz periodic pulse)

    // ---------------------------------------------------------
    // 2. Device Under Test (DUT) Instantiation
    // ---------------------------------------------------------
    counter1mh dut (
        .clk   (clk),
        .reset (reset), 
        .tc    (tc)
    );

    // 100MHz Reference Clock Generation (10ns Period)
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // ---------------------------------------------------------
    // 3. Main Verification Procedure (Stimulus Injection)
    // ---------------------------------------------------------
    initial begin
        // Step 0: System Initialization and Global Reset Assertion
        reset = 1'b1;   
        
        // Maintain reset assertion for initial logic stabilization (200ns)
        #200;           
        
        // Step 1: Deassert reset to initiate continuous counter operation
        reset = 1'b0;   
        
        // Observation Window: Monitor terminal count (tc) pulse generation over 5us
        #5000;          
        
        // Terminate Simulation Gracefully
        $display("Verification Sequence Completed Successfully.");
        $finish;
    end

endmodule