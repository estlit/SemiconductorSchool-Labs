/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Ultrasonic Range Processor Testbench (Virtual Verification)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7) - Simulation Only
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_us_range;

    // ---------------------------------------------------------
    // 1. Stimulus Signals (DUT Inputs)
    // ---------------------------------------------------------
    reg clk;                // 100MHz Primary Reference Clock
    reg reset;              // Synchronous Active-High Global Reset
    reg echo;               // Virtual Ultrasonic Echo Return Signal
    reg tc;                 // 1us Timebase Reference Signal (1MHz)

    // ---------------------------------------------------------
    // 2. Observation Signals (DUT Outputs)
    // ---------------------------------------------------------
    wire trig;              // Ultrasonic Trigger Output from DUT
    wire [8:0] range_cm_out;// Computed Distance Output in Centimeters
                            // (Allocated 9 bits to accommodate a maximal physical range of ~400-500cm)

    // ---------------------------------------------------------
    // 3. Device Under Test (DUT) Instantiation
    // ---------------------------------------------------------
    us_range dut (
        .clk          (clk),          // Primary System Clock
        .reset        (reset),        // Active-High Reset Assertion
        .echo         (echo),         // Echo Return Stimulus
        .tc           (tc),           // 1us Temporal Reference
        .trig         (trig),         // Trigger Output Monitor
        .range_cm_out (range_cm_out)  // Computed Metric Monitor
    );

    // ---------------------------------------------------------
    // 4. Clock & Timebase Generation Infrastructure
    // ---------------------------------------------------------
    
    // 100MHz Reference Clock Generation (10ns Period / 5ns Half-Cycle)
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // 1us Timebase Generation (1MHz Frequency)
    // Toggles every 500ns to synthesize a precise 1us periodic waveform
    initial begin
        tc = 1'b0;
        forever #500 tc = ~tc; 
    end

    // ---------------------------------------------------------
    // 5. Main Verification Procedure (Test Vectors)
    // ---------------------------------------------------------
    initial begin
        // Telemetry Monitor: Continuously observe temporal events and computed metrics
        $monitor("Time: %0t ns | Echo: %b | Computed Range: %0d cm", $time, echo, range_cm_out);

        // Step 1: System Initialization and Reset Assertion
        reset = 1'b1;
        echo  = 1'b0;

        #5000;              // Maintain reset assertion for logic stabilization (5us)
        reset = 1'b0;       // Deassert reset to commence normal operation
        
        // Step 2: FSM Initialization Window
        // Provide a ~15ms temporal buffer to allow the FSM to transition through the initial WAIT state
        #15000000;

        // Step 3: Test Scenario 1 - 10cm Proximity Metrics Evaluation
        // Derivation: 580us acoustic time-of-flight correlates to a 10cm physical distance (580 / 58 = 10)
        $display("\n--- Applying Stimulus 1: 580us Echo Pulse (Target Metric: 10cm) ---");
        echo = 1'b1;  
        #580000;            // Assert high-level echo pulse for 580us (580,000ns)
        echo = 1'b0;

        // Post-Verification Guard Band
        #1000000;           // Extend observation window for 1ms to capture final latched values
        $display("\nVerification Sequence Completed Successfully.");
        $finish;
    end

endmodule