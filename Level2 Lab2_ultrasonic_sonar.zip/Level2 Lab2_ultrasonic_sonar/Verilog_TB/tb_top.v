/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Top-Level System Testbench (Virtual Verification Environment)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7) - Simulation Only
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top;

    // ---------------------------------------------------------
    // 1. System Signals & Clock Generation Infrastructure
    // ---------------------------------------------------------
    reg clk;                // 100MHz Primary Reference Clock
    reg reset;              // Synchronous Active-High Global Reset
    reg echo;               // Virtual Ultrasonic Echo Return Signal
    
    wire trig;              // Ultrasonic Trigger Output from DUT
    wire [3:0] led;         // Sequential LED Indicator Output (LD2 ~ LD5)

    // 100MHz Reference Clock Generation (10ns Period)
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // ---------------------------------------------------------
    // 2. Device Under Test (DUT) Instantiation
    // ---------------------------------------------------------
    top dut (
        .clk   (clk),
        .reset (reset),
        .echo  (echo),
        .trig  (trig),
        .led   (led)
    );

    // ---------------------------------------------------------
    // 3. Virtual Sensor Stimulus Task
    // ---------------------------------------------------------
    // Task: Simulates the physical acoustic echo pulse proportional to target distance
    task simulate_echo;
        input [15:0] distance_cm;
        integer pulse_width_us;
        begin
            // Derivation: 1cm of spatial distance equates to 58us of acoustic time-of-flight
            pulse_width_us = distance_cm * 58; 
            $display("[Time: %0t] Simulating Target Distance: %0d cm", $time, distance_cm);
            
            // Event Synchronization: Align with the rising edge of the hardware trigger
            @(posedge trig);          
            
            // Emulate sensor internal processing latency (10us temporal offset)
            #10000;                   
            echo = 1'b1;
            
            // Sustain the echo pulse for the computed time-of-flight duration
            #(pulse_width_us * 1000); 
            echo = 1'b0;
            
            // Guard Band: Provide adequate time (5ms) for DUT computational logic to stabilize and latch
            #5000000;                 
        end
    endtask

    // ---------------------------------------------------------
    // 4. Main Verification Procedure (Test Vectors)
    // ---------------------------------------------------------
    initial begin
        // Step 0: System Initialization and Global Reset Assertion
        reset = 1'b1;
        echo  = 1'b0;
        #200;
        reset = 1'b0;
        
        // FSM Stabilization Window: Await internal logic setup (15ms)
        #15000000;

        // --- Test Scenario 1: Safe Zone Validation (120cm) ---
        // Expected State: led = 4'b0000 (Distance >= 80cm)
        simulate_echo(120);

        // --- Test Scenario 2: Caution Level 1 Validation (70cm) --- 
        // Expected State: led = 4'b0001 (60cm <= Distance < 80cm)
        simulate_echo(70);

        // --- Test Scenario 3: Caution Level 2 Validation (50cm) ---
        // Expected State: led = 4'b0011 (40cm <= Distance < 60cm)
        simulate_echo(50);

        // --- Test Scenario 4: Warning Level 3 Validation (35cm) ---
        // Expected State: led = 4'b0111 (20cm <= Distance < 40cm)
        simulate_echo(35);

        // --- Test Scenario 5: Danger Zone Validation (15cm) ---
        // Expected State: led = 4'b1111 (Distance < 20cm)
        simulate_echo(15);

        // Terminate Simulation Gracefully
        #10000000;
        $display("Verification Sequence Completed Successfully.");
        $finish;
    end

endmodule