/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Ultrasonic Range Controller and Signal Processor
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * ====================================================================== */

`timescale 1ns / 1ps

module us_range(
    input clk,              // Primary System Clock
    input reset,            // Synchronous Active-High Reset Condition
    input echo,             // Ultrasonic Echo Return Signal
    input tc,               // 1us Timebase Tick (1MHz Reference Signal)
    output reg trig,        // Ultrasonic Trigger Output Pulse
    output wire [3:0] bcd_100, // Hundreds digit (Binary-Coded Decimal)
    output wire [3:0] bcd_10,  // Tens digit (Binary-Coded Decimal)
    output wire [3:0] bcd_1,   // Units digit (Binary-Coded Decimal)
    output wire [15:0] range_cm_out // Final computed distance in centimeters
    );
    
    // Finite State Machine (FSM) State Encodings
    parameter TRIGGER = 4'b0001,
              ECHO    = 4'b0010,
              WAIT    = 4'b0100;

    reg  [15:0] echo_pulse_r;   // Latched accumulator for valid echo duration
    reg  [15:0] count;          // Global cycle tracking counter
    reg  [ 3:0] status;         // Current FSM state register
    reg  [15:0] echo_pulse;     // Real-time echo duration accumulator
    wire [15:0] range_cm;       // Combinational distance computation result

    // 1. Global Timebase Counter (60ms Periodic Measurement Cycle)
    always @(posedge tc) begin
        if (reset) begin
            count <= 16'd0;
        end
        else if (count > 59999) begin // 60,000us (60ms) temporal boundary
            count <= 16'd0;
        end
        else begin
            count <= count + 1'b1;
        end
    end

    // 2. Ultrasonic Transceiver Finite State Machine (FSM) with Data Latching
    always @(posedge tc) begin
        if (reset) begin
            status <= WAIT;
            trig <= 1'b0;
            echo_pulse <= 16'd0;
            echo_pulse_r <= 16'd0;
        end 
        else begin
            case (status)
                WAIT: begin
                    if(count == 9999) begin // Initiate trigger sequence after a 10ms stabilization offset
                        status <= TRIGGER;
                        trig <= 1'b1;
                        echo_pulse <= 16'd0;
                    end
                    else begin
                        status <= WAIT;
                        trig <= 1'b0;
                    end
                end

                TRIGGER: begin
                    if (count > 10019) begin // Assert trigger signal for precisely 20us to initiate sonic burst
                        status <= ECHO;
                        trig <= 1'b0;
                        echo_pulse <= 16'd0;
                    end
                    else begin
                        status <= TRIGGER;
                        trig <= 1'b1;
                    end
                end

                ECHO: begin
                    if (echo) begin
                        // Accumulate temporal pulse width while the echo signal remains asserted
                        echo_pulse <= echo_pulse + 1'b1;
                        status <= ECHO;
                    end
                    else if (echo_pulse > 0) begin
                        // LATCH: Safely capture the terminal pulse width upon the falling edge of the echo signal
                        echo_pulse_r <= echo_pulse;
                        status <= WAIT;
                    end
                    else if (count > 59000) begin
                        // Timeout Protection: Revert to WAIT state if echo duration exceeds maximal operational bounds
                        status <= WAIT;
                    end
                    else begin
                        status <= ECHO;
                    end
                end

                default: status <= WAIT;
            endcase
        end
    end
     
    // 3. Digital Signal Processing: Distance Computation and BCD Conversion
    // Derivation: Distance (cm) = Time of Flight (us) / 58 (Acoustic velocity approximation at standard conditions)
    assign range_cm = echo_pulse_r / 58; 
    assign range_cm_out = range_cm;      
     
    // Binary to Binary-Coded Decimal (BCD) algorithmic extraction logic
    assign bcd_100 = (range_cm / 100);      
    assign bcd_10  = ((range_cm / 10) % 10); 
    assign bcd_1   = (range_cm % 10);         
    
endmodule