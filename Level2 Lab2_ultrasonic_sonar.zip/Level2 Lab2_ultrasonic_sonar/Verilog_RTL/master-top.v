/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Top-Level Core Architecture (System Integration)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * ====================================================================== */

`timescale 1ns / 1ps

module top (
    input clk,              // 100MHz System Clock
    input reset,            // Active High Reset (BTN0)
    input echo,             // Ultrasonic Echo Input
    output trig,            // Ultrasonic Trigger Output
    output reg [3:0] led    // Sequential LEDs (LD2~LD5)
    );

    wire tc;
    wire [15:0] distance;

    // 1. 1us Timebase Generator (1MHz)
    counter1mh counter_inst (
        .clk(clk), 
        .reset(reset), 
        .tc(tc)
    );

    // 2. Ultrasonic Sensor Controller (with Data Latching Mechanism)
    us_range us_range_inst (
        .clk(clk), .reset(reset), .echo(echo), .tc(tc), .trig(trig),
        .range_cm_out(distance)
    );

    // 3. Sequential LED Indicator Logic (Thresholds: 80 / 60 / 40 / 20 cm)
    // Minimum threshold is set to 20cm to ensure optimal visibility of the 4-level warning system.
    always @(*) begin
        if (reset) begin
            led = 4'b0000;
        end
        else if (distance >= 80) begin
            led = 4'b0000; // Distance >= 80cm: Safe Zone (All LEDs OFF)
        end
        else if (distance >= 60) begin
            led = 4'b0001; // 60cm <= Distance < 80cm: Caution Level 1 (1 LED ON)
        end
        else if (distance >= 40) begin
            led = 4'b0011; // 40cm <= Distance < 60cm: Caution Level 2 (2 LEDs ON)
        end
        else if (distance >= 20) begin
            led = 4'b0111; // 20cm <= Distance < 40cm: Warning Level 3 (3 LEDs ON)
        end
        else begin
            led = 4'b1111; // Distance < 20cm: Danger Zone (All 4 LEDs ON)
        end
    end

endmodule