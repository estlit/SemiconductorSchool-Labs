/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : Timebase Generator (1MHz Tick from 100MHz System Clock)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * ====================================================================== */

`timescale 1ns / 1ps

module counter1mh(
    input clk,              // 100MHz Primary System Clock Oscillator Input
    input reset,            // Synchronous Active-High Global Reset (BTN0)
    output tc               // 1MHz Terminal Count (1us periodic pulse stream)
    );
    
    reg [7:0] count;        // 8-bit Internal Register for Clock Division (Modulo-100)
    
    always @(posedge clk) begin
        if (reset) begin    // Synchronous Active-High Reset Condition
            count <= 8'd0;
        end
        else begin
            if (count < 99) begin // Increment phase: Accumulate from 0 up to 99
                count <= count + 1'b1;
            end
            else begin
                count <= 8'd0;    // Wrap-around phase: Reset accumulator upon reaching upper bound
            end
         end
     end
     
     // Continuous Assignment: Generate a singular clock-cycle width pulse at the start of every 1us epoch
     assign tc = (count == 0) ? 1'b1 : 1'b0;   
          
endmodule