"""
=======================================================================
Semiconductor School
dryrun_make_golden.py   (Level 5 - Lab 3 dry-run)

Version   : 1.0
Author    : Roger Kim
Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.

Purpose (the role of Python in the dry-run)
-------------------------------------------
The dry-run stage checks that the (learned-weight) circuit actually works
BEFORE any training is done.  Since we have not trained yet, the weights are
hand-designed "placeholder weights."  This single Python script does exactly
one thing: it computes the GOLDEN answer (golden_feature) used to grade the
RTL result.

  (The training stage Lab2 needs TWO Python programs: dataset generation +
   training.  The dry-run has no training, so ONE golden generator is enough.)

Key concepts
------------
1) Placeholder weight = a direction kernel a human places by hand using only
   0 and 64 (0x40).
     - horizontal = middle row, vertical = middle column,
       '/' = anti-diagonal, '\' = main diagonal
     - bias is all zero.  This is only to test that the circuit runs, so
       these simple values are enough.
2) golden_feature.mem = pass img0..3 through the SAME integer math the
   hardware performs, and store the four resulting feature values per image
   (image x channel) as 32-bit hex.  This is the "answer key."
     - class is NOT stored, because class = argmax(feature) is redundant.
       (The testbench computes the class itself via argmax and compares.)
3) SHIFT_CONV = 4 (dry-run).  The conv accumulator is shifted right by 4 to
   fit into 16 bits.  The weight mem and SHIFT are ONE matched set (if they
   do not match, the feature values will differ).

Integer datapath (bit-identical to the RTL)
-------------------------------------------
   pixel (uint8) -> conv (INT8 weight MAC + INT32 bias, 32-bit accumulate)
     -> arithmetic right shift >> SHIFT_CONV
     -> keep low 16 bits (WRAP, not saturation) -> ReLU
     -> per-position Hard-WTA (tie -> lower index)
     -> per-channel feature accumulation (32-bit) -> feat0..3
   (class = argmax(feat) is not stored)

Run
---
    python dryrun_make_golden.py
  ->  dryrun_output/fpga_mem/  conv_weight.mem, conv_bias.mem, img0..3.mem  (synthesized / registered in FPGA)
      dryrun_output/verify/    golden_feature.mem                          (verification only, not registered)
=======================================================================
"""

import os
import numpy as np

# ---------------------------------------------------------------------
# Parameters (must match the RTL)
# ---------------------------------------------------------------------
IMG_W, IMG_H = 96, 64
CH = 4
CONV_H, CONV_W = IMG_H - 2, IMG_W - 2      # 62 x 94 valid window
SHIFT_CONV = 4                              # for dry-run placeholder weights
OUT = "dryrun_output"

CLASS_EN = ("horizontal", "vertical", "diag45 /", "diag135 \\")


# ---------------------------------------------------------------------
# 1) Placeholder weights (hand-designed 0/1 direction kernels x 64)
# ---------------------------------------------------------------------
def placeholder_weights():
    """Direction kernels made only of 0 and 64 (0x40); bias is 0.
       This encodes the human intuition 'respond strongly when bright pixels
       lie along this direction.'"""
    W = np.zeros((4, 3, 3), np.int64)
    W[0, 1, :] = 64                              # horizontal : middle row
    W[1, :, 1] = 64                              # vertical   : middle column
    W[2, 0, 2] = W[2, 1, 1] = W[2, 2, 0] = 64    # '/'        : anti-diagonal
    W[3, 0, 0] = W[3, 1, 1] = W[3, 2, 2] = 64    # '\'        : main diagonal
    B = np.zeros(4, np.int64)                    # bias = 0
    return W, B


# ---------------------------------------------------------------------
# 2) Reference images img0..3 (Lab1 = Lab2 = Lab3 canonical; white line on black)
# ---------------------------------------------------------------------
def reference_images():
    cy, cx, half, t, tp = IMG_H // 2, IMG_W // 2, 20, 1, 1
    r0, r1, c0, c1 = cy - half, cy + half - 1, cx - half, cx + half - 1
    imgs = []
    a = np.zeros((IMG_H, IMG_W), np.uint8); a[cy-t:cy+t+1, c0:c1+1] = 255; imgs.append(a)   # horizontal
    a = np.zeros((IMG_H, IMG_W), np.uint8); a[r0:r1+1, cx-t:cx+t+1] = 255; imgs.append(a)   # vertical
    a = np.zeros((IMG_H, IMG_W), np.uint8); S = cy + cx                                     # '/'
    for rr in range(r0, r1+1):
        for cc in range(c0, c1+1):
            if abs((rr+cc) - S) <= tp: a[rr, cc] = 255
    imgs.append(a)
    a = np.zeros((IMG_H, IMG_W), np.uint8); D = cy - cx                                     # '\'
    for rr in range(r0, r1+1):
        for cc in range(c0, c1+1):
            if abs((rr-cc) - D) <= tp: a[rr, cc] = 255
    imgs.append(a)
    return np.stack(imgs)


# ---------------------------------------------------------------------
# 3) Integer forward, bit-identical to the hardware (the golden calculator)
# ---------------------------------------------------------------------
def wrap16(a):
    """RTL 16-bit truncation (q = s[15:0], WRAP). Note: this is NOT saturation."""
    return ((a.astype(np.int64) + 0x8000) & 0xFFFF).astype(np.int64) - 0x8000


def integer_forward(img_u8, W, B, shift):
    x = img_u8.astype(np.int64)
    conv = np.empty((CH, CONV_H, CONV_W), np.int64)
    for f in range(CH):                                  # conv : INT8 MAC + INT32 bias
        acc = np.full((CONV_H, CONV_W), int(B[f]), np.int64)
        for dr in range(3):
            for dc in range(3):
                acc += x[dr:dr+CONV_H, dc:dc+CONV_W] * int(W[f, dr, dc])
        conv[f] = acc
    s = conv >> int(shift)                               # requant : arithmetic right shift
    relu = np.where(wrap16(s) > 0, wrap16(s), 0)         # 16-bit wrap -> ReLU
    win_idx = np.argmax(relu, axis=0)                    # Hard-WTA (tie -> lower index)
    win_val = np.max(relu, axis=0)
    feat = [int(win_val[win_idx == f].sum()) for f in range(CH)]   # per-channel feature sum
    cls = int(np.argmax(feat))                           # class = argmax(feature)
    return feat, cls


# ---------------------------------------------------------------------
# 4) Write output files
# ---------------------------------------------------------------------
def hexs(v, nbits):
    return format(int(v) & ((1 << nbits) - 1), "0{}X".format(nbits // 4))


def main():
    os.makedirs(os.path.join(OUT, "fpga_mem"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "verify"), exist_ok=True)

    W, B = placeholder_weights()
    imgs = reference_images()

    # --- Synthesized / registered in FPGA : conv_weight/bias + img0..3 ---
    with open(os.path.join(OUT, "fpga_mem", "conv_weight.mem"), "w") as f:
        for fi in range(4):
            for r in range(3):
                for c in range(3):
                    f.write(hexs(W[fi, r, c], 8) + "\n")
    with open(os.path.join(OUT, "fpga_mem", "conv_bias.mem"), "w") as f:
        for fi in range(4):
            f.write(hexs(B[fi], 32) + "\n")
    for i in range(4):
        with open(os.path.join(OUT, "fpga_mem", "img%d.mem" % i), "w") as f:
            for px in imgs[i].reshape(-1):
                f.write("{:02X}\n".format(int(px)))

    # --- Verification only (not registered) : golden_feature (class not stored) ---
    print("dry-run golden computation (placeholder weights, SHIFT_CONV=%d)" % SHIFT_CONV)
    with open(os.path.join(OUT, "verify", "golden_feature.mem"), "w") as f:
        for i in range(4):
            feat, cls = integer_forward(imgs[i], W, B, SHIFT_CONV)
            for v in feat:
                f.write(hexs(v, 32) + "\n")
            print("  img%d (%-11s) feat=%s  class=%d  %s"
                  % (i, CLASS_EN[i], feat, cls, "OK" if cls == i else "CHECK"))
    with open(os.path.join(OUT, "verify", "quant_config.txt"), "w") as f:
        f.write("# dry-run placeholder weights (hand-designed 0/64, bias 0)\n")
        f.write("SHIFT_CONV = %d\n" % SHIFT_CONV)

    print("\nOutputs:")
    print("  %s/fpga_mem/  conv_weight.mem, conv_bias.mem, img0..3.mem  (synthesized / registered)" % OUT)
    print("  %s/verify/    golden_feature.mem                          (verification only, not registered)" % OUT)
    print("\ngolden_feature.mem is read by the TB as 'feat exp' and compared with the RTL value.")
    print("class is not stored = argmax(feature); the TB computes it directly.")


if __name__ == "__main__":
    main()
