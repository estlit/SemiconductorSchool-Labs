/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_hex2seg
 * Target Board : Digilent Arty S7-25 Rev. E
 * Architecture : Combinational Unit Verification Testbench
 * Description  : Exhaustively verifies the active-high 7-segment decoder 
 * across all 16 hex inputs (0x0 to 0xF) and unknown corner cases ('X').
 * Evaluates the strictly mapped bit ordering: seg_data = {A,B,C,D,E,F,G}.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_hex2seg;

    // Testbench Driving Signals
    reg  [3:0] hex;
    wire [6:0] seg_data;

    // Loop iterator declared outside for Verilog-2001 standard compliance
    integer i;

    // Instantiate Device Under Test (DUT)
    hex2seg dut (
        .hex      (hex),
        .seg_data (seg_data)
    );

    // ==================================================================
    // Unit Verification Sequence
    // ==================================================================
    initial begin
        $display("=================================================");
        $display(" hex2seg Unit Simulation Verification Started");
        $display(" Output Bit Mapping: seg_data[6:0] = {A,B,C,D,E,F,G}");
        $display("=================================================");

        // Sweep all hexadecimal inputs from 0x0 to 0xF with 10ns step
        for (i = 0; i < 16; i = i + 1) begin
            hex = i[3:0];
            #10;
            $display(" Input HEX: %h | Output SEG (ABCDEFG): %b", hex, seg_data);
        end

        // Verify default / corner case handling with unknown input ('X')
        hex = 4'hX; #10;
        $display(" Input HEX: X | Output SEG (ABCDEFG): %b (Expected: 0000001 [-])", seg_data);

        $display("=================================================");
        $display(" Unit Verification Successfully Completed.");
        $display("=================================================");
        $finish;
    end

endmodule