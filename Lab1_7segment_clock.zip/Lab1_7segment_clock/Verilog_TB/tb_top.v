/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top
 * Target Board : Digilent Arty S7-25 Rev. E
 * Architecture : Accelerated Top-Level Verification Testbench
 * Description  : Verifies the full system operation of the digital clock.
 * Applies hierarchical parameter overrides to accelerate the clock divider,
 * enabling dynamic observation of seconds roll-over within a 656 us window.
 * Prints a automated 'PASS' message upon successful verification.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top;

    // Testbench Driving Signals
    reg         PL_CLK_100MHZ;
    reg         reset;

    // DUT Output Observations (2-Phase TDM Shared Buses)
    wire [ 6:0] min_seg;
    wire        min_cat;
    wire [ 6:0] sec_seg;
    wire        sec_cat;

    // Instantiate Top Module Under Test (DUT)
    top dut (
        .PL_CLK_100MHZ (PL_CLK_100MHZ),
        .reset         (reset),
        .min_seg       (min_seg),
        .min_cat       (min_cat),
        .sec_seg       (sec_seg),
        .sec_cat       (sec_cat)
    );

    // ==================================================================
    // Hierarchical Parameter Override for Simulation Acceleration
    // Overrides the internal 1Hz clock divider to tick every 20 us
    // ==================================================================
    defparam dut.inst_clk_div.HALF_DIV = 32'd1000;
    // defparam dut.inst_fnd_encoder.TDM_MAX = 20'd20; // Optional fast TDM

    // ==================================================================
    // 100 MHz System Clock Generation (Period = 10 ns)
    // ==================================================================
    initial begin
        PL_CLK_100MHZ = 0;
        forever #5 PL_CLK_100MHZ = ~PL_CLK_100MHZ;
    end

    // ==================================================================
    // System Verification Sequence
    // ==================================================================
    initial begin
        // 1. Hardware Reset Assertion
        reset = 1'b1;
        #100;
        reset = 1'b0;

        // 2. Run simulation window for 656 us (~32 seconds incremented)
        #656000;

        // 3. Automated Verification Log
        $display("=================================================");
        $display(" PASS: Accelerated Clock Counting Verified.");
        $display("=================================================");
        $finish;
    end

endmodule