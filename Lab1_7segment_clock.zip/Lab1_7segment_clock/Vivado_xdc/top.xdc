## ======================================================================
## Target Board : Digilent Arty S7-25 Rev. E (FPGA)
## Description  : 1x6 Split Cable Mapping (Top Rows Only for JA~JD)
## ======================================================================

set_property -dict { PACKAGE_PIN R2    IOSTANDARD SSTL135 } [get_ports { PL_CLK_100MHZ }]; #
create_clock -add -name sys_clk_pin -period 10.000 -waveform {0 5.000} [get_ports { PL_CLK_100MHZ }]; #
set_property -dict { PACKAGE_PIN G15   IOSTANDARD LVCMOS33 } [get_ports { reset }]; #

## ----------------------------------------------------------------------
## SSD #1 (Seconds): Uses JA Top Row + JB Top Row
## ----------------------------------------------------------------------
set_property -dict { PACKAGE_PIN L17   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[6] }]; # JA Pin 1 (A)
set_property -dict { PACKAGE_PIN L18   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[5] }]; # JA Pin 2 (B)
set_property -dict { PACKAGE_PIN M14   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[4] }]; # JA Pin 3 (C)
set_property -dict { PACKAGE_PIN N14   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[3] }]; # JA Pin 4 (D)
set_property -dict { PACKAGE_PIN P17   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[2] }]; # JB Pin 1 (E)
set_property -dict { PACKAGE_PIN P18   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[1] }]; # JB Pin 2 (F)
set_property -dict { PACKAGE_PIN R18   IOSTANDARD LVCMOS33 } [get_ports { sec_seg[0] }]; # JB Pin 3 (G)
set_property -dict { PACKAGE_PIN T18   IOSTANDARD LVCMOS33 } [get_ports { sec_cat    }]; # JB Pin 4 (CAT)

## ----------------------------------------------------------------------
## SSD #2 (Minutes): Uses JC Top Row + JD Top Row
## ----------------------------------------------------------------------
set_property -dict { PACKAGE_PIN U15   IOSTANDARD LVCMOS33 } [get_ports { min_seg[6] }]; # JC Pin 1 (A)
set_property -dict { PACKAGE_PIN V16   IOSTANDARD LVCMOS33 } [get_ports { min_seg[5] }]; # JC Pin 2 (B)
set_property -dict { PACKAGE_PIN U17   IOSTANDARD LVCMOS33 } [get_ports { min_seg[4] }]; # JC Pin 3 (C)
set_property -dict { PACKAGE_PIN U18   IOSTANDARD LVCMOS33 } [get_ports { min_seg[3] }]; # JC Pin 4 (D)
set_property -dict { PACKAGE_PIN V15   IOSTANDARD LVCMOS33 } [get_ports { min_seg[2] }]; # JD Pin 1 (E)
set_property -dict { PACKAGE_PIN U12   IOSTANDARD LVCMOS33 } [get_ports { min_seg[1] }]; # JD Pin 2 (F)
set_property -dict { PACKAGE_PIN V13   IOSTANDARD LVCMOS33 } [get_ports { min_seg[0] }]; # JD Pin 3 (G)
set_property -dict { PACKAGE_PIN T12   IOSTANDARD LVCMOS33 } [get_ports { min_cat    }]; # JD Pin 4 (CAT)

## Global Configuration
set_property BITSTREAM.CONFIG.CONFIGRATE 50 [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property CFGBVS VCCO [current_design]
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
set_property CONFIG_MODE SPIx4 [current_design]
set_property INTERNAL_VREF 0.675 [get_iobanks 34]