/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : fnd_encoder
 * Target Board : Digilent Arty S7-25 Rev. E
 * Architecture : 2-Phase Time-Division Multiplexing (TDM) Controller
 * Description  : Multiplexes 16-bit time data (MM:SS) onto shared 7-segment 
 * lines across two physical Pmod SSD modules. Alternates digit driving 
 * at 1 ms intervals (1 kHz refresh rate) to ensure flicker-free display.
 * ====================================================================== */

`timescale 1ns / 1ps

module fnd_encoder #(
    // Exposed as 'parameter' for flexible testbench acceleration
    parameter [19:0] TDM_MAX = 20'd100_000 
)(
    input  wire        clk_in,
    input  wire        reset,
    input  wire [15:0] data,       // BCD Input [15:0] = {Min10, Min1, Sec10, Sec1}
    output reg  [ 6:0] min_seg,    // To PMOD JC/JD Top Rows (Minutes)
    output reg         min_cat,    // Digit select cathode for Minutes
    output reg  [ 6:0] sec_seg,    // To PMOD JA/JB Top Rows (Seconds)
    output reg         sec_cat     // Digit select cathode for Seconds
);

    reg [19:0] cnt;
    reg        phase;

    wire [6:0] seg_sec1, seg_sec10, seg_min1, seg_min10;

    // Active-High 7-Segment Decoders (Mapping order: {A, B, C, D, E, F, G})
    hex2seg h_s1  (.hex(data[ 3: 0]), .seg_data(seg_sec1));
    hex2seg h_s10 (.hex(data[ 7: 4]), .seg_data(seg_sec10));
    hex2seg h_m1  (.hex(data[11: 8]), .seg_data(seg_min1));
    hex2seg h_m10 (.hex(data[15:12]), .seg_data(seg_min10));

    // Synchronous TDM Counter & Phase Toggle Logic
    always @(posedge clk_in or posedge reset) begin
        if (reset) begin
            cnt   <= 20'd0;
            phase <= 1'b0;
        end else begin
            if (cnt < (TDM_MAX - 20'd1)) begin
                cnt <= cnt + 20'd1;
            end else begin
                cnt   <= 20'd0;
                phase <= ~phase; // Toggle phase every refresh period
            end
        end
    end

    // Combinational 2-Phase Multiplexer Routing Logic
    always @(*) begin
        if (phase == 1'b0) begin
            // Phase 0: Drive Right Digits (1s unit, CAT = 0)
            sec_seg = seg_sec1;  sec_cat = 1'b0;
            min_seg = seg_min1;  min_cat = 1'b0;
        end else begin
            // Phase 1: Drive Left Digits (10s unit, CAT = 1)
            sec_seg = seg_sec10; sec_cat = 1'b1;
            min_seg = seg_min10; min_cat = 1'b1;
        end
    end

endmodule