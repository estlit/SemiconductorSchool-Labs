/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : sec_cnt
 * Target Board : Digilent Arty Series (Xilinx FPGA)
 * Architecture : Asynchronous BCD Counter Sub-module
 * Description  : 4-bit BCD counter (0~9) with active-high reset.
 * Generates a carry clock pulse (ten_clk) upon reaching 9.
 * ====================================================================== */

`timescale 1ns / 1ps

module sec_cnt(
    input wire       one_clk,
    input wire       reset,
    output reg [3:0] one,
    output reg       ten_clk
);
    always @(posedge one_clk or posedge reset) begin
        if (reset) begin
            one     <= 4'd0;
            ten_clk <= 1'b0;
        end else begin
            if (one < 4'd9) begin
                one     <= one + 4'd1;
                ten_clk <= 1'b0;
            end else begin
                one     <= 4'd0;
                ten_clk <= 1'b1; // Generate carry pulse for the next stage
            end
        end
    end
endmodule