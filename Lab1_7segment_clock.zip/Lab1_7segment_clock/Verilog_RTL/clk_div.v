/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : clk_div
 * Target Board : Digilent Arty Series (Xilinx FPGA)
 * Architecture : Hierarchical Timekeeping Counter Chain
 * Description  : Divides 100MHz system clock to generate 1Hz watch clock
 * and cascades BCD sub-counters to output 16-bit MM:SS data.
 * Uses 'HALF_DIV' parameter for hierarchy-clean overriding in testbench.
 * ====================================================================== */

`timescale 1ns / 1ps

module clk_div #(
    parameter HALF_DIV = 32'd50000000 // Default: 50M cycles (0.5 sec @ 100MHz)
)(
    input wire         clk_in,
    input wire         reset,
    output wire [15:0] data
);

    reg [31:0] counter;
    reg        sec_clk;

    wire tensec_clk;
    wire min_clk;
    wire tenmin_clk;

    // Main clock frequency divider logic
    always @(posedge clk_in or posedge reset) begin
        if (reset) begin
            counter <= 32'd0;
            sec_clk <= 1'b0;
        end else begin
            if (counter < (HALF_DIV - 32'd1)) begin
                counter <= counter + 32'd1;
            end else begin 
                counter <= 32'd0;
                sec_clk <= ~sec_clk;
            end        
        end
    end

    // Sub-counter cascade instantiations [MM:SS]
    sec_cnt one_sec (
        .one_clk(sec_clk), 
        .reset  (reset), 
        .one    (data[3:0]), 
        .ten_clk(tensec_clk)
    );

    min_cnt ten_sec (
        .ten_clk(tensec_clk), 
        .reset  (reset), 
        .ten    (data[7:4]), 
        .one_clk(min_clk)
    );

    sec_cnt one_min (
        .one_clk(min_clk), 
        .reset  (reset), 
        .one    (data[11:8]), 
        .ten_clk(tenmin_clk)
    );

    min_cnt ten_min (
        .one_clk(), 
        .ten_clk(tenmin_clk), 
        .reset  (reset), 
        .ten    (data[15:12])
    );

endmodule