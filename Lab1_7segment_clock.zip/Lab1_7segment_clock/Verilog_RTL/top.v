/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top
 * Target Board : Digilent Arty S7-25 Rev. E
 * Architecture : Top-Level Structural Domain Connector
 * Description  : Interconnects the internal clock divider and 2-Phase 
 * TDM FND encoder directly to the external 2-PMOD (JA/JB & JC/JD top 
 * rows) physical output interfaces for a 4-digit (MM:SS) display.
 * ====================================================================== */

`timescale 1ns / 1ps

module top (
    // System Clock and Reset
    input  wire       PL_CLK_100MHZ,
    input  wire       reset,
    
    // PMOD JC/JD Top Rows Interface (Minutes)
    output wire [6:0] min_seg, 
    output wire       min_cat,
    
    // PMOD JA/JB Top Rows Interface (Seconds)
    output wire [6:0] sec_seg, 
    output wire       sec_cat
);

    // Internal interconnect for 16-bit time data (MM:SS)
    wire [15:0] internal_data;

    // 1. Clock Divider Component Instantiation
    clk_div inst_clk_div (
        .clk_in  (PL_CLK_100MHZ),
        .reset   (reset),
        .data    (internal_data)
    );

    // 2. 2-Phase TDM Core Component Instantiation
    fnd_encoder inst_fnd_encoder (
        .clk_in  (PL_CLK_100MHZ),
        .reset   (reset),
        .data    (internal_data),
        .min_seg (min_seg),
        .min_cat (min_cat),
        .sec_seg (sec_seg),
        .sec_cat (sec_cat)
    );

endmodule