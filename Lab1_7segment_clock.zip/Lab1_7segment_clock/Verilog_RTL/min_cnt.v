/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : min_cnt
 * Target Board : Digilent Arty Series (Xilinx FPGA)
 * Architecture : Asynchronous Modulo-6 Counter Sub-module
 * Description  : 4-bit BCD counter (0~5) for tens of seconds and minutes.
 * Toggles output clock upon reaching 5 with active-high reset.
 * ====================================================================== */

`timescale 1ns / 1ps

module min_cnt(
    input wire       ten_clk,
    input wire       reset,
    output reg [3:0] ten,
    output reg       one_clk
);
    always @(posedge ten_clk or posedge reset) begin
        if (reset) begin
            ten     <= 4'd0;
            one_clk <= 1'b0;
        end else begin
            if (ten < 4'd5) begin
                ten     <= ten + 4'd1;
                one_clk <= 1'b0;
            end else begin
                ten     <= 4'd0;
                one_clk <= 1'b1; // Generate carry pulse for the next stage
            end
        end
    end
endmodule