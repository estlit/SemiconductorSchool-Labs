module twos_adder(x, y, c_in, sum, c_out); 
parameter N=4;
input     [N-1:0] x, y;    // declare as a 4-bit array
input     c_in;
output   [N-1:0] sum;   // declare as a 4-bit array
output   c_out;
wire      [N-1:0] t;        // outputs of xor gates

// Specify the function of a two's complement adder 
// addition when c_in=0, subtraction when c_in=1
    assign t = y ^ {N{c_in}}; 
    assign {c_out, sum} = x + t + c_in;
endmodule 
