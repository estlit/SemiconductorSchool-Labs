module dff_top(clk, rst_n, d, qs, qs_n, qa, qa_n);
input  clk, rst_n, d;
output qs, qs_n, qa, qa_n;

dff_sync  U1_DFF_S(.clk(clk), .rst_n(rst_n), .d(d), .q(qs), .q_n(qs_n));
dff_async U2_DFF_A(.clk(clk), .rst_n(rst_n), .d(d), .q(qa), .q_n(qa_n));
endmodule