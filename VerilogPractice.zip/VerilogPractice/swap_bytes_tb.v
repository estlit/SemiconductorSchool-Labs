// swap_bytes_tb.v
`timescale 1 ns/100 ps
module swap_bytes_tb;
parameter N=32;
reg  [N-1:0] x;
wire [N-1:0] y;
   swap_bytes U_swap(.in(x),.out(y));
   initial begin
	     x = 32'h9876_5432;
	#20  x = 32'h1234_abcd;
 	#20  x = 32'h0102_7531;
 	#20  $finish;        // end of simulation
   end
endmodule