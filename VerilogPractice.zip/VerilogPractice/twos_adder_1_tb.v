`timescale 1 ns/100 ps
module twos_adder_1_tb;
parameter N = 4;
reg  [N-1:0] a, b;
reg c_in;
wire [N-1:0] sum;
wire c_out;
integer i;
  twos_adder U_TADD(.x(a), .y(b), .c_in(c_in), .sum(sum), .c_out(c_out));
  initial begin
       a = 0; 
       b = 0; 
	    c_in = 0;  
  end
  always #20 a = a+1;
  initial for (i=0; i<16; i=i+1) 
              #20  b = 15-i;
  initial #320 c_in = 1;
  initial #640 $finish;   // required - always keeps running

endmodule
