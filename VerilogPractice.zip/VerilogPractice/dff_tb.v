`timescale 1 ns/100 ps

module dff_tb;

parameter N = 1;

reg  [N-1:0] d;
reg clk, rst_n;

wire [N-1:0] qs, qa, qs_n, qa_n;

dff_sync U1_DFF_S(
    .clk(clk), .rst_n(rst_n),
    .d(d), .q(qs), .q_n(qs_n)
);

dff_async U2_DFF_A(
    .clk(clk), .rst_n(rst_n),
    .d(d), .q(qa), .q_n(qa_n)
);

initial begin
    clk = 1'b0;
    rst_n = 1'b0;
    d = 1'b0;

    #20 rst_n = 1'b1;
    #20 d = 1'b1;
    #35 rst_n = 1'b0;
    #5  d = 1'b0;
    #15 rst_n = 1'b1;
    #25 d = 1'b1;
    #40 $finish;
end

always #10 clk = ~clk;

endmodule