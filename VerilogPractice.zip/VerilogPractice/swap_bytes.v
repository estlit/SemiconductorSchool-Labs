// swap_bytes.v
module swap_bytes (in, out);
parameter N=32;
input  [N-1:0] in;
output [N-1:0] out;
// using indexed part-select
assign out [31 -: 8] = in [0  +: 8],
	out [23 -: 8] = in [8  +: 8],
	out [15 -: 8] = in [16 +: 8],
	out [7  -: 8] = in [24 +: 8];
endmodule
