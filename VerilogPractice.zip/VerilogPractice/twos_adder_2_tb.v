`timescale 1 ns/100 ps
module twos_adder_2_tb;
parameter N = 4;
reg  [N-1:0] a, b;
reg c_in;
wire [N-1:0] sum;
wire c_out;
integer i, j;
  twos_adder U_TADD(.x(a), .y(b), .c_in(c_in), .sum(sum), .c_out(c_out));

  initial begin
	       a = 0; b = 0; c_in = 0; 
	       #20;
 	       for (i=0; i<16; i=i+1) begin
		      a = i;			       
 		      for (j=0; j<16;j=j+1) #20 b=b+1; 
 	       end
 	       a = 0; b = 0; c_in =1;     
 	       for (i=0; i<16; i=i+1) begin
		      a = i;
		      for (j=0; j<16;j=j+1) #20 b=b+1; 
 	       end
 	 end

endmodule
