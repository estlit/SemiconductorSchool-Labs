module dff_async(clk, rst_n, d, q, q_n); 
input clk, rst_n, d;    
output reg q;
output q_n;
assign q_n = ~q;
always @(posedge clk, negedge rst_n)
    if (!rst_n) q <= 0;
    else q <= d;
endmodule 

module dff_sync(clk, rst_n, d, q, q_n); 
input clk, rst_n, d;    
output reg q;
output q_n;
assign q_n = ~q;
always @(posedge clk)
    if (!rst_n) q <= 0;
    else q <= d;
endmodule 
