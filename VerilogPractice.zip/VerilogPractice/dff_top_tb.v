`timescale 1 ns/100 ps
module dff_top_tb;
reg  clk, rst_n, d;
wire qs, qs_n, qa, qa_n;

dff_top U_DFF_TOP(.clk(clk), .rst_n(rst_n), .d(d),
                  .qs(qs), .qs_n(qs_n), .qa(qa), .qa_n(qa_n));

initial begin
  clk = 1'b0; rst_n = 1'b0; d = 1'b0;   // initialization
  #100;                                  // wait for GSR release (post-synthesis simulation)
  #20 rst_n = 1'b1;
  #20 d = 1'b1;
  #35 rst_n = 1'b0;
  #5  d = 1'b0;
  #15 rst_n = 1'b1;
  #25 d = 1'b1;
  #40 $finish;
end
always #10 clk = ~clk;   // clock generator
endmodule