/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_cnn_arty_s7_4f (96x64 Line Classifier Top)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : BROM -> line_buffer_module (shift-register) -> 3x3 conv
 *                (4 kernels) -> ReLU/WTA feature sums -> Argmax -> LED.
 *                No fully-connected layer.
 * Description  : Streams one of four 96x64 grayscale images (selected by
 *                {SW1,SW0}) at one pixel per clock and classifies the line
 *                orientation by feature-sum Argmax.
 *
 *                Timing model (shares the verified Level-4 line buffer):
 *                  - Each BROM has a 1-clock registered read latency, so the
 *                    pixel pushed this clock corresponds to address pidx_d
 *                    (pidx delayed by one clock).
 *                  - line_buffer_module taps are combinational and its window
 *                    is centered LEAD = IMG_W+1 pixels behind the newest
 *                    pushed pixel. A window is therefore "center-active" once
 *                    pidx_d >= LEAD (i.e. after the buffer has been primed).
 *                  - conv is registered (1 clock); frame_start / frame_end
 *                    strobes are delayed one clock to line up with conv_valid.
 *
 *                Classes:  0 = horizontal (LD2), 1 = vertical (LD3),
 *                          2 = '/' (LD4),        3 = '\' (LD5)
 * ====================================================================== */

`timescale 1ns / 1ps

module top_cnn_arty_s7_4f (
    input  wire CLK12MHZ,   // F14, 12 MHz board clock
    input  wire BTN0,       // G15, active-high push button (reset)
    input  wire SW0,        // H14, image select bit 0
    input  wire SW1,        // H18, image select bit 1
    output wire LD2,        // E18, class 0 (horizontal)
    output wire LD3,        // F13, class 1 (vertical)
    output wire LD4,        // E13, class 2 ('/')
    output wire LD5         // H15, class 3 ('\')
);

    //==================================================================
    // 1) Reset synchronizer (BTN0 active-high -> internal active-high rst)
    //==================================================================
    reg [1:0] rst_sync_ff;
    always @(posedge CLK12MHZ) begin
        rst_sync_ff <= {rst_sync_ff[0], BTN0};
    end
    wire rst = rst_sync_ff[1];

    //==================================================================
    // 2) Frame parameters
    //==================================================================
    localparam integer IMG_W      = 96;
    localparam integer IMG_H      = 64;
    localparam integer IMG_PIXELS = IMG_W * IMG_H;   // 6144
    localparam integer ADDR_W     = 13;              // 2^13 = 8192 >= 6144
    localparam [ADDR_W-1:0] LEAD  = IMG_W + 1;       // 97, line-buffer center latency
    localparam [ADDR_W-1:0] LAST  = IMG_PIXELS - 1;  // 6143, last pixel index

    //==================================================================
    // 3) Pixel address counter (free running, one pixel per clock)
    //==================================================================
    reg [ADDR_W-1:0] pidx;
    always @(posedge CLK12MHZ) begin
        if (rst)
            pidx <= {ADDR_W{1'b0}};
        else if (pidx == IMG_PIXELS-1)
            pidx <= {ADDR_W{1'b0}};
        else
            pidx <= pidx + 1'b1;
    end

    //==================================================================
    // 4) Four image BROMs (loaded from external .mem files) + select mux
    //    Each BROM returns its pixel one clock after 'pidx' is applied.
    //==================================================================
    wire [7:0] pix0, pix1, pix2, pix3;
    wire [1:0] img_sel = {SW1, SW0};

    img_brom #(.ADDR_W(ADDR_W), .DEPTH(IMG_PIXELS), .MEM_FILE("img0.mem"))
        u_img0 (.clk(CLK12MHZ), .addr(pidx), .dout(pix0));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(IMG_PIXELS), .MEM_FILE("img1.mem"))
        u_img1 (.clk(CLK12MHZ), .addr(pidx), .dout(pix1));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(IMG_PIXELS), .MEM_FILE("img2.mem"))
        u_img2 (.clk(CLK12MHZ), .addr(pidx), .dout(pix2));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(IMG_PIXELS), .MEM_FILE("img3.mem"))
        u_img3 (.clk(CLK12MHZ), .addr(pidx), .dout(pix3));

    reg [7:0] pixel_mux;
    always @(*) begin
        case (img_sel)
            2'b00:   pixel_mux = pix0;
            2'b01:   pixel_mux = pix1;
            2'b10:   pixel_mux = pix2;
            2'b11:   pixel_mux = pix3;
            default: pixel_mux = pix0;
        endcase
    end

    //==================================================================
    // 5) Read-latency alignment.
    //    pidx_d is pidx delayed one clock; it is the raster index of the
    //    pixel returned by the BROM (pixel_mux) this clock. 'started' gates
    //    the pipeline on the first valid pixel after reset.
    //==================================================================
    reg [ADDR_W-1:0] pidx_d;
    reg              started;
    always @(posedge CLK12MHZ) begin
        if (rst) begin
            pidx_d  <= {ADDR_W{1'b0}};
            started <= 1'b0;
        end else begin
            pidx_d  <= pidx;
            started <= 1'b1;
        end
    end

    //==================================================================
    // 6) Stage-0 control (combinational, keyed on pidx_d)
    //    - win_valid  : a full 3x3 window is centered on a real pixel once
    //                   the buffer is primed (pidx_d >= LEAD).
    //    - frame_start: clears the feature accumulators (pidx_d == 0).
    //    - frame_end  : latches the frame result (pidx_d == last pixel).
    //==================================================================
    wire win_valid   = started & (pidx_d >= LEAD);
    wire frame_start = started & (pidx_d == {ADDR_W{1'b0}});
    wire frame_end   = started & (pidx_d == LAST);

    //==================================================================
    // 7) Line buffer (shared verified Level-4 module) + 3x3 conv (4 kernels)
    //==================================================================
    wire [7:0] w00, w01, w02;
    wire [7:0] w10, w11, w12;
    wire [7:0] w20, w21, w22;

    line_buffer_module #(.IMAGE_WIDTH(IMG_W)) u_lb (
        .clk(CLK12MHZ), .reset(rst), .shift_en(started), .data_in(pixel_mux),
        .w00(w00), .w01(w01), .w02(w02),
        .w10(w10), .w11(w11), .w12(w12),
        .w20(w20), .w21(w21), .w22(w22)
    );

    wire               conv_valid;
    wire signed [15:0] conv0, conv1, conv2, conv3;

    conv3x3_4filter u_conv (
        .clk       (CLK12MHZ),
        .rst       (rst),
        .win_valid (win_valid),
        .w00(w00), .w01(w01), .w02(w02),
        .w10(w10), .w11(w11), .w12(w12),
        .w20(w20), .w21(w21), .w22(w22),
        .conv_valid(conv_valid),
        .conv0(conv0), .conv1(conv1), .conv2(conv2), .conv3(conv3)
    );

    //==================================================================
    // 8) Align frame markers to the convolution output (conv = 1 clock).
    //==================================================================
    reg fs_d, fe_d;
    always @(posedge CLK12MHZ) begin
        if (rst) begin
            fs_d <= 1'b0;
            fe_d <= 1'b0;
        end else begin
            fs_d <= frame_start;
            fe_d <= frame_end;
        end
    end

    //==================================================================
    // 9) Feature accumulation (ReLU + WTA) + Argmax classifier
    //==================================================================
    wire [1:0]  class_idx;
    wire        class_valid;
    wire signed [31:0] feat0, feat1, feat2, feat3;   // for verification

    feat_argmax_4f u_feat (
        .clk        (CLK12MHZ),
        .rst        (rst),
        .frame_start(fs_d),
        .frame_end  (fe_d),
        .conv_valid (conv_valid),
        .conv0(conv0), .conv1(conv1), .conv2(conv2), .conv3(conv3),
        .class_idx  (class_idx),
        .class_valid(class_valid),
        .feat0(feat0), .feat1(feat1), .feat2(feat2), .feat3(feat3)
    );

    //==================================================================
    // 10) LED output (one-hot class indicator)
    //==================================================================
    assign LD2 = (class_idx == 2'd0);
    assign LD3 = (class_idx == 2'd1);
    assign LD4 = (class_idx == 2'd2);
    assign LD5 = (class_idx == 2'd3);

endmodule
