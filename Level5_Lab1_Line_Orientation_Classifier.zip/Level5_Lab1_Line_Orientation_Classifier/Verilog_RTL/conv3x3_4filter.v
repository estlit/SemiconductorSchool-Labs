/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : conv3x3_4filter (3x3 Convolution, 4 Fixed Kernels)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Parallel 3x3 multiply-accumulate with binary (0/1) weights
 * Description  : Applies four hand-designed 3x3 kernels (coefficients) to
 *                the incoming window: horizontal, vertical, '/', '\'.
 *                All weights are 0 or 1, so each output is a plain sum of
 *                the selected window pixels. Results conv0..conv3 are
 *                registered with a 1-clock latency.
 * ====================================================================== */

`timescale 1ns / 1ps

module conv3x3_4filter (
    input  wire        clk,
    input  wire        rst,
    input  wire        win_valid,
    input  wire [7:0]  w00, w01, w02,
    input  wire [7:0]  w10, w11, w12,
    input  wire [7:0]  w20, w21, w22,
    output reg         conv_valid,
    output reg signed [15:0] conv0,   // horizontal response
    output reg signed [15:0] conv1,   // vertical response
    output reg signed [15:0] conv2,   // '/' diagonal response
    output reg signed [15:0] conv3    // '\' diagonal response
);
    // Kernel coefficients (weights). Each is 0 or 1.
    // Filter0 : horizontal (middle row)
    localparam [0:0]
        F0_00 = 1'b0, F0_01 = 1'b0, F0_02 = 1'b0,
        F0_10 = 1'b1, F0_11 = 1'b1, F0_12 = 1'b1,
        F0_20 = 1'b0, F0_21 = 1'b0, F0_22 = 1'b0;

    // Filter1 : vertical (middle column)
    localparam [0:0]
        F1_00 = 1'b0, F1_01 = 1'b1, F1_02 = 1'b0,
        F1_10 = 1'b0, F1_11 = 1'b1, F1_12 = 1'b0,
        F1_20 = 1'b0, F1_21 = 1'b1, F1_22 = 1'b0;

    // Filter2 : '/' diagonal
    localparam [0:0]
        F2_00 = 1'b0, F2_01 = 1'b0, F2_02 = 1'b1,
        F2_10 = 1'b0, F2_11 = 1'b1, F2_12 = 1'b0,
        F2_20 = 1'b1, F2_21 = 1'b0, F2_22 = 1'b0;

    // Filter3 : '\' diagonal
    localparam [0:0]
        F3_00 = 1'b1, F3_01 = 1'b0, F3_02 = 1'b0,
        F3_10 = 1'b0, F3_11 = 1'b1, F3_12 = 1'b0,
        F3_20 = 1'b0, F3_21 = 1'b0, F3_22 = 1'b1;

    reg signed [15:0] s0, s1, s2, s3;

    always @(posedge clk) begin
        if (rst) begin
            conv_valid <= 1'b0;
            conv0      <= 16'sd0;
            conv1      <= 16'sd0;
            conv2      <= 16'sd0;
            conv3      <= 16'sd0;
        end else begin
            conv_valid <= win_valid;

            if (win_valid) begin
                // conv0 : horizontal sum
                s0 = 16'sd0;
                s0 = s0 + (F0_00 ? $signed({1'b0,w00}) : 16'sd0);
                s0 = s0 + (F0_01 ? $signed({1'b0,w01}) : 16'sd0);
                s0 = s0 + (F0_02 ? $signed({1'b0,w02}) : 16'sd0);
                s0 = s0 + (F0_10 ? $signed({1'b0,w10}) : 16'sd0);
                s0 = s0 + (F0_11 ? $signed({1'b0,w11}) : 16'sd0);
                s0 = s0 + (F0_12 ? $signed({1'b0,w12}) : 16'sd0);
                s0 = s0 + (F0_20 ? $signed({1'b0,w20}) : 16'sd0);
                s0 = s0 + (F0_21 ? $signed({1'b0,w21}) : 16'sd0);
                s0 = s0 + (F0_22 ? $signed({1'b0,w22}) : 16'sd0);

                // conv1 : vertical sum
                s1 = 16'sd0;
                s1 = s1 + (F1_00 ? $signed({1'b0,w00}) : 16'sd0);
                s1 = s1 + (F1_01 ? $signed({1'b0,w01}) : 16'sd0);
                s1 = s1 + (F1_02 ? $signed({1'b0,w02}) : 16'sd0);
                s1 = s1 + (F1_10 ? $signed({1'b0,w10}) : 16'sd0);
                s1 = s1 + (F1_11 ? $signed({1'b0,w11}) : 16'sd0);
                s1 = s1 + (F1_12 ? $signed({1'b0,w12}) : 16'sd0);
                s1 = s1 + (F1_20 ? $signed({1'b0,w20}) : 16'sd0);
                s1 = s1 + (F1_21 ? $signed({1'b0,w21}) : 16'sd0);
                s1 = s1 + (F1_22 ? $signed({1'b0,w22}) : 16'sd0);

                // conv2 : '/' diagonal sum
                s2 = 16'sd0;
                s2 = s2 + (F2_00 ? $signed({1'b0,w00}) : 16'sd0);
                s2 = s2 + (F2_01 ? $signed({1'b0,w01}) : 16'sd0);
                s2 = s2 + (F2_02 ? $signed({1'b0,w02}) : 16'sd0);
                s2 = s2 + (F2_10 ? $signed({1'b0,w10}) : 16'sd0);
                s2 = s2 + (F2_11 ? $signed({1'b0,w11}) : 16'sd0);
                s2 = s2 + (F2_12 ? $signed({1'b0,w12}) : 16'sd0);
                s2 = s2 + (F2_20 ? $signed({1'b0,w20}) : 16'sd0);
                s2 = s2 + (F2_21 ? $signed({1'b0,w21}) : 16'sd0);
                s2 = s2 + (F2_22 ? $signed({1'b0,w22}) : 16'sd0);

                // conv3 : '\' diagonal sum
                s3 = 16'sd0;
                s3 = s3 + (F3_00 ? $signed({1'b0,w00}) : 16'sd0);
                s3 = s3 + (F3_01 ? $signed({1'b0,w01}) : 16'sd0);
                s3 = s3 + (F3_02 ? $signed({1'b0,w02}) : 16'sd0);
                s3 = s3 + (F3_10 ? $signed({1'b0,w10}) : 16'sd0);
                s3 = s3 + (F3_11 ? $signed({1'b0,w11}) : 16'sd0);
                s3 = s3 + (F3_12 ? $signed({1'b0,w12}) : 16'sd0);
                s3 = s3 + (F3_20 ? $signed({1'b0,w20}) : 16'sd0);
                s3 = s3 + (F3_21 ? $signed({1'b0,w21}) : 16'sd0);
                s3 = s3 + (F3_22 ? $signed({1'b0,w22}) : 16'sd0);

                conv0 <= s0;
                conv1 <= s1;
                conv2 <= s2;
                conv3 <= s3;
            end
        end
    end
endmodule
