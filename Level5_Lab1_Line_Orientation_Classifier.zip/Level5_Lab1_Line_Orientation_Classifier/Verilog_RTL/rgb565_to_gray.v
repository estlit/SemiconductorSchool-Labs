/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : rgb565_to_gray (Level 4)
 * Description  : RGB565 -> 8-bit luma (Y8). Combinational.
 *                Y = (R8 + 2*G8 + B8) >> 2   (green-weighted, shift only)
 * ====================================================================== */
`timescale 1ns / 1ps

module rgb565_to_gray (
    input  wire [15:0] pixel_in,   // RGB565
    output wire [7:0]  gray_out    // Y8 (luma)
);
    wire [4:0] r5 = pixel_in[15:11];
    wire [5:0] g6 = pixel_in[10:5];
    wire [4:0] b5 = pixel_in[4:0];

    // 5/6/5 -> 8-bit expansion (replicate MSBs into LSBs)
    wire [7:0] r8 = {r5, r5[4:2]};
    wire [7:0] g8 = {g6, g6[5:4]};
    wire [7:0] b8 = {b5, b5[4:2]};

    // Y = (R + 2G + B) / 4 ; max = (255 + 510 + 255)/4 = 255
    wire [9:0] acc = r8 + (g8 << 1) + b8;   // 0..1020
    assign gray_out = acc[9:2];             // >> 2
endmodule
