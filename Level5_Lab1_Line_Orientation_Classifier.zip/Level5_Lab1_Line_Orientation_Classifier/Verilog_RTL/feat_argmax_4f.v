/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : feat_argmax_4f (Feature Accumulator + Argmax Classifier)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : ReLU -> Winner-Take-All accumulation -> Argmax
 * Description  : Per convolution position, applies ReLU to conv0..conv3,
 *                keeps only the single strongest channel (Winner-Take-All)
 *                and accumulates its value into that channel's frame sum.
 *                'frame_start' clears the sums; 'frame_end' latches them and
 *                selects the winning class by Argmax (no fully-connected
 *                layer). The control strobes are pre-aligned by the top to
 *                the convolution output stream.
 * ====================================================================== */

`timescale 1ns / 1ps

module feat_argmax_4f (
    input  wire        clk,
    input  wire        rst,
    input  wire        frame_start,   // aligned to conv stream: clear sums
    input  wire        frame_end,     // aligned to conv stream: latch + argmax
    input  wire        conv_valid,
    input  wire signed [15:0] conv0,
    input  wire signed [15:0] conv1,
    input  wire signed [15:0] conv2,
    input  wire signed [15:0] conv3,
    output reg  [1:0]  class_idx,
    output reg         class_valid,
    // Latched per-frame feature sums (exposed for verification/debug).
    output reg signed [31:0] feat0,
    output reg signed [31:0] feat1,
    output reg signed [31:0] feat2,
    output reg signed [31:0] feat3
);
    // Running accumulators for the current frame.
    reg signed [31:0] sum0, sum1, sum2, sum3;

    // Combinational scratch for ReLU + Winner-Take-All + next-sum.
    reg signed [15:0] v0, v1, v2, v3;   // ReLU outputs
    reg signed [15:0] mv;               // winner value
    reg        [1:0]  mi;               // winner index
    reg signed [31:0] add0, add1, add2, add3;   // one-hot contribution
    reg signed [31:0] ns0, ns1, ns2, ns3;       // next sums (this cycle applied)

    // Combinational scratch for Argmax over the latched sums.
    reg signed [31:0] best;
    reg        [1:0]  best_i;

    always @(*) begin
        // 1) ReLU: clip negatives to zero.
        v0 = (conv0 > 0) ? conv0 : 16'sd0;
        v1 = (conv1 > 0) ? conv1 : 16'sd0;
        v2 = (conv2 > 0) ? conv2 : 16'sd0;
        v3 = (conv3 > 0) ? conv3 : 16'sd0;

        // 2) Winner-Take-All: find the strongest channel at this position.
        mv = v0; mi = 2'd0;
        if (v1 > mv) begin mv = v1; mi = 2'd1; end
        if (v2 > mv) begin mv = v2; mi = 2'd2; end
        if (v3 > mv) begin mv = v3; mi = 2'd3; end

        // 3) One-hot contribution (only when a convolution result is valid).
        add0 = 32'sd0; add1 = 32'sd0; add2 = 32'sd0; add3 = 32'sd0;
        if (conv_valid) begin
            case (mi)
                2'd0: add0 = mv;
                2'd1: add1 = mv;
                2'd2: add2 = mv;
                2'd3: add3 = mv;
            endcase
        end

        // 4) Next sums: clear on frame_start, otherwise accumulate.
        ns0 = (frame_start ? 32'sd0 : sum0) + add0;
        ns1 = (frame_start ? 32'sd0 : sum1) + add1;
        ns2 = (frame_start ? 32'sd0 : sum2) + add2;
        ns3 = (frame_start ? 32'sd0 : sum3) + add3;
    end

    always @(posedge clk) begin
        if (rst) begin
            sum0 <= 32'sd0; sum1 <= 32'sd0; sum2 <= 32'sd0; sum3 <= 32'sd0;
            feat0 <= 32'sd0; feat1 <= 32'sd0; feat2 <= 32'sd0; feat3 <= 32'sd0;
            class_idx   <= 2'd0;
            class_valid <= 1'b0;
        end else begin
            // Advance the running accumulators.
            sum0 <= ns0; sum1 <= ns1; sum2 <= ns2; sum3 <= ns3;

            if (frame_end) begin
                // Latch the completed frame sums (ns includes this cycle).
                feat0 <= ns0; feat1 <= ns1; feat2 <= ns2; feat3 <= ns3;

                // Argmax over the frame sums -> class index.
                best = ns0; best_i = 2'd0;
                if (ns1 > best) begin best = ns1; best_i = 2'd1; end
                if (ns2 > best) begin best = ns2; best_i = 2'd2; end
                if (ns3 > best) begin best = ns3; best_i = 2'd3; end

                class_idx   <= best_i;
                class_valid <= 1'b1;
            end
        end
    end
endmodule
