/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : top_level5_lab1 (Level 5 Lab 1 integrated top)
 * Target Board : Digilent Arty S7-25 (XC7S25-1CSGA324C) + Pmod OLEDrgb
 * Architecture : Two independent clock domains
 *                  - 12 MHz  (F14) : line-orientation classifier -> LD2..LD5
 *                  - 100 MHz (R2)  : /16 -> SPI clock -> OLED shows the input
 * Description  : Combines the verified classifier (top_cnn_arty_s7_4f) with
 *                the verified OLED display path (oled_test + spi_master),
 *                reused verbatim. Roles are split so the two paths are almost
 *                independent:
 *                  - OLED   : shows the SELECTED input image only (no overlay)
 *                  - LD2..5 : shows the CLASS decision only (one-hot)
 *                The only shared signals are the two image-select switches
 *                {SW1,SW0}. They are static board inputs and are 2-FF
 *                synchronized separately in EACH clock domain; no multi-bit
 *                signal crosses between domains, so CDC risk is minimal.
 *                The OLED controller runs in grayscale passthrough (mode=0),
 *                so the display is the input image as-is (1-pixel black
 *                border from the valid-only window policy).
 * ====================================================================== */

`timescale 1ns / 1ps

module top_level5_lab1 #(
    // Shrink these in simulation via the testbench to skip the OLED power-up
    // and reset waits; leave at defaults for real hardware.
    parameter POWER_WAIT = 24'd2000000,
    parameter RESET_WAIT = 24'd500000
)(
    input  wire CLK12MHZ,     // F14, 12 MHz  (classifier domain)
    input  wire CLK100MHZ,    // R2, 100 MHz  (OLED domain)
    input  wire BTN0,         // G15, active-high reset
    input  wire SW0,          // H14, image select bit 0
    input  wire SW1,          // H18, image select bit 1

    output wire LD2,          // E18, class 0 (horizontal)
    output wire LD3,          // F13, class 1 (vertical)
    output wire LD4,          // E13, class 2 ('/')
    output wire LD5,          // H15, class 3 ('\')

    // Pmod OLEDrgb (SSD1331) on Pmod JA
    output wire oled_cs_n,
    output wire oled_mosi,
    output wire oled_sck,
    output wire oled_dc,
    output wire oled_res,
    output wire oled_vccen,
    output wire oled_pmoden
);

    wire reset = BTN0;   // async reset for the OLED domain (reference style)

    //==================================================================
    // A) 12 MHz classifier domain
    //==================================================================
    // Synchronize the image-select switches into the 12 MHz domain.
    reg [1:0] sw0_c, sw1_c;
    always @(posedge CLK12MHZ) begin
        sw0_c <= {sw0_c[0], SW0};
        sw1_c <= {sw1_c[0], SW1};
    end

    // Verified classifier reused verbatim; drives LD2..LD5 (class one-hot).
    top_cnn_arty_s7_4f u_cls (
        .CLK12MHZ(CLK12MHZ),
        .BTN0    (BTN0),
        .SW0     (sw0_c[1]),
        .SW1     (sw1_c[1]),
        .LD2(LD2), .LD3(LD3), .LD4(LD4), .LD5(LD5)
    );

    //==================================================================
    // B) OLED domain : 100 MHz / 16 -> 6.25 MHz SPI clock
    //    (ripple-divided derived clock, identical to the verified reference)
    //==================================================================
    reg [3:0] div_cnt;
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    wire spi_clk = div_cnt[3];

    // Synchronize the image-select switches into the OLED (spi_clk) domain.
    reg [1:0] sw0_o, sw1_o;
    always @(posedge spi_clk) begin
        sw0_o <= {sw0_o[0], SW0};
        sw1_o <= {sw1_o[0], SW1};
    end
    wire [1:0] oled_sel = {sw1_o[1], sw0_o[1]};

    // OLED image source (RGB565, 1-clock latency).
    wire [12:0] oled_pix_addr;
    wire [15:0] rom_data;
    oled_gray_rom_rgb565 #(.ADDR_W(13), .DEPTH(6144)) u_orom (
        .clk (spi_clk),
        .addr(oled_pix_addr),
        .sel (oled_sel),
        .data(rom_data)
    );

    // SPI master (SSD1331, Mode 3, MSB first).
    wire       spi_start, spi_busy;
    wire [7:0] spi_data;
    spi_master u_spi (
        .clk(spi_clk), .reset(reset),
        .start(spi_start), .data_in(spi_data), .busy(spi_busy),
        .sclk(oled_sck), .mosi(oled_mosi), .cs_n(oled_cs_n)
    );

    // OLED controller in grayscale passthrough (mode=0): display input as-is.
    oled_test #(.H_RES(96), .V_RES(64),
                .POWER_WAIT(POWER_WAIT), .RESET_WAIT(RESET_WAIT)) u_oled (
        .clk(spi_clk), .reset(reset),
        .spi_start(spi_start), .spi_data(spi_data), .spi_busy(spi_busy),
        .oled_dc(oled_dc), .oled_res(oled_res),
        .oled_vccen(oled_vccen), .oled_pmoden(oled_pmoden),
        .rom_addr(oled_pix_addr), .rom_data(rom_data),
        .mode(3'd0)
    );

endmodule
