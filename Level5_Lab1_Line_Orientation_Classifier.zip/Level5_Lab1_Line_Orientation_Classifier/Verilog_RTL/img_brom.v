/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : img_brom (Image Block ROM)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Single-port synchronous ROM initialized by $readmemh
 * Description  : 8-bit grayscale image ROM for the 96x64 line classifier.
 *                Contents are loaded from an external HEX ".mem" file
 *                (idx = y*96 + x). Registered read gives a 1-clock latency,
 *                which the top module compensates by delaying the pixel
 *                coordinates (x,y) by one clock.
 * ====================================================================== */

`timescale 1ns / 1ps

module img_brom #(
    parameter integer ADDR_W   = 13,          // 2^13 = 8192 >= 6144
    parameter integer DEPTH    = 6144,        // 96 * 64
    parameter         MEM_FILE = "img0.mem"   // HEX file loaded by $readmemh
)(
    input  wire              clk,
    input  wire [ADDR_W-1:0] addr,
    output reg  [7:0]        dout
);

    // Memory array holding one 8-bit pixel per address.
    reg [7:0] mem [0:DEPTH-1];

    // Load image contents from the external HEX file at elaboration time.
    initial begin
        $readmemh(MEM_FILE, mem);
    end

    // Registered read: dout is valid one clock after 'addr' is presented.
    always @(posedge clk) begin
        dout <= mem[addr];
    end

endmodule
