/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : conv_proc_core (Level 4 - full 8 modes)
 * Description  : 3x3 windowed processing, combinational, saturation inline.
 *                All integer math verified bit-exact vs numpy reference AND
 *                vs the on-board Vivado run (mode1 center = 6B4D).
 *   000 grayscale : center passthrough
 *   001 box blur  : (Sum9 * 29) >> 8            (~ /9)
 *   010 gaussian  : (1 2 1 / 2 4 2 / 1 2 1) >> 4  (/16)
 *   011 sharpen   : 9*center - Sum(8 neighbors)   (clamp 0..255)
 *   100 sobel X   : |Gx|                          (clamp 255)
 *   101 sobel Y   : |Gy|                          (clamp 255)
 *   110 magnitude : |Gx| + |Gy|                   (clamp 255)
 *   111 threshold : |Gx|+|Gy| (sat8) > THRESH ? 255 : 0
 * ====================================================================== */
`timescale 1ns / 1ps

module conv_proc_core #(
    parameter [7:0] THRESH = 8'd64
)(
    input  wire [2:0] mode,
    input  wire [7:0] w00, input wire [7:0] w01, input wire [7:0] w02,
    input  wire [7:0] w10, input wire [7:0] w11, input wire [7:0] w12,
    input  wire [7:0] w20, input wire [7:0] w21, input wire [7:0] w22,
    output reg  [7:0] out8
);
    // ---- shared sums ----
    wire [11:0] sum9 = w00 + w01 + w02 + w10 + w11 + w12 + w20 + w21 + w22; // 0..2295

    // ---- 001 box blur : (sum9 * 29) >> 8 ----
    wire [19:0] box_scaled = sum9 * 20'd29;
    wire [11:0] box_v      = box_scaled[19:8];
    wire [7:0]  box_out    = (box_v > 12'd255) ? 8'd255 : box_v[7:0];

    // ---- 010 gaussian : weighted >> 4 ----
    wire [12:0] g_acc = w00 + (w01<<1) + w02
                      + (w10<<1) + (w11<<2) + (w12<<1)
                      + w20 + (w21<<1) + w22;               // 0..4080
    wire [8:0]  g_v   = g_acc[12:4];                        // /16 -> 0..255
    wire [7:0]  gauss_out = (g_v > 9'd255) ? 8'd255 : g_v[7:0];

    // ---- 011 sharpen : 9*center - (sum9 - center) ----
    wire [11:0] neigh8 = sum9 - w11;                        // 0..2040
    wire [11:0] w11x9  = w11 * 9;                           // 0..2295
    wire signed [13:0] sharp = $signed({2'd0, w11x9}) - $signed({2'd0, neigh8});
    wire [7:0]  sharp_out = (sharp < 0)   ? 8'd0   :
                            (sharp > 255) ? 8'd255 : sharp[7:0];

    // ---- 100/101 sobel ----
    wire [10:0] sx_pos = w02 + (w12<<1) + w22;              // right col
    wire [10:0] sx_neg = w00 + (w10<<1) + w20;              // left  col
    wire signed [12:0] gx = $signed({2'b00, sx_pos}) - $signed({2'b00, sx_neg});
    wire [11:0] agx = gx[12] ? (~gx + 1'b1) : gx[11:0];     // |Gx| 0..1020

    wire [10:0] sy_pos = w20 + (w21<<1) + w22;              // bottom row
    wire [10:0] sy_neg = w00 + (w01<<1) + w02;              // top    row
    wire signed [12:0] gy = $signed({2'b00, sy_pos}) - $signed({2'b00, sy_neg});
    wire [11:0] agy = gy[12] ? (~gy + 1'b1) : gy[11:0];     // |Gy| 0..1020

    wire [7:0] sobx_out = (agx > 12'd255) ? 8'd255 : agx[7:0];
    wire [7:0] soby_out = (agy > 12'd255) ? 8'd255 : agy[7:0];

    // ---- 110 magnitude / 111 threshold ----
    wire [12:0] mag     = agx + agy;                        // 0..2040
    wire [7:0]  mag_out = (mag > 13'd255) ? 8'd255 : mag[7:0];
    wire [7:0]  thr_out = (mag_out > THRESH) ? 8'd255 : 8'd0;

    // ---- output MUX ----
    always @(*) begin
        case (mode)
            3'd0: out8 = w11;
            3'd1: out8 = box_out;
            3'd2: out8 = gauss_out;
            3'd3: out8 = sharp_out;
            3'd4: out8 = sobx_out;
            3'd5: out8 = soby_out;
            3'd6: out8 = mag_out;
            3'd7: out8 = thr_out;
            default: out8 = w11;
        endcase
    end
endmodule
