/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_level5_lab1 (Integrated dual-clock testbench)
 * Target Board : Digilent Arty S7-25 (simulation only)
 * Architecture : Two clocks (12 MHz classifier, 100 MHz OLED) + checks
 * Description  : Verifies the integrated Level 5 Lab 1 design:
 *   (1) .mem self-check (files present in the xsim working dir).
 *   (2) OLED path actually runs: init completes and pixel streaming starts;
 *       one full display frame (image 0) is dumped to 'oled_dump.txt' as
 *       (pix_index, RGB565) so it can be reconstructed and compared to the
 *       input by python (python/oled_frame_check.py).
 *   (3) Classifier regression: after the OLED dump, cycle {SW1,SW0}=0..3 and
 *       confirm the class one-hot (LD2..LD5) still matches the expected class
 *       (integration must not break the verified classifier).
 *
 * SW is held at 00 until the OLED frame dump finishes, so the dumped frame
 * is image 0 (horizontal). Requires img0..img3.mem in the xsim working dir.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_level5_lab1;

    // ---- Clocks ----
    reg CLK12MHZ = 1'b0;   always #41.666 CLK12MHZ  = ~CLK12MHZ;  // 12 MHz
    reg CLK100MHZ = 1'b0;  always #5.000  CLK100MHZ = ~CLK100MHZ; // 100 MHz

    reg BTN0 = 1'b0, SW0 = 1'b0, SW1 = 1'b0;
    wire LD2, LD3, LD4, LD5;
    wire oled_cs_n, oled_mosi, oled_sck, oled_dc, oled_res, oled_vccen, oled_pmoden;

    // Shrink OLED power/reset waits so simulation reaches pixel streaming fast.
    top_level5_lab1 #(.POWER_WAIT(24'd50), .RESET_WAIT(24'd20)) dut (
        .CLK12MHZ(CLK12MHZ), .CLK100MHZ(CLK100MHZ),
        .BTN0(BTN0), .SW0(SW0), .SW1(SW1),
        .LD2(LD2), .LD3(LD3), .LD4(LD4), .LD5(LD5),
        .oled_cs_n(oled_cs_n), .oled_mosi(oled_mosi), .oled_sck(oled_sck),
        .oled_dc(oled_dc), .oled_res(oled_res),
        .oled_vccen(oled_vccen), .oled_pmoden(oled_pmoden)
    );

    // Convenient probes
    wire spi_clk = dut.spi_clk;
    wire [1:0]  cls = dut.u_cls.u_feat.class_idx;
    wire signed [31:0] f0=dut.u_cls.u_feat.feat0, f1=dut.u_cls.u_feat.feat1,
                       f2=dut.u_cls.u_feat.feat2, f3=dut.u_cls.u_feat.feat3;

    // ------------------------------------------------------------------
    // .mem self-check (same relative paths as the DUT)
    // ------------------------------------------------------------------
    reg [7:0] chk [0:6143];
    integer i, nx, nz;
    initial begin
        #1;
        $display("==================== MEM FILE SELF-CHECK ====================");
        for (i=0;i<6144;i=i+1) chk[i]=8'hxx; $readmemh("img0.mem", chk);
        nx=0; nz=0; for (i=0;i<6144;i=i+1) if (chk[i]===8'hxx) nx=nx+1; else if (chk[i]!==8'h00) nz=nz+1;
        $display(" img0.mem : X=%0d nonzero=%0d", nx, nz);
        if (nx==6144) $display("   >>> img0.mem NOT FOUND (copy img*.mem into the xsim working dir)");
        $display("============================================================");
    end

    // ------------------------------------------------------------------
    // OLED frame dump : one full frame of image 0 -> oled_dump.txt
    // Sample (pix_index, px565_r) once per pixel when the controller enters
    // ST_SEND_PIX_HI (=5'd11).
    // ------------------------------------------------------------------
    localparam [4:0] ST_SEND_PIX_HI = 5'd11;
    integer fd, dumped = 0;
    reg [4:0] prev_state = 5'd0;
    reg oled_dump_done = 1'b0;
    reg oled_stream_seen = 1'b0;

    initial fd = $fopen("oled_dump.txt", "w");

    always @(posedge spi_clk) begin
        prev_state <= dut.u_oled.state;
        if (dut.u_oled.state == ST_SEND_PIX_HI && prev_state != ST_SEND_PIX_HI) begin
            if (!oled_stream_seen) begin
                oled_stream_seen <= 1'b1;
                $display("[%0t] OLED pixel streaming started (dc=%b cs_n=%b)", $time, oled_dc, oled_cs_n);
            end
            if (dumped < 6144) begin
                $fwrite(fd, "%0d %04x\n", dut.u_oled.pix_index, dut.u_oled.px565_r);
                dumped = dumped + 1;
                if ((dumped % 1024) == 0)
                    $display("[%0t] OLED dump progress: %0d/6144", $time, dumped);
                if (dumped == 6144) begin
                    $fclose(fd);
                    oled_dump_done <= 1'b1;
                    $display("[%0t] OLED frame dump complete -> oled_dump.txt (image 0)", $time);
                end
            end
        end
    end

    // ------------------------------------------------------------------
    // Main sequence
    // ------------------------------------------------------------------
    integer sel, errors = 0;

    // Safety timeout (OLED full frame at 6.25 MHz SPI is the long pole).
    initial begin
        #120_000_000;   // 120 ms
        $display(">>> TIMEOUT");
        $finish;
    end

    initial begin
        $timeformat(-9, 0, " ns", 8);
        // Reset, keep image 0 selected for the OLED dump.
        BTN0 = 1'b1; SW0 = 1'b0; SW1 = 1'b0;
        repeat (20) @(posedge CLK100MHZ);
        BTN0 = 1'b0;

        // Wait for the OLED to finish dumping one full frame of image 0.
        wait (oled_dump_done == 1'b1);
        $display("------------------------------------------------------------");
        $display(" OLED path: init + 6144-pixel frame streamed OK (image 0).");
        $display(" Reconstruct/compare with python/oled_frame_check.py");
        $display("------------------------------------------------------------");

        // Classifier regression: cycle images, check one-hot LEDs.
        for (sel = 0; sel < 4; sel = sel + 1) begin
            {SW1, SW0} = sel[1:0];
            @(posedge dut.u_cls.fe_d);   // let synced SW take effect + one frame
            @(posedge dut.u_cls.fe_d);
            @(posedge CLK12MHZ);
            $display(" SW=%b%b  class=%0d  LD2=%b LD3=%b LD4=%b LD5=%b  feat H=%0d V=%0d /=%0d \\=%0d",
                     SW1, SW0, cls, LD2, LD3, LD4, LD5, f0, f1, f2, f3);
            if (cls === sel[1:0]) $display("   classifier RESULT : PASS");
            else begin $display("   classifier RESULT : FAIL (exp %0d)", sel[1:0]); errors = errors + 1; end
        end

        if (errors == 0) $display(">>> CLASSIFIER: ALL 4 PASSED  |  OLED: frame streamed & dumped");
        else             $display(">>> CLASSIFIER: %0d FAILED", errors);
        $finish;
    end

endmodule
