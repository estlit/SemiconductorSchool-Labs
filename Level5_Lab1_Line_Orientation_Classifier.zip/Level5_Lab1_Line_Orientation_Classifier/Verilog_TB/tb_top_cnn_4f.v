/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : tb_top_cnn_4f (Diagnostic Testbench, full probing)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7) -- simulation only
 * Architecture : Self-checking + heavy internal probing
 * Description  : Verifies the 96x64 line classifier and, when it misbehaves,
 *                makes the cause visible. It (1) self-checks that img0..img3
 *                .mem load from the xsim working directory, (2) exposes the
 *                whole pipeline (pidx/pidx_d, pixel_mux, window, conv, feats,
 *                class) as named waveform signals, (3) flags any X on the
 *                pixel stream, (4) counts valid windows per frame, and
 *                (5) reports feats + predicted class per image, waiting on
 *                real frame boundaries instead of fixed delays.
 *
 * NOTE: $readmemh resolves relative to the xsim run dir
 *       (<proj>.sim/sim_1/behav/xsim). Copy img0..img3.mem there.
 * ====================================================================== */

`timescale 1ns / 1ps

module tb_top_cnn_4f;

    // 12 MHz clock -> period 83.33 ns -> half period 41.666 ns
    reg CLK12MHZ = 1'b0;
    always #41.666 CLK12MHZ = ~CLK12MHZ;

    reg BTN0 = 1'b0, SW0 = 1'b0, SW1 = 1'b0;
    wire LD2, LD3, LD4, LD5;

    top_cnn_arty_s7_4f dut (
        .CLK12MHZ(CLK12MHZ), .BTN0(BTN0), .SW0(SW0), .SW1(SW1),
        .LD2(LD2), .LD3(LD3), .LD4(LD4), .LD5(LD5)
    );

    // ------------------------------------------------------------------
    // Pipeline probes (hierarchical) -> shown as named waves
    // ------------------------------------------------------------------
    wire [12:0] pidx      = dut.pidx;
    wire [12:0] pidx_d    = dut.pidx_d;
    wire        started   = dut.started;
    wire [7:0]  pixel_mux = dut.pixel_mux;
    wire [1:0]  img_sel   = dut.img_sel;
    wire [7:0]  pix0      = dut.pix0;

    wire        win_valid   = dut.win_valid;
    wire        frame_start = dut.frame_start;
    wire        frame_end   = dut.frame_end;
    wire        fs_d        = dut.fs_d;
    wire        fe_d        = dut.fe_d;

    // 3x3 window (center + corners) from the shared line buffer
    wire [7:0]  w00 = dut.w00, w11 = dut.w11, w22 = dut.w22;

    wire        conv_valid = dut.conv_valid;
    wire signed [15:0] conv0 = dut.conv0, conv1 = dut.conv1,
                       conv2 = dut.conv2, conv3 = dut.conv3;

    // Accumulators (running) + latched feature sums + class
    wire signed [31:0] sum0 = dut.u_feat.sum0, sum1 = dut.u_feat.sum1,
                       sum2 = dut.u_feat.sum2, sum3 = dut.u_feat.sum3;
    wire signed [31:0] f0 = dut.u_feat.feat0, f1 = dut.u_feat.feat1,
                       f2 = dut.u_feat.feat2, f3 = dut.u_feat.feat3;
    wire [1:0]  cls         = dut.u_feat.class_idx;
    wire        class_valid = dut.u_feat.class_valid;

    // ------------------------------------------------------------------
    // Per-frame counters: how many valid windows / conv results
    // ------------------------------------------------------------------
    integer wcnt = 0, ccnt = 0;
    always @(posedge CLK12MHZ) begin
        if (frame_start) begin wcnt <= 0; ccnt <= 0; end
        else begin
            if (win_valid)  wcnt <= wcnt + 1;
            if (conv_valid) ccnt <= ccnt + 1;
        end
    end

    // ------------------------------------------------------------------
    // X-detector on the pixel stream (fires once): catches unloaded .mem
    // ------------------------------------------------------------------
    reg xflagged = 1'b0;
    always @(posedge CLK12MHZ) begin
        if (win_valid && ((^pixel_mux) === 1'bx) && !xflagged) begin
            $display("[%0t] *** window pixel = X -> .mem NOT loaded (pix0=%h). Copy img*.mem into the xsim working dir.",
                     $time, pix0);
            xflagged <= 1'b1;
        end
    end

    // ------------------------------------------------------------------
    // Independent .mem self-check (uses the SAME relative paths as the DUT)
    // ------------------------------------------------------------------
    reg [7:0] chk [0:6143];
    integer i, nx, nz;
    initial begin
        #1;
        $display("==================== MEM FILE SELF-CHECK ====================");
        // img0
        for (i=0;i<6144;i=i+1) chk[i]=8'hxx;
        $readmemh("img0.mem", chk); nx=0; nz=0;
        for (i=0;i<6144;i=i+1) if (chk[i]===8'hxx) nx=nx+1; else if (chk[i]!==8'h00) nz=nz+1;
        $display(" img0.mem : X=%0d nonzero=%0d [0]=%h", nx, nz, chk[0]);
        if (nx==6144) $display("   >>> img0.mem NOT FOUND (all X)");
        // img1
        for (i=0;i<6144;i=i+1) chk[i]=8'hxx;
        $readmemh("img1.mem", chk); nx=0; nz=0;
        for (i=0;i<6144;i=i+1) if (chk[i]===8'hxx) nx=nx+1; else if (chk[i]!==8'h00) nz=nz+1;
        $display(" img1.mem : X=%0d nonzero=%0d [0]=%h", nx, nz, chk[0]);
        if (nx==6144) $display("   >>> img1.mem NOT FOUND (all X)");
        // img2
        for (i=0;i<6144;i=i+1) chk[i]=8'hxx;
        $readmemh("img2.mem", chk); nx=0; nz=0;
        for (i=0;i<6144;i=i+1) if (chk[i]===8'hxx) nx=nx+1; else if (chk[i]!==8'h00) nz=nz+1;
        $display(" img2.mem : X=%0d nonzero=%0d [0]=%h", nx, nz, chk[0]);
        if (nx==6144) $display("   >>> img2.mem NOT FOUND (all X)");
        // img3
        for (i=0;i<6144;i=i+1) chk[i]=8'hxx;
        $readmemh("img3.mem", chk); nx=0; nz=0;
        for (i=0;i<6144;i=i+1) if (chk[i]===8'hxx) nx=nx+1; else if (chk[i]!==8'h00) nz=nz+1;
        $display(" img3.mem : X=%0d nonzero=%0d [0]=%h", nx, nz, chk[0]);
        if (nx==6144) $display("   >>> img3.mem NOT FOUND (all X)");
        $display("============================================================");
    end

    // ------------------------------------------------------------------
    // Stimulus: reset, then each image; wait on real frame boundaries
    // ------------------------------------------------------------------
    integer sel, errors = 0;

    // Global safety timeout
    initial begin
        #20_000_000;   // 20 ms hard stop
        $display(">>> TIMEOUT: simulation did not finish in 20 ms");
        $finish;
    end

    initial begin
        $timeformat(-9, 0, " ns", 8);   // %t prints in ns
        BTN0 = 1'b1;
        repeat (8) @(posedge CLK12MHZ);
        BTN0 = 1'b0;

        for (sel = 0; sel < 4; sel = sel + 1) begin
            {SW1, SW0} = sel[1:0];

            // Let the newly selected image flush fully through the pipeline:
            // wait for two complete frame_end pulses, then settle one clock.
            @(posedge fe_d);
            @(posedge fe_d);
            @(posedge CLK12MHZ);

            $display("========================================================");
            $display(" SW1SW0 = %b%b   (expected class %0d)", SW1, SW0, sel[1:0]);
            $display("   windows/frame  wcnt=%0d  ccnt=%0d   (expect ~%0d)",
                     wcnt, ccnt, 6144-97);
            $display("   feat  H=%0d  V=%0d  /=%0d  \\=%0d", f0, f1, f2, f3);
            $display("   class=%0d valid=%b  LD2=%b LD3=%b LD4=%b LD5=%b",
                     cls, class_valid, LD2, LD3, LD4, LD5);
            if (cls === sel[1:0])
                $display("   RESULT : PASS");
            else begin
                $display("   RESULT : FAIL (expected %0d, got %0d)", sel[1:0], cls);
                errors = errors + 1;
            end
            $display("========================================================");
        end

        if (errors == 0) $display(">>> ALL 4 CLASSES PASSED");
        else             $display(">>> %0d CLASS(ES) FAILED", errors);
        $finish;
    end

endmodule
