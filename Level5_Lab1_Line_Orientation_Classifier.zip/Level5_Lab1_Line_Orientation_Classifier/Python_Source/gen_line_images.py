# ======================================================================
# Welcome to 'Semiconductor School'
# Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
# Module       : gen_line_images (Dataset / Memory-Init Generator)
# Target Board : Digilent Arty S7 (Xilinx Spartan-7)
# Architecture : Host-side image baker for BROM $readmemh initialization
# Description  : Generates four 96x64 grayscale line images (horizontal,
#                vertical, '/', '\') on a centered 40x40 region. For each
#                class it emits an 8-bit HEX ".mem" file (6144 entries,
#                idx = y*96 + x) for Verilog $readmemh, plus scaled PNG
#                previews and a 2x2 summary image for visual verification.
# ======================================================================

from PIL import Image, ImageDraw, ImageFont

# ---------------- Geometry parameters ----------------
W = 96                  # image width  (columns)
H = 64                  # image height (rows)
N = W * H               # 6144 total pixels = number of .mem lines

X0, X1 = 28, 67         # line-region x range (inclusive) -> 40 columns
Y0, Y1 = 12, 51         # line-region y range (inclusive) -> 40 rows
XC = (X0 + X1) // 2     # 47  (vertical-line center column)
YC = (Y0 + Y1) // 2     # 31  (horizontal-line center row)
SIZE = X1 - X0          # 39  (region edge length minus 1; diagonal base)

FG = 0xFF               # foreground (line) value
BG = 0x00               # background value
THICK = 1               # half thickness (+-1 -> 3 pixels)

SCALE = 6               # PNG upscale factor for visibility (96x64 -> 576x384)

# ---------------- .mem banner (readmemh-safe // comments) ----------------
MEM_BANNER = [
    "// ======================================================================",
    "// Welcome to 'Semiconductor School'",
    "// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.",
    "// File format  : 8-bit HEX, one value per line, idx = y*96 + x",
    "// Canvas       : 96x64, background 0x00, line 0xFF",
    "// ======================================================================",
]


# ---------------- Image builders ----------------
def blank():
    """Return an H x W 2-D list filled with the background value."""
    return [[BG for _ in range(W)] for _ in range(H)]


def make_horizontal():
    """Class 0: centered horizontal line (rows YC-1..YC+1)."""
    img = blank()
    for y in range(Y0, Y1 + 1):
        for x in range(X0, X1 + 1):
            if abs(y - YC) <= THICK:
                img[y][x] = FG
    return img


def make_vertical():
    """Class 1: centered vertical line (cols XC-1..XC+1)."""
    img = blank()
    for y in range(Y0, Y1 + 1):
        for x in range(X0, X1 + 1):
            if abs(x - XC) <= THICK:
                img[y][x] = FG
    return img


def make_slash():
    """Class 2: '/' anti-diagonal, bottom-left to top-right."""
    img = blank()
    for y in range(Y0, Y1 + 1):
        for x in range(X0, X1 + 1):
            if abs((x - X0) + (y - Y0) - SIZE) <= THICK:
                img[y][x] = FG
    return img


def make_backslash():
    """Class 3: '\\' main diagonal, top-left to bottom-right."""
    img = blank()
    for y in range(Y0, Y1 + 1):
        for x in range(X0, X1 + 1):
            if abs((x - X0) - (y - Y0)) <= THICK:
                img[y][x] = FG
    return img


# ---------------- Writers ----------------
def write_mem(img, path):
    """Write readmemh HEX file with a // banner; returns hex-token count."""
    tokens = 0
    with open(path, "w") as f:
        for line in MEM_BANNER:
            f.write(line + "\n")
        for y in range(H):
            for x in range(W):
                f.write("%02x\n" % img[y][x])
                tokens += 1
    return tokens


def write_png(img, path, label):
    """Save a nearest-neighbor upscaled PNG with a caption strip."""
    base = Image.new("L", (W, H))
    base.putdata([img[y][x] for y in range(H) for x in range(W)])
    big = base.resize((W * SCALE, H * SCALE), Image.NEAREST).convert("RGB")

    # caption strip on top
    strip_h = 26
    canvas = Image.new("RGB", (big.width, big.height + strip_h), (245, 245, 245))
    canvas.paste(big, (0, strip_h))
    d = ImageDraw.Draw(canvas)
    d.text((8, 6), label, fill=(15, 39, 51))
    canvas.save(path)


def write_grid(items, path):
    """Compose a labeled 2x2 grid of all four class previews."""
    tiles = []
    for _, _, kor_en, img in items:
        base = Image.new("L", (W, H))
        base.putdata([img[y][x] for y in range(H) for x in range(W)])
        big = base.resize((W * SCALE, H * SCALE), Image.NEAREST).convert("RGB")
        strip_h = 26
        tile = Image.new("RGB", (big.width, big.height + strip_h), (245, 245, 245))
        tile.paste(big, (0, strip_h))
        ImageDraw.Draw(tile).text((8, 6), kor_en, fill=(15, 39, 51))
        tiles.append(tile)

    tw, th = tiles[0].size
    gap = 12
    grid = Image.new("RGB", (tw * 2 + gap, th * 2 + gap), (255, 255, 255))
    pos = [(0, 0), (tw + gap, 0), (0, th + gap), (tw + gap, th + gap)]
    for tile, p in zip(tiles, pos):
        grid.paste(tile, p)
    grid.save(path)


# ---------------- Main ----------------
def main():
    items = [
        ("img0.mem", "img0_horizontal", "Class0 Horizontal", make_horizontal()),
        ("img1.mem", "img1_vertical",   "Class1 Vertical",   make_vertical()),
        ("img2.mem", "img2_slash",      "Class2 Slash /",    make_slash()),
        ("img3.mem", "img3_backslash",  "Class3 Backslash \\", make_backslash()),
    ]

    print("=" * 70)
    print(" 96x64 image generation  (W=%d, H=%d, total=%d px)" % (W, H, N))
    print(" region x[%d..%d] y[%d..%d], center(XC=%d,YC=%d), thick +-%d"
          % (X0, X1, Y0, Y1, XC, YC, THICK))
    print("=" * 70)

    all_ok = True
    for memname, tag, label, img in items:
        ntok = write_mem(img, memname)          # -> ./imgN.mem
        write_png(img, tag + ".png", label)     # -> ./imgN_*.png
        fg = sum(1 for y in range(H) for x in range(W) if img[y][x])
        ok = (ntok == N)
        all_ok &= ok
        print("[%s] %-9s -> %-16s  hex=%d/%d  fg=%d"
              % ("OK" if ok else "FAIL", memname, tag + ".png", ntok, N, fg))

    write_grid(items, "preview_all_2x2.png")
    print("-" * 70)
    print(" grid    -> preview_all_2x2.png")
    print(" verify  : %s" % ("all files hold 6144 hex values"
                             if all_ok else "COUNT ERROR!"))
    print("-" * 70)


if __name__ == "__main__":
    main()
