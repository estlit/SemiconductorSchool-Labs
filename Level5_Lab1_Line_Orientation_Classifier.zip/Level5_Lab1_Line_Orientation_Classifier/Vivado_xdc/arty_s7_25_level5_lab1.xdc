# ======================================================================
# Welcome to 'Semiconductor School'
# Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
# File   : arty_s7_25_level5_lab1.xdc
# Target : Digilent Arty S7-25 (XC7S25-1CSGA324C) + Pmod OLEDrgb on JA
# Top    : top_level5_lab1
# Purpose: Dual-clock integration. 12 MHz (F14) runs the classifier ->
#          LD2..LD5; 100 MHz (R2) runs the OLED display of the input image
#          on Pmod JA. The two oscillators are independent -> declared async.
#
# Pin sources (Arty S7 Reference Manual, Rev. 2019-10-25):
#   - 12 MHz clock (F14), 100 MHz clock (R2)          (Section 5)
#   - BTN0 G15 ; SW0 H14 ; SW1 H18                     (Figure 7.1)
#   - LD2 E18 ; LD3 F13 ; LD4 E13 ; LD5 H15            (Figure 7.1)
#   - Pmod JA pinout                                   (Table 8.1)
# ======================================================================

# ---------------- Clocks ----------------
# 12 MHz classifier clock (F14)
set_property PACKAGE_PIN F14 [get_ports { CLK12MHZ }]
set_property IOSTANDARD LVCMOS33 [get_ports { CLK12MHZ }]
create_clock -add -name clk12 -period 83.333 -waveform {0 41.667} [get_ports { CLK12MHZ }]

# 100 MHz OLED clock (R2)
set_property PACKAGE_PIN R2 [get_ports { CLK100MHZ }]
set_property IOSTANDARD SSTL135 [get_ports { CLK100MHZ }]
create_clock -add -name clk100 -period 10.000 -waveform {0 5.000} [get_ports { CLK100MHZ }]

# The two on-board oscillators are independent; do not time paths between them.
set_clock_groups -asynchronous -group [get_clocks clk12] -group [get_clocks clk100]

# ---------------- Reset / switches ----------------
set_property PACKAGE_PIN G15 [get_ports { BTN0 }]
set_property IOSTANDARD LVCMOS33 [get_ports { BTN0 }]
set_property PACKAGE_PIN H14 [get_ports { SW0 }]
set_property IOSTANDARD LVCMOS33 [get_ports { SW0 }]
set_property PACKAGE_PIN H18 [get_ports { SW1 }]
set_property IOSTANDARD LVCMOS33 [get_ports { SW1 }]

# ---------------- Class output : LD2..LD5 (one-hot) ----------------
set_property PACKAGE_PIN E18 [get_ports { LD2 }]
set_property IOSTANDARD LVCMOS33 [get_ports { LD2 }]
set_property PACKAGE_PIN F13 [get_ports { LD3 }]
set_property IOSTANDARD LVCMOS33 [get_ports { LD3 }]
set_property PACKAGE_PIN E13 [get_ports { LD4 }]
set_property IOSTANDARD LVCMOS33 [get_ports { LD4 }]
set_property PACKAGE_PIN H15 [get_ports { LD5 }]
set_property IOSTANDARD LVCMOS33 [get_ports { LD5 }]

# ---------------- Pmod OLEDrgb (SSD1331) on Pmod JA ----------------
# JA1  L17 : CS#
set_property PACKAGE_PIN L17 [get_ports { oled_cs_n }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_cs_n }]
# JA2  L18 : MOSI
set_property PACKAGE_PIN L18 [get_ports { oled_mosi }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_mosi }]
# JA4  N14 : SCK
set_property PACKAGE_PIN N14 [get_ports { oled_sck }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_sck }]
# JA7  M16 : D/C
set_property PACKAGE_PIN M16 [get_ports { oled_dc }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_dc }]
# JA8  M17 : RES
set_property PACKAGE_PIN M17 [get_ports { oled_res }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_res }]
# JA9  M18 : VCCEN
set_property PACKAGE_PIN M18 [get_ports { oled_vccen }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_vccen }]
# JA10 N18 : PMODEN
set_property PACKAGE_PIN N18 [get_ports { oled_pmoden }]
set_property IOSTANDARD LVCMOS33 [get_ports { oled_pmoden }]
