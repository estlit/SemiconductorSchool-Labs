// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_Hazard_Branch_Unit.v
//   Testbench for hbu.
// =========================================================================

`timescale 1ns/1ps
module tb_hbu;
  reg [31:0] ex_pc, ex_imm; reg ex_branch, ex_zero, system_stall;
  wire [31:0] btgt; wire btaken, pstall, pflush;
  Hazard_Branch_Unit dut(.ex_pc(ex_pc),.ex_imm(ex_imm),.ex_branch(ex_branch),
    .ex_zero_flag(ex_zero),.system_stall(system_stall),
    .branch_target(btgt),.branch_taken(btaken),
    .pipe_stall(pstall),.pipe_flush(pflush));
  integer pass=0, fail=0;
  task chkT(input [400:0] nm, input [31:0] pc, input [31:0] im, input [31:0] exp);
    begin
      ex_pc=pc; ex_imm=im; #1;
      if (btgt===exp) begin pass=pass+1;
        $display("  PASS  %0s   target=0x%08h", nm, btgt); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   target=0x%08h exp 0x%08h", nm, btgt, exp); end
    end
  endtask
  task chkB(input [400:0] nm, input br, input z, input exp);
    begin
      ex_branch=br; ex_zero=z; #1;
      if (btaken===exp && pflush===exp) begin pass=pass+1;
        $display("  PASS  %0s   branch_taken=%b  pipe_flush=%b", nm, btaken, pflush); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   taken=%b flush=%b  exp %b", nm, btaken, pflush, exp); end
    end
  endtask
  task chkS(input [400:0] nm, input ss, input exp);
    begin
      system_stall=ss; #1;
      if (pstall===exp) begin pass=pass+1;
        $display("  PASS  %0s   pipe_stall=%b", nm, pstall); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   pipe_stall=%b exp %b", nm, pstall, exp); end
    end
  endtask
  initial begin
    ex_branch=0; ex_zero=0; system_stall=0; ex_pc=0; ex_imm=0;
    $display("--- T1  branch_target = ex_pc + ex_imm ---");
    chkT("T1 forward  +8",      32'h0000_0040, 32'h0000_0008, 32'h0000_0048);
    chkT("T1 backward -32",     32'h0000_0100, 32'hFFFF_FFE0, 32'h0000_00E0);
    chkT("T1 imm = 0",          32'h0000_0100, 32'h0000_0000, 32'h0000_0100);
    chkT("T1 32-bit wrap",      32'hFFFF_FFF8, 32'h0000_0010, 32'h0000_0008);
    chkT("T1 odd imm passes through", 32'h0000_0040, 32'h0000_0003, 32'h0000_0043);
    $display("");
    $display("--- T2  branch_taken = ex_branch & ex_zero_flag  (pipe_flush checked at the same time) ---");
    chkB("T2 branch=0 zero=0", 1'b0, 1'b0, 1'b0);
    chkB("T2 branch=0 zero=1", 1'b0, 1'b1, 1'b0);
    chkB("T2 branch=1 zero=0", 1'b1, 1'b0, 1'b0);
    chkB("T2 branch=1 zero=1", 1'b1, 1'b1, 1'b1);
    $display("");
    $display("--- T3  pipe_stall = system_stall, independent of branch ---");
    ex_branch=1'b1; ex_zero=1'b1; #1;
    chkS("T3 stall=0 while branch taken", 1'b0, 1'b0);
    chkS("T3 stall=1 while branch taken", 1'b1, 1'b1);
    ex_branch=1'b0; ex_zero=1'b0; #1;
    chkS("T3 stall=1 without branch", 1'b1, 1'b1);
    chkS("T3 stall=0 without branch", 1'b0, 1'b0);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
