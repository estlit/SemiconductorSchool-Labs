// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_ImmGen.v
//   Testbench for immgen.
// =========================================================================

`timescale 1ns/1ps
module tb_immgen;
  reg  [31:0] instr;
  wire [31:0] imm;
  ImmGen dut(.instr(instr), .imm(imm));
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] ins, input [31:0] exp);
    begin
      instr = ins; #1;
      if (imm===exp) begin pass=pass+1;
        $display("  PASS  %0s   instr=0x%08h  imm=0x%08h", nm, ins, imm); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   instr=0x%08h  imm=0x%08h exp 0x%08h", nm, ins, imm, exp); end
    end
  endtask
  initial begin
    chk("T1  I-type  max positive +2047", 32'h7FF00093, 32'h000007FF);
    chk("T1  I-type  min negative -2048", 32'h80000093, 32'hFFFFF800);
    chk("T1  I-type  -1", 32'hFFF00093, 32'hFFFFFFFF);
    chk("T2  S-type  max positive +2047", 32'h7E20AFA3, 32'h000007FF);
    chk("T2  S-type  min negative -2048", 32'h8020A023, 32'hFFFFF800);
    chk("T3  B-type  +4", 32'h00208263, 32'h00000004);
    chk("T3  B-type  -4", 32'hFE208EE3, 32'hFFFFFFFC);
    chk("T3  B-type  max +4094", 32'h7E208FE3, 32'h00000FFE);
    chk("T3  B-type  min -4096", 32'h80208063, 32'hFFFFF000);
    chk("T4  U-type  upper all ones", 32'hFFFFF0B7, 32'hFFFFF000);
    chk("T4  U-type  upper 0x00001", 32'h000010B7, 32'h00001000);
    chk("T5  unsupported opcode  JAL", 32'h0000006F, 32'h00000000);
    instr = 32'hFFFFF0B7; #1;
    if (imm[11:0]===12'd0) begin pass=pass+1;
      $display("  PASS  T4  U-type  low 12 bits are zero"); end
    else begin fail=fail+1;
      $display("  FAIL  T4  U-type  low 12 bits = 0x%03h", imm[11:0]); end
    instr = 32'h7E208FE3; #1;
    if (imm[0]===1'b0) begin pass=pass+1;
      $display("  PASS  T3  B-type  bit 0 is zero"); end
    else begin fail=fail+1;
      $display("  FAIL  T3  B-type  bit 0 = %b", imm[0]); end
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
