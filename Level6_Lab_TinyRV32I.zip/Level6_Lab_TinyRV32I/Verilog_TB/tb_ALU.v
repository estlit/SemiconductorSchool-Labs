// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_ALU.v
//   Testbench for alu.
// =========================================================================

`timescale 1ns/1ps
module tb_alu;
  reg [31:0] a, b; reg [3:0] c;
  wire [31:0] r; wire z;
  ALU dut(.alu_in_a(a),.alu_in_b(b),.alu_ctrl(c),.alu_result(r),.zero(z));
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] ia, input [31:0] ib, input [3:0] ic,
           input [31:0] er, input ez);
    begin
      a=ia; b=ib; c=ic; #1;
      if (r===er && z===ez) begin pass=pass+1;
        $display("  PASS  %0s   result=0x%08h  zero=%b", nm, r, z); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   result=0x%08h zero=%b  exp 0x%08h %b",
                 nm, r, z, er, ez); end
    end
  endtask
  initial begin
    $display("--- T1  arithmetic and logic ---");
    chk("T1 ADD",    32'd7, 32'd5, 4'b0000, 32'd12, 1'b0);
    chk("T1 SUB",    32'd7, 32'd5, 4'b0001, 32'd2,  1'b0);
    chk("T1 AND",    32'hF0F0_FFFF, 32'h0FF0_00FF, 4'b0010, 32'h00F0_00FF, 1'b0);
    chk("T1 OR",     32'hF0F0_0000, 32'h0F0F_0000, 4'b0011, 32'hFFFF_0000, 1'b0);
    chk("T1 XOR",    32'hFFFF_0000, 32'hF0F0_0000, 4'b0100, 32'h0F0F_0000, 1'b0);
    chk("T1 PASS_B", 32'hDEAD_BEEF, 32'h1234_5000, 4'b0101, 32'h1234_5000, 1'b0);
    $display("");
    $display("--- T2  CMP_EQ : result 0 when the condition is TRUE ---");
    chk("T2 CMP_EQ  a == b", 32'd42, 32'd42, 4'b0110, 32'd0, 1'b1);
    chk("T2 CMP_EQ  a != b", 32'd42, 32'd43, 4'b0110, 32'd1, 1'b0);
    $display("");
    $display("--- T3  CMP_NE : result 0 when the condition is TRUE ---");
    chk("T3 CMP_NE  a != b", 32'd42, 32'd43, 4'b0111, 32'd0, 1'b1);
    chk("T3 CMP_NE  a == b", 32'd42, 32'd42, 4'b0111, 32'd1, 1'b0);
    $display("");
    $display("--- T4  zero is a property of alu_result, not of compare ---");
    chk("T4 ADD  5 + (-5)",  32'd5, 32'hFFFF_FFFB, 4'b0000, 32'd0, 1'b1);
    chk("T4 SUB  9 - 9",     32'd9, 32'd9,         4'b0001, 32'd0, 1'b1);
    chk("T4 AND  no overlap",32'hF0F0_0000, 32'h0F0F_0000, 4'b0010, 32'd0, 1'b1);
    $display("");
    $display("--- T5  32-bit wraparound ---");
    chk("T5 ADD  FFFFFFFF + 1", 32'hFFFF_FFFF, 32'd1, 4'b0000, 32'd0, 1'b1);
    chk("T5 SUB  0 - 1",        32'd0, 32'd1, 4'b0001, 32'hFFFF_FFFF, 1'b0);
    $display("");
    $display("--- T6  unmapped alu_ctrl goes to default ---");
    chk("T6 ctrl 4'b1000", 32'd7, 32'd5, 4'b1000, 32'd0, 1'b1);
    chk("T6 ctrl 4'b1111", 32'd7, 32'd5, 4'b1111, 32'd0, 1'b1);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
