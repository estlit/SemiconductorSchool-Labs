`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 17  Memory-Mapped I/O
// MEM_MMIO_Decoder is a standalone module, so it is driven directly.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_mmio2;
  reg [31:0] addr, wdata; reg mrd, mwr;
  reg rb=1'b1, rs=1'b1, rc=1'b1, rn=1'b1, ro=1'b1, rm=1'b1;
  wire ram_en, ram_we; wire [31:0] ram_addr, ram_wdata;
  wire mmio_valid, mmio_write; wire [31:0] mmio_addr, mmio_wdata;
  wire cs_b, cs_s, cs_c, cs_n, cs_o, cs_m, sstall;
  MEM_MMIO_Decoder dut(.alu_result(addr),.rs2_data(wdata),
    .mem_read(mrd),.mem_write(mwr),
    .peri_board_ready(rb),.peri_sonar_ready(rs),.peri_camera_ready(rc),
    .peri_npu_ready(rn),.peri_oled_ready(ro),.peri_motor_ready(rm),
    .ram_en(ram_en),.ram_we(ram_we),.ram_addr(ram_addr),.ram_wdata(ram_wdata),
    .mmio_valid(mmio_valid),.mmio_write(mmio_write),
    .mmio_addr(mmio_addr),.mmio_wdata(mmio_wdata),
    .cs_board_io(cs_b),.cs_sonar(cs_s),.cs_camera(cs_c),
    .cs_npu(cs_n),.cs_oled(cs_o),.cs_motor(cs_m),.system_stall(sstall));
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  task drive(input [31:0] a, input rd, input wr);
    begin addr=a; mrd=rd; mwr=wr; wdata=32'hCAFE_0001; #1; end
  endtask
  initial begin
    $display("--- T1  addr[31:30] splits the two paths ---");
    drive(32'h0000_1000, 1'b1, 1'b0);
    chk("T1 RAM read   ram_en",     {31'd0, ram_en},     32'd1);
    chk("T1 RAM read   mmio_valid", {31'd0, mmio_valid}, 32'd0);
    drive(32'h4000_0000, 1'b1, 1'b0);
    chk("T1 MMIO read  ram_en",     {31'd0, ram_en},     32'd0);
    chk("T1 MMIO read  mmio_valid", {31'd0, mmio_valid}, 32'd1);
    drive(32'h8000_0000, 1'b1, 1'b0);
    chk("T1 addr[31:30]=10  ram_en",     {31'd0, ram_en},     32'd1);
    chk("T1 addr[31:30]=10  mmio_valid", {31'd0, mmio_valid}, 32'd0);
    $display("");
    $display("--- T2  ram_we is gated by is_mmio, mmio_write is not ---");
    drive(32'h0000_1000, 1'b0, 1'b1);
    chk("T2 RAM store  ram_we",     {31'd0, ram_we},     32'd1);
    chk("T2 RAM store  mmio_valid", {31'd0, mmio_valid}, 32'd0);
    chk("T2 RAM store  mmio_write", {31'd0, mmio_write}, 32'd1);
    $display("");
    $display("--- T3  chip select uses addr[15:8] ---");
    drive(32'h4000_0000, 1'b1, 1'b0);
    chk("T3 0x4000_0000  cs_board_io", {31'd0, cs_b}, 32'd1);
    drive(32'h4000_3000, 1'b1, 1'b0);
    chk("T3 0x4000_3000  cs_oled",     {31'd0, cs_o}, 32'd1);
    chk("T3 0x4000_3000  cs_board_io", {31'd0, cs_b}, 32'd0);
    drive(32'h4000_7F00, 1'b1, 1'b0);
    chk("T3 unmapped   all six cs",
        {26'd0, cs_b, cs_s, cs_c, cs_n, cs_o, cs_m}, 32'd0);
    drive(32'h4000_0000, 1'b0, 1'b0);
    chk("T3 no access  cs_board_io",   {31'd0, cs_b}, 32'd0);
    $display("");
    $display("--- T4  system_stall while every ready input is high ---");
    drive(32'h4000_0000, 1'b1, 1'b0);
    chk("T4 board selected, ready=1", {31'd0, sstall}, 32'd0);
    ro = 1'b0; drive(32'h4000_3000, 1'b1, 1'b0);
    chk("T4 oled selected, oled ready=0", {31'd0, sstall}, 32'd1);
    drive(32'h4000_0000, 1'b1, 1'b0);
    chk("T4 oled not selected, oled ready=0", {31'd0, sstall}, 32'd0);
    ro = 1'b1;
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
