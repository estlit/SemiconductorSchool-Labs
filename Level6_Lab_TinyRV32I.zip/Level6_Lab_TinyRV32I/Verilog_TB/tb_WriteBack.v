`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 20  Write Back
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_wb;
  reg clk=0, rst=1; reg [3:0] sw=4'd9; reg [1:0] btn=2'd0; reg mode=1'b0;
  wire [5:0] led;
  FPGA_Arty_S7_Top dut(.clk(clk),.i_rst_btn(rst),.i_sw(sw),.i_btn_b(btn),
                       .i_btn_mode(mode),.o_led(led));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  // capture the three selection cases as they occur
  reg cA=0, cB=0, cC=0;
  reg [31:0] dA, dB, dC;
  reg [1:0]  tB, tC;          // wb_alu_result[31:30] at that WB cycle
  reg        mB, mC;          // is_wb_mmio at that WB cycle
  // a NOP also raises wb_reg_write, so each case is keyed on its own rd
  wire [4:0] wb_rd = dut.u_CPU_Core.wb_instr[11:7];
  always @(negedge clk) if (!rst && dut.u_CPU_Core.wb_reg_write) begin
    if (!dut.u_CPU_Core.wb_mem_to_reg && wb_rd == 5'd3 && !cA) begin
      cA <= 1; dA <= dut.u_CPU_Core.wb_data; end
    if (dut.u_CPU_Core.wb_mem_to_reg &&  dut.u_CPU_Core.is_wb_mmio
        && wb_rd == 5'd11 && !cB) begin
      cB <= 1; dB <= dut.u_CPU_Core.wb_data;
      tB <= dut.u_CPU_Core.wb_alu_result[31:30];
      mB <= dut.u_CPU_Core.is_wb_mmio; end
    if (dut.u_CPU_Core.wb_mem_to_reg && !dut.u_CPU_Core.is_wb_mmio
        && wb_rd == 5'd14 && !cC) begin
      cC <= 1; dC <= dut.u_CPU_Core.wb_data;
      tC <= dut.u_CPU_Core.wb_alu_result[31:30];
      mC <= dut.u_CPU_Core.is_wb_mmio; end
  end
  initial begin
    #22 rst=0; #1400;
    $display("--- T1  wb_mem_to_reg = 0  ->  wb_alu_result ---");
    chk("T1 case observed  (rd = x3)",  {31'd0, cA}, 32'd1);
    chk("T1 selected wb_data",     dA, 32'h0000_0127);
    chk("T1 x3 = ALU result",      dut.u_CPU_Core.u_RegFile.regs[3], 32'h127);
    $display("");
    $display("--- T2  wb_mem_to_reg = 1, is_wb_mmio = 1  ->  wb_read_data ---");
    chk("T2 case observed  (rd = x11)", {31'd0, cB}, 32'd1);
    chk("T2 selected wb_data",     dB, 32'h0000_0009);
    chk("T2 x11 = MMIO read",      dut.u_CPU_Core.u_RegFile.regs[11], 32'd9);
    $display("");
    $display("--- T3  wb_mem_to_reg = 1, is_wb_mmio = 0  ->  sync_ram_data ---");
    chk("T3 case observed  (rd = x14)", {31'd0, cC}, 32'd1);
    chk("T3 selected wb_data",     dC, 32'h0000_02AB);
    chk("T3 x14 = RAM read",       dut.u_CPU_Core.u_RegFile.regs[14], 32'h2AB);
    chk("T3 data_ram holds it",    dut.u_CPU_Core.data_ram[8'h00],    32'h2AB);
    $display("");
    $display("--- T4  is_wb_mmio is re-evaluated from wb_alu_result[31:30] ---");
    chk("T4 MMIO case  wb_alu_result[31:30]", {30'd0, tB}, 32'b01);
    chk("T4 MMIO case  is_wb_mmio",           {31'd0, mB}, 32'd1);
    chk("T4 RAM  case  wb_alu_result[31:30]", {30'd0, tC}, 32'b00);
    chk("T4 RAM  case  is_wb_mmio",           {31'd0, mC}, 32'd0);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
