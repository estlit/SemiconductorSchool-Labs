// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_IF_ID_Reg.v
//   Testbench for ifid.
// =========================================================================

`timescale 1ns/1ps
module tb_ifid;
  reg clk=0, rst=1, stall=0, flush=0;
  reg [31:0] if_pc=0, if_instr=0;
  wire [31:0] id_pc, id_instr;
  IF_ID_Reg dut(.clk(clk),.rst(rst),.stall(stall),.flush(flush),
                .if_pc(if_pc),.if_instr(if_instr),.id_pc(id_pc),.id_instr(id_instr));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1; $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1; $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    @(negedge clk);
    chk("T1 reset  id_pc", id_pc, 32'h0000_0000);
    chk("T1 reset  id_instr = NOP", id_instr, 32'h0000_0013);
    rst=0;
    // T2 normal load
    if_pc=32'h0000_0020; if_instr=32'h00A00093;
    @(negedge clk);
    chk("T2 load  id_pc", id_pc, 32'h0000_0020);
    chk("T2 load  id_instr", id_instr, 32'h00A00093);
    // T3 stall holds
    if_pc=32'h0000_0024; if_instr=32'hDEADBEEF; stall=1;
    @(negedge clk);
    chk("T3 stall holds  id_pc", id_pc, 32'h0000_0020);
    chk("T3 stall holds  id_instr", id_instr, 32'h00A00093);
    // T4 flush overrides stall
    flush=1;
    @(negedge clk);
    chk("T4 flush over stall  id_pc", id_pc, 32'h0000_0000);
    chk("T4 flush over stall  id_instr = NOP", id_instr, 32'h0000_0013);
    // T5 resume
    flush=0; stall=0; if_pc=32'h0000_0028; if_instr=32'h00B00113;
    @(negedge clk);
    chk("T5 resume  id_pc", id_pc, 32'h0000_0028);
    chk("T5 resume  id_instr", id_instr, 32'h00B00113);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
