`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 25  Full System Simulation
// calc_demo runs as an endless loop, so the inputs are changed while the
// program keeps running and o_led is sampled after each change.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_system;
  reg clk=0, rst=1; reg [3:0] sw=4'd0; reg [1:0] btn=2'd0; reg mode=1'b0;
  wire [5:0] led;
  FPGA_Arty_S7_Top dut(.clk(clk),.i_rst_btn(rst),.i_sw(sw),.i_btn_b(btn),
                       .i_btn_mode(mode),.o_led(led));
  always #5 clk=~clk;
  integer pass=0, fail=0;

  task apply(input [800:0] nm, input [3:0] a, input [1:0] b, input m,
             input [5:0] exp);
    begin
      sw = a; btn = b; mode = m;
      #4000;                       // let the loop read the new inputs
      if (led === exp) begin pass=pass+1;
        $display("  PASS  %0s   sw=%0d btn=%0d mode=%0d  ->  led=%0d",
                 nm, a, b, m, led); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   sw=%0d btn=%0d mode=%0d  ->  led=%0d exp %0d",
                 nm, a, b, m, led, exp); end
    end
  endtask

  initial begin
    $display("--- T1  reset clears the output ---");
    #22;
    if (led === 6'd0) begin pass=pass+1;
      $display("  PASS  T1 o_led after reset = %0d", led); end
    else begin fail=fail+1;
      $display("  FAIL  T1 o_led after reset = %0d", led); end
    rst = 0;
    $display("");
    $display("--- T2  mode 0 : add ---");
    apply("T2  5 + 0", 4'd5,  2'd0, 1'b0, 6'd5);
    apply("T2  5 + 3", 4'd5,  2'd3, 1'b0, 6'd8);
    apply("T2 15 + 3", 4'd15, 2'd3, 1'b0, 6'd18);
    apply("T2  0 + 0", 4'd0,  2'd0, 1'b0, 6'd0);
    $display("");
    $display("--- T3  mode 1 : subtract ---");
    apply("T3  9 - 2", 4'd9,  2'd2, 1'b1, 6'd7);
    apply("T3  5 - 3", 4'd5,  2'd3, 1'b1, 6'd2);
    apply("T3  3 - 3", 4'd3,  2'd3, 1'b1, 6'd0);
    $display("");
    $display("--- T4  subtract below zero keeps the low six bits ---");
    apply("T4  1 - 3", 4'd1,  2'd3, 1'b1, 6'd62);   // -2 & 0x3F
    apply("T4  0 - 1", 4'd0,  2'd1, 1'b1, 6'd63);   // -1 & 0x3F
    $display("");
    $display("--- T5  the loop follows a later input change ---");
    apply("T5 back to add  7 + 1", 4'd7, 2'd1, 1'b0, 6'd8);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
