`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 21  Data Hazard
// The NOP requirement is a property of the whole pipeline, so the audit
// runs real programs on FPGA_Arty_S7_Top and reads the register file.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_hazard;
  reg clk=0, rst=1; reg [3:0] sw=4'd0; reg [1:0] btn=2'd0; reg mode=1'b0;
  wire [5:0] led;
  FPGA_Arty_S7_Top dut(.clk(clk),.i_rst_btn(rst),.i_sw(sw),.i_btn_b(btn),
                       .i_btn_mode(mode),.o_led(led));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  // capture the value the consumer actually reads in its ID cycle.
  // the consumer of each pair is keyed on its own rd field.
  wire [4:0] id_rd = dut.u_CPU_Core.id_instr[11:7];
  reg  [31:0] r1, r2, r3, r4;
  reg         g1=0, g2=0, g3=0, g4=0;
  always @(negedge clk) if (!rst) begin
    if (id_rd == 5'd2  && !g1) begin g1<=1; r1 <= dut.u_CPU_Core.id_rs1_data; end
    if (id_rd == 5'd12 && !g2) begin g2<=1; r2 <= dut.u_CPU_Core.id_rs1_data; end
    if (id_rd == 5'd22 && !g3) begin g3<=1; r3 <= dut.u_CPU_Core.id_rs1_data; end
    if (id_rd == 5'd30 && !g4) begin g4<=1; r4 <= dut.u_CPU_Core.id_rs1_data; end
  end

  initial begin
    #22 rst=0; #1600;
    // program layout, four independent producer / consumer pairs
    //   x1  = 5                      producer
    //   x2  = x1 + 1   distance 1    consumer   -> reads stale x1 = 0
    //   x11 = 5 ; x12 = x11 + 1   distance 2
    //   x21 = 5 ; x22 = x21 + 1   distance 3
    //   x31 = 5 ; x30 = x31 + 1   distance 4
    $display("--- T1  producers all reach the register file ---");
    chk("T1 x1  producer",  dut.u_CPU_Core.u_RegFile.regs[1],  32'd5);
    chk("T1 x11 producer",  dut.u_CPU_Core.u_RegFile.regs[11], 32'd5);
    chk("T1 x21 producer",  dut.u_CPU_Core.u_RegFile.regs[21], 32'd5);
    chk("T1 x31 producer",  dut.u_CPU_Core.u_RegFile.regs[31], 32'd5);
    $display("");
    $display("--- T2  distance 1 / 2 / 3 read the value before the write ---");
    chk("T2 distance 1  x2",  dut.u_CPU_Core.u_RegFile.regs[2],  32'd1);
    chk("T2 distance 2  x12", dut.u_CPU_Core.u_RegFile.regs[12], 32'd1);
    chk("T2 distance 3  x22", dut.u_CPU_Core.u_RegFile.regs[22], 32'd1);
    $display("");
    $display("--- T3  the value read in the consumer ID cycle ---");
    chk("T3 distance 1  id_rs1_data", r1, 32'd0);
    chk("T3 distance 2  id_rs1_data", r2, 32'd0);
    chk("T3 distance 3  id_rs1_data", r3, 32'd0);
    chk("T3 distance 4  id_rs1_data", r4, 32'd5);
    $display("");
    $display("--- T4  distance 4 result ---");
    chk("T4 distance 4  x30", dut.u_CPU_Core.u_RegFile.regs[30], 32'd6);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
