// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_ID_EX_Reg.v
//   Testbench for idex.
// =========================================================================

`timescale 1ns/1ps
module tb_idex;
  reg clk=0, rst=1, stall=0, flush=0;
  reg [31:0] id_pc=0, id_instr=0, id_rs1=0, id_rs2=0, id_imm=0;
  reg [3:0]  id_alu_ctrl=0;
  reg        id_alu_src=0, id_mr=0, id_mw=0, id_rw=0, id_br=0;
  wire [31:0] ex_pc, ex_instr, ex_rs1, ex_rs2, ex_imm;
  wire [3:0]  ex_alu_ctrl;
  wire        ex_alu_src, ex_mr, ex_mw, ex_rw, ex_br;
  ID_EX_Reg dut(.clk(clk),.rst(rst),.stall(stall),.flush(flush),
    .id_pc(id_pc),.id_instr(id_instr),.id_rs1_data(id_rs1),.id_rs2_data(id_rs2),
    .id_imm(id_imm),.id_alu_ctrl(id_alu_ctrl),.id_alu_src(id_alu_src),
    .id_mem_read(id_mr),.id_mem_write(id_mw),.id_reg_write(id_rw),.id_branch(id_br),
    .ex_pc(ex_pc),.ex_instr(ex_instr),.ex_rs1_data(ex_rs1),.ex_rs2_data(ex_rs2),
    .ex_imm(ex_imm),.ex_alu_ctrl(ex_alu_ctrl),.ex_alu_src(ex_alu_src),
    .ex_mem_read(ex_mr),.ex_mem_write(ex_mw),.ex_reg_write(ex_rw),.ex_branch(ex_br));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  task drive(input [31:0] pc, input [31:0] ins, input [31:0] a, input [31:0] b,
             input [31:0] im, input [3:0] ac, input asrc,
             input mr, input mw, input rw, input br);
    begin
      id_pc=pc; id_instr=ins; id_rs1=a; id_rs2=b; id_imm=im;
      id_alu_ctrl=ac; id_alu_src=asrc; id_mr=mr; id_mw=mw; id_rw=rw; id_br=br;
    end
  endtask
  initial begin
    @(negedge clk);
    $display("--- T1  reset values ---");
    chk("T1 ex_pc",        ex_pc,        32'h0000_0000);
    chk("T1 ex_instr NOP", ex_instr,     32'h0000_0013);
    chk("T1 ex_rs1_data",  ex_rs1,       32'h0000_0000);
    chk("T1 ex_rs2_data",  ex_rs2,       32'h0000_0000);
    chk("T1 ex_imm",       ex_imm,       32'h0000_0000);
    chk("T1 control 6",    {24'd0,ex_alu_ctrl,ex_alu_src,ex_mr,ex_mw,ex_rw,ex_br}, 32'd0);
    rst=0;
    $display("");
    $display("--- T2  load all 11 payloads ---");
    drive(32'h0000_0040, 32'h00C58733, 32'hAAAA_0001, 32'hBBBB_0002,
          32'h0000_07FF, 4'b0011, 1'b1, 1'b1, 1'b0, 1'b1, 1'b0);
    @(negedge clk);
    chk("T2 ex_pc",        ex_pc,    32'h0000_0040);
    chk("T2 ex_instr",     ex_instr, 32'h00C58733);
    chk("T2 ex_rs1_data",  ex_rs1,   32'hAAAA_0001);
    chk("T2 ex_rs2_data",  ex_rs2,   32'hBBBB_0002);
    chk("T2 ex_imm",       ex_imm,   32'h0000_07FF);
    chk("T2 ex_alu_ctrl",  {28'd0, ex_alu_ctrl}, 32'd3);
    chk("T2 control 5",    {27'd0,ex_alu_src,ex_mr,ex_mw,ex_rw,ex_br}, 32'b11010);
    $display("");
    $display("--- T3  stall holds every payload ---");
    drive(32'h0000_0044, 32'hDEADBEEF, 32'hCCCC_0003, 32'hDDDD_0004,
          32'h0000_0123, 4'b0101, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1);
    stall=1; @(negedge clk);
    chk("T3 ex_pc held",       ex_pc,    32'h0000_0040);
    chk("T3 ex_instr held",    ex_instr, 32'h00C58733);
    chk("T3 ex_rs1_data held", ex_rs1,   32'hAAAA_0001);
    chk("T3 ex_rs2_data held", ex_rs2,   32'hBBBB_0002);
    chk("T3 ex_imm held",      ex_imm,   32'h0000_07FF);
    chk("T3 ex_alu_ctrl held", {28'd0, ex_alu_ctrl}, 32'd3);
    chk("T3 control held",     {27'd0,ex_alu_src,ex_mr,ex_mw,ex_rw,ex_br}, 32'b11010);
    $display("");
    $display("--- T4  flush overrides stall : what a bubble contains ---");
    flush=1; @(negedge clk);
    chk("T4 ex_instr becomes NOP", ex_instr, 32'h0000_0013);
    chk("T4 ex_pc cleared",        ex_pc,    32'h0000_0000);
    chk("T4 ex_rs1_data cleared",  ex_rs1,   32'h0000_0000);
    chk("T4 ex_rs2_data cleared",  ex_rs2,   32'h0000_0000);
    chk("T4 ex_imm cleared",       ex_imm,   32'h0000_0000);
    chk("T4 control all zero",     {24'd0,ex_alu_ctrl,ex_alu_src,ex_mr,ex_mw,ex_rw,ex_br}, 32'd0);
    $display("");
    $display("--- T5  resume ---");
    flush=0; stall=0; @(negedge clk);
    chk("T5 ex_instr",    ex_instr, 32'hDEADBEEF);
    chk("T5 ex_rs2_data", ex_rs2,   32'hDDDD_0004);
    chk("T5 control",     {27'd0,ex_alu_src,ex_mr,ex_mw,ex_rw,ex_br}, 32'b00101);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
