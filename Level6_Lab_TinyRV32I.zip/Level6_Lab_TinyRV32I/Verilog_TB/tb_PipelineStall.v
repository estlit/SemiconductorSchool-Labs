`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 22  Pipeline Stall
// One stall signal drives all five stall ports at once.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_stall;
  reg clk=0, rst=1;
  // --- generation side
  reg [31:0] addr=32'h4000_3000; reg mrd=1'b1, mwr=1'b0;
  reg rb=1'b1, rs=1'b1, rc=1'b1, rn=1'b1, ro=1'b1, rm=1'b1;
  wire sys_stall;
  // delivery : the same path the CPU uses, Hazard_Branch_Unit drives pipe_stall
  wire [31:0] btgt; wire btaken, pipe_stall, pipe_flush;
  Hazard_Branch_Unit u_hz(.ex_pc(32'd0),.ex_imm(32'd0),.ex_branch(1'b0),
    .ex_zero_flag(1'b0),.system_stall(sys_stall),
    .branch_target(btgt),.branch_taken(btaken),
    .pipe_stall(pipe_stall),.pipe_flush(pipe_flush));
  wire ram_en, ram_we; wire [31:0] ram_addr, ram_wdata;
  wire mv, mw; wire [31:0] ma, mwd;
  wire cb, cs_, cc, cn, co, cm;
  MEM_MMIO_Decoder u_dec(.alu_result(addr),.rs2_data(32'd0),
    .mem_read(mrd),.mem_write(mwr),
    .peri_board_ready(rb),.peri_sonar_ready(rs),.peri_camera_ready(rc),
    .peri_npu_ready(rn),.peri_oled_ready(ro),.peri_motor_ready(rm),
    .ram_en(ram_en),.ram_we(ram_we),.ram_addr(ram_addr),.ram_wdata(ram_wdata),
    .mmio_valid(mv),.mmio_write(mw),.mmio_addr(ma),.mmio_wdata(mwd),
    .cs_board_io(cb),.cs_sonar(cs_),.cs_camera(cc),.cs_npu(cn),
    .cs_oled(co),.cs_motor(cm),.system_stall(sys_stall));

  // --- application side : all five stall ports share one signal
  wire [31:0] pc, instr;
  IF_Stage u_if(.clk(clk),.rst(rst),.stall(pipe_stall),.branch_taken(1'b0),
                .branch_target(32'd0),.pc(pc),.instr(instr));
  reg [31:0] a_pc=32'h100, a_in=32'hAAAA0001;
  wire [31:0] b_pc, b_in;
  IF_ID_Reg u_ifid(.clk(clk),.rst(rst),.stall(pipe_stall),.flush(1'b0),
    .if_pc(a_pc),.if_instr(a_in),.id_pc(b_pc),.id_instr(b_in));
  reg [31:0] c_pc=32'h200, c_in=32'hBBBB0002, c_r1=32'd7, c_r2=32'd8, c_im=32'd9;
  wire [31:0] d_pc, d_in, d_r1, d_r2, d_im; wire [3:0] d_ac;
  wire d_as, d_mr, d_mw, d_rw, d_br;
  ID_EX_Reg u_idex(.clk(clk),.rst(rst),.stall(pipe_stall),.flush(1'b0),
    .id_pc(c_pc),.id_instr(c_in),.id_rs1_data(c_r1),.id_rs2_data(c_r2),
    .id_imm(c_im),.id_alu_ctrl(4'd3),.id_alu_src(1'b1),.id_mem_read(1'b1),
    .id_mem_write(1'b0),.id_reg_write(1'b1),.id_branch(1'b0),
    .ex_pc(d_pc),.ex_instr(d_in),.ex_rs1_data(d_r1),.ex_rs2_data(d_r2),
    .ex_imm(d_im),.ex_alu_ctrl(d_ac),.ex_alu_src(d_as),.ex_mem_read(d_mr),
    .ex_mem_write(d_mw),.ex_reg_write(d_rw),.ex_branch(d_br));
  reg [31:0] e_in=32'hCCCC0003, e_al=32'h300, e_r2=32'd11;
  wire [31:0] f_in, f_al, f_r2; wire f_mr, f_mw, f_rw;
  EX_MEM_Reg u_exmem(.clk(clk),.rst(rst),.stall(pipe_stall),
    .ex_instr(e_in),.ex_alu_result(e_al),.ex_rs2_data(e_r2),
    .ex_mem_read(1'b1),.ex_mem_write(1'b0),.ex_reg_write(1'b1),
    .mem_instr(f_in),.mem_alu_result(f_al),.mem_rs2_data(f_r2),
    .mem_mem_read(f_mr),.mem_mem_write(f_mw),.mem_reg_write(f_rw));
  reg [31:0] g_in=32'hDDDD0004, g_al=32'h400, g_rd=32'd13;
  wire [31:0] h_in, h_al, h_rd; wire h_rw, h_m2r;
  MEM_WB_Reg u_memwb(.clk(clk),.rst(rst),.stall(pipe_stall),
    .mem_instr(g_in),.mem_alu_result(g_al),.mem_read_data(g_rd),
    .mem_reg_write(1'b1),.mem_mem_read(1'b1),
    .wb_instr(h_in),.wb_alu_result(h_al),.wb_read_data(h_rd),
    .wb_reg_write(h_rw),.wb_mem_to_reg(h_m2r));

  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  reg [31:0] s_pc, s_ifid, s_idex, s_exmem, s_memwb;
  initial begin
    @(negedge clk); rst=0;
    @(negedge clk); @(negedge clk);
    $display("--- T1  system_stall generation ---");
    ro=1'b1; #1; chk("T1 oled selected, ready = 1", {31'd0, sys_stall}, 32'd0);
    ro=1'b0; #1; chk("T1 oled selected, ready = 0", {31'd0, sys_stall}, 32'd1);
    $display("");
    $display("--- T2  delivery : system_stall reaches pipe_stall ---");
    ro=1'b0; #1;
    chk("T2 system_stall", {31'd0, sys_stall}, 32'd1);
    chk("T2 pipe_stall",   {31'd0, pipe_stall}, 32'd1);
    ro=1'b1; #1;
    chk("T2 both low again", {30'd0, sys_stall, pipe_stall}, 32'd0);
    $display("");
    $display("--- T3  five stall ports hold together ---");
    s_pc=pc; s_ifid=b_in; s_idex=d_in; s_exmem=f_in; s_memwb=h_in;
    a_in=32'hFFFF0000; c_in=32'hFFFF0000;
    e_in=32'hFFFF0000; g_in=32'hFFFF0000;
    ro=1'b0;                      // the only thing the testbench drives
    @(negedge clk); @(negedge clk);
    chk("T3 IF_Stage    pc held",       pc,    s_pc);
    chk("T3 IF_ID_Reg   id_instr held", b_in,  s_ifid);
    chk("T3 ID_EX_Reg   ex_instr held", d_in,  s_idex);
    chk("T3 EX_MEM_Reg  mem_instr held",f_in,  s_exmem);
    chk("T3 MEM_WB_Reg  wb_instr held", h_in,  s_memwb);
    $display("");
    $display("--- T4  all five resume together ---");
    ro=1'b1;
    @(negedge clk);
    chk("T4 IF_Stage    pc advanced",   pc,    s_pc + 32'd4);
    chk("T4 IF_ID_Reg   id_instr",      b_in,  32'hFFFF0000);
    chk("T4 ID_EX_Reg   ex_instr",      d_in,  32'hFFFF0000);
    chk("T4 EX_MEM_Reg  mem_instr",     f_in,  32'hFFFF0000);
    chk("T4 MEM_WB_Reg  wb_instr",      h_in,  32'hFFFF0000);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
