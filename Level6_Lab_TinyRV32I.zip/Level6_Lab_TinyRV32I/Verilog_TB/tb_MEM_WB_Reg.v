`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 19  MEM/WB Pipeline Register
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_memwb;
  reg clk=0, rst=1, stall=0;
  reg [31:0] m_instr=0, m_alu=0, m_rdata=0;
  reg        m_rw=0, m_mr=0;
  wire [31:0] w_instr, w_alu, w_rdata;
  wire        w_rw, w_m2r;
  MEM_WB_Reg dut(.clk(clk),.rst(rst),.stall(stall),
    .mem_instr(m_instr),.mem_alu_result(m_alu),.mem_read_data(m_rdata),
    .mem_reg_write(m_rw),.mem_mem_read(m_mr),
    .wb_instr(w_instr),.wb_alu_result(w_alu),.wb_read_data(w_rdata),
    .wb_reg_write(w_rw),.wb_mem_to_reg(w_m2r));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    @(negedge clk);
    $display("--- T1  reset values ---");
    chk("T1 wb_instr = NOP",  w_instr, 32'h0000_0013);
    chk("T1 wb_alu_result",   w_alu,   32'h0000_0000);
    chk("T1 wb_read_data",    w_rdata, 32'h0000_0000);
    chk("T1 wb_reg_write",    {31'd0, w_rw},  32'd0);
    chk("T1 wb_mem_to_reg",   {31'd0, w_m2r}, 32'd0);
    rst=0;
    $display("");
    $display("--- T2  five payloads capture ---");
    m_instr=32'h00052583; m_alu=32'h4000_0000; m_rdata=32'h0000_0005;
    m_rw=1'b1; m_mr=1'b1;
    @(negedge clk);
    chk("T2 wb_instr",              w_instr, 32'h00052583);
    chk("T2 wb_alu_result",         w_alu,   32'h4000_0000);
    chk("T2 wb_read_data  (MMIO)",  w_rdata, 32'h0000_0005);
    chk("T2 wb_reg_write",          {31'd0, w_rw}, 32'd1);
    $display("");
    $display("--- T3  signal rename : mem_mem_read to wb_mem_to_reg ---");
    chk("T3 mem_mem_read = 1  ->  wb_mem_to_reg", {31'd0, w_m2r}, 32'd1);
    m_mr = 1'b0;
    @(negedge clk);
    chk("T3 mem_mem_read = 0  ->  wb_mem_to_reg", {31'd0, w_m2r}, 32'd0);
    m_mr = 1'b1;
    @(negedge clk);
    chk("T3 back to 1         ->  wb_mem_to_reg", {31'd0, w_m2r}, 32'd1);
    $display("");
    $display("--- T4  stall holds every payload ---");
    m_instr=32'hDEADBEEF; m_alu=32'h1111_2222; m_rdata=32'h3333_4444;
    m_rw=1'b0; m_mr=1'b0; stall=1'b1;
    @(negedge clk);
    chk("T4 wb_instr held",       w_instr, 32'h00052583);
    chk("T4 wb_alu_result held",  w_alu,   32'h4000_0000);
    chk("T4 wb_read_data held",   w_rdata, 32'h0000_0005);
    chk("T4 wb_reg_write held",   {31'd0, w_rw},  32'd1);
    chk("T4 wb_mem_to_reg held",  {31'd0, w_m2r}, 32'd1);
    $display("");
    $display("--- T5  reset overrides stall ---");
    rst=1'b1; @(negedge clk);
    chk("T5 wb_instr = NOP",  w_instr, 32'h0000_0013);
    chk("T5 wb_alu_result",   w_alu,   32'h0000_0000);
    chk("T5 wb_read_data",    w_rdata, 32'h0000_0000);
    chk("T5 wb_reg_write",    {31'd0, w_rw},  32'd0);
    chk("T5 wb_mem_to_reg",   {31'd0, w_m2r}, 32'd0);
    rst=1'b0;
    $display("");
    $display("--- T6  resume ---");
    stall=1'b0; @(negedge clk);
    chk("T6 wb_instr",        w_instr, 32'hDEADBEEF);
    chk("T6 wb_read_data",    w_rdata, 32'h3333_4444);
    chk("T6 wb_reg_write",    {31'd0, w_rw},  32'd0);
    chk("T6 wb_mem_to_reg",   {31'd0, w_m2r}, 32'd0);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
