// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_IF_Stage.v
//   Testbench for if.
// =========================================================================

`timescale 1ns/1ps
module tb_if;
  reg clk=0, rst=1, stall=0, branch_taken=0;
  reg [31:0] branch_target=32'h0;
  wire [31:0] pc, instr;
  IF_Stage dut(.clk(clk),.rst(rst),.stall(stall),.branch_taken(branch_taken),
               .branch_target(branch_target),.pc(pc),.instr(instr));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  pc = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    @(negedge clk); chk("T1 reset value", pc, 32'h0000_0000);
    rst=0;
    @(negedge clk); chk("T2 sequential  +4", pc, 32'h0000_0004);
    @(negedge clk); chk("T2 sequential  +4", pc, 32'h0000_0008);
    stall=1; @(negedge clk); chk("T3 stall holds pc", pc, 32'h0000_0008);
    @(negedge clk); chk("T3 stall holds pc", pc, 32'h0000_0008);
    branch_taken=1; branch_target=32'h0000_0100;
    @(negedge clk); chk("T4 branch overrides stall", pc, 32'h0000_0100);
    branch_taken=0; stall=0;
    @(negedge clk); chk("T5 resumes from target", pc, 32'h0000_0104);
    // T6 : ROM range guard, in range
    //   0x10 is the fifth word of the program that ships with this lab,
    //   lw x11, 0(x10), so the value is a real instruction rather than a
    //   pattern written only for this test.
    branch_taken=1; branch_target=32'h0000_0010;
    @(negedge clk); branch_taken=0;
    chk("T6 in range  pc", pc, 32'h0000_0010);
    chk("T6 in range  instr from rom", instr, 32'h0005_2583);
    branch_taken=1; branch_target=32'h0000_1000;
    @(negedge clk); branch_taken=0;
    chk("T7 out of range pc", pc, 32'h0000_1000);
    if (instr===32'h00000013) begin pass=pass+1;
      $display("  PASS  T7 out of range  instr = NOP  = 0x%08h", instr); end
    else begin fail=fail+1;
      $display("  FAIL  T7 out of range  instr = 0x%08h", instr); end
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
