`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 18  MMIO Peripheral Interface
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_mmio_p;
  reg clk=0, rst=1; reg [3:0] sw=4'd5; reg [1:0] btn=2'd2; reg mode=1'b1;
  wire [5:0] led;
  FPGA_Arty_S7_Top dut(.clk(clk),.i_rst_btn(rst),.i_sw(sw),.i_btn_b(btn),
                       .i_btn_mode(mode),.o_led(led));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  // observe which chip selects ever assert during the run
  reg seen_b=0, seen_o=0;
  always @(posedge clk) begin
    if (!rst) begin
      if (dut.cs_board_io) seen_b <= 1'b1;
      if (dut.cs_oled)     seen_o <= 1'b1;
    end
  end
  initial begin
    #22 rst=0; #1200;
    $display("--- T1  board mapped reads ---");
    chk("T1 0x4000_0000 -> i_sw",      dut.u_CPU_Core.u_RegFile.regs[11], 32'd5);
    chk("T1 0x4000_0004 -> i_btn_b",   dut.u_CPU_Core.u_RegFile.regs[12], 32'd2);
    chk("T1 0x4000_0008 -> i_btn_mode",dut.u_CPU_Core.u_RegFile.regs[13], 32'd1);
    $display("");
    $display("--- T2  addresses with no read case return the default ---");
    chk("T2 0x4000_000C read", dut.u_CPU_Core.u_RegFile.regs[14], 32'd0);
    $display("");
    $display("--- T3  a chip select other than cs_board_io ---");
    chk("T3 cs_oled asserted during the run", {31'd0, seen_o}, 32'd1);
    chk("T3 0x4000_3000 read result",  dut.u_CPU_Core.u_RegFile.regs[16], 32'd0);
    $display("");
    $display("--- T4  the write path still reaches the LED ---");
    chk("T4 x17 value",  dut.u_CPU_Core.u_RegFile.regs[17], 32'd42);
    chk("T4 o_led",      {26'd0, led}, 32'd42 & 32'h3F);
    chk("T4 cs_board_io asserted during the run", {31'd0, seen_b}, 32'd1);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
