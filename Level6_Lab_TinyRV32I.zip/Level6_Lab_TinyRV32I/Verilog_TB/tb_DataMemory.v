`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 16  Data Memory
// data_ram lives inside TinyRV32I_Top, so the audit drives a real program
// through FPGA_Arty_S7_Top and observes the internal nets.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_dmem;
  reg clk=0, rst=1; reg [3:0] sw=0; reg [1:0] btn=0; reg mode=0;
  wire [5:0] led;
  FPGA_Arty_S7_Top dut(.clk(clk),.i_rst_btn(rst),.i_sw(sw),.i_btn_b(btn),
                       .i_btn_mode(mode),.o_led(led));
  always #5 clk=~clk;

  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask

  // ---- T4 : sync_ram_data must not change while ram_en is low
  reg [31:0] hold_before, hold_after;
  reg        t4_ran = 1'b0;
  always @(negedge clk) begin
    if (!rst && t3_ran && !t4_ran && dut.u_CPU_Core.ram_en === 1'b0) begin
      hold_before = dut.u_CPU_Core.sync_ram_data;
      t4_ran      = 1'b1;
      @(posedge clk);              // an edge with ram_en low
      #1 hold_after = dut.u_CPU_Core.sync_ram_data;
    end
  end

  // ---- T3 : observe the edge at which sync_ram_data takes the array word
  reg [31:0] addressed, before_edge, after_edge;
  reg        t3_ran = 1'b0;
  always @(negedge clk) begin
    if (!rst && !t3_ran
        && dut.u_CPU_Core.ram_en === 1'b1
        && dut.u_CPU_Core.ram_we === 1'b0) begin
      addressed   = dut.u_CPU_Core.data_ram[dut.u_CPU_Core.ram_addr[9:2]];
      before_edge = dut.u_CPU_Core.sync_ram_data;
      t3_ran      = 1'b1;
      @(posedge clk);
      #1 after_edge = dut.u_CPU_Core.sync_ram_data;
    end
  end

  initial begin
    #22 rst=0; #900;
    $display("--- T1  store then load through data_ram ---");
    chk("T1 x10 base address",  dut.u_CPU_Core.u_RegFile.regs[10], 32'h0000_1000);
    chk("T1 x11 value stored",  dut.u_CPU_Core.u_RegFile.regs[11], 32'h0000_02AB);
    chk("T1 data_ram[0] : index of 0x1000",
        dut.u_CPU_Core.data_ram[8'h00], 32'h0000_02AB);
    chk("T1 x12 loaded back",   dut.u_CPU_Core.u_RegFile.regs[12], 32'h0000_02AB);
    $display("");
    $display("--- T2  only ram_addr[9:2] indexes the array ---");
    chk("T2 x13 second address",dut.u_CPU_Core.u_RegFile.regs[13], 32'h0000_1400);
    chk("T2 x14 same array word",
        dut.u_CPU_Core.u_RegFile.regs[14], 32'h0000_02AB);
    $display("");
    $display("--- T3  sync_ram_data is registered on the rising clock edge ---");
    if (!t3_ran) begin
      fail = fail + 1;
      $display("  FAIL  T3 no RAM read cycle was observed");
    end else begin
      chk("T3 after edge = addressed array word",
          after_edge, addressed);
      if (before_edge !== after_edge) begin
        pass = pass + 1;
        $display("  PASS  T3 the update happened at that edge  0x%08h -> 0x%08h",
                 before_edge, after_edge);
      end else begin
        fail = fail + 1;
        $display("  FAIL  T3 no change across the edge  0x%08h", before_edge);
      end
    end
    $display("");
    $display("--- T4  ram_en = 0 leaves sync_ram_data unchanged ---");
    if (!t4_ran) begin
      fail = fail + 1;
      $display("  FAIL  T4 no ram_en = 0 cycle was observed");
    end else begin
      chk("T4 value across an edge with ram_en = 0", hold_after, hold_before);
    end
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
