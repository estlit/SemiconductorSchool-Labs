// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_Decoder.v
//   Testbench for dec.
// =========================================================================

`timescale 1ns/1ps
module tb_dec;
  reg [31:0] instr;
  wire [3:0] ac; wire asrc, mr, mw, rw, br;
  Decoder dut(.instr(instr),.alu_ctrl(ac),.alu_src(asrc),.mem_read(mr),
              .mem_write(mw),.reg_write(rw),.branch(br));
  integer pass=0, fail=0;
  reg [8:0] ctl;                      // {ac, asrc, mr, mw, rw, br}
  task chk(input [400:0] nm, input [31:0] i, input [8:0] exp);
    begin
      instr=i; #1; ctl={ac,asrc,mr,mw,rw,br};
      if (ctl===exp) begin pass=pass+1;
        $display("  PASS  %0s   ctl=%b", nm, ctl); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   ctl=%b exp %b", nm, ctl, exp); end
    end
  endtask
  task same(input [400:0] nm, input [31:0] a, input [31:0] b);
    reg [8:0] x, y;
    begin
      instr=a; #1; x={ac,asrc,mr,mw,rw,br};
      instr=b; #1; y={ac,asrc,mr,mw,rw,br};
      if (x===y) begin pass=pass+1;
        $display("  PASS  %0s   both ctl=%b", nm, x); end
      else begin fail=fail+1;
        $display("  FAIL  %0s   %b vs %b", nm, x, y); end
    end
  endtask
  initial begin
    $display("--- supported 14 ---");
    chk("LUI  ", 32'h000010B7, 9'b0101_1_0_0_1_0);
    chk("LW   ", 32'h0000A083, 9'b0000_1_1_0_1_0);
    chk("SW   ", 32'h0020A023, 9'b0000_1_0_1_0_0);
    chk("ADDI ", 32'h00108093, 9'b0000_1_0_0_1_0);
    chk("ANDI ", 32'h0010F093, 9'b0010_1_0_0_1_0);
    chk("ORI  ", 32'h0010E093, 9'b0011_1_0_0_1_0);
    chk("XORI ", 32'h0010C093, 9'b0100_1_0_0_1_0);
    chk("ADD  ", 32'h002080B3, 9'b0000_0_0_0_1_0);
    chk("SUB  ", 32'h402080B3, 9'b0001_0_0_0_1_0);
    chk("AND  ", 32'h0020F0B3, 9'b0010_0_0_0_1_0);
    chk("OR   ", 32'h0020E0B3, 9'b0011_0_0_0_1_0);
    chk("XOR  ", 32'h0020C0B3, 9'b0100_0_0_0_1_0);
    chk("BEQ  ", 32'h00208063, 9'b0110_0_0_0_0_1);
    chk("BNE  ", 32'h00209063, 9'b0111_0_0_0_0_1);
    $display("");
    $display("--- what the decoder does NOT check ---");
    same("LB  decodes same as LW", 32'h00008083, 32'h0000A083);
    same("LH  decodes same as LW", 32'h00009083, 32'h0000A083);
    same("LBU decodes same as LW", 32'h0000C083, 32'h0000A083);
    same("SB  decodes same as SW", 32'h00208023, 32'h0020A023);
    same("SH  decodes same as SW", 32'h00209023, 32'h0020A023);
    same("SLLI decodes same as ADDI", 32'h00109093, 32'h00108093);
    same("SLTI decodes same as ADDI", 32'h0010A093, 32'h00108093);
    same("SLL  decodes same as ADD",  32'h002090B3, 32'h002080B3);
    same("MUL  decodes same as SUB",  32'h022080B3, 32'h402080B3);
    chk ("BLT  branch=1, alu_ctrl=ADD", 32'h0020C063, 9'b0000_0_0_0_0_1);
    chk ("FENCE -> default control outputs", 32'h0FF0000F, 9'b0000_0_0_0_0_0);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
