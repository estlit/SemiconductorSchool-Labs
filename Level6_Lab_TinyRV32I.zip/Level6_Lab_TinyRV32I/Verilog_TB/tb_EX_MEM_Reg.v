// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_EX_MEM_Reg.v
//   Testbench for exmem.
// =========================================================================

`timescale 1ns/1ps
module tb_exmem;
  reg clk=0, rst=1, stall=0;
  reg [31:0] ex_instr=0, ex_alu=0, ex_rs2=0;
  reg ex_mr=0, ex_mw=0, ex_rw=0;
  wire [31:0] m_instr, m_alu, m_rs2;
  wire m_mr, m_mw, m_rw;
  EX_MEM_Reg dut(.clk(clk),.rst(rst),.stall(stall),
    .ex_instr(ex_instr),.ex_alu_result(ex_alu),.ex_rs2_data(ex_rs2),
    .ex_mem_read(ex_mr),.ex_mem_write(ex_mw),.ex_reg_write(ex_rw),
    .mem_instr(m_instr),.mem_alu_result(m_alu),.mem_rs2_data(m_rs2),
    .mem_mem_read(m_mr),.mem_mem_write(m_mw),.mem_reg_write(m_rw));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [400:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    @(negedge clk);
    $display("--- T1  reset values ---");
    chk("T1 mem_instr = NOP",  m_instr, 32'h0000_0013);
    chk("T1 mem_alu_result",   m_alu,   32'h0000_0000);
    chk("T1 mem_rs2_data",     m_rs2,   32'h0000_0000);
    chk("T1 control 3",        {29'd0, m_mr, m_mw, m_rw}, 32'd0);
    rst=0;
    $display("");
    $display("--- T2  load all six payloads ---");
    ex_instr=32'h00E52623; ex_alu=32'h4000_000C; ex_rs2=32'hCAFE_0001;
    ex_mr=1'b0; ex_mw=1'b1; ex_rw=1'b0;
    @(negedge clk);
    chk("T2 mem_instr",      m_instr, 32'h00E52623);
    chk("T2 mem_alu_result", m_alu,   32'h4000_000C);
    chk("T2 mem_rs2_data",   m_rs2,   32'hCAFE_0001);
    chk("T2 control 3",      {29'd0, m_mr, m_mw, m_rw}, 32'b010);
    $display("");
    $display("--- T3  stall holds every payload ---");
    ex_instr=32'hDEADBEEF; ex_alu=32'h1111_2222; ex_rs2=32'h3333_4444;
    ex_mr=1'b1; ex_mw=1'b0; ex_rw=1'b1; stall=1;
    @(negedge clk);
    chk("T3 mem_instr held",      m_instr, 32'h00E52623);
    chk("T3 mem_alu_result held", m_alu,   32'h4000_000C);
    chk("T3 mem_rs2_data held",   m_rs2,   32'hCAFE_0001);
    chk("T3 control held",        {29'd0, m_mr, m_mw, m_rw}, 32'b010);
    $display("");
    $display("--- T4  reset overrides stall ---");
    // Flush behavior is not tested in this module because
    // EX_MEM_Reg has no flush input.  Absence of a port is verified
    // by interface inspection, not by substituting another signal.
    rst=1; @(negedge clk);
    chk("T4 mem_instr = NOP", m_instr, 32'h0000_0013);
    chk("T4 mem_alu_result",  m_alu,   32'h0000_0000);
    chk("T4 mem_rs2_data",    m_rs2,   32'h0000_0000);
    chk("T4 control 3",       {29'd0, m_mr, m_mw, m_rw}, 32'd0);
    rst=0;
    $display("");
    $display("--- T5  resume ---");
    stall=0; @(negedge clk);
    chk("T5 mem_instr",      m_instr, 32'hDEADBEEF);
    chk("T5 mem_alu_result", m_alu,   32'h1111_2222);
    chk("T5 mem_rs2_data",   m_rs2,   32'h3333_4444);
    chk("T5 control 3",      {29'd0, m_mr, m_mw, m_rw}, 32'b101);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
