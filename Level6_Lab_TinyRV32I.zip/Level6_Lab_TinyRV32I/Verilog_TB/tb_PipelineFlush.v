`timescale 1ns/1ps
// =========================================================================
// Semiconductor School  ·  Chapter 23  Pipeline Flush
// Generation, delivery and application are wired as in the CPU, so the
// testbench only drives the branch inputs.
// Author: Roger Kim   Copyright (c) 2026 Roger Kim & EdgeChipLab
// =========================================================================
module tb_flush;
  reg clk=0, rst=1;
  // --- generation : branch inputs are the only thing the testbench drives
  reg        ex_branch=1'b0, ex_zero=1'b0;
  reg [31:0] ex_pc=32'h40, ex_imm=32'h08;
  reg        rb=1'b1, rs=1'b1, rc=1'b1, rn=1'b1, ro=1'b1, rm=1'b1;
  reg [31:0] addr=32'h4000_3000; reg mrd=1'b1, mwr=1'b0;
  wire sys_stall;
  wire ram_en, ram_we; wire [31:0] ram_addr, ram_wdata;
  wire mv, mw; wire [31:0] ma, mwd;
  wire cb, cs_, cc, cn, co, cm;
  MEM_MMIO_Decoder u_dec(.alu_result(addr),.rs2_data(32'd0),
    .mem_read(mrd),.mem_write(mwr),
    .peri_board_ready(rb),.peri_sonar_ready(rs),.peri_camera_ready(rc),
    .peri_npu_ready(rn),.peri_oled_ready(ro),.peri_motor_ready(rm),
    .ram_en(ram_en),.ram_we(ram_we),.ram_addr(ram_addr),.ram_wdata(ram_wdata),
    .mmio_valid(mv),.mmio_write(mw),.mmio_addr(ma),.mmio_wdata(mwd),
    .cs_board_io(cb),.cs_sonar(cs_),.cs_camera(cc),.cs_npu(cn),
    .cs_oled(co),.cs_motor(cm),.system_stall(sys_stall));
  // --- delivery
  wire [31:0] btgt; wire btaken, pipe_stall, pipe_flush;
  Hazard_Branch_Unit u_hz(.ex_pc(ex_pc),.ex_imm(ex_imm),.ex_branch(ex_branch),
    .ex_zero_flag(ex_zero),.system_stall(sys_stall),
    .branch_target(btgt),.branch_taken(btaken),
    .pipe_stall(pipe_stall),.pipe_flush(pipe_flush));
  // --- application : only the two registers that own a flush port
  reg [31:0] a_pc=32'h100, a_in=32'hAAAA0001;
  wire [31:0] b_pc, b_in;
  IF_ID_Reg u_ifid(.clk(clk),.rst(rst),.stall(pipe_stall),.flush(pipe_flush),
    .if_pc(a_pc),.if_instr(a_in),.id_pc(b_pc),.id_instr(b_in));
  reg [31:0] c_pc=32'h200, c_in=32'hBBBB0002;
  wire [31:0] d_pc, d_in, d_r1, d_r2, d_im; wire [3:0] d_ac;
  wire d_as, d_mr, d_mw, d_rw, d_br;
  ID_EX_Reg u_idex(.clk(clk),.rst(rst),.stall(pipe_stall),.flush(pipe_flush),
    .id_pc(c_pc),.id_instr(c_in),.id_rs1_data(32'd7),.id_rs2_data(32'd8),
    .id_imm(32'd9),.id_alu_ctrl(4'd3),.id_alu_src(1'b1),.id_mem_read(1'b1),
    .id_mem_write(1'b0),.id_reg_write(1'b1),.id_branch(1'b0),
    .ex_pc(d_pc),.ex_instr(d_in),.ex_rs1_data(d_r1),.ex_rs2_data(d_r2),
    .ex_imm(d_im),.ex_alu_ctrl(d_ac),.ex_alu_src(d_as),.ex_mem_read(d_mr),
    .ex_mem_write(d_mw),.ex_reg_write(d_rw),.ex_branch(d_br));

  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [800:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1;
        $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1;
        $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    @(negedge clk); rst=0;
    @(negedge clk); @(negedge clk);
    $display("--- T1  generation : pipe_flush follows branch_taken ---");
    ex_branch=1'b0; ex_zero=1'b0; #1;
    chk("T1 branch 0 zero 0  pipe_flush", {31'd0, pipe_flush}, 32'd0);
    ex_branch=1'b1; ex_zero=1'b0; #1;
    chk("T1 branch 1 zero 0  pipe_flush", {31'd0, pipe_flush}, 32'd0);
    ex_branch=1'b0; ex_zero=1'b1; #1;
    chk("T1 branch 0 zero 1  pipe_flush", {31'd0, pipe_flush}, 32'd0);
    ex_branch=1'b1; ex_zero=1'b1; #1;
    chk("T1 branch 1 zero 1  pipe_flush", {31'd0, pipe_flush}, 32'd1);
    chk("T1 branch_taken and pipe_flush agree",
        {30'd0, btaken, pipe_flush}, 32'b11);
    $display("");
    $display("--- T2  application : both boundaries take the flush value ---");
    @(negedge clk);
    chk("T2 IF_ID_Reg  id_instr = NOP", b_in, 32'h0000_0013);
    chk("T2 IF_ID_Reg  id_pc",          b_pc, 32'h0000_0000);
    chk("T2 ID_EX_Reg  ex_instr = NOP", d_in, 32'h0000_0013);
    chk("T2 ID_EX_Reg  ex_pc",          d_pc, 32'h0000_0000);
    $display("");
    $display("--- T3  flush and stall asserted at the same time ---");
    ex_branch=1'b1; ex_zero=1'b1;   // pipe_flush = 1
    ro=1'b0;                        // pipe_stall = 1
    a_in=32'hEEEE0001; c_in=32'hEEEE0002;
    #1;
    chk("T3 pipe_flush", {31'd0, pipe_flush}, 32'd1);
    chk("T3 pipe_stall", {31'd0, pipe_stall}, 32'd1);
    @(negedge clk);
    chk("T3 IF_ID_Reg  id_instr = NOP", b_in, 32'h0000_0013);
    chk("T3 IF_ID_Reg  id_pc",           b_pc, 32'h0000_0000);
    chk("T3 ID_EX_Reg  ex_instr = NOP",  d_in, 32'h0000_0013);
    chk("T3 ID_EX_Reg  ex_pc",           d_pc, 32'h0000_0000);
    chk("T3 ID_EX_Reg  ex_reg_write",    {31'd0, d_rw}, 32'd0);
    $display("");
    $display("--- T4  stall hold versus normal update ---");
    ex_branch=1'b0; ex_zero=1'b0; #1;   // flush 0, stall still 1
    a_in=32'h1111AAAA; c_in=32'h2222BBBB;
    @(negedge clk);
    chk("T4 stall only  IF_ID_Reg held", b_in, 32'h0000_0013);
    chk("T4 stall only  ID_EX_Reg held", d_in, 32'h0000_0013);
    ro=1'b1; #1;
    @(negedge clk);
    chk("T4 both low  IF_ID_Reg loads", b_in, 32'h1111AAAA);
    chk("T4 both low  ID_EX_Reg loads", d_in, 32'h2222BBBB);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
