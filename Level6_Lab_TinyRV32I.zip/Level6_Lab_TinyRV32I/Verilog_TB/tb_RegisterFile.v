// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// tb_RegisterFile.v
//   Testbench for rf.
// =========================================================================

`timescale 1ns/1ps
module tb_rf;
  reg clk=0, rst=1, reg_write=0;
  reg [4:0] rs1_addr=0, rs2_addr=0, rd_addr=0;
  reg [31:0] wb_data=0;
  wire [31:0] rs1_data, rs2_data;
  RegisterFile dut(.clk(clk),.rst(rst),.rs1_addr(rs1_addr),.rs2_addr(rs2_addr),
                   .rd_addr(rd_addr),.wb_data(wb_data),.reg_write(reg_write),
                   .rs1_data(rs1_data),.rs2_data(rs2_data));
  always #5 clk=~clk;
  integer pass=0, fail=0;
  task chk(input [200:0] nm, input [31:0] got, input [31:0] exp);
    begin
      if (got===exp) begin pass=pass+1; $display("  PASS  %0s  = 0x%08h", nm, got); end
      else begin fail=fail+1; $display("  FAIL  %0s  got 0x%08h exp 0x%08h", nm, got, exp); end
    end
  endtask
  initial begin
    $dumpfile("rf.vcd"); $dumpvars(0, tb_rf);
    @(negedge clk); rst=0;
    // T1 write x5 = 0xDEADBEEF
    rd_addr=5; wb_data=32'hDEADBEEF; reg_write=1; @(negedge clk);
    reg_write=0; rs1_addr=5; #1; chk("T1 read x5 after write", rs1_data, 32'hDEADBEEF);
    // T2 write x0 must be ignored
    rd_addr=0; wb_data=32'hFFFFFFFF; reg_write=1; @(negedge clk);
    reg_write=0; rs1_addr=0; #1; chk("T2 x0 stays zero", rs1_data, 32'h00000000);
    // T3 two ports read different registers at once
    rd_addr=9; wb_data=32'h1234_5678; reg_write=1; @(negedge clk);
    reg_write=0; rs1_addr=5; rs2_addr=9; #1;
    chk("T3 port A", rs1_data, 32'hDEADBEEF);
    chk("T3 port B", rs2_data, 32'h12345678);
    // T4 reset clears everything
    rst=1; @(negedge clk); rst=0; rs1_addr=5; rs2_addr=9; #1;
    chk("T4 x5 after reset", rs1_data, 32'h00000000);
    chk("T4 x9 after reset", rs2_data, 32'h00000000);
    $display("");
    $display("  RESULT : %0d PASS / %0d FAIL", pass, fail);
    $finish;
  end
endmodule
