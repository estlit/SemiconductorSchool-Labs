// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// RegisterFile.v
//   Module RegisterFile.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: RegisterFile
// Description: 32x32-bit RISC-V Register File.
//              - Register 0 (x0) is hardwired to zero.
//              - Two asynchronous read ports.
//              - One synchronous write port with active-high reset.
// =========================================================================
module RegisterFile (
    input  wire        clk,
    input  wire        rst,         // Active-High Reset
    input  wire [4:0]  rs1_addr,
    input  wire [4:0]  rs2_addr,
    input  wire [4:0]  rd_addr,
    input  wire [31:0] wb_data,
    input  wire        reg_write,
    output wire [31:0] rs1_data,
    output wire [31:0] rs2_data
);

    // Declare 32 of 32-bit registers
    reg [31:0] regs [0:31];

    // [Read Port]: Combinational logic (Outputs immediately when address changes)
    // If address is 0, always return 0; otherwise, return the register value.
    assign rs1_data = (rs1_addr == 5'd0) ? 32'd0 : regs[rs1_addr];
    assign rs2_data = (rs2_addr == 5'd0) ? 32'd0 : regs[rs2_addr];

    // [Write Port]: Synchronous write with Active-High Reset
    integer i;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            // Initialize all registers to 0 when rst is asserted high
            for (i = 0; i < 32; i = i + 1) begin
                regs[i] <= 32'd0;
            end
        end else if (reg_write && rd_addr != 5'd0) begin
            // Write data to the destination register (except x0)
            regs[rd_addr] <= wb_data;
        end
    end

endmodule
///////////////////////////////////////////////////////////////////////////
