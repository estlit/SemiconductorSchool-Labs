// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// FPGA_Arty_S7_Top.v
//   Module FPGA_Arty_S7_Top.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: FPGA_Arty_S7_Top
// Description: Top-level hardware wrapper for the TinyRV32I Calculator Demo.
//              Configured for 6-Bit LED Output and BTN2 Reset.
// =========================================================================
module FPGA_Arty_S7_Top (
    input  wire       clk,
    input  wire       i_rst_btn,  // Dedicated Reset (Active-High, Mapped to BTN2)

    input  wire [3:0] i_sw,       // Input A: Slide Switches [SW3:SW0] (0x4000_0000)
    input  wire [1:0] i_btn_b,    // Input B: Push Buttons [BTN1:BTN0] (0x4000_0004)
    input  wire       i_btn_mode, // Mode Select: Push Button [BTN3]   (0x4000_0008)
    output reg  [5:0] o_led       // Output: 6-Bit LEDs [LD5:LD0_Green] (0x4000_000C)
);

    // System Reset Connection
    wire rst = i_rst_btn;

    // =========================================================================
    // Internal Bus & Control Interconnect Wires
    // =========================================================================
    wire        cs_board_io, cs_sonar, cs_camera, cs_npu, cs_oled, cs_motor;
    wire        mmio_valid, mmio_write;
    wire [31:0] mmio_addr;
    wire [31:0] mmio_wdata;
    reg  [31:0] mmio_rdata;

    // =========================================================================
    // Core CPU Instantiation
    // =========================================================================
    TinyRV32I_Top u_CPU_Core (
        .clk              (clk),
        .rst              (rst),
        
        .peri_board_ready (1'b1),
        .peri_sonar_ready (1'b1),
        .peri_camera_ready(1'b1),
        .peri_npu_ready   (1'b1),
        .peri_oled_ready  (1'b1),
        .peri_motor_ready (1'b1),
        
        .cs_board_io      (cs_board_io),
        .cs_sonar         (cs_sonar),
        .cs_camera        (cs_camera),
        .cs_npu           (cs_npu),
        .cs_oled          (cs_oled),
        .cs_motor         (cs_motor),
        
        .mmio_valid       (mmio_valid),
        .mmio_write       (mmio_write),
        .mmio_addr        (mmio_addr),
        .mmio_wdata       (mmio_wdata),
        .mmio_rdata       (mmio_rdata)
    );

    // =========================================================================
    // MMIO Write: Register Output Mapping to LEDs (Address: 0x4000_000C)
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            o_led <= 6'd0;
        end else begin
            if (mmio_valid && mmio_write && cs_board_io && (mmio_addr[15:0] == 16'h000C)) begin
                // Extract only the lower 6 bits to prevent hardware overflow
                o_led <= mmio_wdata[5:0];
            end
        end
    end

    // =========================================================================
    // MMIO Read: Switch/Button Input Mapping to Data Bus
    // =========================================================================
    always @(*) begin
        mmio_rdata = 32'd0; // Default read value
        
        if (mmio_valid && !mmio_write && cs_board_io) begin
            case (mmio_addr[15:0])
                16'h0000: mmio_rdata = {28'd0, i_sw};       // Read Input A (0x00)
                16'h0004: mmio_rdata = {30'd0, i_btn_b};    // Read Input B (0x04)
                16'h0008: mmio_rdata = {31'd0, i_btn_mode}; // Read Mode    (0x08)
                default:  mmio_rdata = 32'd0;
            endcase
        end
    end

endmodule
///////////////////////////////////////////////////////////////////////////
