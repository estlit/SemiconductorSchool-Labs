// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// ALU.v
//   Module ALU.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module ALU (
    input  wire [31:0] alu_in_a,    // Operand A from Register File (rs1)
    input  wire [31:0] alu_in_b,    // Operand B from Register File (rs2) or Immediate
    input  wire [3:0]  alu_ctrl,    // 4-bit ALU control signal
    output reg  [31:0] alu_result,  // 32-bit computation result
    output wire        zero         // Zero flag for Branch condition resolution
);

    // ALU Operation Codes based on POR specification
    localparam ALU_ADD    = 4'b0000;
    localparam ALU_SUB    = 4'b0001;
    localparam ALU_AND    = 4'b0010;
    localparam ALU_OR     = 4'b0011;
    localparam ALU_XOR    = 4'b0100;
    localparam ALU_PASS_B = 4'b0101; // For LUI instruction
    localparam ALU_CMP_EQ = 4'b0110; // For BEQ instruction
    localparam ALU_CMP_NE = 4'b0111; // For BNE instruction

    // Combinational logic for ALU arithmetic and logical operations
    always @(*) begin
        case (alu_ctrl)
            ALU_ADD:    alu_result = alu_in_a + alu_in_b;
            ALU_SUB:    alu_result = alu_in_a - alu_in_b;
            ALU_AND:    alu_result = alu_in_a & alu_in_b;
            ALU_OR:     alu_result = alu_in_a | alu_in_b;
            ALU_XOR:    alu_result = alu_in_a ^ alu_in_b;
            ALU_PASS_B: alu_result = alu_in_b; 

            // [BUG FIX & LOGIC CLARIFICATION]
            // To assert the 'zero' flag (1) when a branch condition is met,
            // the ALU must explicitly output 0. Otherwise, it outputs 1.
            ALU_CMP_EQ: alu_result = (alu_in_a == alu_in_b) ? 32'd0 : 32'd1;
            ALU_CMP_NE: alu_result = (alu_in_a != alu_in_b) ? 32'd0 : 32'd1;

            default:    alu_result = 32'd0; // Default to 0 to prevent inferred latches
        endcase
    end

    // The zero flag is asserted strictly when the ALU result is exactly 0.
    // This flag is routed to the Hazard & Branch Unit to determine if a branch is taken.
    assign zero = (alu_result == 32'd0) ? 1'b1 : 1'b0;

endmodule
///////////////////////////////////////////////////////////////////////////
