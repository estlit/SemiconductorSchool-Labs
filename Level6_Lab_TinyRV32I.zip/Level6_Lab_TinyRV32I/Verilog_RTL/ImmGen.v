// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// ImmGen.v
//   Module ImmGen.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module ImmGen (
    input  wire [31:0] instr,
    output reg  [31:0] imm
);

    // Extract opcode (lower 7 bits of the instruction)
    wire [6:0] opcode = instr[6:0];

    // RISC-V Standard Opcode Macros
    localparam OP_LOAD   = 7'b0000011; // I-type (LW)
    localparam OP_IMM    = 7'b0010011; // I-type (ADDI, ANDI)
    localparam OP_STORE  = 7'b0100011; // S-type (SW)
    localparam OP_BRANCH = 7'b1100011; // B-type (BEQ, BNE)
    localparam OP_LUI    = 7'b0110111; // U-type (LUI)

    // Combinational logic for immediate extraction and sign-extension
    always @(*) begin
        case (opcode)
            // I-Type: Sign-extend instr[31:20]
            OP_LOAD, OP_IMM: 
                imm = {{20{instr[31]}}, instr[31:20]};
                
            // S-Type: Combine instr[31:25] and instr[11:7], then sign-extend
            OP_STORE: 
                imm = {{20{instr[31]}}, instr[31:25], instr[11:7]};
                
            // B-Type: Combine instr[31], instr[7], instr[30:25], instr[11:8], and append 1'b0 (even address)
            OP_BRANCH: 
                imm = {{20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0};
                
            // U-Type: Shift instr[31:12] to the upper 20 bits, fill lower 12 bits with 0
            OP_LUI: 
                imm = {instr[31:12], 12'd0};
                
            // Default case to prevent latches
            default: 
                imm = 32'd0; 
        endcase
    end

endmodule
///////////////////////////////////////////////////////////////////////////
