// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// MEM_MMIO_Decoder.v
//   Module MEM_MMIO_Decoder.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module MEM_MMIO_Decoder (
    // Inputs from EX/MEM Pipeline Register
    input  wire [31:0] alu_result, // Treated as Address
    input  wire [31:0] rs2_data,   // Data to write
    input  wire        mem_read,
    input  wire        mem_write,
    
    // [FIX 4] Inputs from All Peripherals (Ready/Valid Handshake)
    input  wire        peri_board_ready,
    input  wire        peri_sonar_ready,
    input  wire        peri_camera_ready,
    input  wire        peri_npu_ready,
    input  wire        peri_oled_ready,
    input  wire        peri_motor_ready,
    
    // Outputs to Data RAM
    output wire        ram_en,
    output wire        ram_we,
    output wire [31:0] ram_addr,
    output wire [31:0] ram_wdata,
    
    // Outputs to MMIO Peripherals
    output wire        mmio_valid,
    output wire        mmio_write,
    output wire [31:0] mmio_addr,
    output wire [31:0] mmio_wdata,
    
    // Specific Peripheral Select Signals
    output reg         cs_board_io,
    output reg         cs_sonar,
    output reg         cs_camera,
    output reg         cs_npu,
    output reg         cs_oled,
    output reg         cs_motor,
    
    // Output to Pipeline Control
    output wire        system_stall
);

    wire is_mmio = (alu_result[31:30] == 2'b01);
    
    assign ram_en    = !is_mmio & (mem_read | mem_write);
    assign ram_we    = !is_mmio & mem_write;
    assign ram_addr  = alu_result;
    assign ram_wdata = rs2_data;
    
    assign mmio_valid = is_mmio & (mem_read | mem_write);
    assign mmio_write = mem_write;
    assign mmio_addr  = alu_result;
    assign mmio_wdata = rs2_data;

    // 4. MMIO Peripheral Decoding 
    always @(*) begin
        cs_board_io = 1'b0; cs_sonar = 1'b0; cs_camera = 1'b0;
        cs_npu      = 1'b0; cs_oled  = 1'b0; cs_motor  = 1'b0;

        if (is_mmio && (mem_read || mem_write)) begin
            case (alu_result[15:8])
                8'h00: cs_board_io = 1'b1; 
                8'h01: cs_sonar    = 1'b1; 
                8'h10: cs_camera   = 1'b1; 
                8'h20: cs_npu      = 1'b1; 
                8'h30: cs_oled     = 1'b1; 
                8'h40: cs_motor    = 1'b1; 
                default: ; 
            endcase
        end
    end

    // [FIX 4] System Stall Logic expanded to all peripherals
    assign system_stall = 
        (cs_board_io & ~peri_board_ready) |
        (cs_sonar    & ~peri_sonar_ready) |
        (cs_camera   & ~peri_camera_ready)|
        (cs_npu      & ~peri_npu_ready)   |
        (cs_oled     & ~peri_oled_ready)  |
        (cs_motor    & ~peri_motor_ready);

endmodule
///////////////////////////////////////////////////////////////////////////
