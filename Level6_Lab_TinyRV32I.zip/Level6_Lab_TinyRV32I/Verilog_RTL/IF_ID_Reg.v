// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// IF_ID_Reg.v
//   Module IF_ID_Reg.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module IF_ID_Reg (
    input  wire        clk, rst, stall, flush,
    input  wire [31:0] if_pc, if_instr,
    output reg  [31:0] id_pc, id_instr
);
    always @(posedge clk or posedge rst) begin
        if (rst || flush) begin
            id_pc    <= 32'd0;
            id_instr <= 32'h0000_0013; // NOP
        end else if (!stall) begin
            id_pc    <= if_pc;
            id_instr <= if_instr;
        end
    end
endmodule


module ID_EX_Reg (
    input  wire        clk, rst, stall, flush,
    input  wire [31:0] id_pc, id_instr, id_rs1_data, id_rs2_data, id_imm,
    input  wire [3:0]  id_alu_ctrl,
    input  wire        id_alu_src, // NEW
    input  wire        id_mem_read, id_mem_write, id_reg_write, id_branch,

    output reg  [31:0] ex_pc, ex_instr, ex_rs1_data, ex_rs2_data, ex_imm,
    output reg  [3:0]  ex_alu_ctrl,
    output reg         ex_alu_src, // NEW
    output reg         ex_mem_read, ex_mem_write, ex_reg_write, ex_branch
);
    always @(posedge clk or posedge rst) begin
        if (rst || flush) begin
            ex_pc <= 32'd0; ex_instr <= 32'h0000_0013;
            ex_rs1_data <= 32'd0; ex_rs2_data <= 32'd0; ex_imm <= 32'd0;
            ex_alu_ctrl <= 4'b0000; ex_alu_src <= 1'b0; // NEW
            ex_mem_read <= 1'b0; ex_mem_write <= 1'b0; ex_reg_write <= 1'b0; ex_branch <= 1'b0;
        end else if (!stall) begin
            ex_pc <= id_pc; ex_instr <= id_instr;
            ex_rs1_data <= id_rs1_data; ex_rs2_data <= id_rs2_data; ex_imm <= id_imm;
            ex_alu_ctrl <= id_alu_ctrl; ex_alu_src <= id_alu_src; // NEW
            ex_mem_read <= id_mem_read; ex_mem_write <= id_mem_write; ex_reg_write <= id_reg_write; ex_branch <= id_branch;
        end
    end
endmodule

module EX_MEM_Reg (
    input  wire        clk, rst, stall,
    input  wire [31:0] ex_instr, ex_alu_result, ex_rs2_data,
    input  wire        ex_mem_read, ex_mem_write, ex_reg_write,

    output reg  [31:0] mem_instr, mem_alu_result, mem_rs2_data,
    output reg         mem_mem_read, mem_mem_write, mem_reg_write
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            mem_instr      <= 32'h0000_0013;
            mem_alu_result <= 32'd0;      mem_rs2_data   <= 32'd0;
            mem_mem_read   <= 1'b0;       mem_mem_write  <= 1'b0;       mem_reg_write  <= 1'b0;
        end else if (!stall) begin
            mem_instr      <= ex_instr;
            mem_alu_result <= ex_alu_result; mem_rs2_data   <= ex_rs2_data;
            mem_mem_read   <= ex_mem_read;   mem_mem_write  <= ex_mem_write; mem_reg_write  <= ex_reg_write;
        end
    end
endmodule

module MEM_WB_Reg (
    input  wire        clk, rst, stall,
    input  wire [31:0] mem_instr, mem_alu_result, mem_read_data,
    input  wire        mem_reg_write, mem_mem_read,

    output reg  [31:0] wb_instr, wb_alu_result, wb_read_data,
    output reg         wb_reg_write, wb_mem_to_reg
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wb_instr      <= 32'h0000_0013;
            wb_alu_result <= 32'd0;       wb_read_data  <= 32'd0;
            wb_reg_write  <= 1'b0;        wb_mem_to_reg <= 1'b0;
        end else if (!stall) begin
            wb_instr      <= mem_instr;
            wb_alu_result <= mem_alu_result; wb_read_data  <= mem_read_data;
            wb_reg_write  <= mem_reg_write;  wb_mem_to_reg <= mem_mem_read;
        end
    end
endmodule
///////////////////////////////////////////////////////////////////////////
