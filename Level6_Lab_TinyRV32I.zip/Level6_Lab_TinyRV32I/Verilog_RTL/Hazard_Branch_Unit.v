// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Hazard_Branch_Unit.v
//   Module Hazard_Branch_Unit.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module Hazard_Branch_Unit (
    // Inputs from EX Stage (Branch Resolution) [cite: 613-626]
    input  wire [31:0] ex_pc,
    input  wire [31:0] ex_imm,
    input  wire        ex_branch,    // Is current instruction a branch?
    input  wire        ex_zero_flag, // Result from ALU (CMP_EQ / CMP_NE logic)
    
    // Inputs from MEM/MMIO Stage (Stall Generation) [cite: 704-715]
    input  wire        system_stall, // High when peripheral is not ready

    // Outputs to IF Stage (PC Control) [cite: 575-578]
    output wire [31:0] branch_target,
    output wire        branch_taken,
    
    // Outputs to Pipeline Registers (Stall & Flush) [cite: 700-703]
    output wire        pipe_stall,
    output wire        pipe_flush
);

    // 1. Branch Target Calculation (Adder) [cite: 615, 624]
    // In RISC-V, branch target = PC + Sign-Extended Immediate
    assign branch_target = ex_pc + ex_imm;

    // 2. Branch Condition Resolution [cite: 614, 622-623]
    // Taken if it's a branch instruction AND the ALU condition is met (zero_flag = 1)
    assign branch_taken = ex_branch & ex_zero_flag;

    // 3. Pipeline Register Control Routing [cite: 700-715]
    // If a branch is taken, we must flush the wrong instructions fetched in IF and ID
    assign pipe_flush = branch_taken;
    
    // If MMIO/Memory is busy, we stall the pipeline to hold current state
    assign pipe_stall = system_stall;

endmodule
///////////////////////////////////////////////////////////////////////////
