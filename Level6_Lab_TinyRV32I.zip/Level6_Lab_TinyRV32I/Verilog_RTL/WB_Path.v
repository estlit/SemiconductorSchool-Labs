// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// WB_Path.v
//   Module WB_Path.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module WB_Path (
    input  wire [31:0] wb_alu_result, // From MEM/WB Pipeline Register
    input  wire [31:0] wb_read_data,  // From MEM/WB Pipeline Register (Memory output)
    input  wire        wb_mem_to_reg, // Selection control signal (1: Memory, 0: ALU)
    
    output wire [31:0] wb_data        // Final data to be written into Register File
);

    // 2-to-1 Multiplexer for Write Back Data Selection
    assign wb_data = (wb_mem_to_reg) ? wb_read_data : wb_alu_result;

endmodule
// [PART 2] SIMULATION & VERIFICATION MODULES (Testbench)
///////////////////////////////////////////////////////////////////////////
