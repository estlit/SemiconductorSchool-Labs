// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// IF_Stage.v
//   Module IF_Stage.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module IF_Stage (
    input  wire        clk,
    input  wire        rst,
    input  wire        stall,
    input  wire        branch_taken,
    input  wire [31:0] branch_target,
    output reg  [31:0] pc,
    output wire [31:0] instr
);
    reg [31:0] rom [0:1023];
    initial begin
      $readmemh("program_calc.mem", rom);
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc <= 32'h0000_0000;
        end else if (branch_taken) begin
            // [CRITICAL FIX] Flush(Branch) MUST override Stall!
            pc <= branch_target;
        end else if (stall) begin
            pc <= pc;
        end else begin
            pc <= pc + 32'd4;
        end
    end

    assign instr = (pc < 32'h0000_1000) ? rom[pc[11:2]] : 32'h0000_0013;
endmodule
///////////////////////////////////////////////////////////////////////////
