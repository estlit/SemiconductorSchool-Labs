// =========================================================================
// Semiconductor School
// Author: Roger Kim
// Copyright (c) 2026 Roger Kim & EdgeChipLab
//
// Decoder.v
//   Module Decoder.
// =========================================================================

///////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// =========================================================================
// Module: Decoder
// Description: Main Control Unit for TinyRV32I.
//              Decodes the 32-bit instruction to generate control signals
//              for the ALU, Memory, and Register File.
// =========================================================================
module Decoder (
    input  wire [31:0] instr,
    output reg  [3:0]  alu_ctrl,
    output reg         alu_src,     // 0 = rs2, 1 = imm
    output reg         mem_read,
    output reg         mem_write,
    output reg         reg_write,
    output reg         branch
);
    // Extract instruction fields
    wire [6:0] opcode = instr[6:0];
    wire [2:0] funct3 = instr[14:12];
    wire [6:0] funct7 = instr[31:25];

    // RISC-V Standard Opcode Macros
    localparam OP_LOAD   = 7'b0000011; // LW
    localparam OP_IMM    = 7'b0010011; // ADDI, ANDI, ORI, XORI
    localparam OP_STORE  = 7'b0100011; // SW
    localparam OP_BRANCH = 7'b1100011; // BEQ, BNE
    localparam OP_LUI    = 7'b0110111; // LUI
    localparam OP_OP     = 7'b0110011; // ADD, SUB, AND, OR, XOR

    // ALU Control Macros defined in POR specification
    localparam ALU_ADD    = 4'b0000;
    localparam ALU_SUB    = 4'b0001;
    localparam ALU_AND    = 4'b0010;
    localparam ALU_OR     = 4'b0011;
    localparam ALU_XOR    = 4'b0100;
    localparam ALU_PASS_B = 4'b0101; // For LUI
    localparam ALU_CMP_EQ = 4'b0110; // For BEQ
    localparam ALU_CMP_NE = 4'b0111; // For BNE

    // Main Decoding Logic
    always @(*) begin
        // Default control signal initialization to prevent latches
        alu_ctrl  = ALU_ADD;
        alu_src   = 1'b0;
        mem_read  = 1'b0;
        mem_write = 1'b0;
        reg_write = 1'b0;
        branch    = 1'b0;

        case (opcode)
            OP_LUI: begin
                reg_write = 1'b1;
                alu_src   = 1'b1; // Bypass immediate through ALU
                alu_ctrl  = ALU_PASS_B; 
            end
            
            OP_LOAD: begin
                mem_read  = 1'b1;
                reg_write = 1'b1;
                alu_src   = 1'b1; // Use immediate for address calculation
                alu_ctrl  = ALU_ADD;    
            end
            
            OP_STORE: begin
                mem_write = 1'b1;
                alu_src   = 1'b1; // Use immediate for address calculation
                alu_ctrl  = ALU_ADD;    
            end
            
            OP_IMM: begin
                reg_write = 1'b1;
                alu_src   = 1'b1; // I-Type instructions use immediate
                if (funct3 == 3'b000)      alu_ctrl = ALU_ADD;  // ADDI
                else if (funct3 == 3'b111) alu_ctrl = ALU_AND;  // ANDI
                else if (funct3 == 3'b110) alu_ctrl = ALU_OR;   // ORI
                else if (funct3 == 3'b100) alu_ctrl = ALU_XOR;  // XORI
            end
            
            OP_OP: begin
                reg_write = 1'b1;
                alu_src   = 1'b0; // R-Type instructions use register (rs2)
                if (funct3 == 3'b000) begin
                    if (funct7 == 7'b0000000) alu_ctrl = ALU_ADD; // ADD
                    else                      alu_ctrl = ALU_SUB; // SUB
                end
                else if (funct3 == 3'b111) alu_ctrl = ALU_AND; // AND
                else if (funct3 == 3'b110) alu_ctrl = ALU_OR;  // OR
                else if (funct3 == 3'b100) alu_ctrl = ALU_XOR; // XOR
            end
            
            OP_BRANCH: begin
                branch    = 1'b1;
                alu_src   = 1'b0; // Branches compare rs1 and rs2
                if (funct3 == 3'b000)      alu_ctrl = ALU_CMP_EQ; // BEQ
                else if (funct3 == 3'b001) alu_ctrl = ALU_CMP_NE; // BNE
            end
            
            default: begin
                // NOP or unrecognized opcode
                alu_ctrl  = ALU_ADD;
                alu_src   = 1'b0;
                mem_read  = 1'b0;
                mem_write = 1'b0;
                reg_write = 1'b0;
                branch    = 1'b0;
            end
        endcase
    end
endmodule
///////////////////////////////////////////////////////////////////////////
