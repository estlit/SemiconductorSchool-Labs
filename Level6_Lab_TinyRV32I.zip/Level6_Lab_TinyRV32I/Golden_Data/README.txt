=========================================================================
Semiconductor School
Author: Roger Kim
Copyright (c) 2026 Roger Kim & EdgeChipLab

Program images
=========================================================================

IF_Stage.v reads its instruction memory with

    $readmemh("program_calc.mem", rom);

so the file the CPU runs is always named program_calc.mem. Most labs use
the calculator program, which is the copy shipped under that name.

Four testbenches need a program written for the behaviour they check.
Before running one of these, copy the matching file over
program_calc.mem, then run the simulation.

    tb_DataMemory        program_datamem.mem     load and store sequence
    tb_MMIO_Peripheral   program_mmio.mem        peripheral read and write
    tb_WriteBack         program_writeback.mem   write-back source select
    tb_DataHazard        program_hazard.mem      dependent instructions

Every other testbench runs with the calculator program as shipped.

Keep a copy of the original program_calc.mem, or rebuild it from
Program_Source with generate_calc.py.
