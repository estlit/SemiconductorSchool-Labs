# =========================================================================
# Semiconductor School
# Author: Roger Kim
# Copyright (c) 2026 Roger Kim & EdgeChipLab
#
# calc_demo.s
#   A calculator for TinyRV32I. It reads three inputs over MMIO, adds or
#   subtracts, writes the result to the LED address and repeats.
#
#   Input A     0x4000_0000   slide switches, 0 to 15
#   Input B     0x4000_0004   push buttons,   0 to 3
#   Mode        0x4000_0008   push button,    0 adds, 1 subtracts
#   Result      0x4000_000C   six LEDs
#
#   TinyRV32I has no forwarding and no interlock, so a value written by one
#   instruction is not visible to the next three. Every dependent pair below
#   is therefore separated by NOPs.
# =========================================================================
.text
    .globl _start
_start:
    # -----------------------------------------------------------------
    # [1] MMIO base address, 0x4000_0000
    # -----------------------------------------------------------------
    lui x10, 0x40000
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

read_inputs:
    # -----------------------------------------------------------------
    # [2] read the three inputs
    # -----------------------------------------------------------------
    lw x11, 0(x10)          # x11 = Input A
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

    lw x12, 4(x10)          # x12 = Input B
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

    lw x13, 8(x10)          # x13 = Mode, 0 adds and anything else subtracts
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

    # -----------------------------------------------------------------
    # [3] choose the operation
    # -----------------------------------------------------------------
    bne x13, x0, do_sub
    addi x0, x0, 0; addi x0, x0, 0      # margin for the branch flush

do_add:
    add x14, x11, x12       # x14 = A + B
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0
    beq x0, x0, write_out
    addi x0, x0, 0; addi x0, x0, 0

do_sub:
    sub x14, x11, x12       # x14 = A - B
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

write_out:
    # -----------------------------------------------------------------
    # [4] write the result and start again
    # -----------------------------------------------------------------
    sw x14, 12(x10)         # the low six bits reach the LEDs
    addi x0, x0, 0; addi x0, x0, 0; addi x0, x0, 0

    beq x0, x0, read_inputs
    addi x0, x0, 0; addi x0, x0, 0
