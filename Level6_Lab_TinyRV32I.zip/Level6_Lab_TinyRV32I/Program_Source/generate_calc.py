# =========================================================================
# Semiconductor School
# Author: Roger Kim
# Copyright (c) 2026 Roger Kim & EdgeChipLab
#
# generate_calc.py
#   Builds program_calc.mem from calc_demo.s.
#
#   The assembly is linked into an ELF, then the .text section alone is
#   written out in the Verilog memory format that $readmemh reads.
#
#   Run this from the folder that holds calc_demo.s. Every file name below
#   is relative, which both Windows and WSL read the same way.
#
#   Requires the RISC-V bare metal toolchain:
#       riscv64-unknown-elf-gcc
#       riscv64-unknown-elf-objcopy
# =========================================================================
import subprocess
import sys
import os

# =====================================================================
# Environment
# =====================================================================
USE_WSL = True          # set to False when the toolchain is on the PATH


def wrap_cmd(cmd_list):
    if USE_WSL:
        return ["wsl"] + cmd_list
    return cmd_list


# =====================================================================
# Application builder, machine code only, no Spike
# =====================================================================
def compile_app(asm_file):
    print("==================================================")
    print(f"[App Build] generating machine code from '{asm_file}'")
    print("==================================================")

    if not os.path.exists(asm_file):
        print(f"error: '{asm_file}' not found")
        return False

    print("[1/2] writing the linker script and running GCC")
    # a plain memory map, with no tohost region and no answer section
    linker_script = """
OUTPUT_ARCH(riscv)
ENTRY(_start)
SECTIONS
{
  . = 0x80000000;
  .text : { *(.text) }
  .data : { *(.data) }
}
"""
    with open("link_app.ld", "w", encoding="utf-8") as f:
        f.write(linker_script)

    cmd_gcc = wrap_cmd([
        "riscv64-unknown-elf-gcc", "-march=rv32i", "-mabi=ilp32", "-nostdlib",
        "-T", "link_app.ld", asm_file, "-o", "app.elf"
    ])

    try:
        subprocess.run(cmd_gcc, check=True, capture_output=True, text=True,
                       encoding='utf-8')
    except subprocess.CalledProcessError as e:
        print(f"GCC error\n{e.stderr}")
        return False

    print("[2/2] extracting the memory image")
    # A raw binary is taken rather than objcopy's verilog output. The
    # verilog writer has been observed to emit the four bytes of a word in
    # memory order on some installations, which is not what $readmemh needs.
    # Reading the bytes and assembling the words here removes the question.
    cmd_objcopy = wrap_cmd([
        "riscv64-unknown-elf-objcopy", "-O", "binary", "-j", ".text",
        "app.elf", "app.bin"
    ])
    subprocess.run(cmd_objcopy, check=True)

    with open("app.bin", "rb") as f:
        blob = f.read()
    if len(blob) % 4:
        blob += b"\x00" * (4 - len(blob) % 4)
    words = [int.from_bytes(blob[i:i + 4], "little")
             for i in range(0, len(blob), 4)]

    with open("program_calc.mem", "w", encoding="utf-8") as f:
        f.write("@00000000\n")
        for i in range(0, len(words), 4):
            f.write(" ".join("%08X" % w for w in words[i:i + 4]) + "\n")

    print(f"\ndone: 'program_calc.mem' written, {len(words)} words")
    return True


if __name__ == "__main__":
    compile_app("calc_demo.s")
