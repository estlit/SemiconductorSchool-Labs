=========================================================================
Semiconductor School
Author: Roger Kim
Copyright (c) 2026 Roger Kim & EdgeChipLab

Level 6 Lab - TinyRV32I
=========================================================================

Board   Arty S7-25
Part    xc7s25csga324-1
Vivado  2023.1 or later


FOLDERS
-------------------------------------------------------------------------
Verilog_RTL/      The CPU. Add every file to Design Sources.
                  FPGA_Arty_S7_Top.v is the top module.

Verilog_TB/       Testbenches. Add the one for the lab you are running
                  to Simulation Sources and set it as the simulation top.

Golden_Data/      program_calc.mem, the program the CPU runs.
                  Add it to the project as a Memory File.
                  Keep the name. IF_Stage.v looks for it by that name.

Program_Source/   The files that produce program_calc.mem.
                  calc_demo.s        the calculator in RISC-V assembly
                  generate_calc.py   assembles and links it, then writes
                                     the memory image

Vivado_xdc/       TinyRV32I.xdc, the pin assignments. Add to Constraints.


RUNNING A SIMULATION
-------------------------------------------------------------------------
1  Open the project.
2  Right click the testbench and set it as the top for simulation.
3  Run Simulation.
4  Read the Tcl Console. Each check prints PASS or FAIL with the value
   it saw. The last line reports the totals.


REBUILDING THE PROGRAM
-------------------------------------------------------------------------
Golden_Data/program_calc.mem is already built, so the toolchain is only
needed if you change the program.

    cd Program_Source
    python3 generate_calc.py

This needs riscv64-unknown-elf-gcc and riscv64-unknown-elf-objcopy.
