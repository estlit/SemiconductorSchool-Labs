"""
EdgeChipLab CPU Studio - RV32I Text Studio
verify_all - run every check, in the order that makes a failure readable.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

  python verify_all.py

Three layers, and each one exists because the layer below it cannot see the
faults the layer above catches.

  1  engine    encodings and decodings against the specification
  2  book      every screen renders, the numbers on it match, the coverage
               table has no holes, and a capture is reproducible
  3  fault      break the project on purpose and confirm 1 and 2 notice

Layer 3 is the one that matters most. A suite that always passes proves
nothing; the only evidence that a check works is watching it fail when the
fault it guards against is present.
"""

import subprocess
import sys

STAGES = [
    ("엔진 검증", ["-m", "tests.self_test"],
     "인코딩·디코딩이 명세와 맞는가"),
    ("교재 연계 검증", ["-m", "tests.book_test"],
     "화면·덮개·재현성이 교재에 쓸 수 있는 상태인가"),
    ("결함 주입 시험", ["-m", "tests.fault_test"],
     "위 두 검증이 실제로 결함을 잡는가"),
]


def main():
    print("=" * 78)
    print(" EdgeChipLab CPU Studio  —  전체 검증")
    print("=" * 78)
    results = []
    for title, args, why in STAGES:
        print()
        print(" [%s] %s" % (title, why))
        print(" " + "-" * 76)
        run = subprocess.run([sys.executable] + args, capture_output=True,
                             text=True)
        tail = [line for line in run.stdout.split("\n") if line.strip()][-6:]
        for line in tail:
            print("   " + line)
        ok = run.returncode == 0
        results.append((title, ok))
        if not ok:
            print()
            print("   실패한 항목")
            for line in run.stdout.split("\n"):
                if "FAIL" in line or "놓침" in line:
                    print("     " + line.strip())
    print()
    print("=" * 78)
    for title, ok in results:
        print("  %-22s %s" % (title, "통과" if ok else "실패"))
    everything = all(ok for _, ok in results)
    print("-" * 78)
    print("  %s" % ("세 단계 모두 통과했습니다."
                    if everything else "실패한 단계가 있습니다."))
    print("=" * 78)
    return 0 if everything else 1


if __name__ == "__main__":
    sys.exit(main())
