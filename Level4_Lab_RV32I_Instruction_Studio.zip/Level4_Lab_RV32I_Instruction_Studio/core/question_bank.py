from dataclasses import dataclass
from typing import Dict, List, Any

from .cpu_state import CPUState
from .encoder import encode_instruction
from .decoder import decode
from .executor import execute
from .instruction_db import INSTRUCTION_DB, get_instruction


@dataclass(frozen=True)
class Question:
    qid: str
    topic: str
    prompt: str
    answer: str
    explanation: str
    instruction: str | None = None
    source: str = "TOPIC"


TOPIC_QUESTIONS: List[Question] = [
    Question(
        "Q01", "SYSTEM",
        "0x00000073은 ECALL입니까, EBREAK입니까?",
        "ECALL",
        "system immediate가 0x000이고 나머지 고정 비트도 ECALL 패턴과 일치합니다.",
    ),
    Question(
        "Q02", "SYSTEM",
        "ECALL과 EBREAK를 구분하는 핵심 필드는 무엇입니까?",
        "system immediate 12비트",
        "opcode와 funct3는 같으며 즉시값 12비트 전체를 포함한 고정 패턴으로 구분합니다.",
    ),
    Question(
        "Q03", "JUMP",
        "PC=0x1000에서 jal x1, 12를 실행하면 x1과 다음 PC는 얼마입니까?",
        "x1=0x1004, PC=0x100C",
        "JAL은 PC+4를 rd에 저장하고 PC+offset으로 점프합니다.",
    ),
    Question(
        "Q04", "JUMP",
        "x5=0x1003에서 jalr x1, 0(x5)를 실행하면 최종 PC는 얼마입니까?",
        "0x1002",
        "JALR은 rs1+imm을 계산한 뒤 bit0을 0으로 만듭니다.",
    ),
    Question(
        "Q05", "BRANCH",
        "B 형식에서 imm[0]을 저장하지 않는 이유는 무엇입니까?",
        "분기 offset이 항상 2의 배수이기 때문입니다.",
        "최하위 비트가 항상 0이므로 저장하지 않고 도달 범위를 늘립니다.",
    ),
    Question(
        "Q06", "FENCE",
        "FENCE에서 디코드 마스크의 가변 필드로 남겨야 하는 것은 무엇입니까?",
        "pred와 succ",
        "pred와 succ는 접근 종류를 지정하므로 가변이며, 고정 필드만 match_mask에 포함합니다.",
    ),
    Question(
        "Q07", "RTL",
        "LW의 reg_write, mem_read, mem_write 값은 무엇입니까?",
        "1, 1, 0",
        "메모리를 읽은 결과를 rd에 기록하므로 reg_write와 mem_read가 1입니다.",
    ),
    Question(
        "Q08", "RTL",
        "SW의 reg_write, mem_read, mem_write 값은 무엇입니까?",
        "0, 0, 1",
        "저장 명령어는 rd를 기록하지 않고 메모리에 씁니다.",
    ),
    Question(
        "Q09", "RTL",
        "BEQ의 다음 PC 선택 방식은 무엇입니까?",
        "조건에 따라 PC+4 또는 PC+offset",
        "분기 비교 결과가 참이면 분기 목표를, 거짓이면 순차 PC를 선택합니다.",
    ),
    Question(
        "Q10", "FORMATS",
        "R, I, S, B, U, J 외에 Instruction Studio가 별도 레이아웃으로 다루는 세 형식은 무엇입니까?",
        "I_SHIFT, FENCE, SYSTEM",
        "교육적 필드 표시와 고정 패턴 판정을 위해 별도 레이아웃으로 분리했습니다.",
    ),
]


def _hex32(value: int) -> str:
    return f"0x{value & 0xFFFFFFFF:08X}"


def _sample_operands(name: str) -> Dict[str, int]:
    spec = get_instruction(name)
    layout = spec["layout"]

    if layout == "R":
        return {"rd": 5, "rs1": 1, "rs2": 2}
    if layout == "I":
        if name == "JALR":
            return {"rd": 5, "rs1": 1, "imm": 4}
        if name in ("LB", "LBU"):
            return {"rd": 5, "rs1": 1, "imm": 1}
        if name in ("LH", "LHU"):
            return {"rd": 5, "rs1": 1, "imm": 2}
        if name == "LW":
            return {"rd": 5, "rs1": 1, "imm": 4}
        return {"rd": 5, "rs1": 1, "imm": 7}
    if layout == "I_SHIFT":
        return {"rd": 5, "rs1": 1, "shamt": 3}
    if layout == "S":
        return {"rs1": 1, "rs2": 2, "imm": 4}
    if layout == "B":
        return {"rs1": 1, "rs2": 2, "imm": 8}
    if layout == "U":
        return {"rd": 5, "imm20": 0x12345}
    if layout == "J":
        return {"rd": 5, "imm": 8}
    return {}


def _register_setup(name: str, cpu: CPUState) -> None:
    spec = get_instruction(name)
    layout = spec["layout"]

    cpu.pc = 0x00001000

    if layout == "R":
        cpu.write_reg(1, 10)
        cpu.write_reg(2, 3)
    elif layout in ("I", "I_SHIFT"):
        cpu.write_reg(1, 10)
        if name in ("LB", "LBU", "LH", "LHU", "LW"):
            cpu.write_reg(1, 0x00000100)
        if name == "JALR":
            cpu.write_reg(1, 0x00002003)
    elif layout == "S":
        cpu.write_reg(1, 0x00000100)
        cpu.write_reg(2, 0x11223344)
    elif layout == "B":
        if name in ("BEQ", "BGE", "BGEU"):
            cpu.write_reg(1, 5)
            cpu.write_reg(2, 5)
        else:
            cpu.write_reg(1, 3)
            cpu.write_reg(2, 5)
    elif layout == "FENCE":
        pass
    elif layout == "SYSTEM":
        pass

    if name in ("LB", "LBU"):
        cpu.store_byte(0x00000101, 0x80)
    elif name in ("LH", "LHU"):
        cpu.store_half(0x00000102, 0x8001)
    elif name == "LW":
        cpu.store_word(0x00000104, 0x89ABCDEF)


def _assembly_text(name: str, operands: Dict[str, int]) -> str:
    spec = get_instruction(name)
    layout = spec["layout"]

    if layout == "R":
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, x{operands['rs2']}"
    if layout == "I":
        if name in ("LB", "LH", "LW", "LBU", "LHU", "JALR"):
            return f"{name.lower()} x{operands['rd']}, {operands['imm']}(x{operands['rs1']})"
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, {operands['imm']}"
    if layout == "I_SHIFT":
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, {operands['shamt']}"
    if layout == "S":
        return f"{name.lower()} x{operands['rs2']}, {operands['imm']}(x{operands['rs1']})"
    if layout == "B":
        return f"{name.lower()} x{operands['rs1']}, x{operands['rs2']}, {operands['imm']}"
    if layout == "U":
        return f"{name.lower()} x{operands['rd']}, 0x{operands['imm20']:05X}"
    if layout == "J":
        return f"{name.lower()} x{operands['rd']}, {operands['imm']}"
    return name.lower()


def _state_change_answer(name: str, result, cpu: CPUState) -> tuple[str, str]:
    spec = get_instruction(name)
    category = spec["category"]

    if category in ("ALU", "UPPER", "LOAD"):
        answer = f"x{result.rd}={_hex32(result.rd_after)}, PC={_hex32(result.pc_after)}"
        explanation = (
            f"{name} 실행 결과 rd가 {_hex32(result.rd_before)}에서 "
            f"{_hex32(result.rd_after)}로 바뀌고 PC는 4 증가합니다."
        )
        return answer, explanation

    if category == "STORE":
        address = result.effective_address
        width = spec["memory_width"]
        stored = cpu.memory_bytes(address, width)
        bytes_text = " ".join(f"{b:02X}" for b in stored)
        return (
            f"주소 {_hex32(address)}의 {width}바이트 = {bytes_text}, PC={_hex32(result.pc_after)}",
            "저장 명령어는 rd를 기록하지 않고 계산된 주소의 메모리 바이트를 변경합니다.",
        )

    if category == "BRANCH":
        return (
            f"taken={result.branch_taken}, PC={_hex32(result.pc_after)}",
            f"비교 결과에 따라 {_hex32(result.branch_target)} 또는 "
            f"{_hex32(result.sequential_pc)}가 선택됩니다.",
        )

    if category == "JUMP":
        return (
            f"x{result.rd}={_hex32(result.rd_after)}, PC={_hex32(result.pc_after)}",
            "점프 명령어는 PC+4를 rd에 저장하고 계산된 목표 주소를 다음 PC로 선택합니다.",
        )

    if category == "FENCE":
        return (
            f"PC={_hex32(result.pc_after)}",
            "교육용 실행 모델에서는 순서 보장 요청을 표시하고 PC를 4 증가시킵니다.",
        )

    if category == "SYSTEM":
        return (
            f"{result.system_event}, PC={_hex32(result.pc_after)}",
            "특권 모드 trap handler는 모델 범위 밖이므로 예외 요청을 표시하고 원인 PC를 유지합니다.",
        )

    raise ValueError(f"지원하지 않는 범주: {category}")


def _build_instruction_question(index: int, name: str) -> Question:
    operands = _sample_operands(name)
    word = encode_instruction(name, **operands)
    decoded = decode(word)

    cpu = CPUState()
    _register_setup(name, cpu)
    result = execute(cpu, word)

    answer, explanation = _state_change_answer(name, result, cpu)
    assembly = _assembly_text(name, operands)

    prompt = (
        f"{assembly}의 기계어는 {_hex32(word)}입니다. "
        f"주어진 초기 상태에서 이 명령어를 실행한 뒤 핵심 상태 변화는 무엇입니까?"
    )

    return Question(
        qid=f"IQ{index:02d}",
        topic=decoded["layout"],
        prompt=prompt,
        answer=answer,
        explanation=explanation,
        instruction=name,
        source="INSTRUCTION_DB",
    )


INSTRUCTION_QUESTIONS: List[Question] = [
    _build_instruction_question(index, name)
    for index, name in enumerate(INSTRUCTION_DB, start=1)
]

QUESTIONS: List[Question] = TOPIC_QUESTIONS + INSTRUCTION_QUESTIONS


def question_by_id(qid: str) -> Question:
    for q in QUESTIONS:
        if q.qid == qid:
            return q
    raise ValueError(f"알 수 없는 문제 번호: {qid}")


def questions_for_instruction(name: str) -> List[Question]:
    key = name.upper()
    if key not in INSTRUCTION_DB:
        raise ValueError(f"알 수 없는 명령어: {name}")
    return [q for q in INSTRUCTION_QUESTIONS if q.instruction == key]


def validate_question_bank() -> Dict[str, Any]:
    ids = [q.qid for q in QUESTIONS]
    covered = {q.instruction for q in INSTRUCTION_QUESTIONS if q.instruction}
    return {
        "count": len(QUESTIONS),
        "topic_count": len(TOPIC_QUESTIONS),
        "instruction_count": len(INSTRUCTION_QUESTIONS),
        "unique_ids": len(ids) == len(set(ids)),
        "nonempty": all(q.prompt and q.answer and q.explanation for q in QUESTIONS),
        "covered_instructions": covered,
        "all_instructions_covered": covered == set(INSTRUCTION_DB),
        "exactly_one_per_instruction": all(
            len(questions_for_instruction(name)) == 1 for name in INSTRUCTION_DB
        ),
    }
