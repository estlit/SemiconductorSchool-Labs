from .utils import u32

def jal_target(pc: int, offset: int) -> int:
    return u32(pc + offset)

def jalr_target(base: int, offset: int) -> tuple[int, int]:
    raw_target = u32(base + offset)
    final_target = raw_target & 0xFFFFFFFE
    return raw_target, final_target

def return_address(pc: int) -> int:
    return u32(pc + 4)
