def check_register(index: int) -> None:
    if not isinstance(index, int) or not 0 <= index <= 31:
        raise ValueError(f"Register index must be 0..31, got {index!r}")

def check_signed(value: int, bits: int, name: str = "value") -> None:
    lo = -(1 << (bits - 1))
    hi = (1 << (bits - 1)) - 1
    if not isinstance(value, int) or not lo <= value <= hi:
        raise ValueError(f"{name} must be in {lo}..{hi}, got {value!r}")

def u32(value: int) -> int:
    return value & 0xFFFFFFFF

def s32(value: int) -> int:
    value &= 0xFFFFFFFF
    return value - (1 << 32) if value & 0x80000000 else value

def sign_extend(value: int, bits: int) -> int:
    mask = (1 << bits) - 1
    value &= mask
    sign = 1 << (bits - 1)
    return value - (1 << bits) if value & sign else value

def bits(value: int, width: int) -> str:
    return f"{value & ((1 << width) - 1):0{width}b}"
