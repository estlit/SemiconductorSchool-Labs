from .utils import s32, u32

def execute_alu(operation: str, a: int, b: int) -> int:
    a = u32(a)
    b = u32(b)
    shamt = b & 0x1F

    if operation == "ADD":
        return u32(a + b)
    if operation == "SUB":
        return u32(a - b)
    if operation == "SLL":
        return u32(a << shamt)
    if operation == "SLT":
        return 1 if s32(a) < s32(b) else 0
    if operation == "SLTU":
        return 1 if a < b else 0
    if operation == "XOR":
        return u32(a ^ b)
    if operation == "SRL":
        return u32(a >> shamt)
    if operation == "SRA":
        return u32(s32(a) >> shamt)
    if operation == "OR":
        return u32(a | b)
    if operation == "AND":
        return u32(a & b)

    raise ValueError(f"지원하지 않는 ALU 연산: {operation}")
