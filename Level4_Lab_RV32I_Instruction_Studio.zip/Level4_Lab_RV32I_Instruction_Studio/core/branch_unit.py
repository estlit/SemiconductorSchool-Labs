from .utils import s32, u32

def evaluate_branch(comparison: str, a: int, b: int) -> bool:
    """분기 비교 조건을 평가합니다."""
    a_u = u32(a)
    b_u = u32(b)

    if comparison == "EQ":
        return a_u == b_u
    if comparison == "NE":
        return a_u != b_u
    if comparison == "LT":
        return s32(a_u) < s32(b_u)
    if comparison == "GE":
        return s32(a_u) >= s32(b_u)
    if comparison == "LTU":
        return a_u < b_u
    if comparison == "GEU":
        return a_u >= b_u

    raise ValueError(f"지원하지 않는 분기 비교: {comparison}")
