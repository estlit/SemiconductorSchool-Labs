from .instruction_db import INSTRUCTION_DB
from .utils import sign_extend

def _specificity(spec: dict) -> int:
    return spec["match_mask"].bit_count()

def _ordered_candidates():
    return sorted(
        INSTRUCTION_DB.items(),
        key=lambda item: _specificity(item[1]),
        reverse=True,
    )

def _matches(word: int, spec: dict) -> bool:
    return (word & spec["match_mask"]) == spec["match_value"]

def decode(machine_code: int) -> dict:
    word = machine_code & 0xFFFFFFFF

    for name, spec in _ordered_candidates():
        if not _matches(word, spec):
            continue

        decoded = {
            "name": name,
            "format": spec["format"],
            "layout": spec["layout"],
            "opcode": word & 0x7F,
            "match_mask": spec["match_mask"],
            "match_value": spec["match_value"],
        }

        if "rd" in spec["operands"]:
            decoded["rd"] = (word >> 7) & 0x1F
        if "funct3" in spec:
            decoded["funct3"] = (word >> 12) & 0x7
        if "rs1" in spec["operands"]:
            decoded["rs1"] = (word >> 15) & 0x1F
        if "rs2" in spec["operands"]:
            decoded["rs2"] = (word >> 20) & 0x1F
        if "funct7" in spec:
            decoded["funct7"] = (word >> 25) & 0x7F

        layout = spec["layout"]
        if layout == "I":
            imm_raw = (word >> 20) & 0xFFF
            decoded["imm_raw"] = imm_raw
            decoded["imm"] = sign_extend(imm_raw, 12)
        elif layout == "I_SHIFT":
            decoded["shamt"] = (word >> 20) & 0x1F
        elif layout == "S":
            imm_raw = (((word >> 25) & 0x7F) << 5) | ((word >> 7) & 0x1F)
            decoded.update(
                imm_raw=imm_raw, imm=sign_extend(imm_raw, 12),
                imm_hi=(word >> 25) & 0x7F, imm_lo=(word >> 7) & 0x1F,
            )
        elif layout == "B":
            imm12 = (word >> 31) & 1
            imm10_5 = (word >> 25) & 0x3F
            imm4_1 = (word >> 8) & 0xF
            imm11 = (word >> 7) & 1
            imm_raw = (imm12 << 12) | (imm11 << 11) | (imm10_5 << 5) | (imm4_1 << 1)
            decoded.update(
                imm_raw=imm_raw, imm=sign_extend(imm_raw, 13),
                imm12=imm12, imm10_5=imm10_5, imm4_1=imm4_1, imm11=imm11,
            )
        elif layout == "U":
            decoded["imm20"] = (word >> 12) & 0xFFFFF
            decoded["upper_value"] = word & 0xFFFFF000
        elif layout == "J":
            imm20 = (word >> 31) & 1
            imm10_1 = (word >> 21) & 0x3FF
            imm11 = (word >> 20) & 1
            imm19_12 = (word >> 12) & 0xFF
            imm_raw = (imm20 << 20) | (imm19_12 << 12) | (imm11 << 11) | (imm10_1 << 1)
            decoded.update(
                imm_raw=imm_raw, imm=sign_extend(imm_raw, 21),
                imm20=imm20, imm10_1=imm10_1,
                imm11=imm11, imm19_12=imm19_12,
            )
        elif layout == "FENCE":
            decoded.update(
                fm=(word >> 28) & 0xF,
                pred=(word >> 24) & 0xF,
                succ=(word >> 20) & 0xF,
                rs1=(word >> 15) & 0x1F,
                funct3=(word >> 12) & 0x7,
                rd=(word >> 7) & 0x1F,
            )
        elif layout == "SYSTEM":
            decoded.update(
                system_imm=(word >> 20) & 0xFFF,
                rs1=(word >> 15) & 0x1F,
                funct3=(word >> 12) & 0x7,
                rd=(word >> 7) & 0x1F,
            )
        return decoded

    return {
        "name": "ILLEGAL", "format": None, "layout": None,
        "opcode": word & 0x7F, "raw": word,
    }
