from .instruction_db import FORMAT_DB, get_instruction
from .utils import check_register, check_signed, u32

def _check_aligned_range(imm: int, layout: str, label: str) -> None:
    info = FORMAT_DB[layout]["immediate"]
    if not isinstance(imm, int):
        raise ValueError(f"{label}은 정수여야 합니다: {imm!r}")
    if imm % info["alignment"]:
        raise ValueError(f"{label}은 {info['alignment']}의 배수여야 합니다: {imm}")
    if not info["minimum"] <= imm <= info["maximum"]:
        raise ValueError(
            f"{label}은 {info['minimum']}부터 {info['maximum']}까지여야 합니다: {imm}"
        )

def encode_instruction(name: str, **operands: int) -> int:
    spec = get_instruction(name)

    if "fixed_encoding" in spec:
        unexpected = set(operands)
        if unexpected:
            raise ValueError(f"{name}에는 피연산자가 없습니다: {sorted(unexpected)}")
        return spec["fixed_encoding"]

    for operand_name in spec["operands"]:
        if operand_name not in operands:
            raise ValueError(f"{name}에 필요한 피연산자 '{operand_name}'가 없습니다.")

    unexpected = set(operands) - set(spec["operands"])
    if unexpected:
        raise ValueError(f"{name}에 사용하지 않는 피연산자입니다: {sorted(unexpected)}")

    for reg_name in ("rd", "rs1", "rs2"):
        if reg_name in spec["operands"]:
            check_register(operands[reg_name])

    word = spec["opcode"]
    if "rd" in spec["operands"]:
        word |= operands["rd"] << 7
    if "funct3" in spec:
        word |= spec["funct3"] << 12
    if "rs1" in spec["operands"]:
        word |= operands["rs1"] << 15

    layout = spec["layout"]

    if layout == "R":
        word |= operands["rs2"] << 20
        word |= spec["funct7"] << 25
    elif layout == "I":
        imm = operands["imm"]
        check_signed(imm, 12, "즉시값")
        word |= (imm & 0xFFF) << 20
    elif layout == "I_SHIFT":
        shamt = operands["shamt"]
        if not 0 <= shamt < 32:
            raise ValueError(f"shamt는 0부터 31까지여야 합니다: {shamt}")
        word |= shamt << 20
        word |= spec["funct7"] << 25
    elif layout == "S":
        imm = operands["imm"]
        check_signed(imm, 12, "즉시값")
        imm12 = imm & 0xFFF
        word |= (imm12 & 0x1F) << 7
        word |= operands["rs2"] << 20
        word |= ((imm12 >> 5) & 0x7F) << 25
    elif layout == "B":
        imm = operands["imm"]
        _check_aligned_range(imm, "B", "분기 즉시값")
        imm13 = imm & 0x1FFF
        word |= ((imm13 >> 11) & 1) << 7
        word |= ((imm13 >> 1) & 0xF) << 8
        word |= operands["rs2"] << 20
        word |= ((imm13 >> 5) & 0x3F) << 25
        word |= ((imm13 >> 12) & 1) << 31
    elif layout == "U":
        imm20 = operands["imm20"]
        if not 0 <= imm20 <= 0xFFFFF:
            raise ValueError(f"imm20은 0x00000부터 0xFFFFF까지여야 합니다: {imm20}")
        word |= imm20 << 12
    elif layout == "J":
        imm = operands["imm"]
        _check_aligned_range(imm, "J", "점프 즉시값")
        imm21 = imm & 0x1FFFFF
        word |= ((imm21 >> 12) & 0xFF) << 12
        word |= ((imm21 >> 11) & 1) << 20
        word |= ((imm21 >> 1) & 0x3FF) << 21
        word |= ((imm21 >> 20) & 1) << 31
    else:
        raise ValueError(f"지원하지 않는 필드 레이아웃: {layout}")

    return u32(word)
