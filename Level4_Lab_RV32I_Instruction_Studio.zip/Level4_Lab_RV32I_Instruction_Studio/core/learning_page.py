from dataclasses import dataclass, asdict
from typing import Any, Dict, List

from .cpu_state import CPUState
from .decoder import decode
from .encoder import encode_instruction
from .executor import execute
from .instruction_db import INSTRUCTION_DB, get_instruction
from .question_bank import questions_for_instruction
from .rtl_view import control_table, datapath_blocks, educational_rtl


REQUIRED_STAGES = (
    "description",
    "inputs",
    "encoding",
    "decoding",
    "execution",
    "state_change",
    "rtl",
    "question",
)


@dataclass(frozen=True)
class LearningPage:
    instruction: str
    category: str
    layout: str
    opcode: int
    description: str
    inputs: Dict[str, int]
    initial_state: Dict[str, Any]
    assembly: str
    machine_code: int
    decoded: Dict[str, Any]
    execution: Dict[str, Any]
    state_change: Dict[str, Any]
    control_signals: Dict[str, Any]
    datapath: List[str]
    rtl: str
    question: Dict[str, str]

    def stage_payloads(self) -> Dict[str, Any]:
        return {
            "description": self.description,
            "inputs": self.inputs,
            "encoding": {
                "assembly": self.assembly,
                "machine_code": self.machine_code,
            },
            "decoding": self.decoded,
            "execution": self.execution,
            "state_change": self.state_change,
            "rtl": {
                "control_signals": self.control_signals,
                "datapath": self.datapath,
                "code": self.rtl,
            },
            "question": self.question,
        }

    def completeness(self) -> Dict[str, bool]:
        payloads = self.stage_payloads()
        complete: Dict[str, bool] = {}
        for stage in REQUIRED_STAGES:
            value = payloads.get(stage)
            # FENCE, ECALL, EBREAK처럼 피연산자가 없는 명령어의 빈 입력 표도
            # 정상적인 학습 단계이므로 None 여부로 판정합니다.
            if stage == "inputs":
                complete[stage] = value is not None
            else:
                complete[stage] = bool(value)
        return complete


def default_operands(name: str) -> Dict[str, int]:
    spec = get_instruction(name)
    layout = spec["layout"]

    if layout == "R":
        return {"rd": 5, "rs1": 1, "rs2": 2}
    if layout == "I":
        if name == "JALR":
            return {"rd": 5, "rs1": 1, "imm": 4}
        if name in ("LB", "LBU"):
            return {"rd": 5, "rs1": 1, "imm": 1}
        if name in ("LH", "LHU"):
            return {"rd": 5, "rs1": 1, "imm": 2}
        if name == "LW":
            return {"rd": 5, "rs1": 1, "imm": 4}
        return {"rd": 5, "rs1": 1, "imm": 7}
    if layout == "I_SHIFT":
        return {"rd": 5, "rs1": 1, "shamt": 3}
    if layout == "S":
        return {"rs1": 1, "rs2": 2, "imm": 4}
    if layout == "B":
        return {"rs1": 1, "rs2": 2, "imm": 8}
    if layout == "U":
        return {"rd": 5, "imm20": 0x12345}
    if layout == "J":
        return {"rd": 5, "imm": 8}
    return {}


def _assembly(name: str, operands: Dict[str, int]) -> str:
    spec = get_instruction(name)
    layout = spec["layout"]

    if layout == "R":
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, x{operands['rs2']}"
    if layout == "I":
        if name in ("LB", "LH", "LW", "LBU", "LHU", "JALR"):
            return f"{name.lower()} x{operands['rd']}, {operands['imm']}(x{operands['rs1']})"
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, {operands['imm']}"
    if layout == "I_SHIFT":
        return f"{name.lower()} x{operands['rd']}, x{operands['rs1']}, {operands['shamt']}"
    if layout == "S":
        return f"{name.lower()} x{operands['rs2']}, {operands['imm']}(x{operands['rs1']})"
    if layout == "B":
        return f"{name.lower()} x{operands['rs1']}, x{operands['rs2']}, {operands['imm']}"
    if layout == "U":
        return f"{name.lower()} x{operands['rd']}, 0x{operands['imm20']:05X}"
    if layout == "J":
        return f"{name.lower()} x{operands['rd']}, {operands['imm']}"
    return name.lower()


def _prepare_cpu(name: str, operands: Dict[str, int]) -> tuple[CPUState, Dict[str, Any]]:
    cpu = CPUState()
    cpu.pc = 0x00001000
    state: Dict[str, Any] = {"pc": cpu.pc, "registers": {}, "memory": {}}
    spec = get_instruction(name)
    layout = spec["layout"]

    if layout == "R":
        cpu.write_reg(1, 10)
        cpu.write_reg(2, 3)
    elif layout in ("I", "I_SHIFT"):
        cpu.write_reg(1, 10)
        if name in ("LB", "LBU", "LH", "LHU", "LW"):
            cpu.write_reg(1, 0x00000100)
        if name == "JALR":
            cpu.write_reg(1, 0x00002003)
    elif layout == "S":
        cpu.write_reg(1, 0x00000100)
        cpu.write_reg(2, 0x11223344)
    elif layout == "B":
        if name in ("BEQ", "BGE", "BGEU"):
            cpu.write_reg(1, 5)
            cpu.write_reg(2, 5)
        else:
            cpu.write_reg(1, 3)
            cpu.write_reg(2, 5)

    if name in ("LB", "LBU"):
        cpu.store_byte(0x00000101, 0x80)
        state["memory"]["0x00000101"] = "80"
    elif name in ("LH", "LHU"):
        cpu.store_half(0x00000102, 0x8001)
        state["memory"]["0x00000102"] = "01 80"
    elif name == "LW":
        cpu.store_word(0x00000104, 0x89ABCDEF)
        state["memory"]["0x00000104"] = "EF CD AB 89"

    for reg_index in range(1, 32):
        value = cpu.read_reg(reg_index)
        if value:
            state["registers"][f"x{reg_index}"] = value

    return cpu, state


def _execution_summary(result) -> Dict[str, Any]:
    summary: Dict[str, Any] = {
        "instruction": result.instruction,
        "pc_before": result.pc_before,
        "pc_after": result.pc_after,
        "rtl_steps": list(result.rtl_steps),
    }

    for field in (
        "alu_result", "effective_address", "memory_value",
        "branch_taken", "branch_target", "sequential_pc",
        "return_address", "jump_target_raw", "jump_target_final",
        "system_event", "fence_pred", "fence_succ",
    ):
        value = getattr(result, field, None)
        if value is not None:
            summary[field] = value
    return summary


def _state_change(result) -> Dict[str, Any]:
    changes: Dict[str, Any] = {
        "pc": {"before": result.pc_before, "after": result.pc_after},
    }

    if result.rd is not None:
        changes["register"] = {
            "name": f"x{result.rd}",
            "before": result.rd_before,
            "after": result.rd_after,
        }

    if result.effective_address is not None:
        changes["memory"] = {
            "address": result.effective_address,
            "before": list(result.memory_before),
            "after": list(result.memory_after),
        }

    if result.branch_taken is not None:
        changes["branch"] = {
            "taken": result.branch_taken,
            "target": result.branch_target,
            "sequential": result.sequential_pc,
        }

    if result.system_event is not None:
        changes["system_event"] = result.system_event

    if result.fence_pred is not None:
        changes["fence"] = {
            "pred": result.fence_pred,
            "succ": result.fence_succ,
        }

    return changes


def build_learning_page(name: str) -> LearningPage:
    key = name.upper()
    spec = get_instruction(key)
    operands = default_operands(key)
    machine_code = encode_instruction(key, **operands)
    decoded = decode(machine_code)

    cpu, initial_state = _prepare_cpu(key, operands)
    result = execute(cpu, machine_code)

    question_list = questions_for_instruction(key)
    if len(question_list) != 1:
        raise RuntimeError(f"{key}의 명령어별 확인 문제는 정확히 하나여야 합니다.")
    question = question_list[0]

    return LearningPage(
        instruction=key,
        category=spec["category"],
        layout=spec["layout"],
        opcode=spec["opcode"],
        description=spec["description"],
        inputs=operands,
        initial_state=initial_state,
        assembly=_assembly(key, operands),
        machine_code=machine_code,
        decoded=decoded,
        execution=_execution_summary(result),
        state_change=_state_change(result),
        control_signals=control_table(key),
        datapath=datapath_blocks(key),
        rtl=educational_rtl(key),
        question={
            "qid": question.qid,
            "prompt": question.prompt,
            "answer": question.answer,
            "explanation": question.explanation,
        },
    )


LEARNING_PAGES: Dict[str, LearningPage] = {
    name: build_learning_page(name) for name in INSTRUCTION_DB
}


def validate_learning_pages() -> Dict[str, Any]:
    missing_by_instruction: Dict[str, List[str]] = {}
    for name, page in LEARNING_PAGES.items():
        missing = [stage for stage, ok in page.completeness().items() if not ok]
        if missing:
            missing_by_instruction[name] = missing

    return {
        "instruction_count": len(LEARNING_PAGES),
        "required_stage_count": len(REQUIRED_STAGES),
        "total_stage_checks": len(LEARNING_PAGES) * len(REQUIRED_STAGES),
        "missing_by_instruction": missing_by_instruction,
        "all_complete": not missing_by_instruction,
        "instruction_set_matches": set(LEARNING_PAGES) == set(INSTRUCTION_DB),
    }


def instruction_map() -> Dict[str, List[str]]:
    groups: Dict[str, List[str]] = {}
    for name, spec in INSTRUCTION_DB.items():
        opcode = f"0b{spec['opcode']:07b}"
        group_name = f"{spec['category']} · opcode {opcode}"
        groups.setdefault(group_name, []).append(name)
    return groups
