from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any

@dataclass
class ExecutionResult:
    instruction: str
    assembly: str
    machine_code: int
    decoded: Dict[str, Any]
    pc_before: int
    pc_after: int
    rs1_value: Optional[int] = None
    rs2_value: Optional[int] = None
    alu_result: Optional[int] = None
    rd: Optional[int] = None
    rd_before: Optional[int] = None
    rd_after: Optional[int] = None
    effective_address: Optional[int] = None
    memory_width: Optional[int] = None
    memory_signed: Optional[bool] = None
    memory_value: Optional[int] = None
    memory_before: List[int] = field(default_factory=list)
    memory_after: List[int] = field(default_factory=list)
    branch_taken: Optional[bool] = None
    branch_target: Optional[int] = None
    sequential_pc: Optional[int] = None
    return_address: Optional[int] = None
    jump_target_raw: Optional[int] = None
    jump_target_final: Optional[int] = None
    system_event: Optional[str] = None
    fence_pred: Optional[int] = None
    fence_succ: Optional[int] = None
    rtl_steps: List[str] = field(default_factory=list)
