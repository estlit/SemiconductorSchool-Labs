from .instruction_db import FORMAT_DB
from .utils import bits

def _raw_and_meaning(decoded: dict, field: dict):
    name = field["name"]
    kind = field["kind"]

    if name == "imm":
        return decoded["imm_raw"], str(decoded["imm"])
    if name == "imm[11:5]":
        return decoded["imm_hi"], f"imm = {decoded['imm']}"
    if name == "imm[4:0]":
        return decoded["imm_lo"], f"imm = {decoded['imm']}"
    if name == "imm[12]":
        return decoded["imm12"], f"offset = {decoded['imm']}"
    if name == "imm[10:5]":
        return decoded["imm10_5"], f"offset = {decoded['imm']}"
    if name == "imm[4:1]":
        return decoded["imm4_1"], f"offset = {decoded['imm']}"
    if name == "imm[11]":
        return decoded["imm11"], f"offset = {decoded['imm']}"
    if name == "imm[31:12]":
        return decoded["imm20"], f"0x{decoded['upper_value']:08X}"
    if name == "imm[20]":
        return decoded["imm20"], f"offset = {decoded['imm']}"
    if name == "imm[10:1]":
        return decoded["imm10_1"], f"offset = {decoded['imm']}"
    if name == "imm[19:12]":
        return decoded["imm19_12"], f"offset = {decoded['imm']}"
    if name in ("fm", "pred", "succ", "system_imm"):
        raw = decoded[name]
        return raw, f"0x{raw:X}"

    raw = decoded[name]
    if kind == "register":
        meaning = f"x{raw}"
    elif kind == "shift":
        meaning = str(raw)
    else:
        meaning = ""
    return raw, meaning

def build_field_rows(decoded: dict) -> list[dict]:
    layout = decoded["layout"]
    rows = []

    for field in FORMAT_DB[layout]["fields"]:
        hi = field["hi"]
        lo = field["lo"]
        width = hi - lo + 1
        raw, interpretation = _raw_and_meaning(decoded, field)

        rows.append({
            "field": field["name"],
            "range": f"[{hi:2d}:{lo:2d}]",
            "bits": bits(raw, width),
            "interpretation": interpretation,
        })

    return rows

def format_field_table(decoded: dict) -> str:
    rows = build_field_rows(decoded)
    lines = [
        "필드          비트 위치   비트 패턴        의미",
        "----------------------------------------------------",
    ]
    for row in rows:
        lines.append(
            f"{row['field']:<13} {row['range']:<10} "
            f"{row['bits']:<15} {row['interpretation']}"
        )
    return "\n".join(lines)
