"""
RV32I instruction metadata.

모든 디코드 판정은 다음 하나의 규칙을 사용합니다.

    (word & match_mask) == match_value

따라서 opcode/funct3/funct7뿐 아니라 ECALL/EBREAK처럼
즉시값 12비트 전체가 고정된 명령어도 같은 방식으로 판정합니다.
"""

FORMAT_DB = {
    "R": {
        "fields": [
            {"name": "funct7", "hi": 31, "lo": 25, "kind": "constant"},
            {"name": "rs2",    "hi": 24, "lo": 20, "kind": "register"},
            {"name": "rs1",    "hi": 19, "lo": 15, "kind": "register"},
            {"name": "funct3", "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "rd",     "hi": 11, "lo":  7, "kind": "register"},
            {"name": "opcode", "hi":  6, "lo":  0, "kind": "constant"},
        ],
    },
    "I": {
        "fields": [
            {"name": "imm",    "hi": 31, "lo": 20, "kind": "immediate"},
            {"name": "rs1",    "hi": 19, "lo": 15, "kind": "register"},
            {"name": "funct3", "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "rd",     "hi": 11, "lo":  7, "kind": "register"},
            {"name": "opcode", "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "immediate": {"width": 12, "signed": True},
    },
    "I_SHIFT": {
        "fields": [
            {"name": "funct7", "hi": 31, "lo": 25, "kind": "constant"},
            {"name": "shamt",  "hi": 24, "lo": 20, "kind": "shift"},
            {"name": "rs1",    "hi": 19, "lo": 15, "kind": "register"},
            {"name": "funct3", "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "rd",     "hi": 11, "lo":  7, "kind": "register"},
            {"name": "opcode", "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "shift": {"width": 5, "signed": False},
    },
    "S": {
        "fields": [
            {"name": "imm[11:5]", "hi": 31, "lo": 25, "kind": "immediate_part"},
            {"name": "rs2",       "hi": 24, "lo": 20, "kind": "register"},
            {"name": "rs1",       "hi": 19, "lo": 15, "kind": "register"},
            {"name": "funct3",    "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "imm[4:0]",  "hi": 11, "lo":  7, "kind": "immediate_part"},
            {"name": "opcode",    "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "immediate": {"width": 12, "signed": True},
    },
    "B": {
        "fields": [
            {"name": "imm[12]",   "hi": 31, "lo": 31, "kind": "immediate_part"},
            {"name": "imm[10:5]", "hi": 30, "lo": 25, "kind": "immediate_part"},
            {"name": "rs2",       "hi": 24, "lo": 20, "kind": "register"},
            {"name": "rs1",       "hi": 19, "lo": 15, "kind": "register"},
            {"name": "funct3",    "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "imm[4:1]",  "hi": 11, "lo":  8, "kind": "immediate_part"},
            {"name": "imm[11]",   "hi":  7, "lo":  7, "kind": "immediate_part"},
            {"name": "opcode",    "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "immediate": {
            "width": 13, "signed": True, "alignment": 2,
            "minimum": -4096, "maximum": 4094,
        },
    },
    "U": {
        "fields": [
            {"name": "imm[31:12]", "hi": 31, "lo": 12, "kind": "upper_immediate"},
            {"name": "rd",         "hi": 11, "lo":  7, "kind": "register"},
            {"name": "opcode",     "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "immediate": {"width": 20, "signed": False},
    },
    "J": {
        "fields": [
            {"name": "imm[20]",    "hi": 31, "lo": 31, "kind": "immediate_part"},
            {"name": "imm[10:1]",  "hi": 30, "lo": 21, "kind": "immediate_part"},
            {"name": "imm[11]",    "hi": 20, "lo": 20, "kind": "immediate_part"},
            {"name": "imm[19:12]", "hi": 19, "lo": 12, "kind": "immediate_part"},
            {"name": "rd",         "hi": 11, "lo":  7, "kind": "register"},
            {"name": "opcode",     "hi":  6, "lo":  0, "kind": "constant"},
        ],
        "immediate": {
            "width": 21, "signed": True, "alignment": 2,
            "minimum": -1048576, "maximum": 1048574,
        },
    },
    "FENCE": {
        "fields": [
            {"name": "fm",     "hi": 31, "lo": 28, "kind": "constant"},
            {"name": "pred",   "hi": 27, "lo": 24, "kind": "fence"},
            {"name": "succ",   "hi": 23, "lo": 20, "kind": "fence"},
            {"name": "rs1",    "hi": 19, "lo": 15, "kind": "constant"},
            {"name": "funct3", "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "rd",     "hi": 11, "lo":  7, "kind": "constant"},
            {"name": "opcode", "hi":  6, "lo":  0, "kind": "constant"},
        ],
    },
    "SYSTEM": {
        "fields": [
            {"name": "system_imm", "hi": 31, "lo": 20, "kind": "constant"},
            {"name": "rs1",        "hi": 19, "lo": 15, "kind": "constant"},
            {"name": "funct3",     "hi": 14, "lo": 12, "kind": "constant"},
            {"name": "rd",         "hi": 11, "lo":  7, "kind": "constant"},
            {"name": "opcode",     "hi":  6, "lo":  0, "kind": "constant"},
        ],
    },
}

OPCODE_MASK = 0x0000007F
FUNCT3_MASK = 0x00007000
FUNCT7_MASK = 0xFE000000

def _with_match(spec: dict, mask: int, value: int) -> dict:
    spec["match_mask"] = mask & 0xFFFFFFFF
    spec["match_value"] = value & spec["match_mask"]
    return spec

def _r(funct3, operation, description, funct7=0):
    opcode = 0b0110011
    return _with_match({
        "format": "R", "layout": "R", "opcode": opcode,
        "funct3": funct3, "funct7": funct7,
        "operands": ("rd", "rs1", "rs2"),
        "category": "ALU", "operation": operation,
        "description": description,
    }, OPCODE_MASK | FUNCT3_MASK | FUNCT7_MASK,
       opcode | (funct3 << 12) | (funct7 << 25))

def _i(funct3, operation, description):
    opcode = 0b0010011
    return _with_match({
        "format": "I", "layout": "I", "opcode": opcode,
        "funct3": funct3, "operands": ("rd", "rs1", "imm"),
        "category": "ALU", "operation": operation,
        "description": description,
    }, OPCODE_MASK | FUNCT3_MASK, opcode | (funct3 << 12))

def _shift_i(funct3, funct7, operation, description):
    opcode = 0b0010011
    return _with_match({
        "format": "I", "layout": "I_SHIFT", "opcode": opcode,
        "funct3": funct3, "funct7": funct7,
        "operands": ("rd", "rs1", "shamt"),
        "category": "ALU", "operation": operation,
        "description": description,
    }, OPCODE_MASK | FUNCT3_MASK | FUNCT7_MASK,
       opcode | (funct3 << 12) | (funct7 << 25))

def _load(name, funct3, width, signed, description):
    opcode = 0b0000011
    return _with_match({
        "format": "I", "layout": "I", "opcode": opcode,
        "funct3": funct3, "operands": ("rd", "rs1", "imm"),
        "category": "LOAD", "operation": name,
        "memory_width": width, "memory_signed": signed,
        "description": description,
    }, OPCODE_MASK | FUNCT3_MASK, opcode | (funct3 << 12))

def _store(name, funct3, width, description):
    opcode = 0b0100011
    return _with_match({
        "format": "S", "layout": "S", "opcode": opcode,
        "funct3": funct3, "operands": ("rs1", "rs2", "imm"),
        "category": "STORE", "operation": name,
        "memory_width": width, "description": description,
    }, OPCODE_MASK | FUNCT3_MASK, opcode | (funct3 << 12))

def _upper(name, opcode, description):
    return _with_match({
        "format": "U", "layout": "U", "opcode": opcode,
        "operands": ("rd", "imm20"), "category": "UPPER",
        "operation": name, "description": description,
    }, OPCODE_MASK, opcode)

def _branch(name, funct3, comparison, description):
    opcode = 0b1100011
    return _with_match({
        "format": "B", "layout": "B", "opcode": opcode,
        "funct3": funct3, "operands": ("rs1", "rs2", "imm"),
        "category": "BRANCH", "operation": name,
        "comparison": comparison, "description": description,
    }, OPCODE_MASK | FUNCT3_MASK, opcode | (funct3 << 12))

def _jal():
    opcode = 0b1101111
    return _with_match({
        "format": "J", "layout": "J", "opcode": opcode,
        "operands": ("rd", "imm"), "category": "JUMP",
        "operation": "JAL",
        "description": "현재 PC에 상대적인 주소로 점프하고 PC+4를 rd에 저장합니다.",
    }, OPCODE_MASK, opcode)

def _jalr():
    opcode = 0b1100111
    funct3 = 0
    return _with_match({
        "format": "I", "layout": "I", "opcode": opcode,
        "funct3": funct3, "operands": ("rd", "rs1", "imm"),
        "category": "JUMP", "operation": "JALR",
        "description": "rs1과 즉시값을 더한 뒤 최하위 비트를 0으로 만들어 점프합니다.",
    }, OPCODE_MASK | FUNCT3_MASK, opcode)

def _fence():
    # RV32I FENCE: fm=0000, rs1=0, funct3=000, rd=0.
    # pred/succ 8비트는 가변이므로 match mask에서 제외합니다.
    mask = 0xF00FFFFF
    value = 0x0000000F
    return _with_match({
        "format": "FENCE", "layout": "FENCE", "opcode": 0b0001111,
        "funct3": 0, "operands": (),
        "category": "FENCE", "operation": "FENCE",
        "fixed_encoding": 0x0FF0000F,
        "description": "선행 메모리·입출력 접근과 후속 접근의 관찰 순서를 보장합니다.",
    }, mask, value)

def _system(name, encoding, system_imm, description):
    return _with_match({
        "format": "SYSTEM", "layout": "SYSTEM", "opcode": 0b1110011,
        "funct3": 0, "operands": (),
        "category": "SYSTEM", "operation": name,
        "fixed_encoding": encoding, "system_imm": system_imm,
        "description": description,
    }, 0xFFFFFFFF, encoding)

INSTRUCTION_DB = {
    "ADD":  _r(0b000, "ADD",  "두 레지스터 값을 더합니다."),
    "SUB":  _r(0b000, "SUB",  "첫 번째 값에서 두 번째 값을 뺍니다.", 0b0100000),
    "SLL":  _r(0b001, "SLL",  "두 번째 레지스터의 하위 5비트만큼 왼쪽으로 이동합니다."),
    "SLT":  _r(0b010, "SLT",  "두 값을 부호 있는 정수로 비교합니다."),
    "SLTU": _r(0b011, "SLTU", "두 값을 부호 없는 정수로 비교합니다."),
    "XOR":  _r(0b100, "XOR",  "두 값을 비트 단위 XOR 연산합니다."),
    "SRL":  _r(0b101, "SRL",  "논리 오른쪽 이동을 수행합니다."),
    "SRA":  _r(0b101, "SRA",  "산술 오른쪽 이동을 수행합니다.", 0b0100000),
    "OR":   _r(0b110, "OR",   "두 값을 비트 단위 OR 연산합니다."),
    "AND":  _r(0b111, "AND",  "두 값을 비트 단위 AND 연산합니다."),

    "ADDI":  _i(0b000, "ADD",  "레지스터 값과 부호 확장된 즉시값을 더합니다."),
    "SLTI":  _i(0b010, "SLT",  "레지스터와 즉시값을 부호 있는 정수로 비교합니다."),
    "SLTIU": _i(0b011, "SLTU", "레지스터와 즉시값을 부호 없이 비교합니다."),
    "XORI":  _i(0b100, "XOR",  "레지스터와 즉시값을 비트 단위 XOR 연산합니다."),
    "ORI":   _i(0b110, "OR",   "레지스터와 즉시값을 비트 단위 OR 연산합니다."),
    "ANDI":  _i(0b111, "AND",  "레지스터와 즉시값을 비트 단위 AND 연산합니다."),

    "SLLI": _shift_i(0b001, 0b0000000, "SLL", "지정된 shamt만큼 왼쪽으로 이동합니다."),
    "SRLI": _shift_i(0b101, 0b0000000, "SRL", "지정된 shamt만큼 논리 오른쪽 이동합니다."),
    "SRAI": _shift_i(0b101, 0b0100000, "SRA", "지정된 shamt만큼 산술 오른쪽 이동합니다."),

    "LUI":   _upper("LUI",   0b0110111, "20비트 즉시값을 상위 비트 [31:12]에 배치합니다."),
    "AUIPC": _upper("AUIPC", 0b0010111, "상위 즉시값을 현재 PC에 더합니다."),

    "LB":  _load("LB",  0b000, 1, True,  "메모리의 1바이트를 읽고 부호 확장합니다."),
    "LH":  _load("LH",  0b001, 2, True,  "메모리의 2바이트를 읽고 부호 확장합니다."),
    "LW":  _load("LW",  0b010, 4, True,  "메모리의 4바이트 워드를 읽습니다."),
    "LBU": _load("LBU", 0b100, 1, False, "메모리의 1바이트를 읽고 제로 확장합니다."),
    "LHU": _load("LHU", 0b101, 2, False, "메모리의 2바이트를 읽고 제로 확장합니다."),

    "SB": _store("SB", 0b000, 1, "레지스터의 하위 1바이트를 메모리에 저장합니다."),
    "SH": _store("SH", 0b001, 2, "레지스터의 하위 2바이트를 메모리에 저장합니다."),
    "SW": _store("SW", 0b010, 4, "레지스터의 4바이트 워드를 메모리에 저장합니다."),

    "BEQ":  _branch("BEQ",  0b000, "EQ",  "두 레지스터 값이 같으면 분기합니다."),
    "BNE":  _branch("BNE",  0b001, "NE",  "두 레지스터 값이 다르면 분기합니다."),
    "BLT":  _branch("BLT",  0b100, "LT",  "부호 있는 값으로 작으면 분기합니다."),
    "BGE":  _branch("BGE",  0b101, "GE",  "부호 있는 값으로 크거나 같으면 분기합니다."),
    "BLTU": _branch("BLTU", 0b110, "LTU", "부호 없는 값으로 작으면 분기합니다."),
    "BGEU": _branch("BGEU", 0b111, "GEU", "부호 없는 값으로 크거나 같으면 분기합니다."),

    "JAL":  _jal(),
    "JALR": _jalr(),

    "FENCE":  _fence(),
    "ECALL":  _system("ECALL",  0x00000073, 0x000, "실행 환경에 서비스 요청 예외를 발생시킵니다."),
    "EBREAK": _system("EBREAK", 0x00100073, 0x001, "디버거용 중단점 예외를 발생시킵니다."),
}

def get_instruction(name: str) -> dict:
    key = name.upper()
    try:
        return INSTRUCTION_DB[key]
    except KeyError as exc:
        raise ValueError(f"알 수 없는 명령어: {name}") from exc
