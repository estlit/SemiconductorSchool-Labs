from .utils import check_register, sign_extend, u32

class AddressAlignmentError(ValueError):
    pass

class CPUState:
    def __init__(self):
        self.registers = [0] * 32
        self.memory = {}
        self.pc = 0

    def read_reg(self, index: int) -> int:
        check_register(index)
        return self.registers[index]

    def write_reg(self, index: int, value: int) -> None:
        check_register(index)
        if index != 0:
            self.registers[index] = u32(value)
        self.registers[0] = 0

    @staticmethod
    def _check_alignment(address: int, width: int) -> None:
        if width not in (1, 2, 4):
            raise ValueError(f"지원하지 않는 메모리 폭: {width}")
        if address % width:
            raise AddressAlignmentError(
                f"{width}바이트 접근 주소는 {width}바이트 정렬이어야 합니다: "
                f"0x{address:08X}"
            )

    def load(self, address: int, width: int, signed: bool = False) -> int:
        address = u32(address)
        self._check_alignment(address, width)
        value = 0
        for offset in range(width):
            value |= (self.memory.get(address + offset, 0) & 0xFF) << (8 * offset)
        if signed:
            value = sign_extend(value, width * 8)
        return u32(value)

    def store(self, address: int, width: int, value: int) -> None:
        address = u32(address)
        self._check_alignment(address, width)
        value = u32(value)
        for offset in range(width):
            self.memory[address + offset] = (value >> (8 * offset)) & 0xFF

    def load_byte(self, address: int, signed: bool = False) -> int:
        return self.load(address, 1, signed)

    def load_half(self, address: int, signed: bool = False) -> int:
        return self.load(address, 2, signed)

    def load_word(self, address: int) -> int:
        return self.load(address, 4, False)

    def store_byte(self, address: int, value: int) -> None:
        self.store(address, 1, value)

    def store_half(self, address: int, value: int) -> None:
        self.store(address, 2, value)

    def store_word(self, address: int, value: int) -> None:
        self.store(address, 4, value)

    def memory_bytes(self, address: int, count: int) -> list[int]:
        return [self.memory.get(u32(address + i), 0) & 0xFF for i in range(count)]

    def reset(self) -> None:
        self.registers[:] = [0] * 32
        self.memory.clear()
        self.pc = 0
