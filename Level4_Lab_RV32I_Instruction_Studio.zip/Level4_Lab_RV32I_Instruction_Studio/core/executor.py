from .alu import execute_alu
from .branch_unit import evaluate_branch
from .decoder import decode
from .instruction_db import get_instruction
from .jump_unit import jal_target, jalr_target, return_address
from .result import ExecutionResult
from .utils import u32

def _execute_alu(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    rd = decoded["rd"]
    rd_before = cpu.read_reg(rd)
    rs1_value = cpu.read_reg(decoded["rs1"])

    if "rs2" in spec["operands"]:
        rs2_value = cpu.read_reg(decoded["rs2"])
        operand2 = rs2_value
        assembly = f"{name.lower()} x{rd}, x{decoded['rs1']}, x{decoded['rs2']}"
        second_step = f"operand2 = X[{decoded['rs2']}]"
    elif "imm" in spec["operands"]:
        rs2_value = None
        operand2 = decoded["imm"]
        assembly = f"{name.lower()} x{rd}, x{decoded['rs1']}, {decoded['imm']}"
        second_step = f"operand2 = sign_extend({decoded['imm_raw']:012b})"
    else:
        rs2_value = None
        operand2 = decoded["shamt"]
        assembly = f"{name.lower()} x{rd}, x{decoded['rs1']}, {decoded['shamt']}"
        second_step = f"operand2 = shamt = {decoded['shamt']}"

    value = execute_alu(spec["operation"], rs1_value, operand2)
    cpu.write_reg(rd, value)
    cpu.pc = u32(cpu.pc + 4)

    return ExecutionResult(
        instruction=name,
        assembly=assembly,
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        rs1_value=rs1_value,
        rs2_value=rs2_value,
        alu_result=value,
        rd=rd,
        rd_before=rd_before,
        rd_after=cpu.read_reg(rd),
        rtl_steps=[
            f"operand1 = X[{decoded['rs1']}]",
            second_step,
            f"alu_result = {spec['operation']}(operand1, operand2)",
            f"if rd != 0: X[{rd}] = alu_result",
            "PC = PC + 4",
        ],
    )

def _execute_upper(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    rd = decoded["rd"]
    rd_before = cpu.read_reg(rd)
    upper_value = decoded["upper_value"]

    if name == "LUI":
        value = upper_value
        formula = "result = imm20 << 12"
    elif name == "AUIPC":
        value = u32(pc_before + upper_value)
        formula = "result = PC + (imm20 << 12)"
    else:
        raise ValueError(f"지원하지 않는 U 형식 연산: {name}")

    cpu.write_reg(rd, value)
    cpu.pc = u32(cpu.pc + 4)

    return ExecutionResult(
        instruction=name,
        assembly=f"{name.lower()} x{rd}, 0x{decoded['imm20']:05X}",
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        alu_result=value,
        rd=rd,
        rd_before=rd_before,
        rd_after=cpu.read_reg(rd),
        rtl_steps=[
            f"upper_imm = 0x{decoded['imm20']:05X} << 12",
            formula,
            f"if rd != 0: X[{rd}] = result",
            "PC = PC + 4",
        ],
    )

def _execute_load(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    rd = decoded["rd"]
    rd_before = cpu.read_reg(rd)
    rs1_value = cpu.read_reg(decoded["rs1"])
    address = u32(rs1_value + decoded["imm"])
    width = spec["memory_width"]
    signed = spec["memory_signed"]
    before = cpu.memory_bytes(address, width)
    value = cpu.load(address, width, signed)

    cpu.write_reg(rd, value)
    cpu.pc = u32(cpu.pc + 4)

    return ExecutionResult(
        instruction=name,
        assembly=f"{name.lower()} x{rd}, {decoded['imm']}(x{decoded['rs1']})",
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        rs1_value=rs1_value,
        alu_result=address,
        rd=rd,
        rd_before=rd_before,
        rd_after=cpu.read_reg(rd),
        effective_address=address,
        memory_width=width,
        memory_signed=signed,
        memory_value=value,
        memory_before=before,
        memory_after=before[:],
        rtl_steps=[
            f"base = X[{decoded['rs1']}]",
            f"offset = sign_extend({decoded['imm_raw']:012b})",
            "address = base + offset",
            f"memory_data = MEM[{width} bytes at address]",
            "loaded_value = sign_extend(memory_data)" if signed and width < 4
            else "loaded_value = zero_extend(memory_data)" if not signed and width < 4
            else "loaded_value = memory_data",
            f"if rd != 0: X[{rd}] = loaded_value",
            "PC = PC + 4",
        ],
    )

def _execute_store(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    rs1_value = cpu.read_reg(decoded["rs1"])
    rs2_value = cpu.read_reg(decoded["rs2"])
    address = u32(rs1_value + decoded["imm"])
    width = spec["memory_width"]
    before = cpu.memory_bytes(address, width)

    cpu.store(address, width, rs2_value)
    after = cpu.memory_bytes(address, width)
    cpu.pc = u32(cpu.pc + 4)

    return ExecutionResult(
        instruction=name,
        assembly=f"{name.lower()} x{decoded['rs2']}, {decoded['imm']}(x{decoded['rs1']})",
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        rs1_value=rs1_value,
        rs2_value=rs2_value,
        alu_result=address,
        effective_address=address,
        memory_width=width,
        memory_value=rs2_value,
        memory_before=before,
        memory_after=after,
        rtl_steps=[
            f"base = X[{decoded['rs1']}]",
            f"store_data = X[{decoded['rs2']}]",
            f"offset = sign_extend({decoded['imm_raw']:012b})",
            "address = base + offset",
            f"MEM[{width} bytes at address] = store_data[{width * 8 - 1}:0]",
            "PC = PC + 4",
        ],
    )

def _execute_branch(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    sequential_pc = u32(pc_before + 4)
    branch_target = u32(pc_before + decoded["imm"])
    rs1_value = cpu.read_reg(decoded["rs1"])
    rs2_value = cpu.read_reg(decoded["rs2"])

    taken = evaluate_branch(spec["comparison"], rs1_value, rs2_value)
    cpu.pc = branch_target if taken else sequential_pc

    return ExecutionResult(
        instruction=name,
        assembly=(
            f"{name.lower()} x{decoded['rs1']}, "
            f"x{decoded['rs2']}, {decoded['imm']}"
        ),
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        rs1_value=rs1_value,
        rs2_value=rs2_value,
        branch_taken=taken,
        branch_target=branch_target,
        sequential_pc=sequential_pc,
        rtl_steps=[
            f"operand1 = X[{decoded['rs1']}]",
            f"operand2 = X[{decoded['rs2']}]",
            f"condition = {spec['comparison']}(operand1, operand2)",
            f"branch_target = PC + {decoded['imm']}",
            "if condition: PC = branch_target",
            "else: PC = PC + 4",
        ],
    )


def _execute_jump(cpu, machine_code, decoded, spec):
    name = decoded["name"]
    pc_before = cpu.pc
    rd = decoded["rd"]
    rd_before = cpu.read_reg(rd)
    link = return_address(pc_before)

    if name == "JAL":
        raw_target = jal_target(pc_before, decoded["imm"])
        final_target = raw_target
        rs1_value = None
        assembly = f"jal x{rd}, {decoded['imm']}"
        rtl_steps = [
            f"return_address = PC + 4",
            f"jump_target = PC + {decoded['imm']}",
            f"if rd != 0: X[{rd}] = return_address",
            "PC = jump_target",
        ]

    elif name == "JALR":
        rs1_value = cpu.read_reg(decoded["rs1"])
        raw_target, final_target = jalr_target(rs1_value, decoded["imm"])
        assembly = f"jalr x{rd}, {decoded['imm']}(x{decoded['rs1']})"
        rtl_steps = [
            f"return_address = PC + 4",
            f"raw_target = X[{decoded['rs1']}] + {decoded['imm']}",
            "jump_target = raw_target & 0xFFFFFFFE",
            f"if rd != 0: X[{rd}] = return_address",
            "PC = jump_target",
        ]

    else:
        raise ValueError(f"지원하지 않는 점프 명령어: {name}")

    cpu.write_reg(rd, link)
    cpu.pc = final_target

    return ExecutionResult(
        instruction=name,
        assembly=assembly,
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        rs1_value=rs1_value,
        rd=rd,
        rd_before=rd_before,
        rd_after=cpu.read_reg(rd),
        return_address=link,
        jump_target_raw=raw_target,
        jump_target_final=final_target,
        rtl_steps=rtl_steps,
    )



def _execute_fence(cpu, machine_code, decoded, spec):
    pc_before = cpu.pc
    cpu.pc = u32(cpu.pc + 4)
    return ExecutionResult(
        instruction="FENCE",
        assembly="fence",
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=cpu.pc,
        fence_pred=decoded["pred"],
        fence_succ=decoded["succ"],
        rtl_steps=[
            "wait until required predecessor accesses are ordered",
            "prevent required successor accesses from being observed early",
            "PC = PC + 4",
        ],
    )

def _execute_system(cpu, machine_code, decoded, spec):
    pc_before = cpu.pc
    event = "환경 호출 예외" if decoded["name"] == "ECALL" else "중단점 예외"
    # 이 Studio에는 특권 모드 trap handler가 없으므로 예외 요청 지점에서 PC를 유지합니다.
    return ExecutionResult(
        instruction=decoded["name"],
        assembly=decoded["name"].lower(),
        machine_code=machine_code & 0xFFFFFFFF,
        decoded=decoded,
        pc_before=pc_before,
        pc_after=pc_before,
        system_event=event,
        rtl_steps=[
            f"raise {decoded['name']} synchronous exception",
            "trap handler is outside this educational RV32I core model",
            "PC remains at the exception-causing instruction in this model",
        ],
    )


def execute(cpu, machine_code: int) -> ExecutionResult:
    decoded = decode(machine_code)
    name = decoded["name"]
    if name == "ILLEGAL":
        raise ValueError(f"잘못된 명령어: 0x{machine_code & 0xFFFFFFFF:08X}")

    spec = get_instruction(name)
    category = spec["category"]

    if category == "ALU":
        return _execute_alu(cpu, machine_code, decoded, spec)
    if category == "UPPER":
        return _execute_upper(cpu, machine_code, decoded, spec)
    if category == "LOAD":
        return _execute_load(cpu, machine_code, decoded, spec)
    if category == "STORE":
        return _execute_store(cpu, machine_code, decoded, spec)
    if category == "BRANCH":
        return _execute_branch(cpu, machine_code, decoded, spec)
    if category == "JUMP":
        return _execute_jump(cpu, machine_code, decoded, spec)
    if category == "FENCE":
        return _execute_fence(cpu, machine_code, decoded, spec)
    if category == "SYSTEM":
        return _execute_system(cpu, machine_code, decoded, spec)

    raise ValueError(f"지원하지 않는 실행 범주: {category}")
