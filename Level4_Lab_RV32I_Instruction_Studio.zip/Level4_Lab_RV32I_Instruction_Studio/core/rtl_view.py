from dataclasses import dataclass, asdict
from typing import Dict, Any

from .instruction_db import get_instruction


@dataclass(frozen=True)
class ControlSignals:
    reg_write: int = 0
    mem_read: int = 0
    mem_write: int = 0
    branch: int = 0
    jump: int = 0
    alu_src_imm: int = 0
    result_src: str = "NONE"
    alu_control: str = "NONE"
    pc_select: str = "PC_PLUS_4"
    mem_width: int = 0
    load_unsigned: int = 0
    system_event: str = "NONE"
    fence_enable: int = 0


def control_signals(name: str) -> ControlSignals:
    spec = get_instruction(name)
    category = spec["category"]
    operation = spec["operation"]

    if category == "ALU":
        return ControlSignals(
            reg_write=1,
            alu_src_imm=0 if "rs2" in spec["operands"] else 1,
            result_src="ALU",
            alu_control=operation,
        )

    if category == "UPPER":
        return ControlSignals(
            reg_write=1,
            alu_src_imm=1,
            result_src="ALU",
            alu_control="PASS_UIMM" if name == "LUI" else "ADD_PC_UIMM",
        )

    if category == "LOAD":
        return ControlSignals(
            reg_write=1,
            mem_read=1,
            alu_src_imm=1,
            result_src="MEM",
            alu_control="ADD",
            mem_width=spec["memory_width"],
            load_unsigned=0 if spec["memory_signed"] else 1,
        )

    if category == "STORE":
        return ControlSignals(
            mem_write=1,
            alu_src_imm=1,
            result_src="NONE",
            alu_control="ADD",
            mem_width=spec["memory_width"],
        )

    if category == "BRANCH":
        return ControlSignals(
            branch=1,
            result_src="NONE",
            alu_control=spec["comparison"],
            pc_select="BRANCH_CONDITION",
        )

    if category == "JUMP":
        return ControlSignals(
            reg_write=1,
            jump=1,
            alu_src_imm=1,
            result_src="PC_PLUS_4",
            alu_control="ADD",
            pc_select="PC_PLUS_IMM" if name == "JAL" else "RS1_PLUS_IMM_CLEAR_BIT0",
        )

    if category == "FENCE":
        return ControlSignals(
            fence_enable=1,
            pc_select="PC_PLUS_4",
        )

    if category == "SYSTEM":
        return ControlSignals(
            system_event=name,
            pc_select="TRAP_REQUEST",
        )

    raise ValueError(f"지원하지 않는 명령어 범주: {category}")


def control_table(name: str) -> Dict[str, Any]:
    return asdict(control_signals(name))


def rtl_decode_condition(name: str) -> str:
    spec = get_instruction(name)
    return (
        f"(instr & 32'h{spec['match_mask']:08X}) == "
        f"32'h{spec['match_value']:08X}"
    )


def educational_rtl(name: str) -> str:
    spec = get_instruction(name)
    ctrl = control_signals(name)

    lines = [
        f"// {name}",
        f"wire dec_{name.lower()} = {rtl_decode_condition(name)};",
        "",
        "always_comb begin",
        "    reg_write    = 1'b0;",
        "    mem_read     = 1'b0;",
        "    mem_write    = 1'b0;",
        "    branch       = 1'b0;",
        "    jump         = 1'b0;",
        "    fence_enable = 1'b0;",
        "    system_event = SYS_NONE;",
        "    result_src   = RESULT_NONE;",
        "    pc_select    = PC_PLUS_4;",
        "",
        f"    if (dec_{name.lower()}) begin",
        f"        reg_write    = 1'b{ctrl.reg_write};",
        f"        mem_read     = 1'b{ctrl.mem_read};",
        f"        mem_write    = 1'b{ctrl.mem_write};",
        f"        branch       = 1'b{ctrl.branch};",
        f"        jump         = 1'b{ctrl.jump};",
        f"        fence_enable = 1'b{ctrl.fence_enable};",
        f"        result_src   = RESULT_{ctrl.result_src};",
        f"        pc_select    = PC_{ctrl.pc_select};",
    ]

    if ctrl.system_event != "NONE":
        lines.append(f"        system_event = SYS_{ctrl.system_event};")

    lines.extend([
        "    end",
        "end",
    ])
    return "\n".join(lines)


def datapath_blocks(name: str):
    spec = get_instruction(name)
    category = spec["category"]

    if category == "ALU":
        return ["PC", "Instruction Decoder", "Register File", "ALU", "Writeback MUX"]
    if category == "UPPER":
        # LUI 와 AUIPC 도 rd 에 값을 남기므로 레지스터 파일을 지납니다.
        # 예전에는 빠져 있어 "Writeback MUX 는 지나는데 Register File 은
        # 지나지 않는" 모순이 생겼습니다.
        return ["PC", "Instruction Decoder", "Immediate Generator", "ALU",
                "Writeback MUX", "Register File"]
    if category == "LOAD":
        return ["PC", "Instruction Decoder", "Register File", "Immediate Generator",
                "Address Adder", "Data Memory", "Load Extender", "Writeback MUX"]
    if category == "STORE":
        return ["PC", "Instruction Decoder", "Register File", "Immediate Generator",
                "Address Adder", "Data Memory"]
    if category == "BRANCH":
        return ["PC", "Instruction Decoder", "Register File", "Branch Comparator",
                "Immediate Generator", "Branch Target Adder", "PC MUX"]
    if category == "JUMP":
        return ["PC", "Instruction Decoder", "Register File", "Immediate Generator",
                "Jump Target Adder", "Bit 0 Clear" if name == "JALR" else "PC Relative Adder",
                "Writeback MUX", "PC MUX"]
    if category == "FENCE":
        return ["PC", "Instruction Decoder", "Memory Ordering Control", "PC MUX"]
    if category == "SYSTEM":
        return ["PC", "Instruction Decoder", "System Event Detector", "Trap Request"]
    return ["Instruction Decoder"]
