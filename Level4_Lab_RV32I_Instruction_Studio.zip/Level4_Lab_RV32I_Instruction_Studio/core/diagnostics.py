from .instruction_db import FORMAT_DB

def differing_bits(expected: int, actual: int) -> list[int]:
    diff = (expected ^ actual) & 0xFFFFFFFF
    return [bit for bit in range(31, -1, -1) if diff & (1 << bit)]

def _field_value(word: int, hi: int, lo: int) -> int:
    width = hi - lo + 1
    return (word >> lo) & ((1 << width) - 1)

def diagnose_word_mismatch(expected: int, actual: int, layout: str) -> str:
    expected &= 0xFFFFFFFF
    actual &= 0xFFFFFFFF

    lines = [
        f"    기대  0x{expected:08X}  {expected:032b}",
        f"    실제  0x{actual:08X}  {actual:032b}",
    ]

    bits = differing_bits(expected, actual)
    if not bits:
        lines.append("    어긋난 비트  없음")
        return "\n".join(lines)

    lines.append("    어긋난 비트  " + ", ".join(str(bit) for bit in bits))

    for field in FORMAT_DB[layout]["fields"]:
        hi = field["hi"]
        lo = field["lo"]
        exp_value = _field_value(expected, hi, lo)
        act_value = _field_value(actual, hi, lo)
        if exp_value == act_value:
            continue

        width = hi - lo + 1
        name = field["name"]
        lines.append(
            f"      {name:<11} [{hi:2d}:{lo:2d}]  "
            f"기대 {exp_value:0{width}b}  실제 {act_value:0{width}b}"
        )

    return "\n".join(lines)
