"""
EdgeChipLab CPU Studio - RV32I Text Studio
Lab01 - the one file a reader runs.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

  %run Lab01.py

Self-verification runs first. A tool that teaches the wrong encoding is worse
than no tool, so the study session does not start unless every check passes.

The interface is typed, not clicked. That keeps it behaving the same way in a
notebook, in a terminal, and in a piped capture, which is also how the
textbook listings are produced.
"""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent

# Drop any sibling copy of this project that an earlier %run left on the path.
# Match the family name, not one version, so V0, V1 and Text Studio folders are
# all pushed aside in favour of the one this file sits in.
FAMILY = ("RV32I_Instruction_Explorer", "RV32I_Instruction_Studio",
          "RV32I_Text_Studio", "CPU_Studio")
cleaned = []
for item in sys.path:
    try:
        resolved = Path(item).resolve()
    except Exception:
        cleaned.append(item)
        continue
    if resolved != PROJECT_ROOT and any(tag in str(resolved) for tag in FAMILY):
        continue
    cleaned.append(item)
sys.path[:] = [str(PROJECT_ROOT)] + [
    item for item in cleaned if str(item) != str(PROJECT_ROOT)
]

# A notebook keeps modules from an earlier run. Drop only this project's, so a
# second %run picks up the files sitting beside this one.
for module_name in list(sys.modules):
    if module_name.split(".")[0] in ("core", "ui", "tests"):
        del sys.modules[module_name]

from tests.self_test import run_self_test
from ui.text_interface import launch_text_studio

print("=" * 74)
print(" EdgeChipLab Computer Architecture Series")
print(" From Fundamentals to FPGA Implementation")
print("-" * 74)
print(" Volume 1  ·  RV32I Fundamentals")
print(" EdgeChipLab CPU Studio  —  RV32I Text Studio  V1.4.2")
print("=" * 74)
print(" 실습 폴더  %s" % PROJECT_ROOT)
print()

failed = run_self_test(verbose=True)
if failed != 0:
    raise RuntimeError(
        "자체 검증에 실패했습니다. 학습을 시작하지 않습니다. "
        "위에 표시된 항목을 확인해 주십시오."
    )

print()
print(" 자체 검증을 통과했습니다. 학습을 시작합니다.")
launch_text_studio()
