"""
EdgeChipLab CPU Studio - RV32I Text Studio
tests.book_test - verify what the manuscript will rely on.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

self_test.py checks the engine: encodings, decodings, learning-page data. It
passed 1231 checks while the eighth screen still raised an AttributeError,
because the engine was right and the screen read it the wrong way. So this
file checks the layer above: every screen must render, for every instruction,
without an exception, and the coverage table the manuscript prints must have
no holes.

Run:  python -m tests.book_test
"""

import io
import os
import re
import sys
import contextlib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.instruction_db import INSTRUCTION_DB, FORMAT_DB
from core.learning_page import REQUIRED_STAGES, build_learning_page
from core.encoder import encode_instruction
from core.decoder import decode
from ui import text_interface as ti
from ui import book

WIDTH = 84


class Report:
    def __init__(self):
        self.rows = []

    def check(self, name, ok, detail=""):
        self.rows.append((name, bool(ok), detail))
        return ok

    def failures(self):
        return [r for r in self.rows if not r[1]]

    def show(self, title):
        print("=" * WIDTH)
        print(" " + title)
        print("=" * WIDTH)
        for name, ok, detail in self.rows:
            print("  %-64s %s" % (name[:64], "PASS" if ok else "FAIL"))
            if not ok and detail:
                for line in str(detail).split("\n")[:4]:
                    print("      " + line)
        bad = len(self.failures())
        print("-" * WIDTH)
        print("  시험 %d개 · 통과 %d개 · 실패 %d개"
              % (len(self.rows), len(self.rows) - bad, bad))
        return bad == 0


# dispatch() catches exceptions and prints them, so a screen can look drawn
# while it actually failed. Treat those printed lines as failures.
ERROR_MARKS = ("오류:", "Traceback", "알 수 없는 명령")


def render(command, answers=()):
    """Capture one screen, returning (text, error or None).

    An exception that dispatch swallowed still shows up in the text, and that
    counts as a failure: a reader would see a broken screen either way.
    """
    try:
        text = book.transcript(command, answers)
    except Exception as exc:
        return "", "%s: %s" % (type(exc).__name__, exc)
    for mark in ERROR_MARKS:
        if mark in text:
            line = next((l for l in text.split("\n") if mark in l), mark)
            return text, "화면에 오류가 찍혔습니다 — %s" % line.strip()[:70]
    return text, None

# --- 1. every screen renders for every instruction -----------------------
def test_every_screen(rep):
    """The class of failure that engine checks cannot see."""
    for template, answers, need in (
        ("learn %s", ("", "s"), ["[%d." % i for i in range(1, 9)]),
        ("encode %s", (), ["기계어"]),
        ("decode %s", (), ["디코딩 실습", "기계어"]),
        ("rtl %s", (), ["제어 신호"]),
        ("question %s", ("", "s"), ["확인 문제"]),
    ):
        broken, thin, missing = [], [], []
        for name in sorted(INSTRUCTION_DB):
            text, err = render(template % name, answers)
            if err:
                broken.append("%s -> %s" % (name, err))
                continue
            if len(text.strip()) < 120:
                thin.append("%s (%d자)" % (name, len(text)))
            for token in need:
                if token not in text:
                    missing.append("%s 에 %r 없음" % (name, token))
        label = template.split()[0]
        rep.check("%s 화면 40개 예외 없음" % label, not broken,
                  "\n".join(broken[:5]))
        rep.check("%s 화면 40개 내용 충분" % label, not thin,
                  "\n".join(thin[:5]))
        rep.check("%s 화면 40개 필수 항목 포함" % label, not missing,
                  "\n".join(missing[:5]))


# --- 2. the numbers on screen match the engine ---------------------------
def test_screen_numbers(rep):
    wrong = []
    for name in sorted(INSTRUCTION_DB):
        page = build_learning_page(name)
        text, err = render("learn %s" % name, ("", "s"))
        if err:
            wrong.append("%s 렌더 실패" % name)
            continue
        if "0x%08X" % page.machine_code not in text:
            wrong.append("%s 기계어가 화면에 없음" % name)
        if page.assembly not in text:
            wrong.append("%s 어셈블리가 화면에 없음" % name)
    rep.check("화면의 기계어·어셈블리가 엔진 값과 일치", not wrong,
              "\n".join(wrong[:5]))


# --- 3. encode then decode, through the screens -------------------------
def test_encode_decode_roundtrip(rep):
    wrong = []
    for name in sorted(INSTRUCTION_DB):
        word = None
        text, err = render("encode %s" % name, ())
        if err:
            wrong.append("%s encode 실패" % name)
            continue
        found = re.search(r"0x([0-9A-F]{8})", text)
        if not found:
            wrong.append("%s 기계어를 찍지 않음" % name)
            continue
        word = int(found.group(1), 16)
        back, err2 = render("decode 0x%08X" % word, ())
        if err2 or name not in back:
            wrong.append("%s 왕복 실패" % name)
    rep.check("40개 화면 인코딩→디코딩 왕복", not wrong, "\n".join(wrong[:5]))


# --- 4. the shell survives whatever a reader types ----------------------
def test_shell_robustness(rep):
    cases = [
        ("", "빈 입력"), ("   ", "공백만"), ("nonsense", "없는 명령"),
        ("learn", "인수 없는 learn"), ("learn NOPE", "없는 명령어"),
        ("learn add", "소문자"), ("LEARN ADD", "대문자 명령"),
        ("rtl", "인수 없는 rtl"), ("encode", "인수 없는 encode"),
        ("decode", "인수 없는 decode"), ("decode zzz", "숫자가 아닌 기계어"),
        ("reg x99", "범위를 벗어난 레지스터"), ("mem zzz", "잘못된 주소"),
        ("run NOPE", "없는 명령어 실행"), ("map extra", "군더더기 인수"),
        ("legend", "범례"), ("state", "실행 전 상태"), ("?", "물음표"),
    ]
    GUIDED = {"nonsense", "learn NOPE", "run NOPE", "question NOPE",
              "decode zzz", "reg x99", "mem zzz", ""}
    crashed, faulted = [], []
    for raw, why in cases:
        supply = ["", "", "", "", "", "s"]
        buf = io.StringIO()
        ti.__dict__["input"] = lambda p="": supply.pop(0) if supply else ""
        try:
            with contextlib.redirect_stdout(buf):
                ti.dispatch(raw)
        except Exception as exc:
            crashed.append("%s (%r) -> %s" % (why, raw, exc))
        finally:
            ti.__dict__.pop("input", None)
        text = buf.getvalue()
        if raw.strip() and raw not in GUIDED and "오류:" in text:
            line = next(l for l in text.split("\n") if "오류:" in l)
            faulted.append("%s (%r) -> %s" % (why, raw, line.strip()[:56]))
    rep.check("셸이 어떤 입력에도 죽지 않음 (%d가지)" % len(cases),
              not crashed, "\n".join(crashed))
    rep.check("정상 명령이 오류 문구를 찍지 않음", not faulted,
              "\n".join(faulted))


# --- 5. quit works, and only on the intended words ---------------------
def test_quit(rep):
    stops, keeps = [], []
    for word in ("q", "quit", "exit", "Q", "EXIT"):
        with contextlib.redirect_stdout(io.StringIO()):
            if ti.dispatch(word) is not False:
                stops.append(word)
    for word in ("map", "list", "help", "legend"):
        with contextlib.redirect_stdout(io.StringIO()):
            if ti.dispatch(word) is False:
                keeps.append(word)
    rep.check("종료 낱말이 모두 종료시킴", not stops, " ".join(stops))
    rep.check("종료가 아닌 명령은 계속됨", not keeps, " ".join(keeps))


# --- 6. run leaves a result for state, reg and mem ---------------------
def test_state_chain(rep):
    """The trace step only works if the machine remembers the run."""
    from ui import lab_steps
    broken = []
    for name in ("ADD", "ADDI", "SLT", "BEQ", "JAL"):
        lab_steps.LAST.update(cpu=None, result=None, name=None)
        text, err = render("run %s" % name, ("",) * 8)
        if err:
            broken.append("run %s -> %s" % (name, err))
            continue
        if lab_steps.LAST.get("result") is None:
            broken.append("run %s 뒤에 상태가 기억되지 않음" % name)
            continue
        for follow in ("state", "reg", "mem"):
            after, err2 = render(follow, ())
            if err2:
                broken.append("%s 뒤 %s -> %s" % (name, follow, err2))
    rep.check("run 뒤 state·reg·mem 이 같은 실행을 가리킴", not broken,
              "\n".join(broken[:6]))
    # before any run, the trace commands must guide rather than crash
    from ui import lab_steps as ls
    ls.LAST.update(cpu=None, result=None, name=None)
    quiet = []
    for follow in ("state", "reg", "mem"):
        text, err = render(follow, ())
        if err:
            quiet.append("%s -> %s" % (follow, err))
    rep.check("실행 전에도 state·reg·mem 이 안내만 하고 죽지 않음",
              not quiet, "\n".join(quiet))


# --- 7. legend, exam, selftest ----------------------------------------
def test_legend_and_exam(rep):
    text, err = render("legend", ())
    rep.check("legend 가 그려짐", err is None, err or "")
    for token in ("opcode", "여섯 형식", "표기법"):
        rep.check("legend 에 %r 가 있음" % token, token in text)
    text, err = render("exam", ("", "s", "", "s"))
    rep.check("exam 이 그려지고 중단을 받아들임", err is None, err or "")
    text, err = render("selftest", ())
    ok = err is None and "자체 검증" in text and (
        "통과" in text or "PASS" in text.upper())
    rep.check("selftest 가 셸에서 돌아감", ok,
              err or "출력 %r" % text.strip()[:70])


# --- 8. every command the concept spec maps a Lab step onto ------------
def test_required_commands(rep):
    REQUIRED = ["learn", "encode", "decode", "run", "state", "reg", "mem",
                "rtl", "question", "exam", "selftest", "legend"]
    WITH_ARG = {"learn", "encode", "decode", "run", "rtl", "question"}
    missing = []
    for command in REQUIRED:
        probe = command + (" ADD" if command in WITH_ARG else "")
        text, err = render(probe, ("",) * 8)
        if err or len(text.strip()) < 40:
            missing.append("%s -> %s" % (command, err or "출력이 없음"))
    rep.check("사양서가 요구한 명령 %d개가 모두 동작" % len(REQUIRED),
              not missing, "\n".join(missing[:6]))
    text, _ = render("help", ())
    absent = [c for c in REQUIRED if c not in text]
    rep.check("도움말이 명령 %d개를 모두 안내" % len(REQUIRED), not absent,
              " ".join(absent))


# --- 9. the coverage table the appendix prints ------------------------
def test_coverage(rep):
    report = book.coverage_report()
    rep.check("덮개에 빠진 명령어 없음", not report["gaps"],
              "\n".join(report["gaps"][:6]))
    rep.check("덮개에 표에 없는 이름 없음", not report["ghosts"],
              "\n".join(report["ghosts"][:6]))
    rep.check("인코딩·실행 단계에 중복 배정 없음", not report["duplicates"],
              "\n".join(report["duplicates"][:6]))
    table = book.coverage()
    for stage in ("encoding", "execution", "verification"):
        covered = sum(1 for n in table if table[n][stage])
        rep.check("%s 단계가 40개를 덮음" % stage,
                  covered == len(INSTRUCTION_DB),
                  "%d / %d" % (covered, len(INSTRUCTION_DB)))
    markdown = book.coverage_markdown()
    rep.check("덮개 표가 40행으로 생성됨",
              markdown.count("\n") == len(INSTRUCTION_DB) + 1)


# --- 10. transcripts the chapters need --------------------------------
def test_lab_transcripts(rep):
    """Every listing the 13 Labs ask for must be reproducible now."""
    broken, empty = [], []
    for name, items in book.LAB_TRANSCRIPTS.items():
        for command, answers in items:
            text, err = render(command, answers)
            if err:
                broken.append("Lab %s  %s -> %s" % (name, command, err))
            elif len(text.strip()) < 80:
                empty.append("Lab %s  %s (%d자)" % (name, command, len(text)))
    rep.check("Lab 별 캡처가 모두 생성됨", not broken, "\n".join(broken[:5]))
    rep.check("Lab 별 캡처가 비어 있지 않음", not empty, "\n".join(empty[:5]))
    rep.check("Lab %d개 · 캡처 %d개 정의됨"
              % (len(book.LAB_TITLE),
                 sum(len(v) for v in book.LAB_TRANSCRIPTS.values())),
              len(book.LAB_TRANSCRIPTS) == len(book.LAB_TITLE))
    # the structure table the front of the book prints
    table = book.structure_markdown()
    rep.check("구성표가 Lab 수만큼 생성됨",
              table.count("\n") == len(book.LAB_TITLE) + 1,
              "줄 %d" % table.count("\n"))
    missing = [n for n in book.LAB_TITLE if n not in book.LAB_TRANSCRIPTS]
    rep.check("Lab 이 모두 캡처를 가짐", not missing, " ".join(missing))


# --- 11. a transcript is deterministic --------------------------------
def test_determinism(rep):
    unstable = []
    for command, answers in (("learn ADD", ("", "s")), ("encode BEQ", ()),
                             ("rtl LW", ()), ("map", ()), ("legend", ())):
        first, e1 = render(command, answers)
        second, e2 = render(command, answers)
        if e1 or e2 or first != second:
            unstable.append(command)
    rep.check("같은 명령을 두 번 캡처하면 같은 글이 나옴", not unstable,
              " ".join(unstable))


# --- 12. no stray widget dependency -----------------------------------
def test_no_widgets(rep):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    offenders = []
    for folder, _, files in os.walk(root):
        if "__pycache__" in folder:
            continue
        for name in files:
            if not name.endswith((".py", ".txt")):
                continue
            path = os.path.join(folder, name)
            with open(path, encoding="utf-8", errors="ignore") as handle:
                body = handle.read()
            real = re.search(r"^\s*(import|from)\s+ipywidgets", body, re.M)
            listed = (name == "requirements.txt"
                      and re.search(r"^\s*ipywidgets", body, re.M))
            if real or listed:
                offenders.append(os.path.relpath(path, root))
    rep.check("ipywidgets 를 요구하는 파일 없음", not offenders,
              " ".join(offenders))
    rep.check("위젯 UI 파일이 남아 있지 않음",
              not os.path.exists(os.path.join(root, "ui", "explorer.py")))


# --- 13. the three defects an outside review found ----------------------
def test_reported_defects(rep):
    """Each of these produced a raw Python error or the wrong screen.

    They are kept as named tests because a fix without a test is a fix that
    comes back. Each one fails loudly if the behaviour returns.
    """
    # 1) a misaligned load or store must explain itself, not raise
    text, err = render("run LH", ("", "", "", "0x101", "", ""))
    rep.check("정렬 위반이 안내 문구로 나옴 (run LH)",
              err is None and "2 의 배수" in text, err or text[-200:])
    text, err = render("run SH", ("", "", "0x103", "", "", ""))
    rep.check("정렬 위반이 안내 문구로 나옴 (run SH)",
              err is None and "2 의 배수" in text, err or text[-200:])

    # 2) exam ADD must ask about ADD, which is what the help promises
    text, err = render("exam ADD", ("q",))
    rep.check("exam ADD 가 그 명령어의 문제만 냄",
              err is None and "· ADD" in text, err or text[:200])
    text, err = render("exam 5", ("q",))
    rep.check("exam 5 는 여전히 문항 수로 동작",
              err is None and "문제 5개" in text, err or text[:200])

    # 3) a hex typo must not show a python message
    text, err = render("decode 0xGHIJ")
    rep.check("잘못된 16진수에 안내 문구가 나옴",
              err is None and "16진수로 읽을 수 없습니다" in text,
              err or text[-200:])

    # and the paths beside them still work
    text, err = render("decode 0x002082B3")
    rep.check("올바른 16진수 디코딩은 그대로", err is None and "ADD" in text,
              err or text[:200])
    text, err = render("run LW", ("", "", "", "", "", ""))
    rep.check("정렬이 맞는 실행은 그대로", err is None and "실행 결과" in text,
              err or text[:200])


def run():
    rep = Report()
    for suite in (test_every_screen, test_screen_numbers,
                  test_encode_decode_roundtrip, test_shell_robustness,
                  test_quit, test_state_chain, test_legend_and_exam,
                  test_required_commands, test_coverage,
                  test_lab_transcripts, test_determinism,
                  test_no_widgets, test_reported_defects):
        suite(rep)
    ok = rep.show("교재 연계 검증  —  화면·명령·덮개·재현성")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(run())
