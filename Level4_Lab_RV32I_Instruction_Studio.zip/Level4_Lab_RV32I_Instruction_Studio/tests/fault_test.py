"""
EdgeChipLab CPU Studio - RV32I Text Studio
tests.fault_test - break it on purpose, and see whether the checks notice.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

A suite that always passes tells you nothing. The only way to know a check
works is to introduce the exact fault it claims to catch and watch it fail.

So this file damages the project in memory, one fault at a time, runs the two
suites, and records whether they caught it. Every fault is undone before the
next one, and the whole thing finishes with the project untouched.

Run:  python -m tests.fault_test
"""

import contextlib
import copy
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

WIDTH = 92


# --- running the two suites quietly --------------------------------------
def run_engine_suite():
    """tests.self_test — returns (passed, failed)."""
    import importlib
    for name in list(sys.modules):
        if name.split(".")[0] in ("tests",) and "fault" not in name:
            del sys.modules[name]
    from tests import self_test
    importlib.reload(self_test)
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            code = self_test.run_self_test(verbose=True)
    except Exception as exc:
        return 0, 1, "예외 %s" % exc
    text = buffer.getvalue()
    return text.count(": PASS"), text.count(": FAIL"), None


def run_book_suite():
    """tests.book_test — returns (passed, failed)."""
    import importlib
    from tests import book_test
    importlib.reload(book_test)
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            code = book_test.run()
    except Exception as exc:
        return 0, 1, "예외 %s" % exc
    text = buffer.getvalue()
    return text.count(" PASS"), text.count(" FAIL"), None


# --- the faults ----------------------------------------------------------
class Fault:
    """One deliberate defect, with a way to put things back."""

    def __init__(self, name, expect, apply, undo):
        self.name = name
        self.expect = expect        # "engine", "book", or "either"
        self.apply = apply
        self.undo = undo


def build_faults():
    from core import instruction_db as db
    from core import encoder, decoder
    from ui import text_interface as ti
    from ui import book

    faults = []
    saved = {}

    # 1. a wrong funct7: SUB would encode as ADD
    def a1():
        saved["sub"] = db.INSTRUCTION_DB["SUB"]["funct7"]
        db.INSTRUCTION_DB["SUB"]["funct7"] = 0b0000000
    def u1():
        db.INSTRUCTION_DB["SUB"]["funct7"] = saved["sub"]
    faults.append(Fault("SUB 의 funct7 을 0 으로 바꿈", "engine", a1, u1))

    # 2. a wrong opcode: ADDI lands on the OP major opcode
    def a2():
        saved["addi"] = db.INSTRUCTION_DB["ADDI"]["opcode"]
        db.INSTRUCTION_DB["ADDI"]["opcode"] = 0b0110011
    def u2():
        db.INSTRUCTION_DB["ADDI"]["opcode"] = saved["addi"]
    faults.append(Fault("ADDI 의 opcode 를 OP 로 바꿈", "engine", a2, u2))

    # 3. sign extension dropped: negative immediates come back positive
    def a3():
        saved["sx"] = decoder.sign_extend
        decoder.sign_extend = lambda value, width: value & ((1 << width) - 1)
    def u3():
        decoder.sign_extend = saved["sx"]
    faults.append(Fault("부호 확장을 무효화", "engine", a3, u3))

    # 4. an instruction removed from the table
    def a4():
        saved["fence"] = db.INSTRUCTION_DB.pop("FENCE")
    def u4():
        db.INSTRUCTION_DB["FENCE"] = saved["fence"]
    faults.append(Fault("FENCE 를 표에서 제거", "engine", a4, u4))

    # 5. the eighth screen reads a question the wrong way, which is the real
    #    defect that 1231 engine checks could not see
    def a5():
        saved["qfield"] = ti.qfield
        ti.qfield = lambda question, name: getattr(question, name)
    def u5():
        ti.qfield = saved["qfield"]
    faults.append(Fault("확인 문제를 객체로만 읽음 (실제로 겪은 결함)",
                        "book", a5, u5))

    # 6. a screen raises for one instruction only
    def a6():
        saved["rtl"] = ti.show_rtl
        original = saved["rtl"]
        def broken(name):
            if name == "BEQ":
                raise ValueError("의도한 결함")
            return original(name)
        ti.show_rtl = broken
    def u6():
        ti.show_rtl = saved["rtl"]
    faults.append(Fault("rtl 화면이 BEQ 에서만 예외", "book", a6, u6))

    # 7. the shell dies on an unknown command instead of reporting it
    def a7():
        saved["help"] = ti.print_help
        def boom():
            raise RuntimeError("의도한 결함")
        ti.print_help = boom
    def u7():
        ti.print_help = saved["help"]
    faults.append(Fault("help 가 예외를 던짐", "book", a7, u7))

    # 8. a coverage hole: one instruction loses its execution lab
    def a8():
        # SLTIU now lives in the immediate chapter; drop it there
        saved["exec61"] = list(book.LAB_EXECUTION["6-1"])
        book.LAB_EXECUTION["6-1"] = [n for n in saved["exec61"]
                                     if n != "SLTIU"]
    def u8():
        book.LAB_EXECUTION["6-1"] = saved["exec61"]
    faults.append(Fault("덮개에서 SLTIU 의 실행 Lab 삭제", "book", a8, u8))

    # 9. a coverage duplicate: one instruction lands in two execution labs
    def a9():
        saved["exec51"] = list(book.LAB_EXECUTION["5-1"])
        book.LAB_EXECUTION["5-1"] = saved["exec51"] + ["ADDI"]
    def u9():
        book.LAB_EXECUTION["5-1"] = saved["exec51"]
    faults.append(Fault("덮개에 ADDI 를 두 Lab 에 배정", "book", a9, u9))

    # 10. a coverage typo: a name that is not in the table
    def a10():
        saved["exec81"] = list(book.LAB_EXECUTION["8-1"])
        book.LAB_EXECUTION["8-1"] = saved["exec81"] + ["LWU"]
    def u10():
        book.LAB_EXECUTION["8-1"] = saved["exec81"]
    faults.append(Fault("덮개에 표에 없는 이름 LWU 추가", "book", a10, u10))

    # 13. a Lab loses its transcripts, so the manuscript has no listing
    def a13():
        saved["lab51"] = book.LAB_TRANSCRIPTS.pop("5-1")
    def u13():
        book.LAB_TRANSCRIPTS["5-1"] = saved["lab51"]
    faults.append(Fault("Lab 5-1 의 캡처 정의를 제거", "book", a13, u13))

    # 14. a transcript that no longer produces anything
    def a14():
        saved["lab71"] = list(book.LAB_TRANSCRIPTS["7-1"])
        book.LAB_TRANSCRIPTS["7-1"] = [("nosuchcommand", ())]
    def u14():
        book.LAB_TRANSCRIPTS["7-1"] = saved["lab71"]
    faults.append(Fault("Lab 7-1 캡처를 없는 명령으로 바꿈", "book", a14, u14))

    # 11. a screen that no longer prints the machine code it ran
    def a11():
        saved["page"] = ti.show_learning_page
        original = saved["page"]
        def quiet(name):
            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                original(name)
            text = buffer.getvalue()
            print(text.replace("0x", "0y"))       # corrupt every hex value
        ti.show_learning_page = quiet
    def u11():
        ti.show_learning_page = saved["page"]
    faults.append(Fault("학습 화면의 16진 표기를 훼손", "book", a11, u11))

    # 12. a screen whose output changes between runs
    def a12():
        import itertools
        counter = itertools.count()
        saved["map"] = ti.show_instruction_map
        original = saved["map"]
        def drifting():
            original()
            print("호출 횟수 %d" % next(counter))
        ti.show_instruction_map = drifting
    def u12():
        ti.show_instruction_map = saved["map"]
    faults.append(Fault("명령어 지도 출력이 실행마다 달라짐", "book", a12, u12))

    return faults


# --- the harness ---------------------------------------------------------
def main():
    print("=" * WIDTH)
    print(" 자체 검증 체계 시험  —  결함을 일부러 넣고 검증기가 잡는지 본다")
    print("=" * WIDTH)

    base_engine = run_engine_suite()
    base_book = run_book_suite()
    print()
    print(" 손대지 않은 상태")
    print("   엔진 검증    통과 %d · 실패 %d" % base_engine[:2])
    print("   교재 검증    통과 %d · 실패 %d" % base_book[:2])
    clean = base_engine[1] == 0 and base_book[1] == 0
    print("   기준선 %s" % ("정상" if clean else "이미 실패가 있습니다"))
    if not clean:
        print(" 기준선이 깨져 있어 결함 시험을 진행할 수 없습니다.")
        return 1

    faults = build_faults()
    print()
    print(" %-52s %-9s %-9s %s" % ("넣은 결함", "엔진", "교재", "판정"))
    print(" " + "-" * (WIDTH - 2))
    missed = []
    for fault in faults:
        fault.apply()
        try:
            eng = run_engine_suite()
            bok = run_book_suite()
        finally:
            fault.undo()
        caught_engine = eng[1] > 0 or eng[2] is not None
        caught_book = bok[1] > 0 or bok[2] is not None
        if fault.expect == "engine":
            caught = caught_engine
        elif fault.expect == "book":
            caught = caught_book
        else:
            caught = caught_engine or caught_book
        if not caught:
            missed.append(fault.name)
        print(" %-52s %-9s %-9s %s"
              % (fault.name[:52],
                 "실패 %d" % eng[1] if eng[2] is None else "예외",
                 "실패 %d" % bok[1] if bok[2] is None else "예외",
                 "잡음" if caught else "놓침"))

    after_engine = run_engine_suite()
    after_book = run_book_suite()
    restored = (after_engine[:2] == base_engine[:2]
                and after_book[:2] == base_book[:2])

    print(" " + "-" * (WIDTH - 2))
    print(" 결함 %d개 · 잡음 %d개 · 놓침 %d개"
          % (len(faults), len(faults) - len(missed), len(missed)))
    for name in missed:
        print("   놓친 결함: %s" % name)
    print(" 시험 뒤 원상 복구 %s" % ("확인" if restored else "실패"))
    print("   엔진 검증    통과 %d · 실패 %d" % after_engine[:2])
    print("   교재 검증    통과 %d · 실패 %d" % after_book[:2])
    print("=" * WIDTH)
    return 0 if not missed and restored else 1


if __name__ == "__main__":
    sys.exit(main())
