from core import (
    CPUState, AddressAlignmentError, encode_instruction, decode, execute,
    evaluate_branch, jal_target, jalr_target, return_address,
    control_signals, control_table, rtl_decode_condition, educational_rtl,
    datapath_blocks, QUESTIONS, TOPIC_QUESTIONS, INSTRUCTION_QUESTIONS,
    questions_for_instruction, validate_question_bank,
    REQUIRED_STAGES, LEARNING_PAGES, build_learning_page,
    validate_learning_pages, instruction_map,
)
from core.instruction_db import INSTRUCTION_DB, FORMAT_DB

# 형식별 기준 벡터. 새 명령어는 표에 추가하며 기존 벡터를 삭제하지 않습니다.
ENCODING_VECTORS = {
    "R": [
        ("ADD",  {"rd":5,"rs1":1,"rs2":2}, 0x002082B3),
        ("SUB",  {"rd":5,"rs1":1,"rs2":2}, 0x402082B3),
        ("SLL",  {"rd":5,"rs1":1,"rs2":2}, 0x002092B3),
        ("SLT",  {"rd":5,"rs1":1,"rs2":2}, 0x0020A2B3),
        ("SLTU", {"rd":5,"rs1":1,"rs2":2}, 0x0020B2B3),
        ("XOR",  {"rd":5,"rs1":1,"rs2":2}, 0x0020C2B3),
        ("SRL",  {"rd":5,"rs1":1,"rs2":2}, 0x0020D2B3),
        ("SRA",  {"rd":5,"rs1":1,"rs2":2}, 0x4020D2B3),
        ("OR",   {"rd":5,"rs1":1,"rs2":2}, 0x0020E2B3),
        ("AND",  {"rd":5,"rs1":1,"rs2":2}, 0x0020F2B3),
    ],
    "I": [
        ("ADDI",  {"rd":5,"rs1":1,"imm":-1}, 0xFFF08293),
        ("SLTI",  {"rd":5,"rs1":1,"imm":-1}, 0xFFF0A293),
        ("SLTIU", {"rd":5,"rs1":1,"imm":-1}, 0xFFF0B293),
        ("XORI",  {"rd":5,"rs1":1,"imm":-1}, 0xFFF0C293),
        ("ORI",   {"rd":5,"rs1":1,"imm":-1}, 0xFFF0E293),
        ("ANDI",  {"rd":5,"rs1":1,"imm":-1}, 0xFFF0F293),
        ("LB",    {"rd":5,"rs1":1,"imm":-4}, 0xFFC08283),
        ("LH",    {"rd":5,"rs1":1,"imm":-4}, 0xFFC09283),
        ("LW",    {"rd":5,"rs1":1,"imm":-4}, 0xFFC0A283),
        ("LBU",   {"rd":5,"rs1":1,"imm":-4}, 0xFFC0C283),
        ("LHU",   {"rd":5,"rs1":1,"imm":-4}, 0xFFC0D283),
        ("JALR",  {"rd":1,"rs1":5,"imm":12}, 0x00C280E7),
    ],
    "I_SHIFT": [
        ("SLLI", {"rd":5,"rs1":1,"shamt":31}, 0x01F09293),
        ("SRLI", {"rd":5,"rs1":1,"shamt":31}, 0x01F0D293),
        ("SRAI", {"rd":5,"rs1":1,"shamt":31}, 0x41F0D293),
    ],
    "S": [
        ("SB", {"rs1":1,"rs2":2,"imm":-4}, 0xFE208E23),
        ("SH", {"rs1":1,"rs2":2,"imm":-4}, 0xFE209E23),
        ("SW", {"rs1":1,"rs2":2,"imm":-4}, 0xFE20AE23),
    ],
    "B": [
        ("BEQ",  {"rs1":1,"rs2":2,"imm":8}, 0x00208463),
        ("BNE",  {"rs1":1,"rs2":2,"imm":8}, 0x00209463),
        ("BLT",  {"rs1":1,"rs2":2,"imm":8}, 0x0020C463),
        ("BGE",  {"rs1":1,"rs2":2,"imm":8}, 0x0020D463),
        ("BLTU", {"rs1":1,"rs2":2,"imm":8}, 0x0020E463),
        ("BGEU", {"rs1":1,"rs2":2,"imm":8}, 0x0020F463),
        ("BEQ",  {"rs1":1,"rs2":2,"imm":-4}, 0xFE208EE3),
        ("BNE",  {"rs1":1,"rs2":2,"imm":-4}, 0xFE209EE3),
        ("BLT",  {"rs1":1,"rs2":2,"imm":-4}, 0xFE20CEE3),
        ("BGE",  {"rs1":1,"rs2":2,"imm":-4}, 0xFE20DEE3),
        ("BLTU", {"rs1":1,"rs2":2,"imm":-4}, 0xFE20EEE3),
        ("BGEU", {"rs1":1,"rs2":2,"imm":-4}, 0xFE20FEE3),
    ],
    "U": [
        ("LUI",   {"rd":5,"imm20":0x12345}, 0x123452B7),
        ("AUIPC", {"rd":5,"imm20":0x12345}, 0x12345297),
    ],
    "J": [
        ("JAL", {"rd":1,"imm":8}, 0x008000EF),
        ("JAL", {"rd":1,"imm":-4}, 0xFFDFF0EF),
    ],
    "FENCE": [
        ("FENCE", {}, 0x0FF0000F),
    ],
    "SYSTEM": [
        ("ECALL", {}, 0x00000073),
        ("EBREAK", {}, 0x00100073),
    ],
}

DEFAULT_OPERANDS = {
    "R": {"rd":5,"rs1":1,"rs2":2},
    "I": {"rd":5,"rs1":1,"imm":4},
    "I_SHIFT": {"rd":5,"rs1":1,"shamt":3},
    "S": {"rs1":1,"rs2":2,"imm":4},
    "B": {"rs1":1,"rs2":2,"imm":8},
    "U": {"rd":5,"imm20":0x12345},
    "J": {"rd":1,"imm":8},
    "FENCE": {},
    "SYSTEM": {},
}

def run_self_test(verbose=True) -> int:
    checks = []

    def check(name, condition, detail=""):
        ok = bool(condition)
        checks.append((name, ok))
        if verbose:
            print(f"{name:<84}: {'PASS' if ok else 'FAIL'}")
            if not ok and detail:
                print(detail)

    # Database and decode architecture
    check("RV32I 명령어 40개 등록", len(INSTRUCTION_DB) == 40)
    check("모든 명령어에 match_mask 존재",
          all("match_mask" in s for s in INSTRUCTION_DB.values()))
    check("모든 명령어에 match_value 존재",
          all("match_value" in s for s in INSTRUCTION_DB.values()))
    check("match_value가 mask 밖 비트를 사용하지 않음",
          all((s["match_value"] & ~s["match_mask"]) == 0 for s in INSTRUCTION_DB.values()))
    check("ECALL은 32비트 전체 판정", INSTRUCTION_DB["ECALL"]["match_mask"] == 0xFFFFFFFF)
    check("EBREAK는 32비트 전체 판정", INSTRUCTION_DB["EBREAK"]["match_mask"] == 0xFFFFFFFF)
    check("ECALL/EBREAK 즉시값 12비트로 구분",
          INSTRUCTION_DB["ECALL"]["match_value"] ^ INSTRUCTION_DB["EBREAK"]["match_value"] == 0x00100000)
    check("FENCE pred/succ는 mask에서 제외",
          INSTRUCTION_DB["FENCE"]["match_mask"] & 0x0FF00000 == 0)

    # Data-driven encodings and round trips
    names_in_vectors = set()
    for fmt, vectors in ENCODING_VECTORS.items():
        for name, operands, expected in vectors:
            names_in_vectors.add(name)
            actual = encode_instruction(name, **operands)
            check(f"기준 기계어 [{fmt}] {name} {operands}", actual == expected,
                  f"expected=0x{expected:08X}, actual=0x{actual:08X}")
            decoded = decode(actual)
            check(f"이름 왕복 [{fmt}] {name}", decoded["name"] == name,
                  f"decoded={decoded}")
            for key, value in operands.items():
                check(f"피연산자 왕복 [{fmt}] {name}.{key}",
                      decoded[key] == value,
                      f"expected={value}, actual={decoded.get(key)}")

    # Every registered instruction must be covered and executable by encoder/decoder
    check("형식별 벡터가 등록 명령어 40개 전부 포함",
          names_in_vectors == set(INSTRUCTION_DB),
          f"missing={set(INSTRUCTION_DB)-names_in_vectors}")
    for name, spec in INSTRUCTION_DB.items():
        operands = dict(DEFAULT_OPERANDS[spec["layout"]])
        if name == "JALR":
            operands = {"rd":1,"rs1":5,"imm":1}
        word = encode_instruction(name, **operands)
        decoded = decode(word)
        check(f"등록 명령어 전수 인코드·디코드 — {name}", decoded["name"] == name)

    # B-format immediate fragments and boundary/alignment
    d = decode(encode_instruction("BEQ", rs1=1, rs2=2, imm=-4))
    check("B imm[12]", d["imm12"] == 1)
    check("B imm[10:5]", d["imm10_5"] == 0b111111)
    check("B imm[4:1]", d["imm4_1"] == 0b1110)
    check("B imm[11]", d["imm11"] == 1)
    check("B 네 조각 최종 복원", d["imm"] == -4)

    for imm in (-4096, -2, 0, 2, 4094):
        check(f"B 경계·정렬 {imm}",
              decode(encode_instruction("BEQ", rs1=1, rs2=2, imm=imm))["imm"] == imm)
    for bad in (-4098, 4096, -3, -1, 1, 3, 4093):
        try:
            encode_instruction("BEQ", rs1=1, rs2=2, imm=bad)
            rejected = False
        except ValueError:
            rejected = True
        check(f"B 잘못된 offset 거부 {bad}", rejected)

    # Branch comparator and full branch execution coverage
    compare_cases = [
        ("EQ",5,5,True), ("EQ",5,6,False),
        ("NE",5,6,True), ("NE",5,5,False),
        ("LT",0xFFFFFFFF,1,True), ("LT",1,0xFFFFFFFF,False),
        ("GE",0xFFFFFFFF,1,False), ("GE",1,0xFFFFFFFF,True),
        ("LTU",0xFFFFFFFF,1,False), ("LTU",1,0xFFFFFFFF,True),
        ("GEU",0xFFFFFFFF,1,True), ("GEU",1,0xFFFFFFFF,False),
    ]
    for op, a, b, expected in compare_cases:
        check(f"분기 비교 {op} 0x{a:08X},0x{b:08X}",
              evaluate_branch(op,a,b) is expected)

    branch_cases = [
        ("BEQ",10,10,True), ("BEQ",10,20,False),
        ("BNE",10,20,True), ("BNE",10,10,False),
        ("BLT",0xFFFFFFFF,1,True), ("BLT",1,0xFFFFFFFF,False),
        ("BGE",1,0xFFFFFFFF,True), ("BGE",0xFFFFFFFF,1,False),
        ("BLTU",1,0xFFFFFFFF,True), ("BLTU",0xFFFFFFFF,1,False),
        ("BGEU",0xFFFFFFFF,1,True), ("BGEU",1,0xFFFFFFFF,False),
    ]
    for name, a, b, taken in branch_cases:
        cpu = CPUState()
        cpu.pc = 0x1000
        cpu.write_reg(1,a)
        cpu.write_reg(2,b)
        r = execute(cpu, encode_instruction(name, rs1=1, rs2=2, imm=12))
        check(f"분기 조건 {name} {'참' if taken else '거짓'}", r.branch_taken is taken)
        check(f"분기 목표 기록 {name}", r.branch_target == 0x100C)
        check(f"순차 PC 기록 {name}", r.sequential_pc == 0x1004)
        check(f"PC 선택 {name}", r.pc_after == (0x100C if taken else 0x1004))

    cpu = CPUState(); cpu.pc=0x1000; cpu.write_reg(1,7); cpu.write_reg(2,7)
    check("B 음수 offset 실행",
          execute(cpu, encode_instruction("BEQ",rs1=1,rs2=2,imm=-8)).pc_after == 0x0FF8)
    cpu = CPUState(); cpu.pc=0xFFFFFFFC; cpu.write_reg(1,1); cpu.write_reg(2,1)
    check("B target wraparound",
          execute(cpu,encode_instruction("BEQ",rs1=1,rs2=2,imm=8)).pc_after == 4)
    cpu = CPUState(); cpu.pc=0xFFFFFFFC; cpu.write_reg(1,1); cpu.write_reg(2,2)
    check("B PC+4 wraparound",
          execute(cpu,encode_instruction("BEQ",rs1=1,rs2=2,imm=8)).pc_after == 0)

    # J/JALR
    d = decode(encode_instruction("JAL",rd=1,imm=-4))
    check("J imm[20]", d["imm20"] == 1)
    check("J imm[10:1]", d["imm10_1"] == 0b1111111110)
    check("J imm[11]", d["imm11"] == 1)
    check("J imm[19:12]", d["imm19_12"] == 0xFF)
    check("J 네 조각 최종 복원", d["imm"] == -4)

    for imm in (-1048576,-2,0,2,1048574):
        check(f"J 경계·정렬 {imm}",
              decode(encode_instruction("JAL",rd=1,imm=imm))["imm"] == imm)
    for bad in (-1048578,1048576,-3,-1,1,3,1048573):
        try:
            encode_instruction("JAL",rd=1,imm=bad); rejected=False
        except ValueError:
            rejected=True
        check(f"J 잘못된 offset 거부 {bad}", rejected)

    check("JALR 홀수 imm 허용",
          decode(encode_instruction("JALR",rd=1,rs1=5,imm=1))["imm"] == 1)
    check("JAL 홀수 imm 거부",
          _rejects(lambda: encode_instruction("JAL",rd=1,imm=1)))

    check("return address", return_address(0x1000)==0x1004)
    check("return address wraparound", return_address(0xFFFFFFFC)==0)
    check("JAL target 양수", jal_target(0x1000,12)==0x100C)
    check("JAL target 음수", jal_target(0x1000,-8)==0x0FF8)
    check("JAL target wraparound", jal_target(0xFFFFFFFC,8)==4)
    raw, final = jalr_target(0x1003,0)
    check("JALR raw target 홀수", raw==0x1003)
    check("JALR bit0 clear", final==0x1002)

    cpu=CPUState(); cpu.pc=0x1000
    r=execute(cpu,encode_instruction("JAL",rd=1,imm=12))
    check("JAL rd=PC+4", cpu.read_reg(1)==0x1004)
    check("JAL PC=target", cpu.pc==0x100C)
    cpu=CPUState(); cpu.pc=0x2000; cpu.write_reg(5,0x1003)
    r=execute(cpu,encode_instruction("JALR",rd=1,rs1=5,imm=0))
    check("JALR rd=PC+4", cpu.read_reg(1)==0x2004)
    check("JALR raw/final 분리", r.jump_target_raw==0x1003 and r.jump_target_final==0x1002)
    cpu=CPUState(); cpu.pc=0x2000; cpu.write_reg(5,0x1000)
    r=execute(cpu,encode_instruction("JALR",rd=5,rs1=5,imm=4))
    check("JALR rd=rs1 기존 값 사용", r.jump_target_raw==0x1004 and cpu.read_reg(5)==0x2004)

    # Memory regression
    cpu=CPUState(); cpu.store_word(0x1000,0x80FF7F01)
    check("Little Endian", cpu.memory_bytes(0x1000,4)==[0x01,0x7F,0xFF,0x80])
    check("LB sign extension", cpu.load(0x1003,1,True)==0xFFFFFF80)
    check("LBU zero extension", cpu.load(0x1003,1,False)==0x00000080)
    check("LH sign extension", cpu.load(0x1002,2,True)==0xFFFF80FF)
    check("LHU zero extension", cpu.load(0x1002,2,False)==0x000080FF)
    try:
        cpu.load_word(0x1002); rejected=False
    except AddressAlignmentError:
        rejected=True
    check("비정렬 word 접근 거부", rejected)

    # SYSTEM/FENCE exact decode and collision checks
    check("FENCE canonical encoding", encode_instruction("FENCE")==0x0FF0000F)
    check("ECALL exact encoding", encode_instruction("ECALL")==0x00000073)
    check("EBREAK exact encoding", encode_instruction("EBREAK")==0x00100073)
    check("ECALL decode", decode(0x00000073)["name"]=="ECALL")
    check("EBREAK decode", decode(0x00100073)["name"]=="EBREAK")
    check("SYSTEM 다른 imm은 ILLEGAL", decode(0x00200073)["name"]=="ILLEGAL")
    check("FENCE 가변 pred/succ decode", decode(0x0330000F)["name"]=="FENCE")
    check("FENCE.TSO 패턴은 RV32I FENCE로 오인하지 않음", decode(0x8330000F)["name"]=="ILLEGAL")
    check("FENCE reserved rs1 비트는 거부", decode(0x0FF0800F)["name"]=="ILLEGAL")
    check("ECALL과 EBREAK 구분", decode(0x00000073)["name"] != decode(0x00100073)["name"])

    cpu=CPUState(); cpu.pc=0x1000
    r=execute(cpu,encode_instruction("FENCE"))
    check("FENCE PC+4", r.pc_after==0x1004)
    cpu=CPUState(); cpu.pc=0x1000
    r=execute(cpu,encode_instruction("ECALL"))
    check("ECALL 예외 이벤트", r.system_event=="환경 호출 예외" and r.pc_after==0x1000)
    cpu=CPUState(); cpu.pc=0x1000
    r=execute(cpu,encode_instruction("EBREAK"))
    check("EBREAK 예외 이벤트", r.system_event=="중단점 예외" and r.pc_after==0x1000)


    # Educational RTL control coverage
    for name, spec in INSTRUCTION_DB.items():
        ctrl = control_signals(name)
        table = control_table(name)
        check(f"제어 신호 dataclass/table 일치 — {name}",
              table["reg_write"] == ctrl.reg_write and
              table["pc_select"] == ctrl.pc_select)
        condition = rtl_decode_condition(name)
        check(f"RTL 디코드 조건 mask 포함 — {name}",
              f"{spec['match_mask']:08X}" in condition)
        check(f"RTL 디코드 조건 value 포함 — {name}",
              f"{spec['match_value']:08X}" in condition)
        snippet = educational_rtl(name)
        check(f"교육용 RTL 명령어명 포함 — {name}", f"// {name}" in snippet)
        check(f"교육용 RTL dec wire 포함 — {name}",
              f"dec_{name.lower()}" in snippet)
        blocks = datapath_blocks(name)
        check(f"데이터패스 블록 존재 — {name}",
              isinstance(blocks, list) and len(blocks) >= 2)

    # Category-specific control assertions
    check("ADD reg_write", control_signals("ADD").reg_write == 1)
    check("ADDI alu_src_imm", control_signals("ADDI").alu_src_imm == 1)
    check("LW load control",
          control_signals("LW").mem_read == 1 and
          control_signals("LW").mem_write == 0 and
          control_signals("LW").reg_write == 1 and
          control_signals("LW").result_src == "MEM")
    check("LBU unsigned load control", control_signals("LBU").load_unsigned == 1)
    check("LB signed load control", control_signals("LB").load_unsigned == 0)
    check("SW store control",
          control_signals("SW").mem_write == 1 and
          control_signals("SW").reg_write == 0)
    check("BEQ branch control",
          control_signals("BEQ").branch == 1 and
          control_signals("BEQ").pc_select == "BRANCH_CONDITION")
    check("JAL jump/link control",
          control_signals("JAL").jump == 1 and
          control_signals("JAL").result_src == "PC_PLUS_4")
    check("JALR bit0 clear path",
          control_signals("JALR").pc_select == "RS1_PLUS_IMM_CLEAR_BIT0")
    check("FENCE control",
          control_signals("FENCE").fence_enable == 1)
    check("ECALL system event",
          control_signals("ECALL").system_event == "ECALL")
    check("EBREAK system event",
          control_signals("EBREAK").system_event == "EBREAK")

    # Question bank
    qstat = validate_question_bank()
    check("주제별 확인 문제 10개 유지", qstat["topic_count"] == 10)
    check("명령어별 확인 문제 40개 자동 생성", qstat["instruction_count"] == 40)
    check("전체 확인 문제 50개", qstat["count"] == 50)
    check("확인 문제 번호 중복 없음", qstat["unique_ids"])
    check("확인 문제 내용 비어 있지 않음", qstat["nonempty"])
    check("확인 문제 핵심 주제 포함",
          {"SYSTEM","JUMP","BRANCH","FENCE","RTL","FORMATS"}
          <= {q.topic for q in TOPIC_QUESTIONS})
    check("40개 명령어 확인 문제 전수 포함", qstat["all_instructions_covered"])
    check("각 명령어별 확인 문제 정확히 1개", qstat["exactly_one_per_instruction"])
    check("명령어별 문제 source가 INSTRUCTION_DB",
          all(q.source == "INSTRUCTION_DB" for q in INSTRUCTION_QUESTIONS))
    check("명령어별 문제에 instruction 이름 기록",
          {q.instruction for q in INSTRUCTION_QUESTIONS} == set(INSTRUCTION_DB))

    for name in INSTRUCTION_DB:
        related = questions_for_instruction(name)
        check(f"확인 문제 존재 — {name}", len(related) == 1)
        q = related[0]
        check(f"확인 문제 prompt에 명령어 포함 — {name}",
              name.lower() in q.prompt.lower())
        check(f"확인 문제 정답 존재 — {name}", bool(q.answer))
        check(f"확인 문제 해설 존재 — {name}", bool(q.explanation))


    # V1.0.0 공통 학습 페이지 완전성
    learning_stat = validate_learning_pages()
    check("학습 페이지 40개", learning_stat["instruction_count"] == 40)
    check("공통 학습 단계 8개", learning_stat["required_stage_count"] == 8)
    check("40개 × 8단계 = 320개 완전성 관문",
          learning_stat["total_stage_checks"] == 320)
    check("학습 페이지 명령어 집합과 DB 일치",
          learning_stat["instruction_set_matches"])
    check("모든 학습 페이지 완전",
          learning_stat["all_complete"],
          f"missing={learning_stat['missing_by_instruction']}")

    for name in INSTRUCTION_DB:
        page = build_learning_page(name)
        check(f"통합 학습 페이지 instruction — {name}", page.instruction == name)
        check(f"통합 학습 페이지 설명 — {name}", bool(page.description))
        check(f"통합 학습 페이지 입력 — {name}", page.inputs is not None)
        check(f"통합 학습 페이지 인코딩 — {name}",
              decode(page.machine_code)["name"] == name)
        check(f"통합 학습 페이지 디코딩 — {name}",
              page.decoded["name"] == name)
        check(f"통합 학습 페이지 실행 — {name}",
              page.execution["instruction"] == name)
        check(f"통합 학습 페이지 상태 변화 — {name}",
              bool(page.state_change) and "pc" in page.state_change)
        check(f"통합 학습 페이지 RTL — {name}",
              bool(page.rtl) and f"dec_{name.lower()}" in page.rtl)
        check(f"통합 학습 페이지 확인 문제 — {name}",
              bool(page.question["prompt"]) and bool(page.question["answer"]))
        check(f"통합 학습 페이지 8단계 모두 참 — {name}",
              all(page.completeness().values()))

    map_groups = instruction_map()
    mapped_names = [name for names in map_groups.values() for name in names]
    check("명령어 지도에 40개 전부 포함", len(mapped_names) == 40)
    check("명령어 지도 중복 없음", len(mapped_names) == len(set(mapped_names)))
    check("명령어 지도 DB와 일치", set(mapped_names) == set(INSTRUCTION_DB))

    passed = sum(ok for _, ok in checks)
    total = len(checks)
    if verbose:
        print("-"*100)
        print(f"결과: {passed} / {total} PASS")
    return 0 if passed == total else 1

def _rejects(fn):
    try:
        fn()
        return False
    except ValueError:
        return True

if __name__ == "__main__":
    raise SystemExit(run_self_test())
