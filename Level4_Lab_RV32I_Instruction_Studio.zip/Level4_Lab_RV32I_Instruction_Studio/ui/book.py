"""
EdgeChipLab CPU Studio - RV32I Text Studio
ui.book - what the textbook needs from the tool.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

A textbook that prints an output the tool does not actually produce is worse
than one with no output at all. So the book does not transcribe screens by
hand: it asks for them here, and every listing in the manuscript is a file
this module wrote.

Three things are offered.

  transcript()  one screen, captured exactly as a reader would see it
  chapter()     every transcript a chapter needs, written to a folder
  coverage()    which lab covers which instruction, at which of three stages

The coverage matrix is the honest part. It is built from the same lab table
the manuscript uses, so a missing instruction shows up as a gap in the table
rather than as a complaint from a reader.
"""

import io
import os
import contextlib
from typing import Any, Dict, List

from core.instruction_db import INSTRUCTION_DB
from core.learning_page import REQUIRED_STAGES, build_learning_page

from . import text_interface as ti
from . import lab_steps


# --- which lab covers which instruction, at which stage ------------------
# Volume 1, third structure: 4 SECTION, 13 Chapter, 13 Lab.
#
# The Labs are no longer gathered behind the theory. Each Chapter carries the
# one Lab that belongs to it, so a reader meets the instruction, runs it, and
# checks the state without leaving the chapter. Chapters are cut by the path
# the data takes, not by the order the instructions happen to be listed in.
LAB_TITLE = {
    "1-1":  "Exploring the Instruction Map",
    "2-1":  "Tracing Register State",
    "3-1":  "Reading Instruction Fields",
    "4-1":  "Encoding and Reconstructing Immediates",
    "5-1":  "Executing Register Operations",
    "6-1":  "Comparing Immediate Execution Paths",
    "7-1":  "Visualizing Logical and Arithmetic Shifts",
    "8-1":  "Loading and Storing Memory Data",
    "9-1":  "Testing Branch Conditions",
    "10-1": "Tracing Jumps and Trap Requests",
    "11-1": "Tracing the Active Datapath",
    "12-1": "Comparing Control Signal Sets",
    "13-1": "Running the Verification Suite",
}
CHAPTER_TITLE = {
    1:  "From Program to Instruction",
    2:  "Register State and Data Flow",
    3:  "The 32-Bit Instruction Word",
    4:  "Instruction Formats and Immediate Values",
    5:  "Register Arithmetic and Logic",
    6:  "Immediate Arithmetic and Upper Immediates",
    7:  "Shift Operations",
    8:  "Memory Access and Data Width",
    9:  "Conditional Branches",
    10: "Jumps, Ordering, and System Requests",
    11: "Datapath Architecture",
    12: "Control Decisions and Next-PC Selection",
    13: "Bit-True Verification",
}
SECTION_OF_CHAPTER = {
    1:  "I. Understanding Instruction Execution",
    2:  "I. Understanding Instruction Execution",
    3:  "I. Understanding Instruction Execution",
    4:  "I. Understanding Instruction Execution",
    5:  "II. Executing the RV32I Instruction Set",
    6:  "II. Executing the RV32I Instruction Set",
    7:  "II. Executing the RV32I Instruction Set",
    8:  "II. Executing the RV32I Instruction Set",
    9:  "II. Executing the RV32I Instruction Set",
    10: "II. Executing the RV32I Instruction Set",
    11: "III. Building the Execution Hardware",
    12: "III. Building the Execution Hardware",
    13: "IV. Proving Correct Execution",
}
ALL = sorted(INSTRUCTION_DB)

LAB_ENCODING = {"4-1": ALL}
# SECTION II gives every instruction the chapter its data path belongs to.
# The six chapters together take all forty, and none is claimed twice.
LAB_EXECUTION = {
    "5-1":  ["ADD", "SUB", "SLT", "SLTU", "XOR", "OR", "AND"],
    "6-1":  ["ADDI", "SLTI", "SLTIU", "XORI", "ORI", "ANDI", "LUI", "AUIPC"],
    "7-1":  ["SLL", "SRL", "SRA", "SLLI", "SRLI", "SRAI"],
    "8-1":  ["LB", "LH", "LW", "LBU", "LHU", "SB", "SH", "SW"],
    "9-1":  ["BEQ", "BNE", "BLT", "BGE", "BLTU", "BGEU"],
    "10-1": ["JAL", "JALR", "FENCE", "ECALL", "EBREAK"],
}
LAB_VERIFY = {"13-1": ALL}

CHAPTER_OF_LAB = {lab: int(lab.split("-")[0]) for lab in LAB_TITLE}


# --- capturing a screen --------------------------------------------------
def transcript(command, answers=()):
    """Run one Studio command and return exactly what a reader would see.

    answers feeds the input() prompts inside the screen, so a captured
    transcript is deterministic and can be diffed against the manuscript.
    """
    supply = list(answers)

    def fake_input(prompt=""):
        # an exhausted supply must not block; empty means "take the default"
        return supply.pop(0) if supply else ""

    # every module that asks a question needs the same stand-in, or a capture
    # falls through to the real stdin and hangs
    ASKING = (ti, lab_steps)
    saved = [(module, module.__dict__.get("input")) for module in ASKING]
    for module in ASKING:
        module.__dict__["input"] = fake_input
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer):
            ti.dispatch(command)
    finally:
        for module, original in saved:
            if original is None:
                module.__dict__.pop("input", None)
            else:
                module.__dict__["input"] = original
    return buffer.getvalue()


def write_transcript(path, command, answers=()):
    text = transcript(command, answers)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    header = (
        "# 이 파일은 CPU Studio 가 직접 만든 것입니다. 손으로 고치지 마십시오.\n"
        "# 명령  %s\n" % command
    )
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(header + text)
    return path, len(text.splitlines())


# --- the coverage matrix -------------------------------------------------
def coverage() -> Dict[str, Dict[str, List[int]]]:
    """instruction -> stage -> the labs that cover it."""
    table = {name: {"encoding": [], "execution": [], "verification": []}
             for name in INSTRUCTION_DB}
    for stage, source in (("encoding", LAB_ENCODING),
                          ("execution", LAB_EXECUTION),
                          ("verification", LAB_VERIFY)):
        for lab, names in source.items():
            for name in names:
                if name in table:
                    table[name][stage].append(lab)
    return table


def coverage_report() -> Dict[str, Any]:
    table = coverage()
    gaps, duplicates, ghosts = [], [], []
    for stage, source in (("encoding", LAB_ENCODING),
                          ("execution", LAB_EXECUTION),
                          ("verification", LAB_VERIFY)):
        for lab, names in source.items():
            for name in names:
                if name not in INSTRUCTION_DB:
                    ghosts.append("Lab %s 의 %s 는 표에 없는 이름"
                                  % (lab, name))
    for name, stages in table.items():
        for stage, labs in stages.items():
            if not labs:
                gaps.append("%s 는 %s 단계에서 다루지 않습니다" % (name, stage))
            elif len(labs) > 1 and stage != "verification":
                duplicates.append("%s 가 %s 단계에서 Lab %s 에 겹칩니다"
                                  % (name, stage, ", ".join(labs)))
    return dict(total=len(INSTRUCTION_DB), gaps=gaps,
                duplicates=duplicates, ghosts=ghosts,
                complete=not gaps and not ghosts)


def coverage_markdown() -> str:
    """The matrix, ready to drop into the appendix."""
    table = coverage()
    lines = ["| 명령어 | 형식 | 인코딩 | 실행 | SECTION | 검증 |",
             "|---|---|---|---|---|---|"]
    for name in sorted(table):
        spec = INSTRUCTION_DB[name]
        cells = []
        for stage in ("encoding", "execution", "verification"):
            labs = table[name][stage]
            cells.append(", ".join("Lab %s" % n for n in labs) or "—")
        exec_labs = table[name]["execution"]
        section = (SECTION_OF_CHAPTER[CHAPTER_OF_LAB[exec_labs[0]]]
                   if exec_labs else "—")
        lines.append("| %s | %s | %s | %s | %s | %s |"
                     % (name, spec.get("layout", spec["format"]),
                        cells[0], cells[1], section, cells[2]))
    return "\n".join(lines)


# --- what each Lab needs, as the manuscript walks its twelve steps -------
# ④ learn  ⑤ encode  ⑥ decode  ⑦ run  ⑧ state/reg/mem  ⑨ rtl  ⑩ question
LAB_TRANSCRIPTS = {
    # Chapter 1 — the map before any one instruction
    "1-1":  [("legend", ()), ("map", ()), ("learn ADD", ("", "s"))],
    # Chapter 2 — what a register holds before and after
    "2-1":  [("run ADD", ("",) * 8), ("reg", ()), ("state", ())],
    # Chapter 3 — the fields of the word itself
    "3-1":  [("encode ADD", ()), ("decode ADD", ()), ("encode BEQ", ())],
    # Chapter 4 — the immediate taken apart and put back
    "4-1":  [("encode ADDI", ()), ("decode ADDI", ()),
             ("encode SW", ()), ("encode JAL", ()), ("decode BEQ", ())],
    # Chapter 5 — register to register
    "5-1":  [("learn SLT", ("", "s")), ("run ADD", ("",) * 8),
             ("run SLT", ("",) * 8), ("run XOR", ("",) * 8)],
    # Chapter 6 — an immediate on one side
    "6-1":  [("learn LUI", ("", "s")), ("run ADDI", ("",) * 8),
             ("run LUI", ("",) * 8), ("run ANDI", ("",) * 8)],
    # Chapter 7 — the same bits, moved
    "7-1":  [("learn SRA", ("", "s")), ("run SRL", ("",) * 8),
             ("run SRA", ("",) * 8), ("encode SRAI", ())],
    # Chapter 8 — reaching memory, and how wide
    "8-1":  [("learn LW", ("", "s")), ("mem 0x100", ()),
             ("run LW", ("",) * 8), ("run LBU", ("",) * 8),
             ("run SW", ("",) * 8)],
    # Chapter 9 — the branch that does and does not fire
    "9-1":  [("learn BEQ", ("", "s")), ("run BEQ", ("",) * 8),
             ("run BLT", ("",) * 8), ("run BLTU", ("",) * 8),
             ("state", ())],
    # Chapter 10 — leaving, returning, and asking the system
    "10-1": [("learn JAL", ("", "s")), ("run JAL", ("",) * 8),
             ("run JALR", ("",) * 8), ("run ECALL", ("",) * 8),
             ("run FENCE", ("",) * 8)],
    # Chapter 11 — which blocks a given instruction lights
    "11-1": [("rtl ADD", ()), ("rtl LW", ()), ("rtl JAL", ())],
    # Chapter 12 — the control signals side by side
    "12-1": [("rtl BEQ", ()), ("rtl SW", ()), ("rtl ECALL", ())],
    # Chapter 13 — the suite, and what a failure would look like
    "13-1": [("exam", ("1",)), ("question ADD", ()), ("selftest", ())],
}
# kept for callers that ask by chapter number
CHAPTER_TRANSCRIPTS = {}
for _lab, _items in LAB_TRANSCRIPTS.items():
    CHAPTER_TRANSCRIPTS.setdefault(CHAPTER_OF_LAB[_lab], []).extend(_items)



def lab(number, folder="book_out"):
    """Write every transcript Lab `number` needs. number is like "5-1"."""
    made = []
    for command, answers in LAB_TRANSCRIPTS.get(str(number), []):
        slug = command.replace(" ", "_").lower()
        path = os.path.join(folder, "lab%s_%s.txt" % (number, slug))
        made.append(write_transcript(path, command, answers))
    return made


def chapter(number, folder="book_out"):
    """Write every transcript the Labs of chapter `number` need."""
    made = []
    for name in sorted(LAB_TRANSCRIPTS, key=lambda k: CHAPTER_OF_LAB[k]):
        if CHAPTER_OF_LAB[name] == number:
            made += lab(name, folder)
    return made


def all_labs(folder="book_out"):
    out = []
    for name in sorted(LAB_TRANSCRIPTS,
                       key=lambda k: (CHAPTER_OF_LAB[k], k)):
        out += lab(name, folder)
    return out


def all_chapters(folder="book_out"):
    """Kept as the older name; the Labs are the unit now."""
    return all_labs(folder)


def structure_markdown():
    """The Volume 1 map, for the front of the book."""
    lines = ["| SECTION | Chapter | Lab | 제목 | 명령어 |",
             "|---|---|---|---|---|"]
    for name in sorted(LAB_TITLE, key=lambda k: (CHAPTER_OF_LAB[k], k)):
        chapter_no = CHAPTER_OF_LAB[name]
        names = LAB_EXECUTION.get(name)
        if names:
            shown = " ".join(names)
        elif name in LAB_ENCODING or name in LAB_VERIFY:
            shown = "전체 40개"
        else:
            shown = "—"
        lines.append("| %s | Ch.%d | Lab %s | %s | %s |"
                     % (SECTION_OF_CHAPTER[chapter_no], chapter_no, name,
                        LAB_TITLE[name], shown))
    return "\n".join(lines)
