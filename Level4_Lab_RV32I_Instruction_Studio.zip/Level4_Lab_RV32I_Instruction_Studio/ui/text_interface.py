"""Text-only learning interface for the EdgeChipLab RV32I project.

This module intentionally avoids ipywidgets and button callbacks.  It works in
Jupyter Notebook, a terminal, and a standard Python console using only input()
and print().
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any

from core import (
    AddressAlignmentError,
    CPUState,
    INSTRUCTION_QUESTIONS,
    TOPIC_QUESTIONS,
    build_learning_page,
    control_table,
    datapath_blocks,
    educational_rtl,
    encode_instruction,
    execute,
    instruction_map,
)
from core.field_view import build_field_rows
from core.instruction_db import INSTRUCTION_DB, get_instruction
from core.utils import s32
from ui.lab_steps import (
    remember,
    run_exam,
    run_selftest,
    show_decode,
    show_encode,
    show_legend,
    show_memory,
    show_registers,
    show_state,
)


LINE = "=" * 78
SUBLINE = "-" * 78


def _parse_int(text: str, default: int | None = None) -> int:
    value = text.strip()
    if not value:
        if default is None:
            raise ValueError("값을 입력해야 합니다.")
        return default
    return int(value, 0)


class AskCancelled(Exception):
    """The reader asked to leave the question, not to see an error."""


def _ask_int(label: str, default: int) -> int:
    """Ask for a number. q cancels, and end-of-input cancels too.

    Without a way out, a mistyped value trapped the reader in a loop and a
    piped session died with EOFError. Both now return to the prompt.
    """
    shown = default if 0 <= default < 10 else hex(default)
    for _ in range(8):
        try:
            raw = input(f"{label} [{shown}]  (q 는 취소) : ")
        except (EOFError, KeyboardInterrupt):
            print()
            raise AskCancelled
        if raw.strip().lower() in ("q", "quit"):
            raise AskCancelled
        try:
            return _parse_int(raw, default)
        except ValueError:
            print("  10진수나 0x 로 시작하는 16진수를 입력하십시오. "
                  "Enter 는 기본값, q 는 취소입니다.")
    print("  입력이 여러 번 어긋났습니다. 취소합니다.")
    raise AskCancelled


def _format_value(value: Any) -> str:
    if isinstance(value, bool):
        return "참" if value else "거짓"
    if isinstance(value, int):
        return f"0x{value & 0xFFFFFFFF:08X} ({value})"
    if isinstance(value, list):
        return " ".join(f"{x:02X}" if isinstance(x, int) else str(x) for x in value)
    if isinstance(value, dict):
        return ", ".join(f"{k}={_format_value(v)}" for k, v in value.items())
    return str(value)


def _print_dict(title: str, data: dict[str, Any]) -> None:
    print(f"\n[{title}]")
    if not data:
        print("  없음")
        return
    for key, value in data.items():
        print(f"  {key:<22} : {_format_value(value)}")


def _print_field_table(decoded: dict[str, Any]) -> None:
    print("\n[명령어 필드]")
    print(f"  {'필드':<14} {'비트 위치':<14} {'비트 패턴':<20} 의미")
    print("  " + "-" * 72)
    for row in build_field_rows(decoded):
        print(
            f"  {row['field']:<14} {row['range']:<14} "
            f"{row['bits']:<20} {row['interpretation']}"
        )


def qfield(question: Any, name: str) -> Any:
    """Read one field from a question.

    questions_for_instruction() hands back Question objects, while a learning
    page carries the same thing as a dict. Both arrive here, so read either.
    """
    if isinstance(question, dict):
        return question.get(name, "")
    return getattr(question, name, "")


def match_instruction(raw: str) -> str | None:
    """Resolve one typed name, printing a hint when it is ambiguous."""
    name = (raw or "").strip().upper()
    if not name:
        return None
    if name in INSTRUCTION_DB:
        return name
    near = sorted(n for n in INSTRUCTION_DB if n.startswith(name))
    if len(near) == 1:
        return near[0]
    if near:
        print("  여러 개가 걸립니다: %s" % " ".join(near))
        print("  이름을 더 길게 입력해 주십시오.")
    else:
        print("  그런 명령어는 없습니다: %s" % raw)
        print("  list 를 입력하면 지원 명령어를 볼 수 있습니다.")
    return None


def ask_instruction(prompt: str) -> str | None:
    """Ask for an instruction name until one is given, or the reader gives up.

    An empty line is a request to go back, not an error. A misspelling gets a
    hint with the closest matches rather than a Python traceback.
    """
    while True:
        raw = input(prompt).strip()
        if not raw:
            print("  돌아갑니다. 명령어 목록은 list 또는 map 으로 볼 수 있습니다.")
            return None
        name = match_instruction(raw)
        if name:
            return name


def _print_question(question: Any) -> None:
    print("\n[확인 문제]")
    print(f"  {qfield(question, 'qid')} · {qfield(question, 'prompt')}")
    input("  정답을 생각한 뒤 Enter를 누르십시오.")
    print(f"  정답 : {qfield(question, 'answer')}")
    print(f"  해설 : {qfield(question, 'explanation')}")


def show_instruction_map() -> None:
    print(LINE)
    print("RV32I 40개 명령어 지도")
    print(LINE)
    for group, names in instruction_map().items():
        print(f"\n[{group}]")
        print("  " + "  ".join(names))
    print()


def show_learning_page(name: str) -> None:
    name = name.upper()
    page = build_learning_page(name)
    question = page.question

    print(LINE)
    print(f"{page.instruction} 통합 학습")
    print(LINE)
    print(f"분류      : {page.category}")
    print(f"레이아웃  : {page.layout}")
    print(f"opcode    : 0b{page.opcode:07b}")

    print("\n[1. 명령어 설명]")
    print(f"  {page.description}")

    _print_dict("2. 입력", page.inputs)
    _print_dict("초기 상태", page.initial_state)

    print("\n[3. 인코딩]")
    print(f"  어셈블리 : {page.assembly}")
    print(f"  기계어   : 0x{page.machine_code:08X}")
    print(f"  이진수   : {page.machine_code:032b}")

    print("\n[4. 디코딩]")
    _print_field_table(page.decoded)

    _print_dict("5. 실행", page.execution)
    _print_dict("6. 상태 변화", page.state_change)

    print("\n[7. 교육용 RTL]")
    print("  사용 블록 : " + " -> ".join(page.datapath))
    _print_dict("제어 신호", page.control_signals)
    print("\n[Verilog]")
    print(page.rtl)

    print("\n[8. 확인 문제]")
    print(f"  {qfield(question, 'qid')} · {qfield(question, 'prompt')}")
    answer = input(
        "  정답과 해설을 보려면 Enter를 누르십시오. 건너뛰려면 s 입력 : "
    ).strip().lower()
    if answer != "s":
        print(f"  정답 : {qfield(question, 'answer')}")
        print(f"  해설 : {qfield(question, 'explanation')}")
    print()


def show_rtl(name: str) -> None:
    name = name.upper()
    print(LINE)
    print(f"{name} 교육용 RTL")
    print(LINE)
    print("사용 블록 : " + " -> ".join(datapath_blocks(name)))
    _print_dict("제어 신호", control_table(name))
    print("\n[Verilog]")
    print(educational_rtl(name))
    print()


def show_questions(name: str | None = None) -> None:
    """Show questions for one instruction, one question number, or all topics.

    A question number is accepted because the textbook cites individual
    questions, and a reader who wants to meet the same one again cannot get
    there through the exam, which draws ten at random.
    """
    if name:
        target = name.upper()
        questions = [q for q in INSTRUCTION_QUESTIONS if q.instruction == target]
        if not questions:
            questions = [q for q in list(INSTRUCTION_QUESTIONS)
                         + list(TOPIC_QUESTIONS)
                         if q.qid.upper() == target]
        if not questions:
            raise ValueError(
                f"{target} 의 문제를 찾을 수 없습니다. 명령어 이름이나 문제 번호를 넣어 주십시오.")
    else:
        questions = list(TOPIC_QUESTIONS)

    print(LINE)
    print("확인 문제")
    print(LINE)
    for question in questions:
        _print_question(question)
    print()


def _collect_run_inputs(name: str) -> tuple[CPUState, dict[str, int]]:
    spec = get_instruction(name)
    category = spec["category"]
    cpu = CPUState()
    cpu.pc = _ask_int("PC", 0x1000) & 0xFFFFFFFF
    operands: dict[str, int] = {}

    if category == "UPPER":
        operands["rd"] = _ask_int("rd", 5)
        operands["imm20"] = _ask_int("imm20", 0x12345)
        return cpu, operands

    if category == "JUMP" and name == "JAL":
        operands["rd"] = _ask_int("rd", 5)
        operands["imm"] = _ask_int("imm", 8)
        return cpu, operands

    if category in ("FENCE", "SYSTEM"):
        return cpu, operands

    if "rd" in spec["operands"]:
        operands["rd"] = _ask_int("rd", 5)

    if "rs1" in spec["operands"]:
        operands["rs1"] = _ask_int("rs1", 1)
        # a load or store needs a base that keeps the address aligned, so the
        # default is a round number rather than 10
        base_default = 0x100 if category in ("LOAD", "STORE") else 10
        rs1_value = _ask_int(f"x{operands['rs1']} 초기값", base_default)
        cpu.write_reg(operands["rs1"], rs1_value)

    if "rs2" in spec["operands"]:
        operands["rs2"] = _ask_int("rs2", 2)
        rs2_value = _ask_int(f"x{operands['rs2']} 초기값", 20)
        cpu.write_reg(operands["rs2"], rs2_value)

    if "imm" in spec["operands"]:
        # keep the effective address on a natural boundary by default
        width = spec.get("memory_width") or 0
        if category in ("LOAD", "STORE"):
            default_imm = {1: 1, 2: 2, 4: 4}.get(width, 4)
        else:
            default_imm = 8
        operands["imm"] = _ask_int("imm", default_imm)

    if "shamt" in spec["operands"]:
        operands["shamt"] = _ask_int("shamt", 3)

    if category in ("LOAD", "STORE"):
        address = (cpu.read_reg(operands["rs1"]) + operands["imm"]) & 0xFFFFFFFF
        memory_value = _ask_int("메모리 초기값", 0x80FF7F01)
        cpu.store(address, spec["memory_width"], memory_value)

    return cpu, operands


def _alignment_help(name: str, spec, exc, rs1: int = 1) -> None:
    """The one message a misaligned address should produce."""
    print()
    print("  정렬 위반입니다: %s" % exc)
    print("  %s 는 주소가 %d 의 배수여야 합니다."
          % (name, spec.get("memory_width") or 4))
    print("  x%d 의 초기값과 imm 을 더한 값이 그렇게 되도록 다시 "
          "입력해 보십시오." % rs1)


def run_instruction(name: str) -> None:
    name = name.upper()
    if name not in INSTRUCTION_DB:
        raise ValueError(f"지원하지 않는 명령어입니다: {name}")
    spec = get_instruction(name)

    print(LINE)
    print(f"{name} 직접 실행")
    print("빈칸에서 Enter를 누르면 대괄호 안의 기본값을 사용합니다.")
    print(LINE)

    try:
        cpu, operands = _collect_run_inputs(name)
    except AskCancelled:
        print("  실행을 취소했습니다.")
        return
    except AddressAlignmentError as exc:
        # a load or store writes its memory value while the answers are still
        # being collected, so this is where a misaligned address shows up
        _alignment_help(name, spec, exc)
        return
    word = encode_instruction(name, **operands)
    try:
        result = execute(cpu, word)
    except AddressAlignmentError as exc:
        _alignment_help(name, spec, exc, operands.get("rs1", 1))
        return
    # keep it, so state / reg / mem report a machine that actually ran
    remember(name, cpu, result)

    print("\n[실행 결과]")
    print(f"  어셈블리 : {result.assembly}")
    print(f"  기계어   : 0x{result.machine_code:08X}")
    print(f"  이진수   : {result.machine_code:032b}")
    print(f"  PC       : 0x{result.pc_before:08X} -> 0x{result.pc_after:08X}")
    _print_field_table(result.decoded)

    if result.rd is not None:
        print(
            f"\n[레지스터 변화]\n"
            f"  x{result.rd} : 0x{result.rd_before:08X} -> 0x{result.rd_after:08X}"
        )
    if result.alu_result is not None:
        print(
            f"\n[ALU 결과]\n"
            f"  unsigned : 0x{result.alu_result:08X}\n"
            f"  signed   : {s32(result.alu_result)}"
        )
    if result.effective_address is not None:
        print(f"\n[유효 주소]\n  0x{result.effective_address:08X}")
        if result.memory_before:
            print("  실행 전 : " + " ".join(f"{x:02X}" for x in result.memory_before))
        if result.memory_after:
            print("  실행 후 : " + " ".join(f"{x:02X}" for x in result.memory_after))
    if result.branch_taken is not None:
        print(f"\n[분기 결과]\n  {'분기함' if result.branch_taken else '분기하지 않음'}")
    if result.system_event:
        print(f"\n[시스템 이벤트]\n  {result.system_event}")
    print()



def print_help() -> None:
    """The command list, grouped the way a Lab walks through them."""
    print(LINE)
    print("EdgeChipLab CPU Studio 명령")
    print(LINE)
    print("  둘러보기")
    print("    map                 RV32I 40개 명령어 지도")
    print("    list                지원 명령어 이름")
    print("    legend              ③ Quick Reference · 표기법과 형식")
    print("    help                이 도움말")
    print()
    print("  Lab 순서대로")
    print("    learn ADD           ④ 명령어 요약과 여덟 단계")
    print("    encode ADD          ⑤ 어셈블리에서 기계어로")
    print("    decode 0x002082B3   ⑥ 기계어에서 명령어로")
    print("    run ADD             ⑦ CPU 에서 실행")
    print("    state               ⑧ PC · 레지스터 · 메모리 한눈에")
    print("    reg / reg x5        ⑧ 레지스터 전체 또는 하나")
    print("    mem / mem 0x100     ⑧ 메모리 창")
    print("    rtl ADD             ⑨ RTL 데이터패스와 제어 신호")
    print("    question ADD        ⑩ 확인 문제와 해설")
    print()
    print("  마무리")
    print("    exam                문제 전체 목록")
    print("    exam ADD            그 명령어의 문제 목록")
    print("    selftest            자체 검증 실행")
    print("    reset               CPU 상태를 처음으로")
    print("    exit                끝내기")
    print()
    print("이름은 대소문자를 가리지 않고 앞부분만 입력해도 됩니다.")
    print("run 으로 실행한 결과는 남아 있으므로 state · reg · mem 으로")
    print("이어서 관찰할 수 있습니다.")
    print()

def dispatch(raw: str) -> bool:
    """Run one typed command. Returns False when the reader asked to stop.

    The shell and the textbook capture both come through here, so a listing in
    the manuscript is produced by the same path a reader walks.
    """
    raw = (raw or "").strip()
    if not raw:
        return True

    parts = raw.split()
    command = parts[0].lower()
    argument = parts[1].upper() if len(parts) > 1 else None

    try:
        if command in ("exit", "quit", "q"):
            print("프로그램을 종료합니다.")
            return False
        if command in ("help", "h", "?"):
            print_help()
        elif command == "map":
            show_instruction_map()
        elif command in ("legend", "quickref", "ref"):
            show_legend()
        elif command == "list":
            print(" ".join(INSTRUCTION_DB.keys()))
        elif command in ("learn", "run", "rtl"):
            ASKED = {"learn": ("학습할 명령어를 입력하십시오: ",
                               show_learning_page),
                     "run": ("실행할 명령어를 입력하십시오: ",
                             run_instruction),
                     "rtl": ("RTL 을 볼 명령어를 입력하십시오: ", show_rtl)}
            prompt, action = ASKED[command]
            if argument is None:
                argument = ask_instruction("  " + prompt)
            else:
                argument = match_instruction(argument)
            if argument:
                action(argument)
        elif command in ("question", "questions", "quiz"):
            show_questions(argument)
        elif command == "encode":
            if argument is None:
                argument = ask_instruction(
                    "  인코딩할 명령어를 입력하십시오: ")
            else:
                argument = match_instruction(argument)
            if argument:
                show_encode(argument)
        elif command == "decode":
            # decode takes either a machine word or an instruction name, since
            # a reader may arrive here holding one or the other
            raw_argument = parts[1] if len(parts) > 1 else None
            if raw_argument is None:
                raw_argument = input(
                    "  기계어나 명령어 이름을 입력하십시오 "
                    "(예 0x002082B3 또는 ADD): ").strip()
            if not raw_argument:
                print("  돌아갑니다.")
            else:
                looks_numeric = (raw_argument.lower().startswith("0x")
                                 or raw_argument.isdigit())
                if looks_numeric:
                    try:
                        machine_code = int(raw_argument, 0)
                    except ValueError:
                        print("  16진수로 읽을 수 없습니다: %s" % raw_argument)
                        print("  0x 다음에는 0-9 와 A-F 만 옵니다. "
                              "예 0x002082B3")
                    else:
                        show_decode(word=machine_code)
                else:
                    name = match_instruction(raw_argument)
                    if name:
                        show_decode(name)
        elif command == "state":
            show_state()
        elif command in ("reg", "regs", "register"):
            show_registers(parts[1] if len(parts) > 1 else None)
        elif command in ("mem", "memory"):
            show_memory(parts[1] if len(parts) > 1 else None)
        elif command == "exam":
            count, only = 10, None
            if len(parts) > 1:
                if parts[1].isdigit():
                    count = max(1, min(50, int(parts[1])))
                else:
                    only = match_instruction(parts[1])
                    if not only:
                        print("  exam 만 입력하면 전체에서 문제를 뽑습니다.")
                        return True
            run_exam(count, name=only)
        elif command in ("selftest", "verify"):
            run_selftest()
        else:
            print(f"알 수 없는 명령입니다: {command}")
            print("help를 입력하여 사용 가능한 명령을 확인하십시오.")
    except Exception as exc:
        print(f"오류: {type(exc).__name__}: {exc}")
        print("입력값을 확인한 뒤 다시 시도하십시오.\n")
    return True


def launch_text_studio() -> None:
    print(LINE)
    print("EdgeChipLab RV32I Text Studio — V1.4.2")
    print("버튼 없는 입력형 학습 환경")
    print(LINE)
    print("명령을 직접 입력하십시오. 처음에는 help 또는 map을 입력하십시오.\n")

    while True:
        try:
            raw = input("RV32I> ")
        except (EOFError, KeyboardInterrupt):
            print("\n프로그램을 종료합니다.")
            break
        if not dispatch(raw):
            break


# Backward-compatible entry point.
def launch_explorer() -> None:
    launch_text_studio()
