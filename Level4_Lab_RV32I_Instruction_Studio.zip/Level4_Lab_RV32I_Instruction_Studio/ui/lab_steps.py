"""
EdgeChipLab CPU Studio - RV32I Text Studio
ui.lab_steps - one command per step of a Lab.

Author: Roger Kim / Copyright (c) 2026 EdgeChipLab

The textbook walks twelve steps and four of them used to be folded inside a
single `learn`. A reader following step 5 should be able to type the command
for step 5, so encoding, decoding, state inspection and examination each get
a command of their own.

Nothing here computes an encoding or an execution. Every number shown comes
from core, so a screen cannot disagree with the engine that produced it.
"""

import random
from typing import Any, Dict, Optional

from core.instruction_db import INSTRUCTION_DB, FORMAT_DB
from core.encoder import encode_instruction
from core.decoder import decode
from core.executor import execute
from core.cpu_state import CPUState
from core.field_view import format_field_table
from core.learning_page import build_learning_page
from core.question_bank import QUESTIONS, questions_for_instruction

LINE = "=" * 78
THIN = "-" * 78

# The last machine a `run` produced, so `state`, `reg` and `mem` have
# something real to report instead of inventing a fresh one.
LAST: Dict[str, Any] = {"cpu": None, "result": None, "name": None}


def hex32(value: int) -> str:
    return "0x%08X" % (value & 0xFFFFFFFF)


def signed(value: int) -> int:
    value &= 0xFFFFFFFF
    return value - (1 << 32) if value & 0x80000000 else value


def remember(name: str, cpu: CPUState, result: Any) -> None:
    LAST["name"], LAST["cpu"], LAST["result"] = name, cpu, result


def _sample_operands(name: str) -> Dict[str, int]:
    """Values that exercise the instruction without asking the reader."""
    spec = INSTRUCTION_DB[name]
    picked: Dict[str, int] = {}
    for key in spec["operands"]:
        if key == "imm":
            fmt = spec["format"]
            picked[key] = {"B": 8, "J": 8}.get(fmt, 4)
        elif key == "imm20":
            picked[key] = 0x12345
        elif key == "shamt":
            picked[key] = 3
        else:
            picked[key] = {"rd": 5, "rs1": 1, "rs2": 2}[key]
    return picked


# --- step 5 : encoding ---------------------------------------------------
def show_encode(name: str) -> None:
    """Assembly to machine code, field by field, with the bits laid out."""
    spec = INSTRUCTION_DB[name]
    operands = _sample_operands(name)
    word = encode_instruction(name, **operands)
    page = build_learning_page(name)

    print(LINE)
    print("%s 인코딩 실습" % name)
    print(LINE)
    print("형식      : %s" % spec["format"])
    print("레이아웃  : %s" % spec.get("layout", spec["format"]))
    print()
    print("[입력]")
    if not operands:
        print("  피연산자가 없습니다. 고정 인코딩입니다.")
    for key, value in operands.items():
        label = "x%d" % value if key in ("rd", "rs1", "rs2") else str(value)
        print("  %-8s : %s" % (key, label))

    print()
    print("[고정 필드]  명세가 정한 값")
    print("  opcode   : %s" % format(spec["opcode"], "07b"))
    if spec.get("funct3") is not None:
        print("  funct3   : %s" % format(spec["funct3"], "03b"))
    if spec.get("funct7") is not None:
        print("  funct7   : %s" % format(spec["funct7"], "07b"))

    print()
    print("[조립 결과]")
    print("  어셈블리 : %s" % page.assembly)
    print("  기계어   : %s" % hex32(word))
    print("  이진수   : %s" % format(word, "032b"))
    print()
    print("[비트 위치]")
    _bit_ruler(word, spec)
    print()
    print("같은 명령어를 디코딩해 보려면  decode %s  를 입력하십시오." % name)


def _bit_ruler(word: int, spec: Dict[str, Any]) -> None:
    """Show which bits belong to which field, 32 columns wide."""
    layout = spec.get("layout", spec["format"])
    fields = FORMAT_DB[layout]["fields"]
    owner = ["."] * 32
    marks: Dict[str, str] = {}
    for index, field in enumerate(fields):
        mark = field["name"][0].upper()
        while mark in marks and marks[mark] != field["name"]:
            mark = chr(ord(mark) + 1)
        marks[mark] = field["name"]
        for bit in range(field["lo"], field["hi"] + 1):
            owner[bit] = mark
    bits = "".join(str((word >> b) & 1) for b in range(31, -1, -1))
    tags = "".join(owner[b] for b in range(31, -1, -1))
    print("  bit 31" + " " * 20 + "bit 0")
    print("  " + bits)
    print("  " + tags)
    for mark, field_name in marks.items():
        found = next(f for f in fields if f["name"] == field_name)
        print("    %s = %-12s [%2d:%2d]"
              % (mark, field_name, found["hi"], found["lo"]))


# --- step 6 : decoding ---------------------------------------------------
def show_decode(name: Optional[str] = None, word: Optional[int] = None) -> None:
    """Machine code back to fields and a name."""
    if word is None:
        if name is None:
            raise ValueError("명령어 이름이나 기계어가 필요합니다")
        word = encode_instruction(name, **_sample_operands(name))
    decoded = decode(word)

    print(LINE)
    print("디코딩 실습")
    print(LINE)
    print("기계어   : %s" % hex32(word))
    print("이진수   : %s" % format(word, "032b"))
    print()
    print("[1단계] opcode 를 읽는다")
    print("  inst[6:0] = %s" % format(word & 0x7F, "07b"))
    matches = [n for n, s in INSTRUCTION_DB.items()
               if s["opcode"] == (word & 0x7F)]
    print("  이 opcode 를 쓰는 명령어 %d개" % len(matches))
    if len(matches) > 1:
        print("  %s" % " ".join(sorted(matches)))
        print()
        print("[2단계] funct3 로 좁힌다")
        print("  inst[14:12] = %s" % format((word >> 12) & 0x7, "03b"))
        narrowed = [n for n in matches
                    if INSTRUCTION_DB[n].get("funct3") in (None,
                                                           (word >> 12) & 0x7)]
        print("  남은 후보 %d개  %s" % (len(narrowed), " ".join(sorted(narrowed))))
        if len(narrowed) > 1:
            print()
            print("[3단계] funct7 로 가른다")
            print("  inst[31:25] = %s" % format((word >> 25) & 0x7F, "07b"))
    print()
    print("[판정]")
    if decoded.get("name") == "ILLEGAL":
        print("  이 CPU 가 모르는 명령어입니다.")
        return
    print("  명령어   : %s" % decoded["name"])
    print("  형식     : %s" % decoded["format"])
    print()
    print(format_field_table(decoded))
    print()
    print("실행해 보려면  run %s  를 입력하십시오." % decoded["name"])


# --- steps 8 : state, reg, mem ------------------------------------------
def show_state() -> None:
    """Everything the last run changed, in one place."""
    result, cpu = LAST["result"], LAST["cpu"]
    print(LINE)
    print("상태 확인")
    print(LINE)
    if result is None:
        print("아직 실행한 명령어가 없습니다.")
        print("run ADD 처럼 먼저 실행한 뒤 다시 입력하십시오.")
        return
    print("마지막 실행  : %s" % result.assembly)
    print("기계어       : %s" % hex32(result.machine_code))
    print()
    print("[PC]")
    print("  %s -> %s" % (hex32(result.pc_before), hex32(result.pc_after)))
    delta = (result.pc_after - result.pc_before) & 0xFFFFFFFF
    print("  변화 %+d" % signed(delta))
    if result.rd is not None and result.rd_after is not None:
        print()
        print("[레지스터]")
        changed = result.rd_before != result.rd_after
        print("  x%-3d %s -> %s   %s"
              % (result.rd, hex32(result.rd_before or 0),
                 hex32(result.rd_after),
                 "바뀌었습니다" if changed else "값이 같습니다"))
        if result.rd == 0:
            print("  x0 은 언제나 0 이므로 쓰기가 버려집니다.")
    if result.memory_after:
        print()
        print("[메모리]")
        print("  이전 : %s" % " ".join("%02X" % b for b in result.memory_before))
        print("  이후 : %s" % " ".join("%02X" % b for b in result.memory_after))
    if result.branch_taken is not None:
        print()
        print("[분기]")
        print("  조건 %s" % ("성립" if result.branch_taken else "미성립"))
        if result.branch_target is not None:
            print("  목표 %s" % hex32(result.branch_target))
    print()
    print("reg 로 레지스터 전체를, mem 으로 메모리를 볼 수 있습니다.")


def show_registers(which: Optional[str] = None) -> None:
    """The register file after the last run."""
    cpu = LAST["cpu"]
    print(LINE)
    print("레지스터 파일")
    print(LINE)
    if cpu is None:
        print("아직 실행한 명령어가 없습니다. run ADD 처럼 먼저 실행하십시오.")
        return
    if which:
        text = which.lower().lstrip("x")
        if not text.isdigit() or not 0 <= int(text) <= 31:
            print("x0 부터 x31 사이로 입력하십시오: %s" % which)
            return
        index = int(text)
        value = cpu.read_reg(index)
        print("  x%-3d %s   부호로 %d" % (index, hex32(value), signed(value)))
        if index == 0:
            print("  x0 은 하드웨어가 0 으로 고정한 레지스터입니다.")
        return
    nonzero = 0
    for row in range(8):
        cells = []
        for column in range(4):
            index = row + column * 8
            value = cpu.read_reg(index)
            if value:
                nonzero += 1
            cells.append("x%-2d %s" % (index, hex32(value)))
        print("  " + "   ".join(cells))
    print()
    print("  0 이 아닌 레지스터 %d개" % nonzero)
    print("  reg x5 처럼 하나만 볼 수도 있습니다.")


def show_memory(where: Optional[str] = None) -> None:
    """Memory around the address the last run touched."""
    cpu, result = LAST["cpu"], LAST["result"]
    print(LINE)
    print("메모리")
    print(LINE)
    if cpu is None:
        print("아직 실행한 명령어가 없습니다. run LW 처럼 먼저 실행하십시오.")
        return
    if where:
        try:
            base = int(where, 0)
        except ValueError:
            print("주소를 숫자로 입력하십시오. 16진수는 0x 로 시작합니다: %s"
                  % where)
            return
    elif result is not None and result.effective_address is not None:
        base = result.effective_address
        print("마지막으로 접근한 주소를 중심으로 보여 줍니다.")
    else:
        base = 0x1000
        print("접근한 주소가 없어 %s 부터 보여 줍니다." % hex32(base))
    base &= ~0x3
    print()
    print("  주소         +0 +1 +2 +3    워드")
    for offset in range(-8, 12, 4):
        address = (base + offset) & 0xFFFFFFFF
        octets = [cpu.memory.get(address + k, 0) & 0xFF for k in range(4)]
        word = octets[0] | (octets[1] << 8) | (octets[2] << 16) | (octets[3] << 24)
        mark = " <-" if address == base else ""
        print("  %s   %s    %s%s"
              % (hex32(address), " ".join("%02X" % b for b in octets),
                 hex32(word), mark))
    print()
    print("  리틀 엔디안이므로 낮은 주소에 낮은 바이트가 들어갑니다.")
    print("  mem 0x2000 처럼 주소를 지정할 수도 있습니다.")


# --- step 13 : exam and selftest ---------------------------------------
def run_exam(count: int = 10, seed: Optional[int] = None,
             name: Optional[str] = None) -> None:
    """A short set drawn from the question bank, marked as you go.

    With a name it asks only about that instruction, which is what the help
    text has always promised for `exam ADD`.
    """
    picker = random.Random(seed if seed is not None else 20260101)
    pool = list(questions_for_instruction(name)) if name else list(QUESTIONS)
    if not pool:
        print("  %s 에 대한 문제가 아직 없습니다." % name)
        return
    picked = picker.sample(pool, min(count, len(pool)))
    print(LINE)
    print("최종 확인 시험%s  —  문제 %d개"
          % (" · %s" % name if name else "", len(picked)))
    print("정답을 입력하고 Enter 를 누르십시오. q 를 누르면 중단합니다.")
    print(LINE)
    right = 0
    asked = 0
    for number, question in enumerate(picked, 1):
        print()
        print("[%d/%d] %s" % (number, len(picked), question.prompt))
        answer = input("  답 > ").strip()
        if answer.lower() == "q":
            print("  중단합니다.")
            break
        asked += 1
        correct = answer.upper().replace(" ", "") == \
            str(question.answer).upper().replace(" ", "")
        if correct:
            right += 1
        print("  %s   정답 : %s"
              % ("맞았습니다." if correct else "다릅니다.", question.answer))
        print("  %s" % question.explanation)
    print()
    print(THIN)
    if asked:
        print("  %d문제 가운데 %d개를 맞혔습니다. (%.0f %%)"
              % (asked, right, 100.0 * right / asked))
    else:
        print("  풀이한 문제가 없습니다.")
    print("  틀린 문제의 명령어는 learn 으로 다시 볼 수 있습니다.")


def run_selftest() -> None:
    """The engine's own verification, run from inside the shell."""
    print(LINE)
    print("자체 검증")
    print(LINE)
    from tests.self_test import run_self_test
    failed = run_self_test(verbose=False)
    if failed == 0:
        print("엔진 검증을 통과했습니다.")
    else:
        print("엔진 검증에 실패했습니다. python -m tests.self_test 로")
        print("어느 항목인지 확인하십시오.")
    print()
    print("전체 검증은 셸을 나간 뒤 python verify_all.py 로 돌립니다.")
    print("  1 엔진 검증      인코딩·디코딩이 명세와 맞는가")
    print("  2 교재 연계 검증   화면·덮개·재현성")
    print("  3 결함 주입 시험   위 두 검증이 결함을 잡는가")


# --- step 3 : the legend every Lab opens with ---------------------------
def show_legend() -> None:
    """One page of terms and notation, identical in the book and the tool.

    Every Lab begins here, so the words on a page and the words on a screen
    are the same words. A reader who forgets what funct7 means does not have
    to leave the Lab to find out.
    """
    print(LINE)
    print("Quick Reference — 용어와 표기법")
    print(LINE)
    print()
    print("[명령어 필드]")
    ROWS = [
        ("opcode", "inst[6:0]", "명령어의 큰 갈래를 정한다. 7비트"),
        ("rd", "inst[11:7]", "결과를 받는 레지스터"),
        ("funct3", "inst[14:12]", "같은 opcode 안에서 동작을 가른다. 3비트"),
        ("rs1", "inst[19:15]", "첫 번째 원본 레지스터"),
        ("rs2", "inst[24:20]", "두 번째 원본 레지스터"),
        ("funct7", "inst[31:25]", "동작을 한 번 더 가른다. 7비트"),
        ("shamt", "inst[24:20]", "상수 시프트의 이동 칸 수. 5비트"),
        ("imm", "형식마다 다름", "명령어에 박아 넣은 상수"),
    ]
    for name, where, what in ROWS:
        print("  %-8s %-14s %s" % (name, where, what))

    print()
    print("[여섯 형식]")
    FORMATS = [
        ("R", "레지스터 두 개를 연산한다", "ADD SUB AND OR XOR"),
        ("I", "레지스터와 상수를 연산한다", "ADDI LW JALR"),
        ("S", "메모리에 저장한다", "SB SH SW"),
        ("B", "조건이 맞으면 분기한다", "BEQ BNE BLT"),
        ("U", "상위 20비트 상수를 만든다", "LUI AUIPC"),
        ("J", "무조건 점프한다", "JAL"),
    ]
    for name, what, examples in FORMATS:
        print("  %-3s %-24s %s" % (name, what, examples))

    print()
    print("[표기법]")
    print("  0x002082B3        16진수. 32비트 기계어를 이렇게 적는다")
    print("  0b0110011         2진수. 필드 값을 이렇게 적는다")
    print("  inst[31:25]       명령어의 31번 비트부터 25번 비트까지")
    print("  x5                레지스터 5번")
    print("  X[5]              레지스터 5번에 담긴 값")
    print("  MEM[addr]         메모리의 addr 번지")
    print("  PC                다음에 읽을 명령어의 주소")
    print("  sign_extend(v)    v 의 최상위 비트를 위쪽에 채워 32비트로 늘린다")

    print()
    print("[약속]")
    print("  x0 은 언제나 0 이고 쓰기를 해도 값이 남지 않는다")
    print("  명령어는 4바이트이므로 PC 는 보통 4씩 오른다")
    print("  명령어 주소는 4의 배수이므로 하위 두 비트가 언제나 00 이다")
    print("  즉시값의 부호 비트는 여섯 형식 모두 inst[31] 이다")
    print("  메모리는 리틀 엔디안이다. 낮은 주소에 낮은 바이트가 들어간다")

    print()
    print("[Lab 의 열두 단계와 명령]")
    STEPS = [
        ("① Learning Objectives", "-"),
        ("② Background Theory", "-"),
        ("③ Quick Reference", "legend"),
        ("④ Instruction Summary", "learn"),
        ("⑤ Encoding Practice", "encode"),
        ("⑥ Decoding Practice", "decode"),
        ("⑦ CPU Execution Practice", "run"),
        ("⑧ Register / Memory Trace", "state, reg, mem"),
        ("⑨ RTL Datapath Analysis", "rtl"),
        ("⑩ Check Questions", "question"),
        ("⑪ Programming Exercises", "-"),
        ("⑫ Summary", "-"),
    ]
    for step, command in STEPS:
        print("  %-28s %s" % (step, command))
