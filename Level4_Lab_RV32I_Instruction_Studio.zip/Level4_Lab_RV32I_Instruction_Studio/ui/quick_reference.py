QUICK_REFERENCE_HTML = r"""
<h3 style="margin-top:0">Quick Reference (범례)</h3>
<table style="border-collapse:collapse;width:100%">
<tr><th style="text-align:left;border-bottom:1px solid #777;padding:4px">표기</th>
    <th style="text-align:left;border-bottom:1px solid #777;padding:4px">의미</th></tr>
<tr><td style="padding:4px">x0 ~ x31</td><td style="padding:4px">서른두 개의 범용 레지스터. x0는 항상 0입니다.</td></tr>
<tr><td style="padding:4px">rd</td><td style="padding:4px">연산 결과가 기록되는 목적 레지스터</td></tr>
<tr><td style="padding:4px">rs1, rs2</td><td style="padding:4px">연산에 사용되는 소스 레지스터</td></tr>
<tr><td style="padding:4px">imm</td><td style="padding:4px">명령어 안에 포함된 즉시값</td></tr>
<tr><td style="padding:4px">opcode</td><td style="padding:4px">명령어의 큰 종류를 구분하는 필드</td></tr>
<tr><td style="padding:4px">funct3, funct7</td><td style="padding:4px">같은 opcode 안에서 세부 연산을 구분하는 필드</td></tr>
<tr><td style="padding:4px">[31:25]</td><td style="padding:4px">31번 비트부터 25번 비트까지</td></tr>
<tr><td style="padding:4px">00101</td><td style="padding:4px">이진수 5이며, 레지스터 필드에서는 x5를 뜻합니다.</td></tr>
<tr><td style="padding:4px">PC</td><td style="padding:4px">현재 명령어 주소. ADD와 ADDI 실행 후 4 증가합니다.</td></tr>
</table>
<hr>
<b>R 형식 명령어</b><br>
<code>funct7 | rs2 | rs1 | funct3 | rd | opcode</code><br><br>
<b>I 형식 명령어</b><br>
<code>imm[11:0] | rs1 | funct3 | rd | opcode</code>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>Step 4 추가 명령어</h3>
<table style="border-collapse:collapse;width:100%">
<tr><th style="text-align:left">형식</th><th style="text-align:left">명령어</th><th style="text-align:left">핵심 동작</th></tr>
<tr><td>U</td><td>LUI, AUIPC</td><td>상위 즉시값 생성 / PC 상대 상위 주소 생성</td></tr>
<tr><td>I Load</td><td>LB, LH, LW, LBU, LHU</td><td>주소 계산 후 메모리 읽기와 부호·제로 확장</td></tr>
<tr><td>S</td><td>SB, SH, SW</td><td>주소 계산 후 메모리 쓰기</td></tr>
</table>
<p><b>정렬 규칙</b>: byte는 모든 주소, half는 2바이트 정렬, word는 4바이트 정렬</p>
<p><b>Little Endian</b>: 가장 낮은 주소에 값의 최하위 바이트를 저장</p>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>Step 5 추가 명령어 — B 형식</h3>
<table style="border-collapse:collapse;width:100%">
<tr><th style="text-align:left">명령어</th><th style="text-align:left">비교</th><th style="text-align:left">해석</th></tr>
<tr><td>BEQ</td><td>==</td><td>같으면 분기</td></tr>
<tr><td>BNE</td><td>!=</td><td>다르면 분기</td></tr>
<tr><td>BLT</td><td>&lt;</td><td>부호 있는 비교</td></tr>
<tr><td>BGE</td><td>&gt;=</td><td>부호 있는 비교</td></tr>
<tr><td>BLTU</td><td>&lt;</td><td>부호 없는 비교</td></tr>
<tr><td>BGEU</td><td>&gt;=</td><td>부호 없는 비교</td></tr>
</table>
<p><b>B 형식 즉시값</b>: imm[12] · imm[10:5] · imm[4:1] · imm[11]의 네 조각으로 저장됩니다.</p>
<p><b>imm[0]</b>: 항상 0이므로 명령어 안에 저장하지 않습니다.</p>
<p><b>분기 범위</b>: -4096부터 +4094바이트, 2바이트 단위</p>
<p><b>PC 선택</b>: 조건 참이면 PC + offset, 조건 거짓이면 PC + 4</p>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>Step 6 추가 명령어 — JAL / JALR</h3>
<table style="border-collapse:collapse;width:100%">
<tr><th style="text-align:left">명령어</th><th style="text-align:left">다음 PC</th><th style="text-align:left">rd 저장</th></tr>
<tr><td>JAL</td><td>PC + offset</td><td>PC + 4</td></tr>
<tr><td>JALR</td><td>(rs1 + imm) &amp; ~1</td><td>PC + 4</td></tr>
</table>
<p><b>J 형식 즉시값</b>: imm[20] · imm[10:1] · imm[11] · imm[19:12]</p>
<p><b>imm[0]</b>: 항상 0이므로 명령어에 저장하지 않습니다.</p>
<p><b>JAL 범위</b>: -1048576부터 +1048574바이트, 2바이트 단위</p>
<p><b>JALR</b>: I 형식이며 계산된 목표 주소의 bit0을 반드시 0으로 만듭니다.</p>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>Step 7 — RV32I 40개 완성</h3>
<table style="border-collapse:collapse;width:100%">
<tr><th style="text-align:left">명령어</th><th style="text-align:left">핵심 동작</th><th style="text-align:left">기계어</th></tr>
<tr><td>FENCE</td><td>메모리·입출력 접근 순서 보장</td><td>0x0FF0000F</td></tr>
<tr><td>ECALL</td><td>실행 환경 호출 예외</td><td>0x00000073</td></tr>
<tr><td>EBREAK</td><td>중단점 예외</td><td>0x00100073</td></tr>
</table>
<p><b>일반 디코드 규칙</b>: (word &amp; match_mask) == match_value</p>
<p>ECALL과 EBREAK는 opcode와 funct3만으로 구분할 수 없습니다.
즉시값 12비트 전체를 포함한 32비트 고정 패턴으로 판정합니다.</p>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>Step 8 — 교육용 RTL</h3>
<p>각 명령어는 다음 세 층으로 연결됩니다.</p>
<ol>
<li>명령어 필드와 match_mask 판정</li>
<li>제어 신호 생성</li>
<li>데이터패스 블록 선택</li>
</ol>
<p>핵심 제어 신호: reg_write, mem_read, mem_write, branch, jump,
result_src, alu_control, pc_select, system_event, fence_enable</p>
"""


QUICK_REFERENCE_HTML += """
<hr>
<h3>V1.0.0 — 공통 학습 페이지</h3>
<p>모든 명령어는 다음 여덟 단계를 동일하게 제공합니다.</p>
<ol>
<li>설명</li>
<li>입력</li>
<li>인코딩</li>
<li>디코딩</li>
<li>실행</li>
<li>상태 변화</li>
<li>교육용 RTL</li>
<li>확인 문제</li>
</ol>
<p>40개 명령어 × 8개 단계 = 320개 완전성 관문을 자동 검증합니다.</p>
"""
