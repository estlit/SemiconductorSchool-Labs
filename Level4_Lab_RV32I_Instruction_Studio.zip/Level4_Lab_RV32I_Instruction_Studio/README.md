# EdgeChipLab CPU Studio — RV32I Text Studio

**EdgeChipLab Computer Architecture Series**
*From Fundamentals to FPGA Implementation*

Volume 1 · RV32I Instruction Architecture · V1.4.2

---

## 실행

```
%run Lab01.py
```

자체 검증이 먼저 돌고, 통과하면 학습이 시작됩니다. 실패하면 시작하지
않습니다. 잘못된 인코딩을 가르치는 도구는 없는 것보다 나쁩니다.

버튼이 없습니다. 명령을 입력해 진행합니다. 주피터에서든 터미널에서든
스크립트로든 같은 방식으로 동작합니다.

## 명령

```
map              RV32I 40개 명령어 지도
learn ADD        ADD 통합 학습 (여덟 단계)
run ADD          값을 입력해 직접 실행
rtl ADD          교육용 RTL
question ADD     그 명령어의 확인 문제
question Q05     문제 번호로 하나만 보기
list             지원 명령어 이름
help             도움말
exit             끝내기
```

이름은 대소문자를 가리지 않고, 앞부분만 입력해도 됩니다. `learn ad` 처럼
여러 개가 걸리면 후보를 알려 줍니다. 인수를 빼고 `learn` 만 입력하면
이름을 물어보고, 빈 줄을 입력하면 되돌아갑니다.

## 여덟 단계

```
1 설명 → 2 입력 → 3 인코딩 → 4 디코딩
→ 5 실행 → 6 상태 변화 → 7 교육용 RTL → 8 확인 문제
```

40개 명령어가 모두 같은 여덟 단계를 제공합니다.

## 검증

```
python verify_all.py
```

세 단계가 순서대로 돕니다.

```
1  엔진 검증        1231개   인코딩·디코딩이 명세와 맞는가
2  교재 연계 검증      28개   화면·덮개·재현성이 교재에 쓸 수 있는가
3  결함 주입 시험      12개   위 두 검증이 실제로 결함을 잡는가
```

따로 돌릴 수도 있습니다.

```
python -m tests.self_test
python -m tests.book_test
python -m tests.fault_test
```

### 왜 세 단계인가

**1단계는 엔진의 값을 봅니다.** 인코딩, 디코딩, 학습 페이지 데이터입니다.

**2단계는 그 위층을 봅니다.** 40개 × 화면 세 종이 예외 없이 그려지는지,
화면에 찍힌 기계어가 엔진 값과 같은지, 셸이 어떤 입력에도 죽지 않는지,
같은 명령을 두 번 캡처하면 같은 글이 나오는지입니다.

2단계가 필요한 이유가 있습니다. 1단계 1231개를 통과한 상태에서 여덟째
화면이 예외로 죽은 일이 있었습니다. 엔진은 딕셔너리를 주는데 화면이
객체로 읽어서 생긴 일이고, 엔진만 보는 검증으로는 보이지 않습니다.

**3단계는 검증기 자체를 봅니다.** 결함 12개를 일부러 넣고 1·2단계가
잡는지 확인한 뒤 원래대로 되돌립니다.

넣는 결함은 이런 것들입니다.

```
SUB 의 funct7 을 0 으로 바꿈           명세와 어긋나는 인코딩
ADDI 의 opcode 를 OP 로 바꿈          디코더가 잘못 판정하게 만듦
부호 확장을 무효화                     음수 즉시값이 양수로 돌아옴
FENCE 를 표에서 제거                   명령어 하나가 사라짐
확인 문제를 객체로만 읽음                실제로 겪은 결함을 재현
rtl 화면이 BEQ 에서만 예외              특정 명령어에서만 나는 결함
help 가 예외를 던짐                    화면에 오류 문구가 찍히는 결함
덮개에서 SLTIU 의 실행 Lab 삭제         교재의 빠진 칸
덮개에 ADDI 를 두 Lab 에 배정           교재의 중복 배정
덮개에 표에 없는 이름 추가               교재의 오타
학습 화면의 16진 표기를 훼손             화면과 엔진이 어긋남
명령어 지도 출력이 실행마다 달라짐          인쇄물이 재현되지 않음
```

**3단계에서 실제로 구멍을 찾았습니다.** 처음 돌렸을 때 12개 중 2개를
놓쳤고, 원인은 `dispatch()` 가 예외를 삼켜 화면에 출력하므로 2단계가
「화면이 그려졌다」고 판정한 것이었습니다. 화면에 찍힌 오류 문구도 결함으로
보도록 고쳤고, 그 과정에서 `learn` 만 입력했을 때 예외가 나는 실제 결함도
함께 드러나 고쳤습니다.

## 교재 연계

교재에 실을 화면은 손으로 옮기지 않습니다. 도구가 직접 만듭니다.

```python
from ui.book import all_chapters, coverage_markdown

all_chapters("book_out")                  # Chapter 별 캡처 31개
open("book_out/coverage.md", "w").write(coverage_markdown())
```

캡처 파일 머리에 이렇게 적힙니다.

```
# 이 파일은 CPU Studio 가 직접 만든 것입니다. 손으로 고치지 마십시오.
# 명령  learn BEQ
```

`coverage.md` 는 40개 명령어가 어느 Lab 에서 어느 단계로 다뤄지는지를
표로 냅니다. 부록에 그대로 들어가며, 빠진 것이 있으면 표에 빈칸으로
나타나므로 원고를 쓰는 쪽에서 먼저 알게 됩니다.

셸과 교재 캡처는 `dispatch()` 라는 같은 경로를 지납니다. 교재의 출력이
수강생이 보는 것과 다를 수 없습니다.

## 필요한 것

Python 3.8 이상. 설치할 패키지가 없습니다.

---
Semiconductor School · www.SemiconductorSchool.co.kr

## 명령과 Lab 단계의 대응

교재의 Lab 은 열두 단계로 되어 있고, ④부터 ⑩까지가 Studio 명령과
하나씩 짝을 이룹니다. 실습 지시가 한 줄로 끝납니다.

```
③ Quick Reference       legend
④ Instruction Summary   learn ADD
⑤ Encoding Practice     encode ADD
⑥ Decoding Practice     decode 0x002082B3
⑦ CPU Execution         run ADD
⑧ Register/Memory Trace state · reg · mem
⑨ RTL Datapath          rtl ADD
⑩ Check Questions       question ADD
   Final Verification   exam · selftest
```

`run` 의 결과는 남아 있으므로 `state` · `reg` · `mem` 으로 이어서
관찰할 수 있습니다. 처음으로 되돌리려면 `reset` 을 입력합니다.

## Volume 1 구성

6 SECTION · 13 Chapter · 17 Lab. RV32I 40개 명령어가 모두 들어갑니다.

```python
from ui.book import structure_markdown, coverage_markdown, all_labs

structure_markdown()          # SECTION · Chapter · Lab · 명령어 표
coverage_markdown()           # 40개 × 인코딩·실행·검증 덮개 표
all_labs("book_out")          # Lab 별 캡처 59개
```

덮개는 세 단계로 봅니다.

```
인코딩    Lab 4-1 이 40개 전부
실행      Lab 5-1 부터 12-2 까지 열한 개가 나눠 가짐
검증      Lab 13-1 이 40개 전부
```

한 명령어가 실행 단계에서 두 Lab 에 겹치면 검증이 실패합니다.

## 변경 이력

### V1.4.2
- `question` 이 문제 번호도 받습니다. 교재가 문제 하나를 인용할 때 독자가
  같은 문제로 되돌아올 길이 `exam` 밖에 없었는데, 그것은 오십 문제 가운데
  열 개를 뽑는 방식이라 특정 문제에 닿을 수 없었습니다.

### V1.4.1
- 옛 이름 `Explorer` 가 두 곳에 남아 있어 `Instruction Studio` 로 통일했습니다.
  하나는 문제은행의 문제 문장이라 교재에도 그대로 실리고 있었습니다.

### V1.4.0
- 교재 구조를 2판으로 바꿨습니다. SECTION 6 → **4**, Lab 17 → **13**.
  Lab 을 따로 모으지 않고 **각 Chapter 안에** 둡니다.
- Chapter 경계를 데이터가 지나는 경로 기준으로 다시 갈랐습니다. 예를 들어
  레지스터끼리 계산하는 명령과 즉시값을 쓰는 명령이 서로 다른 장이 됩니다.
- `LAB_TITLE` · `CHAPTER_TITLE` · `SECTION_OF_CHAPTER` · `LAB_EXECUTION` ·
  `LAB_TRANSCRIPTS` 를 모두 새 구조로 다시 썼습니다.
- 실행 단계가 명령어 40개를 여전히 빠짐없이 덮으며 중복 배정이 없습니다.
- 결함 주입 시험 두 건이 옛 Lab 번호(5-2)를 가리키고 있어 새 번호로
  옮겼습니다.

### V1.3.2
- `datapath_blocks("LUI")` 와 `("AUIPC")` 가 Writeback MUX 는 지나면서
  Register File 은 지나지 않는 모순이 있었습니다. 두 명령 모두 rd 에 값을
  남기므로 Register File 을 더했습니다. 이 값을 쓰는 그림(ch13_01)의
  집계가 35 에서 37 로 바로잡힙니다.
- `Bit0 Clear` 를 `Bit 0 Clear` 로 고쳤습니다. 0 이 비트 번호임을 드러냅니다.

### V1.3.1
- 외부 검수 지적 3건 수정
  - `run` 의 정렬 위반이 파이썬 오류로 새던 문제. 원인이 세 겹이었습니다.
    `AddressAlignmentError` 가 import 되어 있지 않았고, `spec` 이 선언되지
    않았으며, 예외가 실행 단계가 아니라 입력 수집 단계에서 먼저 났습니다.
    안내 문구를 `_alignment_help()` 로 묶어 두 단계 모두에서 잡습니다.
  - `exam ADD` 가 도움말대로 동작하지 않던 문제. `run_exam(name=...)` 을
    더해 그 명령어의 문제만 냅니다.
  - `decode 0xGHIJ` 처럼 16진수를 흉내 낸 오타에 파이썬 메시지가 노출되던
    문제. 안내 문구로 바꿨습니다.
- 위 세 결함의 회귀 시험 7개 추가 (`tests/book_test.py`)
- 교재 연계 검증 46 → 53항목

### V1.3.0
- Volume 1 구성을 6 SECTION · 13 Chapter · 17 Lab 으로 확정
- 덮개 표에 SECTION 열 추가, Lab 번호를 `5-1` 형식으로
- 캡처를 Chapter 단위에서 Lab 단위로 바꾸고 59개로 확장
- `structure_markdown()` 추가 — 책 앞의 구성표
- 결함 주입 시험을 14개로 확장
  Lab 캡처 정의 제거 · 없는 명령으로 바꾸기
- 교재 연계 검증 46항목

### V1.2.0
- 교재 연계 검증을 12묶음 43항목으로 확장
  화면 다섯 종 × 40개 · 인코딩→디코딩 왕복 · 셸 18가지 입력
  실행 뒤 상태 유지 · 사양서가 요구한 명령 12개 · 도움말 일치
- 검증기가 실제 화면 문구와 어긋나던 두 곳 수정
- 도움말에 `legend` 누락을 보완

### V1.1.0
- 검증 체계를 세 단계로 구성하고 `verify_all.py` 를 추가
- 결함 주입 시험 12개 신설 — 검증기가 실제로 결함을 잡는지 확인
- 결함 주입에서 드러난 검증기 구멍 수정
  화면에 찍힌 오류 문구도 결함으로 판정하게 함
- 실제 결함 수정
  `learn` 만 입력하면 예외가 나던 것을 안내로 처리
  이름 앞부분만 입력했을 때 후보를 알려 주도록 통일
- `Lab01.py` 의 경로 정리가 `V0_` 만 걸러내던 것을 폴더 이름 세 종으로 확대

### V1.0.2
- 확인 문제를 딕셔너리와 객체 양쪽에서 읽도록 수정
  여덟째 화면이 `AttributeError` 로 죽던 결함
- `dispatch()` 분리 — 셸과 교재 캡처가 같은 경로를 지나게 함
- `ui/book.py` 추가 — Chapter 별 캡처와 덮개 표 생성
- `tests/book_test.py` 추가 — 화면·덮개·재현성 검증
- 위젯 UI 삭제, `ipywidgets` 의존성 제거

### V1.0.1
- 텍스트 인터페이스 도입, 버튼 방식 폐지
