`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// tb_lab3_classifier : [Project B - Stage 2] verify 4 images img0..3 with learned weights
//   Same dry-run structure; weights/paths use the learned set (absolute path) + SHIFT_CONV=8.
//   golden_class.mem is NOT used -> expected class = argmax(golden_feature).
//   Path rule: D:/Arty_home/lab2_output/  (Lab2_02 output folder)
//     fpga_mem/ conv_weight.mem, conv_bias.mem, img0..3.mem
//     verify/   golden_feature.mem
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module tb_lab3_classifier;
    reg clk=0, rst=1, SW0=0, SW1=0;
    wire LD2,LD3,LD4,LD5;
    always #41.667 clk=~clk;   // 12 MHz

    // learned weights + image paths as absolute paths, SHIFT_CONV=8
    top_level5_lab3_classifier #(
        .SHIFT_CONV(8),
        .I0("D:/Arty_home/training/lab2_output/fpga_mem/img0.mem"),
        .I1("D:/Arty_home/training/lab2_output/fpga_mem/img1.mem"),
        .I2("D:/Arty_home/training/lab2_output/fpga_mem/img2.mem"),
        .I3("D:/Arty_home/training/lab2_output/fpga_mem/img3.mem"),
        .WFILE("D:/Arty_home/training/lab2_output/fpga_mem/conv_weight.mem"),
        .BFILE("D:/Arty_home/training/lab2_output/fpga_mem/conv_bias.mem")
    ) dut(
        .clk(clk), .rst(rst), .SW0(SW0), .SW1(SW1),
        .LD2(LD2),.LD3(LD3),.LD4(LD4),.LD5(LD5));

    // load golden feature only (class computed via argmax -> golden_class.mem not needed)
    reg signed [31:0] gfeat [0:15];
    initial $readmemh("D:/Arty_home/training/lab2_output/verify/golden_feature.mem", gfeat);

    integer mismatch = 0;
    integer img, cvcount;

    function [1:0] argmax4(input signed [31:0] a,b,c,d);
        reg signed [31:0] mx; reg [1:0] mi;
        begin
            mx=a; mi=2'd0;
            if (b>mx) begin mx=b; mi=2'd1; end
            if (c>mx) begin mx=c; mi=2'd2; end
            if (d>mx) begin mx=d; mi=2'd3; end
            argmax4=mi;
        end
    endfunction

    task run_image(input [1:0] sw);
        reg signed [31:0] ef0,ef1,ef2,ef3; reg [1:0] ec;
        begin
            {SW1,SW0} = sw;
            cvcount = 0;                       // warm-up: 3 class_valid pulses (drop 2 frames)
            while (cvcount < 3) begin
                @(posedge clk);
                if (dut.class_valid) cvcount = cvcount + 1;
            end
            img = sw;
            ef0=gfeat[img*4+0]; ef1=gfeat[img*4+1];
            ef2=gfeat[img*4+2]; ef3=gfeat[img*4+3];
            ec = argmax4(ef0,ef1,ef2,ef3);     // expected class = argmax(golden feature)
            $display("---------------------------------------------");
            $display(" IMG%0d (SW=%b)", img, sw);
            $display("  feat exp = %0d %0d %0d %0d", ef0,ef1,ef2,ef3);
            $display("  feat rtl = %0d %0d %0d %0d",
                     dut.u_wta.feat0,dut.u_wta.feat1,dut.u_wta.feat2,dut.u_wta.feat3);
            if (dut.u_wta.feat0!==ef0) mismatch=mismatch+1;
            if (dut.u_wta.feat1!==ef1) mismatch=mismatch+1;
            if (dut.u_wta.feat2!==ef2) mismatch=mismatch+1;
            if (dut.u_wta.feat3!==ef3) mismatch=mismatch+1;
            if (dut.class_idx!==ec) mismatch=mismatch+1;
            $display("  class exp=%0d rtl=%0d LED=%b%b%b%b => %s",
                     ec, dut.class_idx, LD2,LD3,LD4,LD5,
                     ((dut.class_idx===ec)?"PASS":"FAIL"));
        end
    endtask

    initial begin
        rst=1; repeat(20) @(posedge clk); rst=0;
        run_image(2'b00); run_image(2'b01);
        run_image(2'b10); run_image(2'b11);
        $display("=============================================");
        $display(" [Stage 2] learned weights, 4 reference images");
        $display(" Mismatch Count = %0d", mismatch);
        $display(" FINAL RESULT = %s",
                 (mismatch==0)?"100% BIT-TRUE PASS":"MISMATCH");
        $display("=============================================");
        $finish;
    end
endmodule
