`timescale 1ns/1ps
// Semiconductor School  |  Copyright (c) 2026 Roger Kim & EdgeChipLab.
// =============================================================
// tb_mass (verbose) : per-image golden vs RTL logged side by side in DEC + HEX(bit)
//   VERBOSE=1 : print all 128 images / 0 : print mismatches only (summary always)
// =============================================================
module tb_mass;
    localparam N = 128;
    localparam VERBOSE = 1;              // set 0 to print mismatches only
    reg clk=0, rst=1;
    wire [1:0] class_idx; wire class_valid;
    wire signed [31:0] feat0,feat1,feat2,feat3;
    wire [7:0] ended_frame_img, img;
    always #41.667 clk=~clk;            // 12 MHz

    top_mass_classifier dut(
        .clk(clk), .rst(rst), .class_idx(class_idx), .class_valid(class_valid),
        .feat0(feat0),.feat1(feat1),.feat2(feat2),.feat3(feat3),
        .ended_frame_img(ended_frame_img), .img(img));

    reg signed [31:0] golden [0:N*5-1];
    initial $readmemh("D:/Arty_home/training/lab2_output/mass/mass_golden.mem", golden);

    reg signed [31:0] rf0[0:N-1], rf1[0:N-1], rf2[0:N-1], rf3[0:N-1];
    reg [1:0] rc[0:N-1];
    reg got[0:N-1];
    integer i;
    initial for (i=0;i<N;i=i+1) got[i]=1'b0;

    always @(posedge clk) begin
        if (!rst && class_valid && ended_frame_img < N) begin
            rf0[ended_frame_img]<=feat0; rf1[ended_frame_img]<=feat1;
            rf2[ended_frame_img]<=feat2; rf3[ended_frame_img]<=feat3;
            rc[ended_frame_img]<=class_idx; got[ended_frame_img]<=1'b1;
        end
    end

    integer mism, fmm, cmm, okc;
    reg imgok;
    initial begin
        rst=1; repeat(20) @(posedge clk); rst=0;
        wait (img > N);
        repeat (7000) @(posedge clk);
        mism=0; fmm=0; cmm=0; okc=0;
        $display("=====================================================================");
        $display(" per-image : PY(python golden) vs RTL(verilog)  - DEC + HEX(bit)");
        $display("=====================================================================");
        for (i=0;i<N;i=i+1) begin
            imgok = (rf0[i]===golden[i*5+0]) && (rf1[i]===golden[i*5+1]) &&
                    (rf2[i]===golden[i*5+2]) && (rf3[i]===golden[i*5+3]) &&
                    (rc[i]===golden[i*5+4][1:0]) && got[i];
            if (imgok) okc=okc+1;
            if (VERBOSE || !imgok) begin
                $display("-- IMG %0d --  %s", i, imgok?"PASS":"*** MISMATCH ***");
                $display("   PY  dec: %0d %0d %0d %0d | cls %0d",
                    golden[i*5+0],golden[i*5+1],golden[i*5+2],golden[i*5+3],golden[i*5+4]);
                $display("   RTL dec: %0d %0d %0d %0d | cls %0d",
                    rf0[i],rf1[i],rf2[i],rf3[i],rc[i]);
                $display("   PY  hex: %08h %08h %08h %08h | %02h",
                    golden[i*5+0],golden[i*5+1],golden[i*5+2],golden[i*5+3],golden[i*5+4]);
                $display("   RTL hex: %08h %08h %08h %08h | %02h",
                    rf0[i],rf1[i],rf2[i],rf3[i],{6'd0,rc[i]});
            end
            if (!got[i]) begin mism=mism+1; $display("   img%0d NOT CAPTURED",i); end
            else begin
                if (rf0[i]!==golden[i*5+0]||rf1[i]!==golden[i*5+1]||
                    rf2[i]!==golden[i*5+2]||rf3[i]!==golden[i*5+3]) begin fmm=fmm+1; mism=mism+1; end
                if (rc[i]!==golden[i*5+4][1:0]) begin cmm=cmm+1; mism=mism+1; end
            end
        end
        $display("=====================================================================");
        $display(" Images = %0d   PASS = %0d   Feature mismatch = %0d   Class mismatch = %0d",
                  N, okc, fmm, cmm);
        $display(" Mismatch Count = %0d", mism);
        $display(" FINAL RESULT = %s", (mism==0)?"100% BIT-TRUE PASS (augmented set)":"MISMATCH");
        $display("=====================================================================");
        $finish;
    end
endmodule
