`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// pixel_addr_gen : 96x64 frame pixel address / coordinate / frame-marker generator
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module pixel_addr_gen #(
    parameter IMG_W = 96,
    parameter IMG_H = 64
)(
    input  wire        clk,
    input  wire        rst,
    output reg  [12:0] pixel_idx,     // 0..6143
    output reg  [6:0]  x,             // 0..95
    output reg  [5:0]  y,             // 0..63
    output reg         frame_start,
    output reg         frame_end
);
    localparam N_PIX = IMG_W*IMG_H;   // 6144
    always @(posedge clk) begin
        if (rst) begin
            pixel_idx <= 13'd0; x <= 7'd0; y <= 6'd0;
            frame_start <= 1'b1; frame_end <= 1'b0;
        end else begin
            frame_start <= (pixel_idx == 13'd0);
            frame_end   <= (pixel_idx == N_PIX-1);
            if (pixel_idx == N_PIX-1) begin
                pixel_idx <= 13'd0; x <= 7'd0; y <= 6'd0;
            end else begin
                pixel_idx <= pixel_idx + 13'd1;
                if (x == IMG_W-1) begin x <= 7'd0; y <= y + 6'd1; end
                else                    x <= x + 7'd1;
            end
        end
    end
endmodule
