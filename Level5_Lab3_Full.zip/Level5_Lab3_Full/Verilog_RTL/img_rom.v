`timescale 1ns/1ps
// 96x64 8-bit grayscale BROM ($readmemh, 1-clock read latency)
module img_rom #(
    parameter MEMFILE = "img0.mem",
    parameter N_PIX   = 6144
)(
    input  wire        clk,
    input  wire [12:0] addr,
    output reg  [7:0]  dout
);
    reg [7:0] mem [0:N_PIX-1];
    initial $readmemh(MEMFILE, mem);
    always @(posedge clk) dout <= mem[addr];
endmodule
