///////////////////////////////////////////////////////////////////////////

/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : spi_master (SPI Master Controller)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : Finite State Machine (FSM)
 * Description  : 8-bit SPI Master configured for Mode 3 
 * (CPOL = 1, CPHA = 1), MSB first transmission.
 * Specifically tailored for the SSD1331 OLED controller.
 * ====================================================================== */

module spi_master (
    // System Interfaces
    input  wire       clk,      // SPI system clock domain
    input  wire       reset,    // Active-high asynchronous reset
    
    // Control and Data Interfaces
    input  wire       start,    // 1-cycle pulse to initiate transmission
    input  wire [7:0] data_in,  // 8-bit data to be transmitted
    output reg        busy,     // High while transmission is in progress
    
    // SPI Physical Interface (Pmod)
    output reg        sclk,     // SPI Clock
    output reg        mosi,     // Master Out Slave In
    output reg        cs_n      // Chip Select (Active-low)
);

    // ----------------------------------------------------------------------
    // Internal Registers & State Machine Definitions
    // ----------------------------------------------------------------------
    reg [3:0] bit_cnt;          // Counter for the 8 bits (7 down to 0)
    reg [7:0] shreg;            // Shift register for data transmission

    localparam IDLE = 2'd0,
               LOAD = 2'd1,
               SEND = 2'd2,
               DONE = 2'd3;

    reg [1:0] state;
    
    // Phase control for Mode 3 (CPOL=1, CPHA=1)
    // 0: Prepare for the falling edge (Data Setup)
    // 1: Prepare for the rising edge (Data Sampled by Slave)
    reg       phase;  

    // ----------------------------------------------------------------------
    // Main FSM Logic
    // ----------------------------------------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state   <= IDLE;
            bit_cnt <= 4'd0;
            shreg   <= 8'd0;
            busy    <= 1'b0;
            sclk    <= 1'b1;    // Mode 3: Idle clock is HIGH (CPOL=1)
            mosi    <= 1'b0;
            cs_n    <= 1'b1;    // Deselect slave (Active-low)
            phase   <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    if (start) begin
                        busy  <= 1'b1;
                        state <= LOAD;
                    end
                end

                LOAD: begin
                    shreg   <= data_in; // Latch input data
                    bit_cnt <= 4'd7;    // Initialize bit counter for 8 bits
                    cs_n    <= 1'b0;    // Assert Chip Select (Select OLED)
                    sclk    <= 1'b1;    // Ensure SCLK is high before starting
                    phase   <= 1'b0;    // First operation will be a falling edge
                    state   <= SEND;
                end

                SEND: begin
                    if (phase == 1'b0) begin
                        // 1st Edge (Falling Edge): SCLK transitions 1 -> 0.
                        // In Mode 3, the master updates/shifts data onto MOSI here.
                        sclk  <= 1'b0;
                        mosi  <= shreg[7]; // MSB first
                        phase <= 1'b1;     // Next state will handle rising edge
                    end else begin
                        // 2nd Edge (Rising Edge): SCLK transitions 0 -> 1.
                        // The slave (SSD1331) samples the MOSI data on this edge.
                        sclk <= 1'b1;
                        
                        // Check if all 8 bits have been transmitted
                        if (bit_cnt == 0) begin
                            state <= DONE;
                        end else begin
                            bit_cnt <= bit_cnt - 1'b1;        // Decrement counter
                            shreg   <= {shreg[6:0], 1'b0};    // Left shift the register
                            phase   <= 1'b0;                  // Ready for the next falling edge
                        end
                    end
                end

                DONE: begin
                    sclk  <= 1'b1;  // Return SCLK to idle high
                    cs_n  <= 1'b1;  // Deassert Chip Select
                    busy  <= 1'b0;  // Clear busy flag
                    state <= IDLE;  // Return to IDLE state
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule

