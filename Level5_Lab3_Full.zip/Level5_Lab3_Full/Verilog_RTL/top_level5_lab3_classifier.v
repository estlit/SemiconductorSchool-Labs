`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// top_level5_lab3_classifier  (classifier domain only, 12 MHz)
//   96x64 -> BROM(4, SW select) -> line_buffer_3x3 -> conv3x3_4filter_int8
//   -> requant_relu_4f(shift+ReLU, no saturation) -> wta_feat_argmax_4f -> LD2..LD5
//   The OLED display path is added at the integrated top (top_level5_lab3);
//   this module contains only the bit-true-verified classification path.
// Pipeline alignment:
//   pixel_idx -> BROM(+1, pixel_in) : delay coords x,y by 1 clock (x_d,y_d)
//   pixel_in -> line_buffer(+1) -> conv(+1) -> requant(+1) = relu
//   frame markers (based on x_d,y_d) -> delayed 3 clocks -> aligned to relu stream
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module top_level5_lab3_classifier #(
    parameter IMG_W = 96,
    parameter IMG_H = 64,
    parameter SHIFT_CONV = 4,
    parameter I0="img0.mem", parameter I1="img1.mem",
    parameter I2="img2.mem", parameter I3="img3.mem",
    parameter WFILE="conv_weight.mem", parameter BFILE="conv_bias.mem"
)(
    input  wire clk,          // 12 MHz
    input  wire rst,          // active-high
    input  wire SW0, SW1,     // image select
    output wire LD2, LD3, LD4, LD5
);
    // 1) address generation
    wire [12:0] pixel_idx; wire [6:0] x; wire [5:0] y;
    wire frame_start, frame_end;
    pixel_addr_gen #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_addr (
        .clk(clk), .rst(rst), .pixel_idx(pixel_idx), .x(x), .y(y),
        .frame_start(frame_start), .frame_end(frame_end));

    // 2) four BROMs + select (1-clock read latency)
    wire [7:0] pix0,pix1,pix2,pix3;
    img_rom #(.MEMFILE(I0)) u0(.clk(clk), .addr(pixel_idx), .dout(pix0));
    img_rom #(.MEMFILE(I1)) u1(.clk(clk), .addr(pixel_idx), .dout(pix1));
    img_rom #(.MEMFILE(I2)) u2(.clk(clk), .addr(pixel_idx), .dout(pix2));
    img_rom #(.MEMFILE(I3)) u3(.clk(clk), .addr(pixel_idx), .dout(pix3));
    reg [7:0] pixel_in;
    always @(*) case({SW1,SW0})
        2'b00: pixel_in=pix0; 2'b01: pixel_in=pix1;
        2'b10: pixel_in=pix2; 2'b11: pixel_in=pix3; endcase

    // delay coordinates 1 clock to align with pixel_in
    reg [6:0] x_d; reg [5:0] y_d;
    always @(posedge clk) begin x_d<=x; y_d<=y; end

    // 3) line buffer -> 3x3 window
    wire win_valid;
    wire [7:0] w00,w01,w02,w10,w11,w12,w20,w21,w22;
    line_buffer_3x3 #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_lb (
        .clk(clk), .rst(rst), .pixel_in(pixel_in), .pixel_valid(1'b1),
        .x(x_d), .y(y_d), .win_valid(win_valid),
        .w00(w00),.w01(w01),.w02(w02),.w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22));

    // 4) INT8 convolution
    wire conv_valid; wire signed [31:0] conv0,conv1,conv2,conv3;
    conv3x3_4filter_int8 #(.WFILE(WFILE), .BFILE(BFILE)) u_conv (
        .clk(clk), .rst(rst), .win_valid(win_valid),
        .w00(w00),.w01(w01),.w02(w02),.w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22),
        .conv_valid(conv_valid), .conv0(conv0),.conv1(conv1),.conv2(conv2),.conv3(conv3));

    // 5) shift + ReLU (no saturation)
    wire relu_valid; wire signed [15:0] relu0,relu1,relu2,relu3;
    requant_relu_4f #(.SHIFT_CONV(SHIFT_CONV)) u_rq (
        .clk(clk), .rst(rst), .conv_valid(conv_valid),
        .conv0(conv0),.conv1(conv1),.conv2(conv2),.conv3(conv3),
        .relu_valid(relu_valid),
        .relu0(relu0),.relu1(relu1),.relu2(relu2),.relu3(relu3));

    // frame-start marker: based on pixel_in (=x_d,y_d) -> delayed 2 clocks (conv+requant)
    wire fs_p = (x_d==7'd0) && (y_d==6'd0);
    reg [1:0] fs_pipe;
    always @(posedge clk) begin
        if (rst) fs_pipe <= 2'b0;
        else     fs_pipe <= {fs_pipe[0], fs_p};
    end
    wire frame_start_a = fs_pipe[1];

    // 6) WTA + feature accumulation + Argmax
    wire signed [31:0] feat0,feat1,feat2,feat3;
    wire [1:0] class_idx; wire class_valid;
    wta_feat_argmax_4f u_wta (
        .clk(clk), .rst(rst), .relu_valid(relu_valid),
        .frame_start_a(frame_start_a),
        .relu0(relu0),.relu1(relu1),.relu2(relu2),.relu3(relu3),
        .feat0(feat0),.feat1(feat1),.feat2(feat2),.feat3(feat3),
        .class_idx(class_idx), .class_valid(class_valid));

    // 7) LED one-hot
    assign LD2 = (class_idx==2'd0);
    assign LD3 = (class_idx==2'd1);
    assign LD4 = (class_idx==2'd2);
    assign LD5 = (class_idx==2'd3);
endmodule
