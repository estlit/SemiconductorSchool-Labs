`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// line_buffer_3x3 : 1 pixel/clock streaming -> 3x3 window (combinational out)
//   Three row buffers (r_top=y-2, r_mid=y-1, r_cur=y), rotated at row start (x==0).
//   Window center = (y-1, x-1); win_valid = pixel_valid & y>=2 & x>=2.
//   Combinational window -> clean column alignment (no shift-register skew),
//   giving a 1:1 match with the Python golden model.
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module line_buffer_3x3 #(
    parameter IMG_W = 96,
    parameter IMG_H = 64
)(
    input  wire       clk,
    input  wire       rst,
    input  wire [7:0] pixel_in,
    input  wire       pixel_valid,
    input  wire [6:0] x,
    input  wire [5:0] y,
    output wire       win_valid,
    output wire [7:0] w00, w01, w02,
    output wire [7:0] w10, w11, w12,
    output wire [7:0] w20, w21, w22
);
    integer i;
    reg [7:0] r_top [0:IMG_W-1];   // y-2
    reg [7:0] r_mid [0:IMG_W-1];   // y-1
    reg [7:0] r_cur [0:IMG_W-1];   // y (current)

    always @(posedge clk) begin
        if (pixel_valid) begin
            // Rotate at the start of a new row (previous row just completed)
            if (x == 7'd0 && y != 6'd0) begin
                for (i=0;i<IMG_W;i=i+1) begin
                    r_top[i] <= r_mid[i];
                    r_mid[i] <= r_cur[i];
                end
            end
            r_cur[x] <= pixel_in;    // fill the current row
        end
    end

    // Combinational window (cols: x-2,x-1,x / rows: y-2,y-1,y)
    assign win_valid = pixel_valid && (y >= 6'd2) && (x >= 7'd2);
    assign w00 = r_top[x-2]; assign w01 = r_top[x-1]; assign w02 = r_top[x];
    assign w10 = r_mid[x-2]; assign w11 = r_mid[x-1]; assign w12 = r_mid[x];
    assign w20 = r_cur[x-2]; assign w21 = r_cur[x-1]; assign w22 = pixel_in;
endmodule
