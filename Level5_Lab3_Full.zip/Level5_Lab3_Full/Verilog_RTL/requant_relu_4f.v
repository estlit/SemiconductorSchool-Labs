`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// requant_relu_4f : arithmetic right shift -> keep signed 16-bit -> ReLU
//   NOTE: no INT8 saturation (Lab 3 spec).
//   output relu0..3 : signed [15:0] (0..32767 after ReLU), relu_valid (1-clock registered)
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module requant_relu_4f #(
    parameter SHIFT_CONV = 4
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        conv_valid,
    input  wire signed [31:0] conv0, conv1, conv2, conv3,
    output reg         relu_valid,
    output reg signed [15:0] relu0, relu1, relu2, relu3
);
    // arithmetic shift, then keep the low 16 bits (signed)
    wire signed [31:0] s0 = conv0 >>> SHIFT_CONV;
    wire signed [31:0] s1 = conv1 >>> SHIFT_CONV;
    wire signed [31:0] s2 = conv2 >>> SHIFT_CONV;
    wire signed [31:0] s3 = conv3 >>> SHIFT_CONV;
    wire signed [15:0] q0 = s0[15:0];
    wire signed [15:0] q1 = s1[15:0];
    wire signed [15:0] q2 = s2[15:0];
    wire signed [15:0] q3 = s3[15:0];
    always @(posedge clk) begin
        if (rst) begin
            relu_valid<=1'b0; relu0<=0; relu1<=0; relu2<=0; relu3<=0;
        end else begin
            relu_valid <= conv_valid;
            relu0 <= (q0 > 0) ? q0 : 16'sd0;
            relu1 <= (q1 > 0) ? q1 : 16'sd0;
            relu2 <= (q2 > 0) ? q2 : 16'sd0;
            relu3 <= (q3 > 0) ? q3 : 16'sd0;
        end
    end
endmodule
