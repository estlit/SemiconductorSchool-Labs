///////////////////////////////////////////////////////////////////////////

/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_test (Level 4 - windowed / line-buffer streaming)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Description  : SSD1331 96x64 FSM. Level 3 init/window/refresh KEPT intact.
 *                Level 4 additions:
 *                  - rom_data is now RAW RGB565 (processing moved inside)
 *                  - internal pipeline: rgb565_to_gray -> line_buffer ->
 *                    conv_proc_core -> saturate(in core) -> border -> rgb565
 *                  - READ pointer (rom_addr) LEADS the WRITE pointer by
 *                    LEAD = H_RES + 1 = 97   (line-buffer center latency)
 *                  - ST_PRIME: fill the line buffer LEAD times before display
 *                  - px565_r latched once per output pixel (HI/LO consistent)
 *                  - frame-edge fetch >= TOTAL_PIX feeds 0 (bottom border black)
 *
 * IMPORTANT: OLED write address = WRITE pointer (pix_index), NOT the read
 * (fetch) pointer. Mixing these shifts the whole image by LEAD pixels.
 * ====================================================================== */
`timescale 1ns / 1ps

module oled_test #(
    parameter H_RES = 96,
    parameter V_RES = 64,
    parameter POWER_WAIT = 24'd2000000,  // shrink in simulation
    parameter RESET_WAIT = 24'd500000    // shrink in simulation
)(
    input  wire        clk,
    input  wire        reset,

    // SPI Master Interface
    output reg         spi_start,
    output reg  [7:0]  spi_data,
    input  wire        spi_busy,

    // SSD1331 Physical Control
    output reg         oled_dc,
    output reg         oled_res,
    output reg         oled_vccen,
    output reg         oled_pmoden,

    // ROM Interface (now RAW RGB565)
    output reg  [12:0] rom_addr,
    input  wire [15:0] rom_data,

    // Level 4: filter mode (sw[3:1])
    input  wire [2:0]  mode
);
    // ------------------------------------------------------------------
    // FSM states
    // ------------------------------------------------------------------
    localparam ST_POWER_ON      = 5'd0;
    localparam ST_RESET_RELEASE = 5'd1;
    localparam ST_INIT_SEND     = 5'd2;
    localparam ST_SET_WINDOW    = 5'd3;
    localparam ST_PRIME_FETCH   = 5'd4;
    localparam ST_PRIME_WAIT    = 5'd5;
    localparam ST_PRIME_PUSH    = 5'd6;
    localparam ST_PIX_FETCH     = 5'd7;
    localparam ST_PIX_WAIT      = 5'd8;
    localparam ST_PIX_PUSH      = 5'd9;
    localparam ST_PIX_LATCH     = 5'd10;
    localparam ST_SEND_PIX_HI   = 5'd11;
    localparam ST_SEND_PIX_LO   = 5'd12;
    localparam ST_WAIT_SPI      = 5'd13;
    localparam ST_DONE          = 5'd14;

    reg [4:0]  state;
    reg [4:0]  prev_state;
    reg [23:0] wait_cnt;

    
    localparam integer INIT_LEN   = 45;
    localparam integer WIN_LEN    = 7;
    localparam integer TOTAL_PIX  = H_RES * V_RES;   // 6144
    localparam integer LEAD       = H_RES + 1;       // 97  (line-buffer center latency)

    reg [5:0]  init_index;
    reg [2:0]  win_index;

    reg [15:0] pix_index;    // WRITE pointer (output coordinate / OLED raster)
    reg [7:0]  x_cnt;        // pix_index % H_RES
    reg [7:0]  y_cnt;        // pix_index / H_RES
    reg [15:0] prime_cnt;    // 0..LEAD-1
    reg        feed_zero;    // push 0 when fetch >= TOTAL_PIX
    reg [15:0] px565_r;      // latched processed pixel (RGB565)

    // ------------------------------------------------------------------
    // Processing pipeline (combinational except the line buffer)
    // ------------------------------------------------------------------
    wire [7:0] gray;
    rgb565_to_gray u_gray (.pixel_in(rom_data), .gray_out(gray));

    wire [7:0] lb_data = feed_zero ? 8'd0 : gray;
    wire       shift_en = (state == ST_PRIME_PUSH) || (state == ST_PIX_PUSH);

    wire [7:0] w00,w01,w02,w10,w11,w12,w20,w21,w22;
    line_buffer_module #(.IMAGE_WIDTH(H_RES)) u_lb (
        .clk(clk), .reset(reset), .shift_en(shift_en), .data_in(lb_data),
        .w00(w00),.w01(w01),.w02(w02),
        .w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22)
    );

    wire [7:0] conv_out;
    conv_proc_core u_conv (
        .mode(mode),
        .w00(w00),.w01(w01),.w02(w02),
        .w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22),
        .out8(conv_out)
    );

    // Border (valid-only). Interior = [1..H_RES-2] x [1..V_RES-2], else 0.
    wire valid_px = (x_cnt >= 8'd1) && (x_cnt <= (H_RES-2)) &&
                    (y_cnt >= 8'd1) && (y_cnt <= (V_RES-2));
    wire [7:0]  masked   = valid_px ? conv_out : 8'd0;
    // Gray -> RGB565 (replicate)
    wire [15:0] px565_nx = { masked[7:3], masked[7:2], masked[7:3] };

    // ------------------------------------------------------------------
    // SSD1331 init sequence (45 bytes) - identical to Level 3
    // ------------------------------------------------------------------
    function [7:0] init_byte (input [5:0] idx);
        begin
            case (idx)
                6'd0:  init_byte=8'hFD; 6'd1:  init_byte=8'h12; 6'd2:  init_byte=8'hAE;
                6'd3:  init_byte=8'h75; 6'd4:  init_byte=8'h00; 6'd5:  init_byte=8'h3F;
                6'd6:  init_byte=8'h15; 6'd7:  init_byte=8'h00; 6'd8:  init_byte=8'h5F;
                6'd9:  init_byte=8'hA0; 6'd10: init_byte=8'h72; 6'd11: init_byte=8'hA1;
                6'd12: init_byte=8'h00; 6'd13: init_byte=8'hA2; 6'd14: init_byte=8'h00;
                6'd15: init_byte=8'hA4; 6'd16: init_byte=8'hA8; 6'd17: init_byte=8'h3F;
                6'd18: init_byte=8'hAD; 6'd19: init_byte=8'h8F; 6'd20: init_byte=8'hB0;
                6'd21: init_byte=8'h1A; 6'd22: init_byte=8'hB1; 6'd23: init_byte=8'h74;
                6'd24: init_byte=8'hB3; 6'd25: init_byte=8'hD0; 6'd26: init_byte=8'h8A;
                6'd27: init_byte=8'h81; 6'd28: init_byte=8'h8B; 6'd29: init_byte=8'h82;
                6'd30: init_byte=8'h8C; 6'd31: init_byte=8'h83; 6'd32: init_byte=8'hBB;
                6'd33: init_byte=8'h3E; 6'd34: init_byte=8'hBE; 6'd35: init_byte=8'h3E;
                6'd36: init_byte=8'h87; 6'd37: init_byte=8'h0F; 6'd38: init_byte=8'h81;
                6'd39: init_byte=8'h80; 6'd40: init_byte=8'h82; 6'd41: init_byte=8'h80;
                6'd42: init_byte=8'h83; 6'd43: init_byte=8'h80; 6'd44: init_byte=8'hAF;
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    // Window (0,0)-(95,63) + Write-RAM - identical to Level 3
    function [7:0] win_byte (input [2:0] idx);
        begin
            case (idx)
                3'd0: win_byte=8'h15; 3'd1: win_byte=8'h00; 3'd2: win_byte=8'h5F;
                3'd3: win_byte=8'h75; 3'd4: win_byte=8'h00; 3'd5: win_byte=8'h3F;
                3'd6: win_byte=8'h5C;
                default: win_byte = 8'h00;
            endcase
        end
    endfunction

    // ------------------------------------------------------------------
    // Main FSM
    // ------------------------------------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state       <= ST_POWER_ON;
            prev_state  <= ST_POWER_ON;
            wait_cnt    <= 24'd0;
            init_index  <= 6'd0;
            win_index   <= 3'd0;
            spi_start   <= 1'b0;
            spi_data    <= 8'd0;
            rom_addr    <= 13'd0;
            pix_index   <= 16'd0;
            x_cnt       <= 8'd0;
            y_cnt       <= 8'd0;
            prime_cnt   <= 16'd0;
            feed_zero   <= 1'b0;
            px565_r     <= 16'd0;
            oled_dc     <= 1'b0;
            oled_res    <= 1'b0;
            oled_vccen  <= 1'b0;
            oled_pmoden <= 1'b0;
        end else begin
            spi_start <= 1'b0;  // default de-assert

            case (state)
                // ---- Power / reset / init : Level 3 ----
                ST_POWER_ON: begin
                    oled_vccen <= 1'b1; oled_pmoden <= 1'b1; oled_res <= 1'b0;
                    wait_cnt <= wait_cnt + 1'b1;
                    if (wait_cnt == POWER_WAIT) begin
                        wait_cnt <= 24'd0; state <= ST_RESET_RELEASE;
                    end
                end
                ST_RESET_RELEASE: begin
                    oled_res <= 1'b1;
                    wait_cnt <= wait_cnt + 1'b1;
                    if (wait_cnt == RESET_WAIT) begin
                        wait_cnt <= 24'd0; init_index <= 6'd0; state <= ST_INIT_SEND;
                    end
                end
                ST_INIT_SEND: begin
                    if (!spi_busy) begin
                        oled_dc <= 1'b0; spi_data <= init_byte(init_index);
                        spi_start <= 1'b1; prev_state <= ST_INIT_SEND; state <= ST_WAIT_SPI;
                    end
                end
                ST_SET_WINDOW: begin
                    if (!spi_busy) begin
                        oled_dc <= 1'b0; spi_data <= win_byte(win_index);
                        spi_start <= 1'b1; prev_state <= ST_SET_WINDOW; state <= ST_WAIT_SPI;
                    end
                end

                // ---- PRIME : fill line buffer LEAD times (no display) ----
                ST_PRIME_FETCH: begin
                    rom_addr  <= prime_cnt[12:0];  // pixels 0..LEAD-1
                    feed_zero <= 1'b0;
                    state     <= ST_PRIME_WAIT;
                end
                ST_PRIME_WAIT: begin               // ROM synchronous read latency
                    state <= ST_PRIME_PUSH;
                end
                ST_PRIME_PUSH: begin               // shift_en asserted (comb) this cycle
                    if (prime_cnt == (LEAD-1)) begin
                        pix_index <= 16'd0; x_cnt <= 8'd0; y_cnt <= 8'd0;
                        state <= ST_PIX_FETCH;
                    end else begin
                        prime_cnt <= prime_cnt + 1'b1;
                        state     <= ST_PRIME_FETCH;
                    end
                end

                // ---- Per output pixel : fetch(read=write+LEAD) -> push -> latch -> send ----
                ST_PIX_FETCH: begin
                    if ((pix_index + LEAD) < TOTAL_PIX) begin
                        rom_addr  <= (pix_index + LEAD);
                        feed_zero <= 1'b0;
                    end else begin
                        feed_zero <= 1'b1;         // beyond image -> push 0
                    end
                    state <= ST_PIX_WAIT;
                end
                ST_PIX_WAIT: begin                 // ROM latency
                    state <= ST_PIX_PUSH;
                end
                ST_PIX_PUSH: begin                 // shift_en asserted (comb); window now centers on pix_index
                    state <= ST_PIX_LATCH;
                end
                ST_PIX_LATCH: begin                // latch processed pixel (stable for HI+LO)
                    px565_r <= px565_nx;
                    state   <= ST_SEND_PIX_HI;
                end

                ST_SEND_PIX_HI: begin
                    if (!spi_busy) begin
                        oled_dc <= 1'b1; spi_data <= px565_r[15:8];
                        spi_start <= 1'b1; prev_state <= ST_SEND_PIX_HI; state <= ST_WAIT_SPI;
                    end
                end
                ST_SEND_PIX_LO: begin
                    if (!spi_busy) begin
                        oled_dc <= 1'b1; spi_data <= px565_r[7:0];
                        spi_start <= 1'b1; prev_state <= ST_SEND_PIX_LO; state <= ST_WAIT_SPI;
                    end
                end

                // ---- shared SPI wait / sequencing ----
                ST_WAIT_SPI: begin
                    case (prev_state)
                        ST_INIT_SEND: begin
                            if (init_index < INIT_LEN-1) begin
                                init_index <= init_index + 1'b1; state <= ST_INIT_SEND;
                            end else state <= ST_SET_WINDOW;
                        end
                        ST_SET_WINDOW: begin
                            if (win_index < WIN_LEN-1) begin
                                win_index <= win_index + 1'b1; state <= ST_SET_WINDOW;
                            end else begin
                                prime_cnt <= 16'd0; state <= ST_PRIME_FETCH;  // -> re-prime each frame
                            end
                        end
                        ST_SEND_PIX_HI: state <= ST_SEND_PIX_LO;
                        ST_SEND_PIX_LO: begin
                            if (pix_index == (TOTAL_PIX-1)) begin
                                state <= ST_DONE;
                            end else begin
                                pix_index <= pix_index + 1'b1;
                                // maintain x/y counters for the WRITE pixel
                                if (x_cnt == (H_RES-1)) begin
                                    x_cnt <= 8'd0; y_cnt <= y_cnt + 1'b1;
                                end else x_cnt <= x_cnt + 1'b1;
                                state <= ST_PIX_FETCH;
                            end
                        end
                        default: state <= ST_POWER_ON;
                    endcase
                end

                // ---- frame done -> refresh (re-window, re-prime) ----
                ST_DONE: begin
                    pix_index <= 16'd0; win_index <= 3'd0;
                    x_cnt <= 8'd0; y_cnt <= 8'd0; prime_cnt <= 16'd0;
                    state <= ST_SET_WINDOW;
                end

                default: state <= ST_POWER_ON;
            endcase
        end
    end
endmodule


