`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// wta_feat_argmax_4f : Hard-WTA (per-position winner) -> feature accumulate -> frame Argmax
//   At frame reset (frame_start_a: start of the NEXT frame) the completed
//   accumulation fs of the previous frame is latched, so the last corner
//   window is included (no boundary drop).
//   Ties resolve to the lower index ('>' compare). feat_sum is signed 32-bit.
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module wta_feat_argmax_4f (
    input  wire        clk,
    input  wire        rst,
    input  wire        relu_valid,
    input  wire        frame_start_a,
    input  wire signed [15:0] relu0, relu1, relu2, relu3,
    output reg  signed [31:0] feat0, feat1, feat2, feat3,
    output reg  [1:0]  class_idx,
    output reg         class_valid
);
    // Per-position Hard-WTA (combinational)
    reg signed [15:0] wval; reg [1:0] widx;
    always @(*) begin
        wval = relu0; widx = 2'd0;
        if (relu1 > wval) begin wval = relu1; widx = 2'd1; end
        if (relu2 > wval) begin wval = relu2; widx = 2'd2; end
        if (relu3 > wval) begin wval = relu3; widx = 2'd3; end
    end
    // Argmax over the accumulated sums fs (combinational, tie -> lower index)
    reg signed [31:0] fs0, fs1, fs2, fs3;
    reg signed [31:0] mx; reg [1:0] mi;
    always @(*) begin
        mx = fs0; mi = 2'd0;
        if (fs1 > mx) begin mx = fs1; mi = 2'd1; end
        if (fs2 > mx) begin mx = fs2; mi = 2'd2; end
        if (fs3 > mx) begin mx = fs3; mi = 2'd3; end
    end
    // Accumulate / latch
    always @(posedge clk) begin
        if (rst) begin
            fs0<=0; fs1<=0; fs2<=0; fs3<=0;
            feat0<=0; feat1<=0; feat2<=0; feat3<=0;
            class_idx<=2'd0; class_valid<=1'b0;
        end else begin
            if (frame_start_a) begin
                // Latch + decide the previous frame's completed accumulation, then reset
                feat0<=fs0; feat1<=fs1; feat2<=fs2; feat3<=fs3;
                class_idx<=mi; class_valid<=1'b1;
                fs0<=0; fs1<=0; fs2<=0; fs3<=0;
            end else begin
                class_valid<=1'b0;
                if (relu_valid) begin
                    case (widx)
                        2'd0: fs0 <= fs0 + wval;
                        2'd1: fs1 <= fs1 + wval;
                        2'd2: fs2 <= fs2 + wval;
                        2'd3: fs3 <= fs3 + wval;
                    endcase
                end
            end
        end
    end
endmodule
