///////////////////////////////////////////////////////////////////////////

/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : oled_gray_rom_rgb565 (OLED-path image ROM)
 * Target Board : Digilent Arty S7 (Xilinx Spartan-7)
 * Architecture : 4x grayscale BROM (img_brom) + select mux + RGB565 pack
 * Description  : Display-path image source for the OLED. Instantiates four
 *                independent img_brom copies that read the SAME grayscale
 *                .mem originals as the classifier (one image source, separate
 *                memory instances), selects one by 'sel' = {SW1,SW0}, and
 *                packs the 8-bit luma into RGB565 by MSB replication so the
 *                data matches the interface expected by oled_test:
 *                  0x00 -> 0x0000 (black), 0xFF -> 0xFFFF (white).
 *                Read latency is one clock (from img_brom), identical to the
 *                original oled_combined_rom, so oled_test timing is unchanged.
 * ====================================================================== */

`timescale 1ns / 1ps

module oled_gray_rom_rgb565 #(
    parameter integer ADDR_W = 13,
    parameter integer DEPTH  = 6144,
    parameter I0 = "img0.mem", parameter I1 = "img1.mem",
    parameter I2 = "img2.mem", parameter I3 = "img3.mem"
)(
    input  wire              clk,
    input  wire [ADDR_W-1:0] addr,
    input  wire [1:0]        sel,   // {SW1,SW0}, synchronized to this clock
    output wire [15:0]       data   // RGB565, 1-clock latency
);
    // Four independent grayscale ROMs, same .mem originals as the classifier.
    wire [7:0] g0, g1, g2, g3;

    img_brom #(.ADDR_W(ADDR_W), .DEPTH(DEPTH), .MEM_FILE(I0))
        u_g0 (.clk(clk), .addr(addr), .dout(g0));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(DEPTH), .MEM_FILE(I1))
        u_g1 (.clk(clk), .addr(addr), .dout(g1));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(DEPTH), .MEM_FILE(I2))
        u_g2 (.clk(clk), .addr(addr), .dout(g2));
    img_brom #(.ADDR_W(ADDR_W), .DEPTH(DEPTH), .MEM_FILE(I3))
        u_g3 (.clk(clk), .addr(addr), .dout(g3));

    // Select one image (registered ROM outputs -> combinational mux).
    reg [7:0] gy;
    always @(*) begin
        case (sel)
            2'b00:   gy = g0;
            2'b01:   gy = g1;
            2'b10:   gy = g2;
            2'b11:   gy = g3;
            default: gy = g0;
        endcase
    end

    // 8-bit luma -> RGB565 by MSB replication (lossless for 0x00 / 0xFF).
    assign data = { gy[7:3], gy[7:2], gy[7:3] };

endmodule


