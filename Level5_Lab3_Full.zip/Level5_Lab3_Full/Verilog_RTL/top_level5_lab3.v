`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// top_level5_lab3 : [Project B - learned-weight board top]
//   Functionally identical to Lab 1 (OLED input display + LED classification),
//   with the classifier datapath replaced by the learned-weight INT8 + requant path.
//   - A) 12 MHz classifier : top_level5_lab3_classifier (INT8 conv -> requant -> WTA -> LED)
//        learned conv_weight/bias.mem (absolute path), SHIFT_CONV=8
//   - B) 100 MHz OLED      : same as Lab 1 (displays input image img0..3 on the OLED)
//   OLED image reuses the same img0..3.mem as the classifier.
//   Path: D:/Arty_home/lab2_output/fpga_mem/  (Lab2_02 output)
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module top_level5_lab3 #(
    parameter POWER_WAIT = 24'd2000000,
    parameter RESET_WAIT = 24'd500000,
    parameter W = "D:/Arty_home/training/lab2_output/fpga_mem/conv_weight.mem",
    parameter B = "D:/Arty_home/training/lab2_output/fpga_mem/conv_bias.mem",
    parameter M0 = "D:/Arty_home/training/lab2_output/fpga_mem/img0.mem",
    parameter M1 = "D:/Arty_home/training/lab2_output/fpga_mem/img1.mem",
    parameter M2 = "D:/Arty_home/training/lab2_output/fpga_mem/img2.mem",
    parameter M3 = "D:/Arty_home/training/lab2_output/fpga_mem/img3.mem"
)(
    input  wire CLK12MHZ,     // F14, 12 MHz  (classifier domain)
    input  wire CLK100MHZ,    // R2, 100 MHz  (OLED domain)
    input  wire BTN0,         // G15, active-high reset
    input  wire SW0,          // H14, image select bit 0
    input  wire SW1,          // H18, image select bit 1
    output wire LD2,          // E18, class 0 (horizontal)
    output wire LD3,          // F13, class 1 (vertical)
    output wire LD4,          // E13, class 2 ('/')
    output wire LD5,          // H15, class 3 ('\')
    output wire oled_cs_n, output wire oled_mosi, output wire oled_sck,
    output wire oled_dc, output wire oled_res, output wire oled_vccen, output wire oled_pmoden
);
    wire reset = BTN0;

    //================================================================
    // A) 12 MHz classifier domain - learned-weight INT8 classifier
    //================================================================
    reg [1:0] sw0_c, sw1_c;
    always @(posedge CLK12MHZ) begin
        sw0_c <= {sw0_c[0], SW0};
        sw1_c <= {sw1_c[0], SW1};
    end

    top_level5_lab3_classifier #(
        .SHIFT_CONV(8),
        .I0(M0), .I1(M1), .I2(M2), .I3(M3),
        .WFILE(W), .BFILE(B)
    ) u_cls (
        .clk(CLK12MHZ), .rst(BTN0),
        .SW0(sw0_c[1]), .SW1(sw1_c[1]),
        .LD2(LD2), .LD3(LD3), .LD4(LD4), .LD5(LD5)
    );

    //================================================================
    // B) 100 MHz OLED domain - same as Lab 1 (display input image)
    //================================================================
    reg [3:0] div_cnt;
    always @(posedge CLK100MHZ or posedge reset) begin
        if (reset) div_cnt <= 4'd0;
        else       div_cnt <= div_cnt + 1'b1;
    end
    wire spi_clk = div_cnt[3];

    reg [1:0] sw0_o, sw1_o;
    always @(posedge spi_clk) begin
        sw0_o <= {sw0_o[0], SW0};
        sw1_o <= {sw1_o[0], SW1};
    end
    wire [1:0] oled_sel = {sw1_o[1], sw0_o[1]};

    wire [12:0] oled_pix_addr;
    wire [15:0] rom_data;
    oled_gray_rom_rgb565 #(.ADDR_W(13), .DEPTH(6144),
                           .I0(M0), .I1(M1), .I2(M2), .I3(M3)) u_orom (
        .clk(spi_clk), .addr(oled_pix_addr), .sel(oled_sel), .data(rom_data));

    wire spi_start, spi_busy; wire [7:0] spi_data;
    spi_master u_spi (
        .clk(spi_clk), .reset(reset),
        .start(spi_start), .data_in(spi_data), .busy(spi_busy),
        .sclk(oled_sck), .mosi(oled_mosi), .cs_n(oled_cs_n));

    oled_test #(.H_RES(96), .V_RES(64),
                .POWER_WAIT(POWER_WAIT), .RESET_WAIT(RESET_WAIT)) u_oled (
        .clk(spi_clk), .reset(reset),
        .spi_start(spi_start), .spi_data(spi_data), .spi_busy(spi_busy),
        .oled_dc(oled_dc), .oled_res(oled_res),
        .oled_vccen(oled_vccen), .oled_pmoden(oled_pmoden),
        .rom_addr(oled_pix_addr), .rom_data(rom_data), .mode(3'd0));
endmodule
