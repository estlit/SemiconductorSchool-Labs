`timescale 1ns/1ps
// Semiconductor School  |  Copyright (c) 2026 Roger Kim & EdgeChipLab.
// =============================================================
// top_mass_classifier : classify many augmented images streamed sequentially
//   big ROM(N_IMG x 6144) -> line_buffer -> conv(INT8) -> requant/ReLU -> WTA
//   each image is streamed for K frames; feat/class latched at frame reset.
//   ended_frame_img = image index of the just-finished frame (latch alignment).
// =============================================================
module top_mass_classifier #(
    parameter IMG_W = 96, parameter IMG_H = 64, parameter K = 3,
    parameter N_IMG = 128, parameter SHIFT_CONV = 8
)(
    input  wire clk, input wire rst,
    output wire [1:0] class_idx, output wire class_valid,
    output wire signed [31:0] feat0, feat1, feat2, feat3,
    output reg  [7:0] ended_frame_img,
    output reg  [7:0] img
);
    localparam NP = IMG_W*IMG_H;

    reg [7:0] mem [0:N_IMG*NP-1];
    initial $readmemh("D:/Arty_home/training/lab2_output/mass/mass_images.mem", mem);

    reg [1:0] frame; reg [12:0] pix; reg [6:0] x; reg [5:0] y;
    wire [7:0] rom_img = (img < N_IMG) ? img : 8'd0;
    wire new_frame = (pix == NP-1);

    // pixel ROM (1 clock)
    reg [7:0] pixel_in;
    always @(posedge clk) pixel_in <= mem[rom_img*NP + pix];

    // counters
    always @(posedge clk) begin
        if (rst) begin img<=0; frame<=0; pix<=0; x<=0; y<=0; ended_frame_img<=0; end
        else begin
            if (new_frame) begin
                pix<=0; x<=0; y<=0;
                ended_frame_img <= img;               // image of the just-finished frame
                if (frame==K-1) begin frame<=0; img<=img+1; end
                else frame<=frame+1;
            end else begin
                pix<=pix+1;
                if (x==IMG_W-1) begin x<=0; y<=y+1; end else x<=x+1;
            end
        end
    end

    // delay coords 1 clock (pixel alignment)
    reg [6:0] x_d; reg [5:0] y_d;
    always @(posedge clk) begin x_d<=x; y_d<=y; end

    // frame-start marker delayed 2 clocks -> relu alignment
    wire fs_p = (x_d==7'd0) && (y_d==6'd0);
    reg [1:0] fs_pipe;
    always @(posedge clk) fs_pipe <= rst ? 2'b0 : {fs_pipe[0], fs_p};
    wire frame_start_a = fs_pipe[1];

    wire win_valid;
    wire [7:0] w00,w01,w02,w10,w11,w12,w20,w21,w22;
    line_buffer_3x3 #(.IMG_W(IMG_W), .IMG_H(IMG_H)) u_lb (
        .clk(clk), .rst(rst), .pixel_in(pixel_in), .pixel_valid(1'b1),
        .x(x_d), .y(y_d), .win_valid(win_valid),
        .w00(w00),.w01(w01),.w02(w02),.w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22));

    wire conv_valid; wire signed [31:0] conv0,conv1,conv2,conv3;
    conv3x3_4filter_int8 #(.WFILE("D:/Arty_home/training/lab2_output/fpga_mem/conv_weight.mem"), .BFILE("D:/Arty_home/training/lab2_output/fpga_mem/conv_bias.mem")) u_conv (
        .clk(clk), .rst(rst), .win_valid(win_valid),
        .w00(w00),.w01(w01),.w02(w02),.w10(w10),.w11(w11),.w12(w12),
        .w20(w20),.w21(w21),.w22(w22),
        .conv_valid(conv_valid), .conv0(conv0),.conv1(conv1),.conv2(conv2),.conv3(conv3));

    wire relu_valid; wire signed [15:0] relu0,relu1,relu2,relu3;
    requant_relu_4f #(.SHIFT_CONV(SHIFT_CONV)) u_rq (
        .clk(clk), .rst(rst), .conv_valid(conv_valid),
        .conv0(conv0),.conv1(conv1),.conv2(conv2),.conv3(conv3),
        .relu_valid(relu_valid), .relu0(relu0),.relu1(relu1),.relu2(relu2),.relu3(relu3));

    wta_feat_argmax_4f u_wta (
        .clk(clk), .rst(rst), .relu_valid(relu_valid), .frame_start_a(frame_start_a),
        .relu0(relu0),.relu1(relu1),.relu2(relu2),.relu3(relu3),
        .feat0(feat0),.feat1(feat1),.feat2(feat2),.feat3(feat3),
        .class_idx(class_idx), .class_valid(class_valid));
endmodule
