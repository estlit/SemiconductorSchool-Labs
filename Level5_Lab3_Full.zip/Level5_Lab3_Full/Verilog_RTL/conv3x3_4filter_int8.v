`timescale 1ns/1ps
// =============================================================
// Semiconductor School
// conv3x3_4filter_int8 : Learned INT8 4-filter convolution + bias
//   weight : signed INT8 (conv_weight.mem, 8-bit, filter-major addr=f*9+r*3+c)
//   bias   : signed INT32 (conv_bias.mem, 32-bit)
//   pixel  : uint8 -> {1'b0,pixel} = 9-bit signed (always positive)
//   acc    : signed 32-bit
//   output : conv0..3 (signed 32-bit) + conv_valid  (1-clock registered)
// Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
// =============================================================
module conv3x3_4filter_int8 #(
    parameter WFILE = "conv_weight.mem",
    parameter BFILE = "conv_bias.mem"
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        win_valid,
    input  wire [7:0]  w00,w01,w02,w10,w11,w12,w20,w21,w22,
    output reg         conv_valid,
    output reg signed [31:0] conv0, conv1, conv2, conv3
);
    reg signed [7:0]  wgt [0:35];    // 4x9 INT8
    reg signed [31:0] bia [0:3];     // 4  INT32
    initial begin $readmemh(WFILE, wgt); $readmemh(BFILE, bia); end

    // 9-bit signed pixel (uint8 zero-extended)
    wire signed [8:0] p [0:8];
    assign p[0]=$signed({1'b0,w00}); assign p[1]=$signed({1'b0,w01}); assign p[2]=$signed({1'b0,w02});
    assign p[3]=$signed({1'b0,w10}); assign p[4]=$signed({1'b0,w11}); assign p[5]=$signed({1'b0,w12});
    assign p[6]=$signed({1'b0,w20}); assign p[7]=$signed({1'b0,w21}); assign p[8]=$signed({1'b0,w22});

    integer k;
    reg signed [31:0] acc0, acc1, acc2, acc3;
    always @(posedge clk) begin
        if (rst) begin
            conv_valid<=1'b0; conv0<=0; conv1<=0; conv2<=0; conv3<=0;
        end else begin
            conv_valid <= win_valid;
            if (win_valid) begin
                acc0 = bia[0]; acc1 = bia[1]; acc2 = bia[2]; acc3 = bia[3];
                for (k=0;k<9;k=k+1) begin
                    acc0 = acc0 + p[k]*wgt[0*9+k];
                    acc1 = acc1 + p[k]*wgt[1*9+k];
                    acc2 = acc2 + p[k]*wgt[2*9+k];
                    acc3 = acc3 + p[k]*wgt[3*9+k];
                end
                conv0<=acc0; conv1<=acc1; conv2<=acc2; conv3<=acc3;
            end
        end
    end
endmodule
