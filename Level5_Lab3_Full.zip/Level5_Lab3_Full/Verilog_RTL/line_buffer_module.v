///////////////////////////////////////////////////////////////////////////

/* ======================================================================
 * Welcome to 'Semiconductor School'
 * Copyright (c) 2026 Roger Kim & EdgeChipLab. All rights reserved.
 * Module       : line_buffer_module (Level 4)
 * Origin       : Adapted from NPU line_buffer_module (MNIST).
 * Change       : Added 'shift_en' (advance one pixel on demand, since the
 *                SPI/OLED write is much slower than 1 pixel/clock), and a
 *                FLATTENED 3x3 window output (w00..w22) for plain-Verilog use.
 *
 * Window mapping (identical taps to the NPU version):
 *   top    row : w00 w01 w02  = shift_reg[2W+2] [2W+1] [2W]
 *   middle row : w10 w11 w12  = shift_reg[W+2]  [W+1]  [W]     (w11 = CENTER)
 *   bottom row : w20 w21 w22  = shift_reg[2]    [1]    [0]     (newest)
 *
 * Border policy: none here (valid-only). Reset/zero fill only. The linear
 * shift-register's row-wrap contamination lands exactly on the discarded
 * 1-pixel border, so it is harmless (masked to 0 downstream).
 * ====================================================================== */
`timescale 1ns / 1ps

module line_buffer_module #(
    parameter IMAGE_WIDTH = 96
)(
    input  wire       clk,
    input  wire       reset,      // active-high
    input  wire       shift_en,   // advance the window by one pixel
    input  wire [7:0] data_in,    // Y8 (luma) to push
    output wire [7:0] w00, output wire [7:0] w01, output wire [7:0] w02,
    output wire [7:0] w10, output wire [7:0] w11, output wire [7:0] w12,
    output wire [7:0] w20, output wire [7:0] w21, output wire [7:0] w22
);
    // Shift register length = 2*W + 3 (indices 0 .. 2W+2)
    reg [7:0] shift_reg [0:2*IMAGE_WIDTH+2];
    integer k;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            for (k = 0; k <= 2*IMAGE_WIDTH+2; k = k + 1)
                shift_reg[k] <= 8'd0;
        end else if (shift_en) begin
            for (k = 2*IMAGE_WIDTH+2; k > 0; k = k - 1)
                shift_reg[k] <= shift_reg[k-1];
            shift_reg[0] <= data_in;
        end
    end

    // Combinational 3x3 window extraction
    assign w20 = shift_reg[2];
    assign w21 = shift_reg[1];
    assign w22 = shift_reg[0];
    assign w10 = shift_reg[IMAGE_WIDTH+2];
    assign w11 = shift_reg[IMAGE_WIDTH+1];   // CENTER
    assign w12 = shift_reg[IMAGE_WIDTH];
    assign w00 = shift_reg[2*IMAGE_WIDTH+2];
    assign w01 = shift_reg[2*IMAGE_WIDTH+1];
    assign w02 = shift_reg[2*IMAGE_WIDTH];
endmodule


